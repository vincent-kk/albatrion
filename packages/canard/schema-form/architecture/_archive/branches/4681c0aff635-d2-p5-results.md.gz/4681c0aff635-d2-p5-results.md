# D2-P5 결과 — 보류

**보류: 소유자 지시로 분기 전환 재검토 때까지**

소유자가 분기 전환은 현재 수치로 수용하고 마운트 작업을 마친 뒤 다시 검토하기로 정하여, 2026-10-27T00:54:12Z의 코디네이터 지시에서 D2-P5를 중단했습니다. 이는 속도 채택/폐기 판정이 아닙니다. 현재 DETAIL·신규 시험·진행 중인 제품 코드를 가지에 보존하며 PR은 열지 않습니다.

## 재개 위치와 현재 상태

- 가지: `perf/schema-form-d2-sibling-linear`.
- 기준: `origin/integration/schema-form-d2`, `53d49ca94cb43a70d1ccdb1cddc0cedb5d6c3047`.
- 선행 DETAIL 전용 커밋: `bda538640`(blueprint·record·settle의 계약).
- 진행분 소스/시험 커밋: `3e76eae2646ae656ef48950f5c5f72e64248ddae`. 이 문서는 별도 후속 커밋입니다.
- 기존 시험 파일의 변경과 기존 단언 변경은 모두 0건입니다.
- 현재 dist는 **기준 53d49ca94**의 빌드입니다. 후보 소스는 아직 build하지 않았으므로 현재 dist로 후보 효과를 재면 안 됩니다.
- 원자료: `<기계 로컬 임시 경로, 보존되지 않음>`. 프로파일 실행기, 명령·시각, coverage/CPU JSON, 준비된 기준 dist, 시험/타입 검사 로그를 보존했습니다.
- 보류 시점 typecheck는 **실패(exit 2, 신규 시험의 타입 오류 7건)**입니다. 신규 시험 16건은 런타임 실행에서 통과했으나 후보가 전체 검증을 마쳤다고 주장하지 않습니다.

## 1단계 프로파일

실제 창 시작은 **2026-10-27T00:27:37.597082+00:00 UTC**이며 시작 status 뒤 기준 build를 실행했습니다. Node **v26.12.1**, `NODE_ENV=production`, 기본 플래그에서 기존 `tools/helpers/setupOperation.mjs`의 `switch-siblings-{0,100,1000,4000}`을 호출했습니다. 판별자 쓰기 한 번이 연산 한 번입니다.

기준 Node dist SHA256은 `3cd015751444657797806cd582d1b5ccc6df78a2ce366cca463801c4eb3d3d4a`입니다. 예열 20회 뒤 V8 정밀 coverage 50회를 모았고, 별도 프로세스에서 CPU 200µs 간격으로 4초씩 수집했습니다. 결과 검사는 측정 구간 밖입니다. 파일:줄은 기준 소스의 선언/콜백 자리입니다.

| 함수·기준 자리 | 형제 0 호출/쓰기 | 형제 1000 호출/쓰기 | 형제당 증가 | CPU 자기시간 0/1000 µs/쓰기 | 계약/알고리즘 구분 |
|---|---:|---:|---:|---:|---|
| createStaticEntryReuser 반환 콜백, settle/utils/compute/childSelection/utils/createStaticEntryReuser.ts:59 | 4 | 2004 | 2 | 0.098 / 406.111 | 정적 발생을 prime와 selection에서 다시 확인하는 현재 알고리즘; SETTLE-044가 이 방문 횟수를 요구하지 않음 |
| primeHost, settle/utils/compute/primeHost.ts:33 | 1 | 1 | 호출 0, 내부 순회 S | 0.262 / 272.541 | 고정 baseline 의미는 계약, 맵·배열 재구성 순회는 알고리즘 |
| selectChildren, settle/utils/compute/childSelection/selectChildren.ts:43 | 1 | 1 | 호출 0, 내부 순회 S | 0.230 / 354.035 | 최종 형상/순서는 계약, prior 키 열거·전체 비교 횟수는 알고리즘 |
| getCommittedDeclarationKey, utils/controls/getCommittedDeclarationKey.ts:18 | 4 | 1004 | 1 | 0.031 / 13.728 | 불변 정적 ID의 반복 공표가 현재 알고리즘 |
| PathKeyedMap.set, utils/pathIndex/PathKeyedMap.ts:20 | 4 | 1004 | 1 | 0.048 / 30.262 | 위 공표를 위한 반복 기록, GOAL-011의 제거 대상 |
| FieldNode.path getter, surface/runtime/FieldNode.ts:205 | 90 | 6090 | 6 | 상세 JSON 참조 | 정적 발생 경로 재확인 증가분; NODE-044 수명 증명으로 준비 가능 |
| FieldNode.name getter, surface/runtime/FieldNode.ts:193 | 10 | 4010 | 4 | 상세 JSON 참조 | 같은 정적 발생 재확인 증가분 |
| assembleObject, behaviors/objectBehavior/branch/utils/assembleObject.ts:21 | 1 | 1 | 내부 필드 방문 S | 0.311 / 99.444 | 불변 호스트 값의 필요한 O(폭) 조립 비용 |
| preserveReferences children.every, settle/utils/compute/preserveReferences.ts:38 | 3 | 1003 | 1 | 부모 함수 0.030 / 4.738 | identity/order 의미는 계약, 전체 목록 재비교는 알고리즘 |

400C-03의 구분처럼 공개 값·배달·노드 identity/order가 계약이며 사적 방문 이력은 알고리즘입니다. 호출 수가 1→1인 함수도 내부에 선형 순회가 있으므로 상수 비용이라고 해석하지 않습니다.

| 형제 수 | CPU 루프 반복 수 | 루프 벽시계 ms/쓰기 |
|---:|---:|---:|
| 0 | 413862 | 0.009707 |
| 100 | 36995 | 0.108614 |
| 1000 | 2058 | 1.955147 |
| 4000 | 602 | 6.695754 |

이는 CPU 프로파일 루프의 관측값이며 최종 표준 20/100/3 통계가 아닙니다. 반복 수와 V8 최적화 진행이 크게 달라 CPU 자기 시간 귀속을 제거 가능한 시간으로 그대로 더하지 않습니다. profile-summary.json, count-*.json, cpu-*.json과 profile-commands.json에 원자료가 있습니다. 1단계 종료 때 창 종료 status를 보냈으며 보류 뒤 무거운 명령은 실행하지 않았습니다.

## 승인된 설계와 코디네이터의 두 답

첫 답은 다음 설계를 조건부 승인했습니다. 준비물은 청사진의 정적/동적 membership과 호스트 인스턴스 수명의 정적 발생 증인을 나눠 보관합니다. 청사진 부분은 순수 파생 자료이고, 인스턴스 부분은 루트 runtime의 지연 WeakMap으로 보관합니다. 노드에 칸을 추가하지 않습니다. 최초 O(S) 검증과 준비된 gated 호스트당 **O(S) 참조 보유량**을 DETAIL에 명시했습니다.

반복 wheel은 불변 정적 자식에서 출발하고 동적 엔트리를 기존 게이트 순서로 다시 고릅니다. 정적 발생의 매번 검증, 정적 선언 ID 재공표, prior 전체 키 열거와 불필요한 children 비교를 줄이는 가설입니다. 이전 동적 snapshot은 재사용과 나감 비교에만 사용합니다. gate 전수 평가, 즉시 반영, 상속 overlay와 BLUEPRINT-007 역색인 금지를 유지합니다. 현재 예측은 N1000의 0.2~0.6 ms 탐색이며 보장하지 않고, N4000의 D4 작은 상수 배 달성은 미리 주장하지 않습니다.

첫 승인에 붙은 다섯 조건은 다음과 같습니다.

1. **커밋된 객체는 제자리에서 고치지 않습니다.** 작업 structure는 커밋된 structure·children·호스트 값과 다른 사적 스크래치여야 합니다. 동적 구성원 동일성 증명으로 이전 불변 객체를 재사용하거나 새 불변 객체를 만듭니다. 전환 전 잡아 둔 참조의 내용 불변을 시험합니다.
2. 최초 답의 “게이트 예외 때 정착 전 상태와 같아야 한다”는 조항은 아래 두 번째 답으로 정정되었습니다.
3. load·reset·FormHandle.rebuild·호스트 나감/재진입(새 인스턴스)·배열 재배치·경로 변경·상속 overlay·relocated 게이트를 무효화 목록에 포함하고 각각 시험합니다.
4. 준비물을 쓰는 정착마다 정적 발생 증인을 새로 계산해 비교하는 확인을 S7과 같은 모양의 **verify 전용**으로 넣습니다. 출하 설정에서는 끕니다.
5. DETAIL에 다음 문장을 그대로 둡니다: “동적 엔트리는 매 정착에서 고정 출발점부터 기존 순서·게이트 평가로 전부 다시 고르고, 직전 동적 snapshot 은 노드 재사용과 나감 비교에만 쓴다(SETTLE-044).”

두 번째 답은 조건 2를 명시적으로 정정했습니다. 기준의 settle.error-gate-exits.test.ts 3건을 수정 없이 실행해, ERROR-125가 예외 뒤 분기를 나가게 하고 raw/derive의 부분 커밋을 유지함을 확인한 뒤 질의했습니다. 코디네이터가 다음 의미를 승인했고 449라운드 원장에서 448C-07의 예외 조항을 정정한다고 밝혔습니다.

> 예외 때의 커밋·오류·배달 의미는 기준 53d49ca94와 완전히 같고(ERROR-125 단언 변경 0), 준비물은 실패한 정착 뒤 버리거나 다음 정착에서 재검증하며, 정착 전에 커밋되어 있던 불변 structure·children·값 객체 참조의 내용은 훼손하지 않습니다.

시험은 준비된 호스트의 **게이트 오류 → 다음 정상 정착**을 기준과 후보에서 같은 결과로 비교하는 것입니다. 전체 transactional rollback을 추가하는 설계가 아닙니다.

## 보류 시점 구현과 관측

- HostStaticPartition에 순수 dynamicEntries를 추가하고, FieldNodeRuntime에 settle 소유 unknown WeakMap 칸을 지연 선언했습니다. FieldNode/노드 레코드 자체의 칸은 추가하지 않았습니다.
- hostPreparation helper들은 한 번 검증한 정적 발생, 사적 working map, 정착별 prior dynamic snapshot을 분리합니다. prime/선택/flush/presence/마감에서 정적 순회를 생략하고 마지막에 이전 구조 참조나 새 소유 구조로 봉합합니다. 사적 working map 자체를 커밋하지 않습니다.
- load, 배열 rekey, host exit/dispose 경로의 무효화와 일반 경로 fallback을 진행했습니다. 현재는 준비된 direct selection table이 있는 호스트 및 숫자 동적 이름 등은 보수적으로 일반 경로를 유지합니다.
- S8은 verify에서 발생·스키마·선언 ID를 다시 확인하고 손상 증인을 거부합니다. 현재 membership 열거는 기존 HostStaticPartition 파생 목록을 사용하므로, 재개 때 독립성 요구에 충분한지 검토하고 필요하면 immutable blueprint에서 membership까지 직접 재구축하십시오.
- 신규 오류 시험은 prepareHostFrame을 끈 기존 일반 경로와 켠 경로의 부분 커밋·회복을 같은 시험 안에서 비교합니다. **고정 53d49ca94 번들과의 독립 배달 differential은 아직 수행하지 않았습니다.**

| 신규 시험 파일 | 실행 결과 |
|---|---|
| settle.prepared-host-work | 5 통과: S0/100/1000/4000 상한 + 과거 참조 불변 |
| settle.prepared-host-verification | 2 통과: table에서 S8 꺼짐/verify 수행 + 손상 거부 |
| settle.prepared-host-failure | 1 통과: 일반/준비 경로 오류와 회복 동치 |
| settle.prepared-host-invalidation | 7 통과: load·reset·host 재진입·array 삽입 재배치·제거 뒤 경로·overlay·relocation |
| RootNodeContext prepared-host-rebuild (render) | 1 통과: 새 root/store와 기존 store 폐기 |

수정 전 workload 시험은 S100/1000/4000에서 reuser 204/2004/8004와 key 104/1004/4004가 상한 24를 넘어 실패했습니다. 후보의 같은 시험은 모든 S에서 **reuser 0회, committed key 3회/쓰기**였고 통과했습니다. 원자료 d2-p5-work-red-both.log와 new-work.log를 남겼습니다. 이는 호출 수 관측이며 시간 개선 채택 근거가 아닙니다.

기존 host-static-partition, host-static-shared, non-wheel-preservation, gate-wheel-critical, error-gate-exits 5파일도 단일 파일 실행에서 통과했습니다. 신규 시험 16건은 포맷 직전 소스에서 통과했고 이후 변화는 포맷과 신규 render 시험의 계약 marker 정정뿐입니다. 최종 포맷과 git diff --check는 통과했습니다.

최종 typecheck의 미해결 7건(pause-typecheck.log)은 다음입니다.

- settle.prepared-host-failure.test.ts:14의 `schema.oneOf`가 unknown/{}로 남아 iterator를 보장하지 못합니다(TS2488).
- settle.prepared-host-invalidation.test.ts:122의 `schema.properties`가 object로 좁혀지지 않았습니다(TS2698).
- prepared-host-rebuild.test.tsx의 old/current node가 optional인 것을 좁히지 않았습니다(TS18048·TS2345, 5건).

중단 지시에 따라 이 오류를 고치며 구현을 계속하지 않았습니다. 소스 런타임 파일의 타입 오류는 최종 로그에 없지만 후보 전체 typecheck는 실패입니다.

## 남은 단계와 재개 방법

1. 소유자의 분기 전환 재검토 허가 뒤 이 가지를 checkout하고 이 문서와 선행 DETAIL을 읽으십시오. 임의로 현재 dist를 후보로 취급하지 마십시오.
2. 위 신규 시험 타입 좁히기 7건을 수정하고 typecheck 및 영향을 받은 단일 파일 시험을 확인하십시오. 기존 단언은 변경하지 마십시오.
3. S8 독립성, 예외 finally의 사적 객체 봉합, 무효화 조건별 ablation(조항 제거 시 실패), dirty static 자식과 노드 배치 확인을 마무리하십시오. 아직 모든 조항의 ablation을 완료하지 않았습니다.
4. 미실행 가드: 전체 presence/키 순서/바퀴/배열/재진입 시험과 전체 다섯 test 프로젝트·lint·test:verify가 남았습니다. 작업량 단언이 깨지면 수정하지 말고 목록을 ask하십시오.
5. **build·전체 시험·test:verify·측정은 다시 ask로 창을 요청하고 코디네이터 status 뒤 실행하십시오.** 단일 파일 시험과 typecheck는 허용 범위입니다.
6. tools에 고정 A/B 번들 지원과 14행 suite(코어8+구독2+형제4)를 준비하십시오. 제품 코드를 복사하거나 임의 캐시/노드 칸을 더하지 마십시오. 기존 D2-P4 도구는 참고할 수 있으나 이 가지에는 아직 도입하지 않았습니다.
7. 같은 창 A(53d49ca94 dist)/B(새 HEAD build)/A′, 각 20 예열·100 표본·독립 3 프로세스로 재십시오. `W=max(|A−A′|, range(A), range(A′))`; B−A·B−A′가 같은 부호로 모두 엄격히 W 밖일 때만 개선/악화입니다. **S1000·4000 둘 다 개선, 14행 악화0, Node·Bun B2 각7표본의 B중앙값≤A최대**가 모두 있어야 채택합니다. 형제1000/0 비율도 보고하십시오. 이 규칙은 첫 정식 측정 전에 고정되어 있으며 아직 실행하지 않았습니다.
8. 채택 시 typecheck·lint·다섯 test 프로젝트·build·test:verify·독립 전후 배달 차이0·index.d.ts diff0과 메모리 비용을 확인하십시오. PR base는 integration/schema-form-d2, 제목은 `perf(schema-form): prepare a gated host's static children once per host lifetime so a discriminator write stops scaling with sibling count (D2-P5)`이며 “독립 검토는 코디네이터가 배정”을 넣습니다. 폐기 판정이면 후보를 복원하고 결과 문서만 커밋합니다. **현재는 보류이므로 어느 판정도 하지 않았고 PR도 없습니다.**

원자료의 profile-and-design.md에는 최초 설계가, 이 결과 문서에는 후속 승인 조건과 예외 정정이 반영되어 있습니다. .seiri/tasks/d2-p5-sibling-linear의 plan/adr/gates는 로컬 작업 기록이며, 재개에 필요한 판단과 명령 조건은 이 문서에도 기록했습니다.
