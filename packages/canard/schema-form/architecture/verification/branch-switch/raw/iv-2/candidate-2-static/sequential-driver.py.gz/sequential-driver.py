import os
import subprocess
import sys

for project in ['unit', 'render', 'storybook', 'react18', 'production', 'verify']:
    command = ['yarn', 'workspace', '@canard/schema-form']
    if project == 'verify':
        command += ['test:verify', '--run', '--maxWorkers=4']
    else:
        command += ['test', '--run', '--project', project, '--maxWorkers=4']
    with open('<scratch>/iv-2-c2-final-' + project + '.log', 'w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    print(project + ' EXIT ' + str(result.returncode), flush=True)
    if result.returncode:
        sys.exit(result.returncode)
print('CANDIDATE_2_SEQUENTIAL_PROJECTS_COMPLETE', flush=True)
