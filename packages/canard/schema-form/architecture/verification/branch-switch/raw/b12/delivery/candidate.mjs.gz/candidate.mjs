const __SCHEMA_FORM_DEV__ = process.env.NODE_ENV !== "production";
import { isArray, isEmptyObject, isFunction, isPlainObject } from "@winglet/common-utils/filter";
import { clone, createFingerprintFactory, equals, getDataProperty, merge } from "@winglet/common-utils/object";
import { BaseError } from "@winglet/common-utils/error";
import { remainOnlyReactComponent } from "@winglet/react-utils/object";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { isArraySchema, isStringSchema } from "@winglet/json-schema/filter";
import { Fragment as Fragment$1, createContext, createElement, forwardRef, memo, useCallback, useContext, useEffect, useImperativeHandle, useInsertionEffect, useLayoutEffect, useMemo, useReducer, useRef, useState, useSyncExternalStore } from "react";
import { useConstant, useHandle, useLazyConstant, useMemorize, useOnUnmount, useReference, useSnapshot } from "@winglet/react-utils/hook";
import { intersectionLite, intersectionWith, map } from "@winglet/common-utils/array";
import { JSONPointer as JSONPointer$1 } from "@winglet/json/pointer";
import { escapeSegment, unescapeSegment } from "@winglet/json/pointer-escape";
import { hasOwnProperty } from "@winglet/common-utils/lib";
import { lcm, maxLite, minLite } from "@winglet/common-utils/math";
import { NOOP_FUNCTION, NULL_FUNCTION } from "@winglet/common-utils/constant";
import { isMemoComponent, isReactComponent } from "@winglet/react-utils/filter";
import { ErrorBoundary, withErrorBoundary, withErrorBoundaryForwardRef } from "@winglet/react-utils/hoc";
import { getTrackableHandler } from "@winglet/common-utils/function";
import { printWarning } from "@winglet/common-utils/console";
import { scheduleCancelableMacrotaskSafe } from "@winglet/common-utils/scheduler";

//#region src/errors/constants/FormErrorGroup.ts
const FormErrorGroup = {
	JsonSchema: "JSON_SCHEMA_ERROR",
	SchemaForm: "SCHEMA_FORM_ERROR",
	Unhandled: "UNHANDLED_ERROR",
	Validation: "VALIDATION_ERROR"
};

//#endregion
//#region src/errors/constants/FormWarningGroup.ts
const FormWarningGroup = { SchemaForm: "SCHEMA_FORM_WARNING" };

//#endregion
//#region src/errors/constants/JSONSchemaErrorSpecific.ts
const JSONSchemaErrorSpecific = {
	ReservedPropertyName: "RESERVED_PROPERTY_NAME",
	UnknownJsonSchema: "UNKNOWN_JSON_SCHEMA",
	UnexpectedArraySchema: "UNEXPECTED_ARRAY_SCHEMA",
	AllOfTypeRedefinition: "ALL_OF_TYPE_REDEFINITION",
	ConflictingConstValues: "CONFLICTING_CONST_VALUES",
	InvalidRange: "INVALID_RANGE",
	EmptyEnumIntersection: "EMPTY_ENUM_INTERSECTION",
	VirtualFieldsNotValid: "VIRTUAL_FIELDS_NOT_VALID",
	VirtualFieldsNotInProperties: "VIRTUAL_FIELDS_NOT_IN_PROPERTIES",
	CreateDynamicFunction: "CREATE_DYNAMIC_FUNCTION",
	ObservedValues: "OBSERVED_VALUES",
	UnknownGroupKey: "UNKNOWN_GROUP_KEY",
	DiscriminatorMismatch: "DISCRIMINATOR_MISMATCH",
	SharedNodeKindConflict: "SHARED_NODE_KIND_CONFLICT",
	TerminalStrategyMismatch: "TERMINAL_STRATEGY_MISMATCH",
	RecursiveShapeUnbounded: "RECURSIVE_SHAPE_UNBOUNDED",
	VirtualFieldsMismatch: "VIRTUAL_FIELDS_MISMATCH",
	ChildrenTargetNotFound: "CHILDREN_TARGET_NOT_FOUND",
	TerminalOptionUnsupported: "TERMINAL_OPTION_UNSUPPORTED",
	InvalidControlShape: "INVALID_CONTROL_SHAPE"
};

//#endregion
//#region src/errors/constants/SchemaFormErrorSpecific.ts
const SchemaFormErrorSpecific = {
	SharedNodeConflict: "SHARED_NODE_CONFLICT",
	BudgetExceeded: "BUDGET_EXCEEDED",
	ExpressionThrew: "EXPRESSION_THREW",
	GuardFailed: "GUARD_FAILED",
	InjectTargetMissing: "INJECT_TARGET_MISSING",
	FeedbackLimitExceeded: "FEEDBACK_LIMIT_EXCEEDED",
	ListenerThrew: "LISTENER_THREW",
	MultipleErrors: "MULTIPLE_ERRORS",
	FormTypeInputMap: "FORM_TYPE_INPUT_MAP",
	InvalidWriteOption: "INVALID_WRITE_OPTION",
	DisposedNodeWrite: "DISPOSED_NODE_WRITE",
	WriteInObserver: "WRITE_IN_OBSERVER",
	SubmitWhileDegraded: "SUBMIT_WHILE_DEGRADED",
	ValidatorCompileFailed: "VALIDATOR_COMPILE_FAILED",
	ValidatorThrew: "VALIDATOR_THREW",
	RenderFailed: "RENDER_FAILED",
	InvalidVirtualNodeValues: "INVALID_VIRTUAL_NODE_VALUES",
	ArrayMethodOnNonArray: "ARRAY_METHOD_ON_NON_ARRAY",
	RecursiveShapeDiverged: "RECURSIVE_SHAPE_DIVERGED"
};

//#endregion
//#region src/errors/constants/SchemaFormWarningSpecific.ts
const SchemaFormWarningSpecific = {
	AllOfKeywordIgnoredForForm: "ALL_OF_KEYWORD_IGNORED_FOR_FORM",
	NullBranchIgnoredForForm: "NULL_BRANCH_IGNORED_FOR_FORM",
	VirtualizationDisabledForForm: "VIRTUALIZATION_DISABLED_FOR_FORM",
	IfWithoutElseFalse: "IF_WITHOUT_ELSE_FALSE",
	LockOnNonTerminalObject: "LOCK_ON_NON_TERMINAL_OBJECT",
	ConditionalSchemaWithoutValidator: "CONDITIONAL_SCHEMA_WITHOUT_VALIDATOR",
	ValidatorMissing: "VALIDATOR_MISSING",
	MultipleGatedBranchesActive: "MULTIPLE_GATED_BRANCHES_ACTIVE",
	ResetRebuiltByReference: "RESET_REBUILT_BY_REFERENCE",
	DependentSchemasIgnoredForForm: "DEPENDENT_SCHEMAS_IGNORED_FOR_FORM",
	ChildNodeComponentsOnTerminal: "CHILD_NODE_COMPONENTS_ON_TERMINAL",
	TerminalSubtreeKeyIgnoredForForm: "TERMINAL_SUBTREE_KEY_IGNORED_FOR_FORM",
	DiscriminatorBranchUnreachable: "DISCRIMINATOR_BRANCH_UNREACHABLE",
	NonJsonWholeValue: "NON_JSON_WHOLE_VALUE",
	FormTypeTestInvalid: "FORM_TYPE_TEST_INVALID",
	Misfit: "MISFIT",
	DialectMismatch: "DIALECT_MISMATCH",
	DetachedNodeWrite: "DETACHED_NODE_WRITE",
	InactiveValueWithUnsetOnInactive: "INACTIVE_VALUE_WITH_UNSET_ON_INACTIVE",
	WriteInInactiveResolver: "WRITE_IN_INACTIVE_RESOLVER"
};

//#endregion
//#region src/errors/constants/UnhandledErrorSpecific.ts
const UnhandledErrorSpecific = {
	RegisterPlugin: "REGISTER_PLUGIN",
	ValidatorBindRefused: "VALIDATOR_BIND_REFUSED"
};

//#endregion
//#region src/errors/constants/ValidationErrorSpecific.ts
const ValidationErrorSpecific = { SchemaValidationFailed: "SCHEMA_VALIDATION_FAILED" };

//#endregion
//#region src/errors/utils/getCodeSpecific.ts
const SPECIFICS = new Map([
	[FormErrorGroup.JsonSchema, JSONSchemaErrorSpecific],
	[FormErrorGroup.SchemaForm, SchemaFormErrorSpecific],
	[FormErrorGroup.Unhandled, UnhandledErrorSpecific],
	[FormErrorGroup.Validation, ValidationErrorSpecific],
	[FormWarningGroup.SchemaForm, SchemaFormWarningSpecific]
].flatMap(([group, specifics]) => Object.values(specifics).map((specific) => [`${group}.${specific}`, specific])));
const getCodeSpecific = (code) => {
	const specific = SPECIFICS.get(code);
	if (specific === void 0) throw new Error(`Unknown form code: ${code}`);
	return specific;
};

//#endregion
//#region src/errors/classes/JSONSchemaError.ts
const GROUP$3 = FormErrorGroup.JsonSchema;
var JSONSchemaError = class extends BaseError {
	constructor(code, message, details = {}) {
		super(GROUP$3, getCodeSpecific(code), message, details);
		this.name = GROUP$3;
	}
};
const isJSONSchemaError = (error) => error instanceof JSONSchemaError;

//#endregion
//#region src/errors/classes/SchemaFormError.ts
const GROUP$2 = FormErrorGroup.SchemaForm;
var SchemaFormError = class extends BaseError {
	constructor(code, message, details = {}) {
		super(GROUP$2, getCodeSpecific(code), message, details);
		this.name = GROUP$2;
	}
};
const isSchemaFormError = (error) => error instanceof SchemaFormError;

//#endregion
//#region src/errors/classes/UnhandledError.ts
const GROUP$1 = FormErrorGroup.Unhandled;
var UnhandledError = class extends BaseError {
	constructor(code, message, details = {}) {
		super(GROUP$1, getCodeSpecific(code), message, details);
		this.name = GROUP$1;
	}
};
const isUnhandledError = (error) => error instanceof UnhandledError;

//#endregion
//#region src/errors/classes/ValidationError.ts
const GROUP = FormErrorGroup.Validation;
var ValidationError = class extends BaseError {
	constructor(code, message, details = {}) {
		super(GROUP, getCodeSpecific(code), message, details);
		this.name = GROUP;
	}
};
const isValidationError = (error) => error instanceof ValidationError;

//#endregion
//#region src/errors/utils/assembleCodeGroup.ts
const assembleCodeGroup = (group, specifics) => Object.fromEntries(Object.entries(specifics).map(([key, specific]) => [key, `${group}.${specific}`]));

//#endregion
//#region src/errors/constants/FormErrorCode.ts
const FormErrorCode = {
	UnknownJsonSchema: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.UnknownJsonSchema}`,
	UnexpectedArraySchema: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.UnexpectedArraySchema}`,
	AllOfTypeRedefinition: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.AllOfTypeRedefinition}`,
	ConflictingConstValues: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.ConflictingConstValues}`,
	InvalidRange: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.InvalidRange}`,
	EmptyEnumIntersection: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.EmptyEnumIntersection}`,
	VirtualFieldsNotValid: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.VirtualFieldsNotValid}`,
	VirtualFieldsNotInProperties: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.VirtualFieldsNotInProperties}`,
	CreateDynamicFunction: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.CreateDynamicFunction}`,
	ObservedValues: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.ObservedValues}`,
	UnknownGroupKey: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.UnknownGroupKey}`,
	DiscriminatorMismatch: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.DiscriminatorMismatch}`,
	SharedNodeKindConflict: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.SharedNodeKindConflict}`,
	TerminalStrategyMismatch: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.TerminalStrategyMismatch}`,
	SharedNodeConflict: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.SharedNodeConflict}`,
	BudgetExceeded: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.BudgetExceeded}`,
	ExpressionThrew: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.ExpressionThrew}`,
	GuardFailed: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.GuardFailed}`,
	InjectTargetMissing: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.InjectTargetMissing}`,
	FeedbackLimitExceeded: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.FeedbackLimitExceeded}`,
	ListenerThrew: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.ListenerThrew}`,
	MultipleErrors: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.MultipleErrors}`,
	FormTypeInputMap: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.FormTypeInputMap}`,
	RegisterPlugin: `${FormErrorGroup.Unhandled}.${UnhandledErrorSpecific.RegisterPlugin}`,
	InvalidWriteOption: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.InvalidWriteOption}`,
	DisposedNodeWrite: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.DisposedNodeWrite}`,
	WriteInObserver: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.WriteInObserver}`,
	SubmitWhileDegraded: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.SubmitWhileDegraded}`,
	ValidatorCompileFailed: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.ValidatorCompileFailed}`,
	ValidatorThrew: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.ValidatorThrew}`,
	RenderFailed: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.RenderFailed}`,
	InvalidVirtualNodeValues: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.InvalidVirtualNodeValues}`,
	ArrayMethodOnNonArray: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.ArrayMethodOnNonArray}`,
	RecursiveShapeUnbounded: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.RecursiveShapeUnbounded}`,
	RecursiveShapeDiverged: `${FormErrorGroup.SchemaForm}.${SchemaFormErrorSpecific.RecursiveShapeDiverged}`,
	VirtualFieldsMismatch: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.VirtualFieldsMismatch}`,
	ChildrenTargetNotFound: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.ChildrenTargetNotFound}`,
	TerminalOptionUnsupported: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.TerminalOptionUnsupported}`,
	ValidatorBindRefused: `${FormErrorGroup.Unhandled}.${UnhandledErrorSpecific.ValidatorBindRefused}`,
	InvalidControlShape: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.InvalidControlShape}`,
	SchemaValidationFailed: `${FormErrorGroup.Validation}.${ValidationErrorSpecific.SchemaValidationFailed}`,
	ReservedPropertyName: `${FormErrorGroup.JsonSchema}.${JSONSchemaErrorSpecific.ReservedPropertyName}`
};
const JSONSchemaErrorCodes = assembleCodeGroup(FormErrorGroup.JsonSchema, JSONSchemaErrorSpecific);
const SchemaFormErrorCodes = assembleCodeGroup(FormErrorGroup.SchemaForm, SchemaFormErrorSpecific);
const UnhandledErrorCodes = assembleCodeGroup(FormErrorGroup.Unhandled, UnhandledErrorSpecific);
const ValidationErrorCodes = assembleCodeGroup(FormErrorGroup.Validation, ValidationErrorSpecific);

//#endregion
//#region src/errors/constants/FormWarningCode.ts
const FormWarningCode = {
	AllOfKeywordIgnoredForForm: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.AllOfKeywordIgnoredForForm}`,
	NullBranchIgnoredForForm: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.NullBranchIgnoredForForm}`,
	VirtualizationDisabledForForm: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.VirtualizationDisabledForForm}`,
	IfWithoutElseFalse: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.IfWithoutElseFalse}`,
	LockOnNonTerminalObject: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.LockOnNonTerminalObject}`,
	ConditionalSchemaWithoutValidator: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.ConditionalSchemaWithoutValidator}`,
	ValidatorMissing: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.ValidatorMissing}`,
	MultipleGatedBranchesActive: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.MultipleGatedBranchesActive}`,
	ResetRebuiltByReference: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.ResetRebuiltByReference}`,
	DependentSchemasIgnoredForForm: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.DependentSchemasIgnoredForForm}`,
	ChildNodeComponentsOnTerminal: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.ChildNodeComponentsOnTerminal}`,
	TerminalSubtreeKeyIgnoredForForm: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.TerminalSubtreeKeyIgnoredForForm}`,
	DiscriminatorBranchUnreachable: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.DiscriminatorBranchUnreachable}`,
	NonJsonWholeValue: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.NonJsonWholeValue}`,
	FormTypeTestInvalid: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.FormTypeTestInvalid}`,
	Misfit: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.Misfit}`,
	DialectMismatch: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.DialectMismatch}`,
	DetachedNodeWrite: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.DetachedNodeWrite}`,
	InactiveValueWithUnsetOnInactive: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.InactiveValueWithUnsetOnInactive}`,
	WriteInInactiveResolver: `${FormWarningGroup.SchemaForm}.${SchemaFormWarningSpecific.WriteInInactiveResolver}`
};
const SchemaFormWarningCodes = assembleCodeGroup(FormWarningGroup.SchemaForm, SchemaFormWarningSpecific);

//#endregion
//#region src/errors/utils/isFormErrorCode.ts
const CODES$1 = new Set(Object.values(FormErrorCode));
const isFormErrorCode = (value) => typeof value === "string" && CODES$1.has(value);

//#endregion
//#region src/errors/utils/isFormWarningCode.ts
const CODES = new Set(Object.values(FormWarningCode));
const isFormWarningCode = (value) => typeof value === "string" && CODES.has(value);

//#endregion
//#region src/components/FallbackComponents/components/FormInputRenderer.tsx
const FormInputRenderer = ({ Input }) => /* @__PURE__ */ jsx(Input, {});

//#endregion
//#region src/components/FallbackComponents/components/FormFieldRenderer.tsx
const LABEL_NOTE_STYLE = { fontSize: "0.85em" };
const LABEL_GAP_STYLE = { marginRight: 5 };
const REQUIRED_MARK_STYLE = { color: "red" };
const FormFieldRenderer = ({ node, depth, path, name, required, Input, errorMessage, style, className }) => {
	if (depth === 0) return /* @__PURE__ */ jsx(Input, {});
	if (node.strategy === "branch") return /* @__PURE__ */ jsxs("fieldset", {
		style: {
			marginBottom: 5,
			marginLeft: 5 * depth,
			...style
		},
		className,
		children: [
			/* @__PURE__ */ jsx("legend", {
				id: "label:" + path,
				children: node.name
			}),
			/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("em", {
				style: LABEL_NOTE_STYLE,
				children: errorMessage
			}) }),
			/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Input, {}) })
		]
	});
	else return /* @__PURE__ */ jsxs("div", {
		style: {
			marginBottom: 5,
			marginLeft: 5 * depth,
			...style
		},
		className,
		children: [
			node.parentNode && isArraySchema(node.parentNode) === false && /* @__PURE__ */ jsxs("label", {
				htmlFor: path,
				id: "label:" + path,
				style: LABEL_GAP_STYLE,
				children: [
					name,
					" ",
					required && /* @__PURE__ */ jsx("span", {
						style: REQUIRED_MARK_STYLE,
						children: "*"
					})
				]
			}),
			/* @__PURE__ */ jsx(Input, {}),
			/* @__PURE__ */ jsx("br", {}),
			/* @__PURE__ */ jsx("em", {
				style: LABEL_NOTE_STYLE,
				children: errorMessage
			})
		]
	});
};

//#endregion
//#region src/components/FallbackComponents/components/FormLabelRenderer.tsx
const FormLabelRenderer = ({ name }) => name;

//#endregion
//#region src/components/FallbackComponents/components/FormErrorRenderer.tsx
const FormErrorRenderer = ({ errorMessage }) => /* @__PURE__ */ jsx("em", { children: errorMessage });

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/utils/fillArraySlot.ts
const fillArraySlot = (current, index, value) => Array.from({ length: Math.max(current?.length ?? 0, index + 1) }, (_, position) => position === index ? value : current?.[position]);

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/utils/readSlotKind.ts
const readSlotKind = (jsonSchema, index, itemSchema) => {
	const schema = itemSchema ?? jsonSchema.prefixItems?.[index] ?? jsonSchema.items;
	if (!schema || typeof schema !== "object" || schema.enum || schema.format) return "fill";
	const type = [schema.type].flat().find((item) => item !== "null");
	if (type === "string") return "text";
	if (type === "number" || type === "integer") return "number";
	return type === "boolean" ? "checkbox" : "fill";
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/components/Button.tsx
const Button = memo(function Button({ title, label, disabled, onClick, size = "1.3rem", fontSize = "0.8rem", style }) {
	return /* @__PURE__ */ jsx("button", {
		title,
		onClick,
		disabled,
		style: {
			position: "relative",
			width: size,
			height: size,
			padding: 0,
			border: "none",
			cursor: "pointer",
			borderRadius: "50%",
			display: "flex",
			alignItems: "center",
			justifyContent: "center",
			...style
		},
		children: /* @__PURE__ */ jsx("span", {
			style: {
				fontSize,
				lineHeight: 1,
				position: "absolute",
				top: "50%",
				left: "50%",
				transform: "translate(-50%, -50%)"
			},
			children: label
		})
	});
});

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/components/EmptySlot.tsx
const FLEX_ROW_STYLE$1 = { display: "flex" };
const EmptySlot = memo(function EmptySlot({ index, kind, readOnly, disabled, onWrite }) {
	if (kind === "fill") return /* @__PURE__ */ jsx("div", {
		style: FLEX_ROW_STYLE$1,
		children: /* @__PURE__ */ jsx("button", {
			type: "button",
			title: "fill item",
			disabled: disabled || readOnly,
			onClick: () => onWrite(index, void 0),
			children: "+"
		})
	});
	const handleChange = (event) => {
		const value = readSlotInput(kind, event.currentTarget);
		if (!readOnly && value !== void 0) onWrite(index, value);
	};
	return /* @__PURE__ */ jsx("div", {
		style: FLEX_ROW_STYLE$1,
		children: /* @__PURE__ */ jsx("input", {
			type: kind,
			readOnly,
			disabled: disabled || readOnly && kind === "checkbox",
			onChange: handleChange
		})
	});
});
const readSlotInput = (kind, input) => {
	if (kind === "checkbox") return input.checked;
	if (kind === "text") return input.value || void 0;
	const number = input.value.trim() === "" ? NaN : Number(input.value);
	return Number.isFinite(number) ? number : void 0;
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/components/ArrayItems.tsx
const FLEX_ROW_STYLE = { display: "flex" };
const ADD_BUTTON_ROW_STYLE = {
	display: "flex",
	justifyContent: "flex-end",
	alignItems: "center",
	cursor: "pointer",
	marginBottom: 5
};
const ADD_LABEL_STYLE = { marginRight: 10 };
const ArrayItems = memo(function ArrayItems({ node, jsonSchema, readOnly, disabled, ChildFields, style, onChange, childCount }) {
	const handleClick = useCallback(() => {
		node.push();
	}, [node]);
	const handleRemoveClick = useCallback((event) => {
		const row = event.currentTarget.parentElement;
		node.remove(Array.prototype.indexOf.call(row.parentElement.children, row));
	}, [node]);
	const container = useRef(null);
	const focusRow = useRef(null);
	const handleSlotWrite = useCallback((index, value) => {
		focusRow.current = index;
		onChange(fillArraySlot(node.value, index, value));
	}, [node, onChange]);
	useLayoutEffect(() => {
		if (focusRow.current === null || focusRow.current >= childCount) return;
		const row = container.current?.children[focusRow.current];
		focusRow.current = null;
		row?.querySelector("input, select, textarea, button")?.focus();
	});
	const rows = [];
	for (let index = 0; ChildFields && index < ChildFields.length; index++) {
		const ChildField = ChildFields[index];
		const key = ChildField.key;
		rows.push(/* @__PURE__ */ jsxs("div", {
			style: FLEX_ROW_STYLE,
			children: [/* @__PURE__ */ jsx(ChildField, {}, key), !readOnly && /* @__PURE__ */ jsx(Button, {
				title: "remove item",
				label: "x",
				disabled,
				index,
				onClick: handleRemoveClick
			})]
		}, key));
	}
	const slotEnd = Math.min(jsonSchema.minItems ?? 0, jsonSchema.maxItems ?? Infinity);
	for (let index = childCount; index < slotEnd; index++) rows.push(/* @__PURE__ */ jsx(EmptySlot, {
		index,
		kind: readSlotKind(jsonSchema, index, node.find("./" + index)?.jsonSchema),
		readOnly,
		disabled,
		onWrite: handleSlotWrite
	}, "slot:" + index));
	return /* @__PURE__ */ jsxs("div", {
		ref: container,
		style: {
			display: "flex",
			flexDirection: "column",
			gap: 5,
			...style
		},
		children: [rows, !readOnly && (jsonSchema.maxItems ?? Infinity) > childCount && /* @__PURE__ */ jsxs("label", {
			style: ADD_BUTTON_ROW_STYLE,
			children: [/* @__PURE__ */ jsx("div", {
				style: ADD_LABEL_STYLE,
				children: "Add New Item"
			}), /* @__PURE__ */ jsx(Button, {
				title: "add item",
				label: "+",
				disabled,
				onClick: handleClick,
				fontSize: "1rem"
			})]
		})]
	});
});

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/FieldInputArray.tsx
const FieldInputArray = ({ node, jsonSchema, readOnly, disabled, ChildFields, style, onChange }) => /* @__PURE__ */ jsx(ArrayItems, {
	node,
	jsonSchema,
	readOnly,
	disabled,
	ChildFields,
	style,
	onChange,
	childCount: node.children?.length ?? 0
});

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputArray/index.ts
const FieldInputArrayDefinition = {
	Component: FieldInputArray,
	test: { type: "array" }
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputBoolean/FieldInputBoolean.tsx
const FieldInputBoolean = ({ path, name, readOnly, disabled, misfit, value, onChange, style, className }) => {
	const ref = useRef(null);
	useLayoutEffect(() => {
		if (ref.current) ref.current.indeterminate = typeof value !== "boolean";
	}, [value]);
	const handleChange = useHandle((event) => {
		onChange(event.target.checked);
	});
	return /* @__PURE__ */ jsx("input", {
		ref,
		type: "checkbox",
		id: path,
		name,
		disabled: disabled || readOnly,
		checked: value === true,
		onChange: handleChange,
		style,
		className,
		"aria-invalid": misfit || void 0
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputBoolean/index.ts
const FieldInputBooleanDefinition = {
	Component: FieldInputBoolean,
	test: { type: "boolean" }
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputDateFormat/utils/isRenderableDateInputValue.ts
const TIME_PATTERN = /^(?:[01][0-9]|2[0-3]):[0-5][0-9](?::[0-5][0-9](?:\.[0-9]{1,3})?)?$/;
const DATE_TIME_SEPARATOR = /[T ]/;
const MONTH_PATTERN = /^([0-9]{4,})-([0-9]{2})$/;
const WEEK_PATTERN = /^([0-9]{4,})-W([0-9]{2})$/;
const DATE_PATTERN = /^([0-9]{4,})-([0-9]{2})-([0-9]{2})$/;
const isRenderableDateInputValue = (type, value) => {
	if (value === void 0 || value === null || value === "") return true;
	if (typeof value !== "string") return false;
	if (type === "time") return TIME_PATTERN.test(value);
	const parts = type === "datetime-local" ? value.split(DATE_TIME_SEPARATOR) : [value];
	if (type === "datetime-local" && (parts.length !== 2 || !TIME_PATTERN.test(parts[1]))) return false;
	const match = (type === "month" ? MONTH_PATTERN : type === "week" ? WEEK_PATTERN : type === "date" || type === "datetime-local" ? DATE_PATTERN : void 0)?.exec(parts[0]);
	if (!match) return false;
	const year = BigInt(match[1]);
	if (year === 0n) return false;
	const leapYear = year % 4n === 0n && (year % 100n !== 0n || year % 400n === 0n);
	const component = Number(match[2]);
	if (type === "week") {
		const previousYear = year - 1n;
		const weekday = Number((previousYear + previousYear / 4n - previousYear / 100n + previousYear / 400n) % 7n);
		return component >= 1 && component <= (weekday === 3 || weekday === 2 && leapYear ? 53 : 52);
	}
	if (component < 1 || component > 12) return false;
	if (type === "month") return true;
	const day = Number(match[3]);
	return day >= 1 && day <= (component === 2 ? leapYear ? 29 : 28 : component === 4 || component === 6 || component === 9 || component === 11 ? 30 : 31);
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputDateFormat/FieldInputDateFormat.tsx
const FieldInputDateFormat = ({ path, name, jsonSchema, readOnly, disabled, defaultValue, value, misfit, onChange, style, className, minimum, maximum }) => {
	const [type] = useState(() => isRenderableDateInputValue(jsonSchema.format, defaultValue) ? jsonSchema.format : "text");
	const handleChange = useHandle((event) => {
		if (event.target.validity.badInput) return;
		onChange(event.target.value === "" ? void 0 : event.target.value);
	});
	return /* @__PURE__ */ jsx("input", {
		type,
		id: path,
		name,
		readOnly,
		disabled,
		max: maximum,
		"aria-invalid": misfit || void 0,
		min: minimum,
		defaultValue: defaultValue ?? void 0,
		onChange: handleChange,
		onBlur: (event) => {
			if (event.target.validity.badInput) event.target.value = value == null ? "" : String(value);
		},
		style,
		className
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputDateFormat/index.ts
const FieldInputDateFormatDefinition = {
	Component: FieldInputDateFormat,
	test: {
		type: "string",
		format: [
			"month",
			"week",
			"date",
			"time",
			"datetime-local"
		]
	}
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputNumber/FieldInputNumber.tsx
const FieldInputNumber = ({ path, name, jsonSchema, readOnly, disabled, defaultValue, value, misfit, onChange, placeholder, style, className }) => {
	const handleChange = useHandle((event) => {
		if (event.target.validity.badInput) return;
		onChange(event.target.value === "" ? void 0 : event.target.valueAsNumber);
	});
	return /* @__PURE__ */ jsx("input", {
		type: "number",
		id: path,
		name,
		step: jsonSchema.multipleOf,
		readOnly,
		disabled,
		placeholder,
		"aria-invalid": misfit || void 0,
		defaultValue: defaultValue == null || typeof defaultValue === "number" && !Number.isFinite(defaultValue) ? void 0 : defaultValue,
		onChange: handleChange,
		onBlur: (event) => {
			if (event.target.validity.badInput) event.target.value = value == null || typeof value === "number" && !Number.isFinite(value) ? "" : String(value);
		},
		style,
		className
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputNumber/index.ts
const FieldInputNumberDefinition = {
	Component: FieldInputNumber,
	test: { type: "number" }
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputObject/FieldInputObject.tsx
const FieldInputObject = ({ ChildFields }) => {
	return /* @__PURE__ */ jsx(Fragment$1, { children: useMemo(() => {
		return ChildFields ? map(ChildFields, (ChildField) => /* @__PURE__ */ jsx(ChildField, {}, ChildField.key)) : null;
	}, [ChildFields]) });
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputObject/index.ts
const FieldInputObjectDefinition = {
	Component: FieldInputObject,
	test: { type: "object" }
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputString/FieldInputString.tsx
const FieldInputString = ({ path, name, readOnly, disabled, misfit, jsonSchema, defaultValue, onChange, placeholder, style, className, inputProps }) => {
	const type = useMemo(() => {
		if (jsonSchema?.format === "password") return "password";
		else if (jsonSchema?.format === "email") return "email";
		else return "text";
	}, [jsonSchema?.format]);
	const handleChange = useHandle((event) => {
		onChange(event.target.value === "" ? void 0 : event.target.value);
	});
	return /* @__PURE__ */ jsx("input", {
		type,
		id: path,
		name,
		readOnly,
		disabled,
		placeholder,
		defaultValue: defaultValue ?? void 0,
		onChange: handleChange,
		style,
		className,
		"aria-invalid": misfit || void 0,
		...inputProps
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputString/index.ts
const FieldInputStringDefinition = {
	Component: FieldInputString,
	test: { type: "string" }
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputStringCheckbox/FieldInputStringCheckbox.tsx
const FieldInputStringCheckbox = ({ path, name, jsonSchema, readOnly, disabled, defaultValue, misfit, onChange, context, alias, style, className }) => {
	const checkboxOptions = useMemo(() => jsonSchema.items?.enum ? map(jsonSchema.items.enum, (rawValue) => {
		const value = "" + rawValue;
		return {
			value,
			rawValue,
			label: context.checkboxLabels?.[value] || alias?.[value] || value
		};
	}) : [], [
		context,
		jsonSchema,
		alias
	]);
	const selected = isArray(defaultValue) ? defaultValue : [];
	const handleChange = useHandle((event) => {
		const { value, checked } = event.target;
		const rawValue = checkboxOptions.find((option) => option.value === value)?.rawValue;
		if (rawValue === void 0) return;
		if (checked) onChange((prev) => [...isArray(prev) ? prev : [], rawValue]);
		else onChange((prev) => isArray(prev) ? prev.filter((option) => option !== rawValue) : []);
	});
	return /* @__PURE__ */ jsx("div", {
		role: "group",
		"aria-labelledby": "label:" + path,
		"aria-invalid": misfit || void 0,
		children: map(checkboxOptions, ({ value, rawValue, label }, index) => {
			const id = path + "-" + index;
			return /* @__PURE__ */ jsxs("label", {
				htmlFor: id,
				style,
				className,
				children: [/* @__PURE__ */ jsx("input", {
					type: "checkbox",
					id,
					name,
					readOnly,
					disabled,
					value,
					defaultChecked: selected.includes(rawValue),
					onChange: handleChange
				}), label]
			}, value);
		})
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputStringCheckbox/index.ts
const FieldInputStringCheckboxDefinition = {
	Component: FieldInputStringCheckbox,
	test: ({ type, inputType, jsonSchema }) => type === "array" && inputType === "checkbox" && isStringSchema(jsonSchema.items) && !!jsonSchema.items?.enum?.length
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputStringEnum/FieldInputStringEnum.tsx
const FieldInputStringEnum = ({ path, name, jsonSchema, defaultValue, onChange, readOnly, disabled, misfit, context, alias, style, className }) => {
	const enumOptions = useMemo(() => jsonSchema.enum ? map(jsonSchema.enum, (rawValue) => {
		const value = "" + rawValue;
		return {
			value,
			rawValue,
			label: context.enumLabels?.[value] || alias?.[value] || value
		};
	}) : [], [
		context,
		jsonSchema,
		alias
	]);
	const initialValue = useMemo(() => {
		if (defaultValue === void 0) return "";
		if (defaultValue === null) return "null";
		return defaultValue;
	}, [defaultValue]);
	const outOfDomainValue = defaultValue === void 0 ? "" : defaultValue !== null && !enumOptions.some((option) => option.value === "" + defaultValue) ? "" + defaultValue : void 0;
	const handleChange = useHandle((event) => {
		const rawValue = enumOptions.find((option) => option.value === event.target.value)?.rawValue;
		if (rawValue === void 0) return;
		onChange(rawValue);
	});
	return /* @__PURE__ */ jsxs("select", {
		id: path,
		name,
		disabled: disabled || readOnly,
		defaultValue: initialValue,
		onChange: handleChange,
		style,
		className,
		"aria-invalid": misfit || void 0,
		children: [outOfDomainValue !== void 0 && /* @__PURE__ */ jsx("option", {
			disabled: true,
			value: outOfDomainValue,
			children: outOfDomainValue
		}), map(enumOptions, ({ value, label }) => /* @__PURE__ */ jsx("option", {
			value,
			children: label
		}, value))]
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputStringEnum/index.ts
const FieldInputStringEnumDefinition = {
	Component: FieldInputStringEnum,
	test: ({ type, jsonSchema }) => type === "string" && !!jsonSchema.enum?.length
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputStringRadio/FieldInputStringRadio.tsx
const FieldInputStringRadio = ({ path, name, jsonSchema, readOnly, disabled, misfit, defaultValue, onChange, context, alias, style, className }) => {
	const radioOptions = useMemo(() => jsonSchema.enum ? map(jsonSchema.enum, (rawValue) => {
		const value = "" + rawValue;
		return {
			value,
			rawValue,
			label: context.radioLabels?.[value] || alias?.[value] || value
		};
	}) : [], [
		context,
		jsonSchema,
		alias
	]);
	const handleChange = useHandle((event) => {
		const rawValue = radioOptions.find((option) => option.value === event.target.value)?.rawValue;
		if (rawValue === void 0) return;
		onChange(rawValue);
	});
	return /* @__PURE__ */ jsx("span", {
		role: "group",
		"aria-labelledby": "label:" + path,
		"aria-invalid": misfit || void 0,
		children: map(radioOptions, ({ value, rawValue, label }, index) => {
			const id = path + "-" + index;
			return /* @__PURE__ */ jsxs("label", {
				htmlFor: id,
				style,
				className,
				children: [/* @__PURE__ */ jsx("input", {
					type: "radio",
					id,
					name,
					readOnly,
					disabled,
					value,
					defaultChecked: rawValue === defaultValue,
					onChange: handleChange
				}), label]
			}, value);
		})
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputStringRadio/index.ts
const FieldInputStringRadioDefinition = {
	Component: FieldInputStringRadio,
	test: ({ type, inputType, jsonSchema }) => type === "string" && (inputType === "radio" || inputType === "radiogroup") && !!jsonSchema.enum?.length
};

//#endregion
//#region src/helpers/jsonPointer/constants/JSONPointer.ts
const JSONPointer = {
	Root: JSONPointer$1.Root,
	Fragment: JSONPointer$1.Fragment,
	Separator: JSONPointer$1.Separator,
	Parent: "..",
	Current: ".",
	Wildcard: "*",
	Index: "*",
	Context: "@"
};

//#endregion
//#region src/helpers/jsonPointer/constants/PointerOperator.ts
const PointerOperator = {
	Wildcard: Symbol("pointer.wildcard"),
	Parent: Symbol("pointer.parent"),
	Current: Symbol("pointer.current"),
	Context: Symbol("pointer.context")
};

//#endregion
//#region src/helpers/jsonPointer/utils/stripFragment.ts
const stripFragment = (path, preserveAbsoluteRoot = false) => path[0] === JSONPointer.Fragment ? preserveAbsoluteRoot && path.length === 1 ? path : path.slice(1) : path;

//#endregion
//#region src/helpers/jsonPointer/utils/isAbsolutePath.ts
const isAbsolutePath = (pointer) => pointer[0] === JSONPointer.Separator || pointer[0] === JSONPointer.Fragment && pointer[1] === JSONPointer.Separator;

//#endregion
//#region src/helpers/jsonPointer/utils/isAbsolutePointer.ts
const isAbsolutePointer = (pointer) => typeof pointer === "string" ? pointer === "#" || isAbsolutePath(pointer) : pointer[0] === "#";

//#endregion
//#region src/helpers/jsonPointer/utils/parsePointerSegment.ts
const parsePointerSegment = (token) => {
	switch (token) {
		case "*": return PointerOperator.Wildcard;
		case "..": return PointerOperator.Parent;
		case ".": return PointerOperator.Current;
		case "@": return PointerOperator.Context;
		case "%2A": return "*";
		case "%2E%2E": return "..";
		case "%2E": return ".";
		case "%40": return "@";
		default: return token.includes("~") ? unescapeSegment(token) : token;
	}
};

//#endregion
//#region src/helpers/jsonPointer/utils/parsePointerSegments.ts
const EMPTY_SEGMENTS = Object.freeze([]);
const parsePointerSegments = (pointer) => {
	if (pointer === "" || pointer === "#") return EMPTY_SEGMENTS;
	if (typeof pointer !== "string") {
		const offset = pointer[0] === "#" ? 1 : 0;
		let segments = offset ? pointer.slice(offset) : void 0;
		for (let index = offset; index < pointer.length; index++) {
			const segment = parsePointerSegment(pointer[index]);
			if (!segments && segment !== pointer[index]) segments = pointer.slice(offset);
			if (segments) segments[index - offset] = segment;
		}
		return segments ?? pointer;
	}
	const offset = pointer.startsWith("#/") ? 2 : pointer[0] === "/" ? 1 : 0;
	const names = (offset ? pointer.slice(offset) : pointer).split("/");
	const segments = names;
	for (let index = 0; index < names.length; index++) segments[index] = parsePointerSegment(names[index]);
	return segments;
};

//#endregion
//#region src/helpers/jsonPointer/utils/parsePointer.ts
const RELATIVE_EMPTY = Object.freeze({
	absolute: false,
	segments: parsePointerSegments("")
});
const ABSOLUTE_EMPTY = Object.freeze({
	absolute: true,
	segments: parsePointerSegments("#")
});
const parsePointer = (pointer) => {
	if (pointer === "") return RELATIVE_EMPTY;
	if (pointer === "#") return ABSOLUTE_EMPTY;
	return {
		absolute: isAbsolutePointer(pointer),
		segments: parsePointerSegments(pointer)
	};
};

//#endregion
//#region src/helpers/jsonPointer/utils/parseStandardPointer.ts
var PointerSyntaxError = class extends BaseError {
	constructor(pointer) {
		super("JSON_POINTER", "INVALID_POINTER_TYPE", "JSON pointer must start with #/ or /.", { pointer });
	}
};
const parseStandardPointer = (pointer) => {
	if (pointer === "" || pointer === "#") return [];
	const fragment = pointer[0] === "#";
	if (fragment ? pointer[1] !== "/" : pointer[0] !== "/") throw new PointerSyntaxError(pointer);
	const segments = pointer.slice(fragment ? 2 : 1).split("/");
	for (let index = 0; index < segments.length; index++) {
		let name = segments[index];
		if (fragment && name.includes("%")) name = decodeURIComponent(name);
		segments[index] = name.includes("~") ? unescapeSegment(name) : name;
	}
	return segments;
};

//#endregion
//#region src/helpers/jsonPointer/utils/formatSegment.ts
const formatSegment = (name) => {
	switch (name) {
		case "*": return "%2A";
		case "..": return "%2E%2E";
		case ".": return "%2E";
		case "@": return "%40";
		default: return escapeSegment(name);
	}
};

//#endregion
//#region src/helpers/jsonPointer/utils/isReservedPercentName.ts
const isReservedPercentName = (name) => name.charCodeAt(0) === 37 && (name === "%2A" || name === "%2E" || name === "%2E%2E" || name === "%40");

//#endregion
//#region src/helpers/jsonPointer/utils/appendFormattedSegment.ts
const appendFormattedSegment = (parentPath, formattedName) => parentPath + "/" + formattedName;

//#endregion
//#region src/helpers/jsonPointer/utils/appendSegment.ts
const appendSegment = (parentPath, name) => appendFormattedSegment(parentPath, formatSegment(String(name)));

//#endregion
//#region src/helpers/jsonPointer/utils/joinPointer.ts
const joinPointer = (segments) => {
	let path = "";
	for (const segment of segments) {
		const token = typeof segment === "string" ? formatSegment(segment) : segment === PointerOperator.Wildcard ? "*" : segment === PointerOperator.Parent ? ".." : segment === PointerOperator.Current ? "." : "@";
		path += "/" + token;
	}
	return path;
};

//#endregion
//#region src/helpers/jsonPointer/utils/joinPointerWithPrefixOf.ts
const joinPointerWithPrefixOf = (reference, segments) => (reference[0] === "#" ? "#" : "") + joinPointer(segments);

//#endregion
//#region src/helpers/jsonPointer/utils/isDescendantPath.ts
const isDescendantPath = (path, ancestorPath) => path.length > ancestorPath.length && path[ancestorPath.length] === "/" && path.startsWith(ancestorPath);

//#endregion
//#region src/helpers/jsonPointer/utils/resolvePointer.ts
const resolvePointer = (basePath, pointer) => {
	if (pointer === "@") return "@";
	if (pointer === "#") return "";
	if (pointer === "..") {
		const end = basePath.lastIndexOf("/");
		return end > 0 ? basePath.slice(0, end) : "";
	}
	if (pointer === ".") return basePath;
	if (pointer[0] === "/") return pointer;
	if (pointer.startsWith("#/")) return pointer.slice(1);
	const parsed = parsePointer(pointer);
	const resolved = parsed.absolute ? [] : [...parsePointerSegments(basePath)];
	for (let index = 0; index < parsed.segments.length; index++) {
		const segment = parsed.segments[index];
		if (segment === PointerOperator.Parent) resolved.pop();
		else if (segment !== PointerOperator.Current) {
			if (segment === "" && index === parsed.segments.length - 1 && index > 0 && typeof parsed.segments[index - 1] !== "string") continue;
			resolved.push(segment);
		}
	}
	return joinPointer(resolved);
};

//#endregion
//#region src/helpers/jsonPointer/utils/readFormattedPointerSegment.ts
const readFormattedPointerSegment = (path, index) => {
	if (path === "" || path === "#") return void 0;
	const offset = path.startsWith("#/") ? 2 : path[0] === "/" ? 1 : 0;
	let start = offset;
	let end = path.length;
	if (index < 0) {
		for (let position = -1; position > index; position--) {
			end = path.lastIndexOf("/", end - 1);
			if (end < offset) return void 0;
		}
		start = Math.max(offset, path.lastIndexOf("/", end - 1) + 1);
	} else {
		for (let position = 0; position < index; position++) {
			start = path.indexOf("/", start);
			if (start < 0) return void 0;
			start++;
		}
		const next = path.indexOf("/", start);
		if (next >= 0) end = next;
	}
	return path.slice(start, end);
};

//#endregion
//#region src/helpers/jsonPointer/utils/readPointerSegment.ts
const readPointerSegment = (path, index) => {
	const segment = readFormattedPointerSegment(path, index);
	return segment === void 0 ? void 0 : parsePointerSegment(segment);
};

//#endregion
//#region src/helpers/jsonPointer/utils/readFormattedNameSegment.ts
const readFormattedNameSegment = (path, index) => {
	const segment = readFormattedPointerSegment(path, index);
	switch (segment) {
		case "*":
		case "..":
		case ".":
		case "@": return;
		default: return segment;
	}
};

//#endregion
//#region src/helpers/jsonPointer/utils/getChildPointer.ts
const getChildPointer = (path, ancestorPath) => {
	if (!isDescendantPath(path, ancestorPath)) return void 0;
	const end = path.indexOf("/", ancestorPath.length + 1);
	return end < 0 ? path : path.slice(0, end);
};

//#endregion
//#region src/helpers/jsonPointer/utils/rebasePointer.ts
const rebasePointer = (path, previousPath, nextPath) => nextPath + path.slice(previousPath.length);

//#endregion
//#region src/helpers/jsonPointer/utils/hasPointerOperator.ts
const hasPointerOperator = (path, operator) => {
	const token = operator === PointerOperator.Wildcard ? "*" : operator === PointerOperator.Parent ? ".." : operator === PointerOperator.Current ? "." : operator === PointerOperator.Context ? "@" : void 0;
	if (token === void 0) return false;
	let start = path.indexOf(token);
	while (start >= 0) {
		const end = start + token.length;
		if ((start === 0 || path[start - 1] === "/") && (end === path.length || path[end] === "/")) return true;
		start = path.indexOf(token, end);
	}
	return false;
};

//#endregion
//#region src/helpers/jsonPointer/utils/bindPointerTemplate.ts
const bindPointerTemplate = (templatePath, occurrencePath) => {
	if (!hasPointerOperator(templatePath, PointerOperator.Wildcard)) return templatePath;
	let templateStart = 0;
	let occurrenceStart = 0;
	let copiedThrough = 0;
	let bound = "";
	while (templateStart < templatePath.length) {
		const templateSlash = templatePath.indexOf("/", templateStart + 1);
		const templateEnd = templateSlash < 0 ? templatePath.length : templateSlash;
		const occurrenceSlash = occurrencePath.indexOf("/", occurrenceStart + 1);
		const occurrenceEnd = occurrenceSlash < 0 ? occurrencePath.length : occurrenceSlash;
		if (templateEnd === templateStart + 2 && templatePath[templateStart + 1] === "*" && occurrenceStart < occurrencePath.length) {
			bound += templatePath.slice(copiedThrough, templateStart + 1);
			bound += occurrencePath.slice(occurrenceStart + 1, occurrenceEnd);
			copiedThrough = templateEnd;
		}
		templateStart = templateEnd;
		occurrenceStart = occurrenceEnd;
	}
	return bound ? bound + templatePath.slice(copiedThrough) : templatePath;
};

//#endregion
//#region src/helpers/jsonPointer/utils/isCanonicalPath.ts
const SEPARATOR = JSONPointer.Separator;
const isCanonicalPath = (path) => path[0] === SEPARATOR;

//#endregion
//#region src/core/engine/utils/cache/derivedRecords.ts
let blueprintRecords = /* @__PURE__ */ new WeakMap();
let hostRecords = /* @__PURE__ */ new WeakMap();
const getBlueprintDerived = (blueprint) => {
	let record = blueprintRecords.get(blueprint);
	if (!record) {
		record = {};
		blueprintRecords.set(blueprint, record);
	}
	return record;
};
const getHostDerived = (host) => {
	let record = hostRecords.get(host);
	if (!record) {
		record = {};
		hostRecords.set(host, record);
	}
	return record;
};
const resetEngineDerivedRecords = () => {
	blueprintRecords = /* @__PURE__ */ new WeakMap();
	hostRecords = /* @__PURE__ */ new WeakMap();
};

//#endregion
//#region src/core/engine/utils/cache/engineModes.ts
const modes = {
	gatePredicate: "on",
	gateSelection: "table",
	gateWheel: "skip",
	deriveShadow: false
};
const engineModes = {
	get gatePredicate() {
		return modes.gatePredicate;
	},
	get gateSelection() {
		return modes.gateSelection;
	},
	get gateWheel() {
		return modes.gateWheel;
	},
	get deriveShadow() {
		return modes.deriveShadow;
	},
	setMode(name, value) {
		if (modes[name] === value) return;
		modes[name] = value;
		resetEngineDerivedRecords();
	}
};

//#endregion
//#region src/core/engine/settle/utils/input/assertVirtualWriteShape.ts
const assertVirtualWriteShape = (node, input) => {
	const fields = node.blueprintNode.fields ?? [];
	if (input !== void 0 && (!isArray(input) || input.length !== fields.length)) throw new SchemaFormError(FormErrorCode.InvalidVirtualNodeValues, `Invalid virtual node values at ${node.path}`, {
		path: node.path,
		expected: fields.length,
		received: input
	});
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/finalize/ensureEffectiveSchemaCache.ts
const ensureEffectiveSchemaCache = (memo, node, options) => {
	const mode = options.mode ?? "runtime";
	const record = memo === void 0 ? getHostDerived(node) : void 0;
	const entries = memo?.get(node) ?? record?.effectiveSchemaMemo ?? [];
	const found = entries.find((entry) => entry.mode === mode && entry.isAtomic === options.isAtomic);
	if (found) return found.schemas;
	const schemas = /* @__PURE__ */ new Map();
	entries.push({
		mode,
		isAtomic: options.isAtomic,
		schemas
	});
	if (memo) memo.set(node, entries);
	else if (record) record.effectiveSchemaMemo = entries;
	return schemas;
};

//#endregion
//#region src/core/engine/constants/schemaGroup.ts
const SCHEMA_GROUP = {
	controls: "controls",
	options: "options",
	presentation: "presentation"
};

//#endregion
//#region src/core/engine/utils/cache/valueMemos.ts
const ownedSchemaValues = /* @__PURE__ */ new WeakSet();
const staticChoices = /* @__PURE__ */ new WeakMap();
const trimmedArrays = /* @__PURE__ */ new WeakMap();
const objectKeyCounts = /* @__PURE__ */ new WeakMap();
const scalarSpecs = [/* @__PURE__ */ new Map(), /* @__PURE__ */ new Map()];
const unionSpecs = [/* @__PURE__ */ new WeakMap(), /* @__PURE__ */ new WeakMap()];

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/finalize/isObjectRecord.ts
const isObjectRecord = (value) => value !== null && typeof value === "object";

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/finalize/freezeCreatedHintObjects.ts
const freezeCreatedHintObjects = (result, earlier, later) => {
	if (!isObjectRecord(result)) return;
	const keys = Object.keys(result);
	for (let index = 0; index < keys.length; index++) {
		const key = keys[index];
		const value = result[key];
		const previous = getDataProperty(earlier, key);
		const next = getDataProperty(later, key);
		if (value === previous || value === next || !isPlainObject(value)) continue;
		freezeCreatedHintObjects(value, previous, next);
		Object.freeze(value);
	}
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/merge/mergeHintGroup.ts
const mergeHintGroup = (earlier, later, omitVirtual, isAtomic) => {
	const source = omitVirtual && later && typeof later === "object" && hasOwnProperty(later, "virtual") ? Object.fromEntries(Object.entries(later).filter(([key]) => key !== "virtual")) : later;
	if (source !== later && source && typeof source === "object") ownedSchemaValues.add(source);
	if (source === void 0) return earlier;
	if (earlier === void 0) return source;
	if (!earlier || !source || typeof earlier !== "object" || typeof source !== "object") return source;
	const result = merge(earlier, source, {
		immutable: true,
		preserveReferences: true,
		arrayStrategy: "replace",
		isAtomic
	});
	if (result !== earlier && result !== source) {
		freezeCreatedHintObjects(result, earlier, source);
		ownedSchemaValues.add(result);
	}
	return result;
};

//#endregion
//#region src/helpers/schemaIntersection/utils/constant.ts
const EMPTY_INTERSECTION = Symbol("EMPTY_INTERSECTION");

//#endregion
//#region src/helpers/schemaIntersection/utils/intersectConst.ts
const intersectConst = (baseConst, sourceConst) => {
	if (baseConst === void 0) return sourceConst;
	if (sourceConst === void 0) return baseConst;
	return equals(baseConst, sourceConst) ? baseConst : EMPTY_INTERSECTION;
};

//#endregion
//#region src/helpers/schemaIntersection/utils/intersectEnum.ts
const intersectEnum = (baseEnum, sourceEnum, deepEqual) => {
	if (!baseEnum) return sourceEnum;
	if (!sourceEnum) return baseEnum;
	const values = deepEqual ? intersectionWith(baseEnum, sourceEnum, equals) : intersectionLite(baseEnum, sourceEnum);
	return values.length ? values : EMPTY_INTERSECTION;
};

//#endregion
//#region src/helpers/schemaIntersection/utils/intersectMaximum.ts
const intersectMaximum = (baseMax, sourceMax) => {
	if (baseMax === void 0) return sourceMax;
	if (sourceMax === void 0) return baseMax;
	return minLite(baseMax, sourceMax);
};

//#endregion
//#region src/helpers/schemaIntersection/utils/intersectMinimum.ts
const intersectMinimum = (baseMin, sourceMin) => {
	if (baseMin === void 0) return sourceMin;
	if (sourceMin === void 0) return baseMin;
	return maxLite(baseMin, sourceMin);
};

//#endregion
//#region src/helpers/schemaIntersection/utils/intersectMultipleOf.ts
const intersectMultipleOf = (baseMultiple, sourceMultiple) => {
	const base = Number.isFinite(baseMultiple) ? baseMultiple : void 0;
	const source = Number.isFinite(sourceMultiple) ? sourceMultiple : void 0;
	if (base === void 0) return source;
	if (source === void 0) return base;
	return lcm(base, source);
};

//#endregion
//#region src/helpers/schemaIntersection/utils/validateRange.ts
const validateRange = (min, max) => min !== void 0 && max !== void 0 && min > max ? EMPTY_INTERSECTION : void 0;

//#endregion
//#region src/core/engine/blueprint/utils/diagnostics/throwBlueprintError.ts
const throwBlueprintError = (code, schemaPath, details = {}, options) => {
	options?.collect?.({
		code,
		level: "error",
		schemaPath,
		details
	});
	throw new JSONSchemaError(code, `${code.slice(code.indexOf(".") + 1)} at ${schemaPath || JSONPointer.Fragment}; ${details.guidance ?? "check the authored schema"}`, {
		schemaPath,
		...details
	});
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/apply/applyConstraintKeywords.ts
const BOUND_KEYWORD_PAIRS = [["minimum", "exclusiveMinimum"], ["maximum", "exclusiveMaximum"]];
const RANGES = [
	["minimum", "maximum"],
	["exclusiveMinimum", "exclusiveMaximum"],
	["minLength", "maxLength"],
	["minItems", "maxItems"],
	["minProperties", "maxProperties"]
];
const applyConstraintKeywords = (state, source, schemaPath, options) => {
	const target = state.schema;
	for (const [bound, exclusive] of BOUND_KEYWORD_PAIRS) {
		if (typeof source[exclusive] !== "boolean") continue;
		const clause = {
			[exclusive]: source[exclusive],
			...source[bound] === void 0 ? {} : { [bound]: source[bound] }
		};
		ownedSchemaValues.add(clause);
		target.allOf = [...isArray(target.allOf) ? target.allOf : [], clause];
		ownedSchemaValues.add(target.allOf);
	}
	for (const [lower, upper] of RANGES) {
		const crossing = (numberValue(source[lower]) !== void 0 || numberValue(source[upper]) !== void 0) && (target[lower] !== void 0 || target[upper] !== void 0);
		const minimum = intersectMinimum(numberValue(target[lower]), numberValue(source[lower]));
		const maximum = intersectMaximum(numberValue(target[upper]), numberValue(source[upper]));
		if (minimum !== void 0) target[lower] = minimum;
		if (maximum !== void 0) target[upper] = maximum;
		if (options.mode === "static" && crossing && validateRange(minimum, maximum) === EMPTY_INTERSECTION) throwBlueprintError(FormErrorCode.InvalidRange, schemaPath, {
			lower,
			upper,
			minimum,
			maximum
		}, options);
	}
	const multipleOf = intersectMultipleOf(numberValue(target.multipleOf), numberValue(source.multipleOf));
	if (multipleOf !== void 0) target.multipleOf = multipleOf;
	const enumeration = intersectEnum(isArray(target.enum) ? target.enum : void 0, isArray(source.enum) ? source.enum : void 0, true);
	if (enumeration === EMPTY_INTERSECTION) {
		if (options.mode === "static") throwBlueprintError(FormErrorCode.EmptyEnumIntersection, schemaPath, {}, options);
		target.enum = [];
		ownedSchemaValues.add(target.enum);
	} else if (enumeration !== void 0) {
		if (enumeration !== target.enum && enumeration !== source.enum) ownedSchemaValues.add(enumeration);
		target.enum = enumeration;
	}
	const constant = intersectConst(target.const, source.const);
	if (constant === EMPTY_INTERSECTION) {
		if (options.mode === "static") throwBlueprintError(FormErrorCode.ConflictingConstValues, schemaPath, {}, options);
		state.conflictingConst = true;
	} else if (constant !== void 0 && !state.conflictingConst) target.const = constant;
	if (state.conflictingConst) {
		delete target.const;
		target.enum = [];
		ownedSchemaValues.add(target.enum);
	}
};
function numberValue(value) {
	return typeof value === "number" ? value : void 0;
}

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/apply/applyControlHints.ts
function applyControlHints(target, source) {
	if (!isObjectRecord(source)) return;
	const controls = { ...target.controls };
	const hints = source;
	if (hints.watch !== void 0) controls.watch = hints.watch;
	if (hints.default !== void 0) controls.default = hints.default;
	if (Object.keys(controls).length) {
		target.controls = controls;
		ownedSchemaValues.add(controls);
	}
}

//#endregion
//#region src/core/engine/blueprint/utils/allowedTypes/intersectAllowedTypes.ts
const intersectAllowedTypes = (left, right) => {
	if (!left) return right;
	if (!right) return left;
	const result = [];
	for (const type of left) {
		const matched = right.includes(type) ? type : type === "number" && right.includes("integer") ? "integer" : type === "integer" && right.includes("number") ? "integer" : void 0;
		if (matched && !result.includes(matched)) result.push(matched);
	}
	return result;
};

//#endregion
//#region src/core/engine/blueprint/utils/allowedTypes/unionAllowedTypes.ts
const unionAllowedTypes = (sets) => {
	const result = [];
	for (const set of sets) for (const type of set) {
		if (type === "integer" && result.includes("number")) continue;
		if (type === "number" && result.includes("integer")) {
			result[result.indexOf("integer")] = "number";
			continue;
		}
		if (!result.includes(type)) result.push(type);
	}
	return result;
};

//#endregion
//#region src/core/engine/blueprint/utils/allowedTypes/readAllowedTypes.ts
const readAllowedTypes = (schema, schemaPath, options) => {
	if (typeof schema === "boolean" || schema.type === void 0) return void 0;
	const values = isArray(schema.type) ? schema.type : [schema.type];
	if (!isAllowedTypeList(values)) return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, {
		type: schema.type,
		guidance: "Specify a nonempty type without duplicate or unknown names."
	}, options);
	const result = [...values];
	if (schema.nullable === true && !result.includes("null")) result.push("null");
	return unionAllowedTypes([result]);
};
const TYPE_NAMES = [
	"string",
	"number",
	"integer",
	"boolean",
	"null",
	"object",
	"array"
];
function isAllowedTypeList(values) {
	return !!values.length && !values.some((value, index) => !TYPE_NAMES.includes(value) || values.indexOf(value) !== index);
}

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/apply/applyTypeContribution.ts
const applyTypeContribution = (state, schema, schemaPath, options) => {
	if (!state.allowedTypes) return;
	state.allowedTypes = intersectAllowedTypes(state.allowedTypes, readAllowedTypes(schema, schemaPath, options));
	if (state.allowedTypes?.length !== 0) return;
	if (options.mode === "static") throwBlueprintError(FormErrorCode.AllOfTypeRedefinition, schemaPath, { guidance: "Static type declarations must have a nonempty intersection." }, options);
	state.conflictingType = true;
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/apply/applySchemaContribution.ts
const CONSTRAINT_KEYS = [
	"enum",
	"const",
	"multipleOf",
	"minimum",
	"maximum",
	"exclusiveMinimum",
	"exclusiveMaximum",
	"minLength",
	"maxLength",
	"minItems",
	"maxItems",
	"minProperties",
	"maxProperties"
];
const applySchemaContribution = (state, declaration, options) => {
	const schema = declaration.schema;
	if (typeof schema === "boolean") return;
	applyTypeContribution(state, schema, declaration.schemaPath, options);
	for (const key of Object.keys(schema)) {
		const value = schema[key];
		if (value === void 0 || key === "type" || key === "nullable" || CONSTRAINT_KEYS.includes(key)) continue;
		if (key === SCHEMA_GROUP.options || key === SCHEMA_GROUP.presentation) state.schema[key] = mergeHintGroup(state.schema[key], value, key === SCHEMA_GROUP.options, options.isAtomic);
		else if (key === SCHEMA_GROUP.controls) {
			if (declaration.scope === "node") applyControlHints(state.schema, value);
		} else if (key === "readOnly") state.schema.readOnly = state.schema.readOnly === true || value === true;
		else if (key === "required" && isArray(value)) {
			const earlier = isArray(state.schema.required) ? state.schema.required : [];
			state.schema.required = [...earlier, ...value.filter((entry, index) => !earlier.includes(entry) && value.indexOf(entry) === index)];
			ownedSchemaValues.add(state.schema.required);
		} else if (key === "pattern" && typeof value === "string") {
			if (!state.patterns.includes(value)) state.patterns.push(value);
		} else if (key === "allOf" && isArray(value)) {
			state.schema.allOf = [...isArray(state.schema.allOf) ? state.schema.allOf : [], ...value];
			ownedSchemaValues.add(state.schema.allOf);
		} else state.schema[key] = value;
	}
	applyConstraintKeywords(state, schema, declaration.schemaPath, options);
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/finalize/freezeEffectiveSchema.ts
const freezeEffectiveSchema = (result) => {
	const schema = result.schema;
	if (typeof schema === "object") {
		const required = schema.required;
		const allOf = schema.allOf;
		const enumeration = schema.enum;
		const controls = schema.controls;
		const options = schema.options;
		const presentation = schema.presentation;
		const type = schema.type;
		if (required && typeof required === "object" && ownedSchemaValues.delete(required)) Object.freeze(required);
		if (allOf && typeof allOf === "object" && ownedSchemaValues.delete(allOf)) Object.freeze(allOf);
		if (enumeration && typeof enumeration === "object" && ownedSchemaValues.delete(enumeration)) Object.freeze(enumeration);
		if (controls && typeof controls === "object" && ownedSchemaValues.delete(controls)) Object.freeze(controls);
		if (options && typeof options === "object" && ownedSchemaValues.delete(options)) Object.freeze(options);
		if (presentation && typeof presentation === "object" && ownedSchemaValues.delete(presentation)) Object.freeze(presentation);
		if (type && typeof type === "object" && ownedSchemaValues.delete(type)) Object.freeze(type);
		if (isArray(allOf)) for (let index = 0; index < allOf.length; index++) {
			const clause = allOf[index];
			if (clause && typeof clause === "object" && ownedSchemaValues.delete(clause)) Object.freeze(clause);
		}
		Object.freeze(schema);
	}
	if (__SCHEMA_FORM_DEV__) Object.freeze(result);
	return result;
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/finalize/finalizeEffectiveSchema.ts
const finalizeEffectiveSchema = (state, node) => {
	const schema = state.schema;
	if (state.patterns.length) {
		schema.pattern = state.patterns[0];
		if (state.patterns.length > 1) {
			const clauses = [...isArray(schema.allOf) ? schema.allOf : []];
			for (let index = 1; index < state.patterns.length; index++) {
				const clause = { pattern: state.patterns[index] };
				ownedSchemaValues.add(clause);
				clauses.push(clause);
			}
			schema.allOf = clauses;
			ownedSchemaValues.add(clauses);
		}
	}
	const types = state.allowedTypes?.filter((type) => type !== "null");
	const staticTypes = isArray(node.schemaType) ? node.schemaType : [node.schemaType];
	const unchanged = types?.length === staticTypes.length && types.every((type, index) => type === staticTypes[index]);
	schema.type = node.kind === "virtual" ? "virtual" : state.conflictingType || unchanged ? node.schemaType : types?.length === 0 ? "null" : types;
	if (schema.type === types && types !== void 0) ownedSchemaValues.add(types);
	if (state.conflictingType) {
		if (node.nullable) schema.nullable = true;
	} else if (node.nullable || state.allowedTypes?.includes("null")) schema.nullable = state.allowedTypes?.includes("null") ?? node.nullable;
	if (state.conflictingConst) {
		schema.enum = [];
		ownedSchemaValues.add(schema.enum);
	}
	return freezeEffectiveSchema({
		schema,
		typeConflict: state.conflictingType
	});
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/merge/mergeSingleStaticContribution.ts
const mergeSingleStaticContribution = (node, declarations, options) => {
	if (options.mode !== "static" || options.isAtomic !== void 0 || options.collect !== void 0 || node.nullable || node.kind === "virtual" || node.declarations.length !== 1 || declarations.length !== 1) return void 0;
	const declaration = declarations[0];
	const source = declaration.schema;
	if (declaration !== node.declarations[0] || declaration.gates.length !== 0 || declaration.context !== "conjunction" || declaration.role !== "declaration" || declaration.scope !== "node" || declaration.validationOnly || typeof source === "boolean" || typeof source.type !== "string" || source.type !== node.schemaType || "nullable" in source || "pattern" in source || SCHEMA_GROUP.options in source || "enum" in source || "const" in source || "multipleOf" in source || "minimum" in source || "maximum" in source || "exclusiveMinimum" in source || "exclusiveMaximum" in source || "minLength" in source || "maxLength" in source || "minItems" in source || "maxItems" in source || "minProperties" in source || "maxProperties" in source) return void 0;
	const schema = {};
	const keys = Object.keys(source);
	for (let index = 0; index < keys.length; index++) {
		const key = keys[index];
		const value = source[key];
		if (value === void 0 || key === "type") continue;
		if (key === SCHEMA_GROUP.controls) applyControlHints(schema, value);
		else if (key === "readOnly") schema.readOnly = value === true;
		else if (key === "required" && isArray(value)) {
			const required = [];
			for (let item = 0; item < value.length; item++) if (item in value && value.indexOf(value[item]) === item) required.push(value[item]);
			schema.required = required;
			ownedSchemaValues.add(required);
		} else if (key === "allOf" && isArray(value)) {
			schema.allOf = [...value];
			ownedSchemaValues.add(schema.allOf);
		} else schema[key] = value;
	}
	schema.type = node.schemaType;
	return freezeEffectiveSchema({
		schema,
		typeConflict: false
	});
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/merge/mergeSchemaContributions.ts
const mergeSchemaContributions = (node, declarations, options) => {
	const single = mergeSingleStaticContribution(node, declarations, options);
	if (single !== void 0) return single;
	const staticTypes = node.schemaType === void 0 ? void 0 : isArray(node.schemaType) ? node.schemaType : [node.schemaType];
	const state = {
		schema: {},
		patterns: [],
		conflictingConst: false,
		conflictingType: false,
		allowedTypes: staticTypes && node.nullable && !staticTypes.includes("null") ? [...staticTypes, "null"] : staticTypes
	};
	for (let index = 0; index < declarations.length; index++) {
		const declaration = declarations[index];
		if (declaration.schema === false) return freezeEffectiveSchema({
			schema: false,
			typeConflict: false
		});
		if (declaration.schema === true) continue;
		applySchemaContribution(state, declaration, options);
	}
	return finalizeEffectiveSchema(state, node);
};

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/merge/selectEffectiveDeclarations.ts
const selectEffectiveDeclarations = (node, activeIds, staticConjunctions) => {
	if (staticConjunctions !== void 0) {
		const selected = [];
		for (let index = 0; index < staticConjunctions.length; index++) {
			const entry = staticConjunctions[index];
			if (!entry.validationOnly && entry.gates.length === 0) selected.push(entry);
		}
		return selected.sort(compareDeclarations);
	}
	const active = node.declarations.filter((entry) => !entry.validationOnly && (entry.gates.length === 0 || activeIds.includes(entry.id)));
	const declarations = active.filter((entry) => entry.role === "declaration");
	return active.filter((entry) => entry.context === "conjunction" || declarations.length === 1 && declarations[0].context === "declaration" && entry === declarations[0]).sort(compareDeclarations);
};
function compareDeclarations(left, right) {
	const length = Math.min(left.order.length, right.order.length);
	for (let index = 0; index < length; index++) {
		const difference = left.order[index] - right.order[index];
		if (difference) return difference;
	}
	return left.order.length - right.order.length || left.id - right.id;
}

//#endregion
//#region src/core/engine/blueprint/effectiveSchema/utils/merge/mergeEffectiveSchema.ts
const DEFAULT_MERGE_OPTIONS = {};
const mergeEffectiveSchema = (node, activeDeclarationIds, options = DEFAULT_MERGE_OPTIONS, memo) => {
	const defaultNoActive = activeDeclarationIds.length === 0 && (options.mode === void 0 || options.mode === "runtime") && options.isAtomic === void 0 && options.collect === void 0 && memo === void 0;
	if (defaultNoActive) {
		const cached = getHostDerived(node).defaultEffectiveSchema;
		if (cached !== void 0) return cached;
	}
	const declarations = selectEffectiveDeclarations(node, activeDeclarationIds);
	const schemas = ensureEffectiveSchemaCache(memo, node, options);
	const key = declarations.map((declaration) => declaration.id).join(",");
	const cached = schemas.get(key);
	if (cached !== void 0) return cached;
	if (memo === void 0 && options.collect === void 0 && options.isAtomic === void 0 && (options.mode === void 0 || options.mode === "runtime") && node.declarations.length === 1 && node.declarations[0].gates.length === 0) {
		const normalized = getHostDerived(node).defaultEffectiveSchema;
		if (normalized !== void 0) {
			schemas.set(key, normalized);
			return normalized;
		}
	}
	const effective = mergeSchemaContributions(node, declarations, options);
	schemas.set(key, effective);
	if (defaultNoActive) getHostDerived(node).defaultEffectiveSchema = effective;
	return effective;
};

//#endregion
//#region src/core/engine/blueprint/utils/analyze/readSchemaObject.ts
const readSchemaObject = (schema) => typeof schema === "boolean" ? {} : schema;

//#endregion
//#region src/core/engine/blueprint/utils/expressions/regex.ts
const IDENTIFIER_CHARS = "a-zA-Z0-9_";
const PATH_PREFIX_CHARS = JSONPointer.Fragment + JSONPointer.Current + JSONPointer.Separator + JSONPointer.Context;
const NOT_PRECEDED_BY_IDENTIFIER_OR_PATH_CHAR = `(?<![${IDENTIFIER_CHARS}${PATH_PREFIX_CHARS}"'\`\\\\])`;
const FOLLOWED_BY_VALID_JS_TOKEN = `(?=\\${JSONPointer.Current}(?![\\${JSONPointer.Separator}\\${JSONPointer.Current}])|[\\[\\]\\)\\}\\s,;:?=!<>&|+\\-*%~^]|$)`;
const BALANCED_BRACKETS = `\\[[^\\s\\(\\)\\[\\]\\{\\}]*\\]`;
const BALANCED_BRACES = `\\{[^\\s\\(\\)\\[\\]\\{\\}]*\\}`;
const CONTINUING_BRACKET = `[\\[\\]\\{\\}](?=[^\\s\\(\\)\\[\\]\\{\\}\\${JSONPointer.Separator}~])`;
const SINGLE_PATH_SEGMENT = `(?:[^\\s\\(\\)\\[\\]\\{\\}\\${JSONPointer.Separator}~]|~[01]|${BALANCED_BRACKETS}|${BALANCED_BRACES}|${CONTINUING_BRACKET})+`;
const MULTI_LEVEL_PATH = `${SINGLE_PATH_SEGMENT}(?:\\${JSONPointer.Separator}${SINGLE_PATH_SEGMENT})*`;
const OPTIONAL_PATH = `(?:${MULTI_LEVEL_PATH})?(?!\\${JSONPointer.Separator})`;
const PARENT_REFERENCES = `(?:\\${JSONPointer.Parent}\\${JSONPointer.Separator})+`;
const FRAGMENT_OR_CURRENT_PREFIX = `(?:\\${JSONPointer.Fragment}|\\${JSONPointer.Current})`;
const CONTEXT_INVALID_PRECEDING_CHARS = `${IDENTIFIER_CHARS}${PATH_PREFIX_CHARS}"'\`\\\\`;
const JSON_POINTER_PATH_REGEX = new RegExp(NOT_PRECEDED_BY_IDENTIFIER_OR_PATH_CHAR + `(?:${FRAGMENT_OR_CURRENT_PREFIX}\\${JSONPointer.Separator}${OPTIONAL_PATH}|` + PARENT_REFERENCES + OPTIONAL_PATH + `|\\${JSONPointer.Separator}${MULTI_LEVEL_PATH}|(?:(?<![${CONTEXT_INVALID_PRECEDING_CHARS}])\\${JSONPointer.Context}|^\\${JSONPointer.Context})${FOLLOWED_BY_VALID_JS_TOKEN}|(?<=\\()\\${JSONPointer.Separator}(?=\\))|(?:(?<![${CONTEXT_INVALID_PRECEDING_CHARS}])\\${JSONPointer.Fragment}|^\\${JSONPointer.Fragment})${FOLLOWED_BY_VALID_JS_TOKEN})`, "g");

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/gates/collectGateEvaluationReads.ts
const collectGateEvaluationReads = (condition) => {
	if (typeof condition !== "string") return Object.freeze([]);
	const reads = [];
	for (const match of condition.matchAll(JSON_POINTER_PATH_REGEX)) {
		const path = match[0];
		const parsed = parsePointer(path);
		if (parsed.segments[0] === PointerOperator.Context) continue;
		if (parsed.absolute) reads.push(resolvePointer("", path));
		else {
			let levels = 0;
			for (const segment of parsed.segments) {
				if (segment !== PointerOperator.Parent) break;
				levels++;
			}
			reads.push(levels);
		}
	}
	return Object.freeze(reads);
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/gates/createBlueprintGate.ts
const createBlueprintGate = (gate) => Object.freeze({
	...gate,
	...gate.appliesWhen === void 0 ? {} : { appliesWhen: Object.freeze([...gate.appliesWhen]) },
	evaluationReads: gate.kind === "active" ? collectGateEvaluationReads(gate.condition) : Object.freeze([])
});

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/children/appendChildEntries.ts
const appendChildEntries = (node, name, path, schemaPath, children, inputs, declarationInputs) => {
	if (children.length > 1) node.hasPropertyCandidates = true;
	const entries = node.childEntries;
	for (let childIndex = 0; childIndex < children.length; childIndex++) {
		const child = children[childIndex];
		const declarations = [];
		for (let index = 0; index < child.declarations.length; index++) {
			const declaration = child.declarations[index];
			const gates = inputs[declarationInputs.get(declaration.id) ?? 0].gates.slice();
			for (let gateIndex = 0; gateIndex < declaration.gates.length; gateIndex++) {
				const gate = declaration.gates[gateIndex];
				if (gate.hostPath === child.path) gates.push(createBlueprintGate({
					...gate,
					hostPath: path
				}));
			}
			const binding = {
				...declaration,
				order: [...declaration.order],
				name,
				path,
				hostPath: node.path,
				schemaPath: declaration.schemaPath === child.schemaPath ? schemaPath : declaration.schemaPath,
				gates
			};
			if (__SCHEMA_FORM_DEV__) {
				Object.freeze(binding.order);
				Object.freeze(gates);
				Object.freeze(binding);
			}
			declarations.push(binding);
		}
		const entry = {
			name,
			node: child,
			hostPath: node.path,
			declarations
		};
		if (__SCHEMA_FORM_DEV__) {
			Object.freeze(declarations);
			Object.freeze(entry);
		}
		entries.push(entry);
	}
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/children/assertAddressableName.ts
const assertAddressableName = (context, declarationSchemaPath, name) => {
	if (!isReservedPercentName(name)) return;
	throwBlueprintError(FormErrorCode.ReservedPropertyName, appendSegment(appendSegment(declarationSchemaPath, "properties"), name), {
		property: name,
		guidance: `Property name "${name}" is not supported: its path reads back as a reserved operator name. Rename the property.`
	}, context.options);
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/references/isBlueprintSchema.ts
const isBlueprintSchema = (value) => typeof value === "boolean" || value !== null && typeof value === "object";

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/references/resolveReference.ts
const resolveReference = (context, reference, schemaPath) => {
	if (stripFragment(reference) === reference) return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, {
		reference,
		guidance: "References must resolve within the authored root."
	}, context.options);
	let pointer;
	let schema;
	try {
		const names = parseStandardPointer(reference);
		pointer = joinPointerWithPrefixOf(reference, names);
		schema = context.schema;
		for (const name of names) {
			if (schema === null || typeof schema !== "object") {
				schema = void 0;
				break;
			}
			schema = hasOwnProperty(schema, name) ? Reflect.get(schema, name) : void 0;
		}
	} catch (cause) {
		return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, {
			reference,
			cause,
			guidance: "The reference must be a valid local schema pointer."
		}, context.options);
	}
	if (!isBlueprintSchema(schema)) return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, {
		reference,
		guidance: "The reference must identify a schema."
	}, context.options);
	return {
		schema,
		schemaPath: pointer
	};
};

//#endregion
//#region src/core/engine/constants/controlKey.ts
const CONTROL_KEY = {
	active: "active",
	visible: "visible",
	readOnly: "readOnly",
	disabled: "disabled",
	default: "default",
	derived: "derived",
	unsetValue: "unsetValue",
	resetInteraction: "resetInteraction",
	unsetOnInactive: "unsetOnInactive",
	inactiveValue: "inactiveValue",
	fields: "fields",
	injectTo: "injectTo",
	discriminator: "discriminator",
	watch: "watch"
};

//#endregion
//#region src/core/engine/blueprint/utils/expressions/expressionControlKeys.ts
const EXPRESSION_CONTROL_KEYS = [
	CONTROL_KEY.active,
	CONTROL_KEY.visible,
	CONTROL_KEY.readOnly,
	CONTROL_KEY.disabled,
	CONTROL_KEY.unsetOnInactive,
	CONTROL_KEY.derived,
	CONTROL_KEY.unsetValue,
	CONTROL_KEY.resetInteraction
];

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/declarations/isLiteralDefault.ts
const isLiteralDefault = (value, active) => {
	if (value === null || typeof value === "string" || typeof value === "boolean") return true;
	if (typeof value === "number") return Number.isFinite(value);
	if (typeof value !== "object") return false;
	const prototype = Object.getPrototypeOf(value);
	if (!isArray(value) && prototype !== Object.prototype && prototype !== null) return false;
	active ?? (active = /* @__PURE__ */ new WeakSet());
	if (active.has(value)) return false;
	active.add(value);
	const keys = Object.keys(value);
	for (let index = 0; index < keys.length; index++) {
		const descriptor = Object.getOwnPropertyDescriptor(value, keys[index]);
		if (!descriptor || !("value" in descriptor) || !isLiteralDefault(descriptor.value, active)) return false;
	}
	active.delete(value);
	return true;
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/declarations/collectSchemaCapabilities.ts
const collectSchemaCapabilities = (context, schema) => {
	const record = readSchemaObject(schema);
	const capabilities = context.capabilities;
	if (context.staticFirstLoad) {
		const fallback = Object.getOwnPropertyDescriptor(record, "default");
		if (fallback && (!("value" in fallback) || fallback.value !== void 0 && !isLiteralDefault(fallback.value))) context.staticFirstLoad = false;
	}
	if (record.oneOf !== void 0 || record.anyOf !== void 0 || record.if !== void 0 || record.then !== void 0 || record.else !== void 0) capabilities.branchless = false;
	if (record.readOnly !== void 0) capabilities.hasState = true;
	const controls = record.controls;
	if (!controls) return;
	if (controls.discriminator !== void 0) capabilities.branchless = false;
	const fields = controls.fields;
	for (let index = -1; index < (isArray(fields) ? fields.length : 0); index++) {
		const group = index < 0 ? controls : fields[index].controls;
		if (!group) continue;
		if (hasOwnProperty(group, CONTROL_KEY.default) || group.unsetValue !== void 0 || group.injectTo !== void 0) context.staticFirstLoad = false;
		if (group.active !== void 0) capabilities.branchless = false;
		if (group.watch !== void 0) capabilities.hasWatch = true;
		if (group.visible !== void 0 || group.readOnly !== void 0 || group.disabled !== void 0) capabilities.hasState = true;
		if (group.derived !== void 0 || group.unsetValue !== void 0 || group.resetInteraction !== void 0 || group.injectTo !== void 0) capabilities.hasDerive = true;
		if (!capabilities.hasExpressions) {
			for (let key = 0; key < EXPRESSION_CONTROL_KEYS.length; key++) if (typeof group[EXPRESSION_CONTROL_KEYS[key]] === "string") {
				capabilities.hasExpressions = true;
				break;
			}
		}
	}
};

//#endregion
//#region src/core/engine/utils/nodeIdentity/foldAllowedTypes.ts
const foldAllowedTypes = (types) => {
	const allowed = typeof types === "string" ? [types] : types ?? [];
	let mask = 0;
	for (const type of allowed) if (type !== "null") mask |= TYPE_MASK[type];
	return mask || TYPE_MASK.null;
};
const TYPE_MASK = {
	string: 1,
	number: 2,
	integer: 2,
	boolean: 4,
	object: 8,
	array: 16,
	null: 32
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/references/collectStaticSchemas.ts
const NO_VISITING$2 = Object.freeze([]);
const collectStaticSchemas = (context, schema, schemaPath, visiting = NO_VISITING$2, cycle) => {
	if (visiting.includes(schemaPath)) {
		if (cycle) cycle.found = true;
		return [];
	}
	const result = [{
		schema,
		schemaPath
	}];
	if (typeof schema === "boolean") return result;
	const stack = [...visiting, schemaPath];
	if (typeof schema.$ref === "string") {
		const target = resolveReference(context, schema.$ref, schemaPath);
		result.push(...collectStaticSchemas(context, target.schema, target.schemaPath, stack, cycle));
	}
	if (isArray(schema.allOf)) schema.allOf.forEach((part, index) => {
		if ((typeof part === "object" && part !== null ? part.controls : void 0)?.active === void 0) result.push(...collectStaticSchemas(context, part, appendSegment(appendSegment(schemaPath, "allOf"), index), stack, cycle));
	});
	return result;
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/nodeTypes/inferLiteralTypes.ts
const inferLiteralTypes = (context, parts, schemaPath) => {
	const values = [];
	let hasLiteral = false;
	for (const part of parts) {
		if (typeof part.schema === "boolean") continue;
		if (hasOwnProperty(part.schema, "const")) {
			values.push(part.schema.const);
			hasLiteral = true;
		}
		if (hasOwnProperty(part.schema, "enum")) {
			hasLiteral = true;
			if (!isArray(part.schema.enum)) return throwBlueprintError(FormErrorCode.UnknownJsonSchema, part.schemaPath, { guidance: "Specify type explicitly for an invalid enum literal." }, context.options);
			values.push(...part.schema.enum);
		}
	}
	if (!hasLiteral) return void 0;
	const types = [];
	for (const value of values) {
		const type = value === null ? "null" : typeof value;
		if (type !== "string" && type !== "number" && type !== "boolean" && type !== "null") return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, { guidance: "Specify type explicitly for an object or array literal." }, context.options);
		if (!types.includes(type)) types.push(type);
	}
	if (types.filter((type) => type !== "null").length === 1 && types.length > 0) return types;
	if (types.length === 1 && types[0] === "null") return types;
	return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, { guidance: "Specify type explicitly for mixed or empty literals." }, context.options);
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/nodeTypes/inferAllowedTypes.ts
const NO_TYPES = Object.freeze([]);
const NO_VISITING$1 = Object.freeze([]);
const BRANCH_KEYWORDS = ["oneOf", "anyOf"];
const inferAllowedTypes = (context, schema, schemaPath, allowTop = false, visiting = NO_VISITING$1, isBranch = false) => {
	if (visiting.includes(schemaPath)) return NO_TYPES;
	const cycle = isBranch ? { found: false } : void 0;
	const parts = collectStaticSchemas(context, schema, schemaPath, NO_VISITING$1, cycle);
	if (isBranch && cycle?.found || parts.some((part) => visiting.includes(part.schemaPath))) return NO_TYPES;
	const stack = [...visiting, ...parts.map((part) => part.schemaPath)];
	let allowed;
	for (const part of parts) {
		allowed = intersectAllowedTypes(allowed, readAllowedTypes(part.schema, part.schemaPath, context.options));
		if (allowed?.length === 0) return throwBlueprintError(FormErrorCode.AllOfTypeRedefinition, part.schemaPath, { schema }, context.options);
	}
	if (allowed) return allowed;
	let inferred;
	let hasUngatedBranch = false;
	for (const keyword of BRANCH_KEYWORDS) {
		const groups = [];
		let hasKeywordBranch = false;
		for (const part of parts) {
			if (typeof part.schema === "boolean") continue;
			const branches = part.schema[keyword];
			if (!isArray(branches)) continue;
			branches.forEach((branch, index) => {
				const path = appendSegment(appendSegment(part.schemaPath, keyword), index);
				if (branch?.controls?.active !== void 0 || context.discriminatorBranches?.has(path)) return;
				hasKeywordBranch = true;
				const types = inferAllowedTypes(context, branch, path, true, stack, true);
				if (!types) return throwBlueprintError(FormErrorCode.UnknownJsonSchema, path, { guidance: "Specify type explicitly for an unconstrained branch." }, context.options);
				if (types.length) groups.push(types);
			});
		}
		if (hasKeywordBranch) {
			hasUngatedBranch = true;
			inferred = intersectAllowedTypes(inferred, unionAllowedTypes(groups));
		}
	}
	if (inferred?.length) {
		const kindMask = foldAllowedTypes(inferred);
		if ((kindMask & 24) !== 0 && kindMask !== 8 && kindMask !== 16) return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, { guidance: "Specify type explicitly for object or array branches mixed with another kind." }, context.options);
		return inferred;
	}
	if (!hasUngatedBranch && !isBranch) {
		const literals = inferLiteralTypes(context, parts, schemaPath);
		if (literals) return literals;
	}
	if (allowTop && inferred === void 0) return void 0;
	return throwBlueprintError(FormErrorCode.UnknownJsonSchema, schemaPath, { guidance: "Specify type explicitly; no nonempty branch union or primitive literal determines this slot." }, context.options);
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/declarations/readDiscriminatorBranches.ts
const UNION_KEYWORDS$1 = ["oneOf", "anyOf"];
const readDiscriminatorBranches = (context, schema, schemaPath) => {
	const host = readSchemaObject(schema);
	const propertyName = host.controls?.discriminator;
	const result = /* @__PURE__ */ new Map();
	if (propertyName === void 0) return result;
	if (typeof propertyName !== "string" || !propertyName.length) return throwBlueprintError(FormErrorCode.InvalidControlShape, appendSegment(appendSegment(schemaPath, "controls"), "discriminator"), {
		group: SCHEMA_GROUP.controls,
		key: "discriminator",
		expected: "string"
	}, context.options);
	for (const keyword of UNION_KEYWORDS$1) {
		if (!isArray(host[keyword])) continue;
		let previousMask;
		const previousValues = [];
		for (let index = 0; index < host[keyword].length; index++) {
			const branch = host[keyword][index];
			const branchPath = appendSegment(appendSegment(schemaPath, keyword), index);
			const parts = collectStaticSchemas(context, branch, branchPath);
			let branchTypes;
			for (const part of parts) branchTypes = intersectAllowedTypes(branchTypes, readAllowedTypes(part.schema, part.schemaPath, context.options));
			if (branchTypes?.every((type) => type === "null")) continue;
			let values;
			let mask;
			for (const part of parts) {
				const property = readSchemaObject(part.schema).properties?.[propertyName];
				if (property === void 0) continue;
				const propertyPath = appendSegment(appendSegment(part.schemaPath, "properties"), propertyName);
				const types = inferAllowedTypes(context, property, propertyPath, true);
				if (types) mask = foldAllowedTypes(types);
				for (const tag of collectStaticSchemas(context, property, propertyPath)) {
					const record = readSchemaObject(tag.schema);
					const restrictions = [record.enum, hasOwnProperty(record, "const") ? [record.const] : void 0];
					for (const restriction of restrictions) {
						if (!isArray(restriction)) continue;
						const intersection = intersectEnum(values, restriction, true);
						if (intersection === EMPTY_INTERSECTION || intersection?.length === 0) return throwBlueprintError(FormErrorCode.EmptyEnumIntersection, tag.schemaPath, { propertyName }, context.options);
						values = intersection;
					}
				}
			}
			if (values === void 0) continue;
			if (mask !== void 0 && previousMask !== void 0 && mask !== previousMask) return throwBlueprintError(FormErrorCode.DiscriminatorMismatch, branchPath, {
				propertyName,
				reason: "kind"
			}, context.options);
			if (values.some((value) => previousValues.some((previous) => equals(previous, value)))) return throwBlueprintError(FormErrorCode.DiscriminatorMismatch, branchPath, {
				propertyName,
				reason: "overlap"
			}, context.options);
			previousMask = mask ?? previousMask;
			previousValues.push(...values);
			result.set(branchPath, Object.freeze({
				propertyName,
				values: Object.freeze([...values])
			}));
		}
	}
	if (!result.size) return throwBlueprintError(FormErrorCode.DiscriminatorMismatch, schemaPath, {
		propertyName,
		reason: "missing"
	}, context.options);
	return result;
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/declarations/validateControlGroups.ts
const CONTROL_GROUPS = [SCHEMA_GROUP.controls, SCHEMA_GROUP.options];
const validateControlGroups = (context, schema, schemaPath, fragment) => {
	const record = readSchemaObject(schema);
	for (const group of CONTROL_GROUPS) {
		const value = record[group];
		if (value === void 0) continue;
		const allowed = group === SCHEMA_GROUP.options ? OPTION_KEYS : fragment ? CHILD_CONTROL_KEYS : CONTROL_KEYS;
		if (!value || typeof value !== "object" || isArray(value)) throwBlueprintError(FormErrorCode.InvalidControlShape, appendSegment(schemaPath, group), {
			group,
			key: group,
			expected: "object"
		}, context.options);
		for (const key of Object.keys(value)) if (!allowed.includes(key)) throwBlueprintError(FormErrorCode.UnknownGroupKey, appendSegment(appendSegment(schemaPath, group), key), {
			group,
			key
		}, context.options);
	}
	const controls = record.controls;
	if (controls && typeof controls === "object" && hasOwnProperty(controls, CONTROL_KEY.inactiveValue)) context.hasInactiveValues = true;
	if (controls?.injectTo !== void 0 && typeof controls.injectTo !== "function") throwBlueprintError(FormErrorCode.InvalidControlShape, appendSegment(appendSegment(schemaPath, "controls"), "injectTo"), {
		group: SCHEMA_GROUP.controls,
		key: "injectTo",
		expected: "function"
	}, context.options);
	if (controls?.fields !== void 0) {
		if (!isArray(controls.fields)) throwBlueprintError(FormErrorCode.InvalidControlShape, appendSegment(appendSegment(schemaPath, "controls"), "fields"), {
			group: SCHEMA_GROUP.controls,
			key: "fields",
			expected: "array"
		}, context.options);
		controls.fields.forEach((entry, index) => {
			const path = appendSegment(appendSegment(appendSegment(schemaPath, "controls"), "fields"), index);
			if (!entry || typeof entry !== "object" || Object.keys(entry).some((key) => key !== "targets" && key !== "controls") || !isArray(entry.targets) || entry.targets.some((name) => typeof name !== "string")) throwBlueprintError(FormErrorCode.InvalidControlShape, path, {
				group: SCHEMA_GROUP.controls,
				key: "fields",
				expected: "{ targets: string[], controls? }"
			}, context.options);
			validateControlGroups(context, { controls: entry.controls }, path, true);
		});
	}
};
const CHILD_CONTROL_KEY_SET = {
	active: true,
	visible: true,
	readOnly: true,
	disabled: true,
	default: true,
	derived: true,
	unsetValue: true,
	resetInteraction: true,
	unsetOnInactive: true,
	inactiveValue: true
};
const CONTROL_KEY_SET = {
	...CHILD_CONTROL_KEY_SET,
	fields: true,
	injectTo: true,
	discriminator: true,
	watch: true
};
const CHILD_CONTROL_KEYS = Object.keys(CHILD_CONTROL_KEY_SET);
const CONTROL_KEYS = Object.keys(CONTROL_KEY_SET);
const OPTION_KEYS = [
	"terminal",
	"virtual",
	"propertyOrder",
	"omitEmpty",
	"omitTrailing",
	"trim"
];

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/declarations/collectDeclarations.ts
const NO_VISITING = Object.freeze([]);
const FRAGMENT_KEYWORDS = [
	["allOf", 1],
	["then", 2],
	["else", 2],
	["oneOf", 3],
	["anyOf", 4]
];
const collectDeclarations = (context, input, path, visiting = NO_VISITING, ownerId, result = []) => {
	if (visiting.includes(input.schemaPath)) return result;
	const schema = readSchemaObject(input.schema);
	validateControlGroups(context, input.schema, input.schemaPath, input.isFragment ?? false);
	readAllowedTypes(input.schema, input.schemaPath, context.options);
	collectSchemaCapabilities(context, input.schema);
	if (input.gates.length || input.context === "declaration") context.capabilities.branchless = false;
	const gates = input.gates.slice();
	if (schema.controls?.active !== void 0 && !gates.some((gate) => gate.schemaPath === appendSegment(appendSegment(input.schemaPath, "controls"), "active"))) gates.push(createBlueprintGate({
		kind: "active",
		schemaPath: appendSegment(appendSegment(input.schemaPath, "controls"), "active"),
		hostPath: path,
		condition: schema.controls.active
	}));
	const fragment = {
		id: context.fragments.length,
		hostPath: path,
		schemaPath: input.schemaPath,
		schema: input.schema,
		context: input.context,
		order: input.order.slice(),
		gates,
		declares: [],
		overlays: [],
		inheritedOverlays: [],
		children: []
	};
	context.fragments.push(fragment);
	input.fragment?.children.push(fragment.id);
	const declaration = {
		id: context.declarationId++,
		name: readFormattedPointerSegment(path, -1) ?? "",
		path,
		schemaPath: input.schemaPath,
		schema: input.schema,
		fragmentId: fragment.id,
		role: input.role,
		scope: input.isFragment ? "fragment" : "node",
		validationOnly: false,
		context: input.context,
		gates: fragment.gates.slice(),
		order: fragment.order.slice(),
		inherited: input.inherited,
		hostPath: input.hostPath
	};
	if (schema.controls?.discriminator !== void 0 || schema.controls?.fields !== void 0) context.hasChildTargets = true;
	if (__SCHEMA_FORM_DEV__) {
		Object.freeze(fragment.order);
		Object.freeze(fragment.gates);
		Object.freeze(declaration.order);
		Object.freeze(declaration.gates);
		Object.freeze(declaration);
	}
	fragment[input.role === "declaration" ? "declares" : "overlays"].push(declaration.id);
	if (input.inherited) fragment.inheritedOverlays.push(declaration.id);
	result.push(declaration);
	const owner = ownerId ?? declaration.id;
	if (!context.capabilities.branchless) (context.declarationOwners ?? (context.declarationOwners = /* @__PURE__ */ new Map())).set(declaration.id, owner);
	const discriminators = schema.controls?.discriminator === void 0 ? void 0 : readDiscriminatorBranches(context, input.schema, input.schemaPath);
	if (discriminators?.size) {
		context.discriminatorBranches ?? (context.discriminatorBranches = /* @__PURE__ */ new Set());
		for (const branchPath of discriminators.keys()) context.discriminatorBranches.add(branchPath);
	}
	if (typeof schema.$ref !== "string" && schema.allOf === void 0 && schema.if === void 0 && schema.oneOf === void 0 && schema.anyOf === void 0) return result;
	const stack = [...visiting, input.schemaPath];
	if (typeof schema.$ref === "string") {
		const target = resolveReference(context, schema.$ref, input.schemaPath);
		collectDeclarations(context, {
			...input,
			...target,
			gates,
			fragment,
			role: "overlay",
			inherited: true
		}, path, stack, owner, result);
	}
	for (let keywordIndex = 0; keywordIndex < FRAGMENT_KEYWORDS.length; keywordIndex++) {
		const [keyword, rank] = FRAGMENT_KEYWORDS[keywordIndex];
		if ((keyword === "then" || keyword === "else") && schema.if === void 0) continue;
		const values = keyword === "then" || keyword === "else" ? [schema[keyword]] : schema[keyword];
		if (!isArray(values)) continue;
		for (let index = 0; index < values.length; index++) {
			const child = values[index];
			if (child === void 0 || child === false) continue;
			const childPath = keyword === "then" || keyword === "else" ? appendSegment(input.schemaPath, keyword) : appendSegment(appendSegment(input.schemaPath, keyword), index);
			const nestedGates = [...gates];
			const discriminator = discriminators?.get(childPath);
			if (discriminator) nestedGates.push(createBlueprintGate({
				kind: "discriminator",
				schemaPath: childPath,
				hostPath: path,
				condition: discriminator
			}));
			if (keyword === "then" || keyword === "else") nestedGates.push(createBlueprintGate({
				kind: "if",
				schemaPath: appendSegment(input.schemaPath, "if"),
				hostPath: path,
				condition: schema.if,
				negated: keyword === "else"
			}));
			const branch = keyword === "oneOf" || keyword === "anyOf";
			const active = readSchemaObject(child).controls?.active;
			const declarationOnly = input.context === "declaration" || branch && active === void 0 && discriminator === void 0;
			collectDeclarations(context, {
				schema: child,
				schemaPath: childPath,
				role: "overlay",
				gates: nestedGates,
				context: declarationOnly ? "declaration" : "conjunction",
				order: [
					...input.order,
					rank,
					keyword === "else" ? 1 : index
				],
				inherited: input.inherited,
				hostPath: path,
				fragment,
				isFragment: true
			}, path, stack, owner, result);
		}
	}
	return result;
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/declarations/copyBlueprintDeclarations.ts
const copyBlueprintDeclarations = (source) => {
	const result = [];
	for (let index = 0; index < source.length; index++) {
		const declaration = source[index];
		const copy = {
			...declaration,
			order: [...declaration.order],
			gates: [...declaration.gates]
		};
		if (__SCHEMA_FORM_DEV__) {
			Object.freeze(copy.order);
			Object.freeze(copy.gates);
			Object.freeze(copy);
		}
		result.push(copy);
	}
	return __SCHEMA_FORM_DEV__ ? Object.freeze(result) : result;
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/nodeTypes/resolveNodeStrategy.ts
const resolveNodeStrategy = (context, kind, declarations) => {
	const count = declarations.filter((declaration) => declaration.role === "declaration").length;
	const relevant = declarations.filter((declaration) => !declaration.validationOnly && (declaration.context === "conjunction" || count === 1 && declaration.role === "declaration"));
	if (kind !== "object" && kind !== "array") {
		const terminal = kind !== "virtual";
		for (const declaration of relevant) {
			const value = readSchemaObject(declaration.schema).options?.terminal;
			if (value !== void 0 && value !== terminal) throwBlueprintError(FormErrorCode.TerminalOptionUnsupported, declaration.schemaPath, {
				type: kind,
				value
			}, context.options);
		}
		return terminal ? "terminal" : "branch";
	}
	const root = {
		children: /* @__PURE__ */ new Map(),
		hasDeclaration: false
	};
	relevant.forEach((declaration, index) => {
		var _current;
		let current = root;
		for (const gate of declaration.gates) {
			const key = JSON.stringify([
				gate.kind,
				gate.schemaPath,
				gate.hostPath,
				gate.negated
			]);
			let child = current.children.get(key);
			if (!child) {
				child = {
					children: /* @__PURE__ */ new Map(),
					hasDeclaration: false
				};
				current.children.set(key, child);
			}
			current = child;
		}
		const explicit = readSchemaObject(declaration.schema).options?.terminal;
		const renderer = context.options.isTerminal?.(declaration.schema);
		if (explicit !== void 0) current.explicit = {
			index,
			value: explicit
		};
		if (renderer !== void 0) current.renderer = {
			index,
			value: renderer
		};
		(_current = current).hasDeclaration || (_current.hasDeclaration = declaration.role === "declaration");
		current.schemaPath = declaration.schemaPath;
	});
	let strategy;
	const pending = [root];
	while (pending.length) {
		const current = pending.pop();
		if (current.hasDeclaration && current.schemaPath !== void 0) {
			const terminal = current.explicit?.value ?? current.renderer?.value ?? false;
			if (strategy !== void 0 && strategy !== terminal) throwBlueprintError(FormErrorCode.TerminalStrategyMismatch, current.schemaPath, { type: kind }, context.options);
			strategy = terminal;
		}
		for (const child of current.children.values()) {
			child.hasDeclaration || (child.hasDeclaration = current.hasDeclaration);
			if ((current.explicit?.index ?? -1) > (child.explicit?.index ?? -1)) child.explicit = current.explicit;
			if ((current.renderer?.index ?? -1) > (child.renderer?.index ?? -1)) child.renderer = current.renderer;
			pending.push(child);
		}
	}
	return strategy ? "terminal" : "branch";
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/children/populateVirtualNodes.ts
const populateVirtualNodes = (context, host) => {
	const groups = /* @__PURE__ */ new Map();
	for (const declaration of host.declarations) {
		const virtual = readSchemaObject(declaration.schema).options?.virtual;
		if (virtual === void 0) continue;
		if (!virtual || typeof virtual !== "object" || isArray(virtual)) throwBlueprintError(FormErrorCode.VirtualFieldsNotValid, appendSegment(appendSegment(declaration.schemaPath, "options"), "virtual"), {}, context.options);
		for (const [name, value] of Object.entries(virtual)) {
			const schema = readSchemaObject(value);
			const schemaPath = appendSegment(appendSegment(appendSegment(declaration.schemaPath, "options"), "virtual"), name);
			const fields = schema.fields;
			if (!isArray(fields) || fields.some((field) => typeof field !== "string") || fields.some((field, index) => fields.indexOf(field) !== index)) throwBlueprintError(FormErrorCode.VirtualFieldsNotValid, schemaPath, { fields }, context.options);
			for (const field of fields) if (!host.childEntries.some((edge) => edge.name === field && edge.node.kind !== "virtual")) throwBlueprintError(FormErrorCode.VirtualFieldsNotInProperties, schemaPath, { field }, context.options);
			const group = groups.get(name);
			if (group && (group.fields.length !== fields.length || group.fields.some((field, index) => field !== fields[index]))) throwBlueprintError(FormErrorCode.VirtualFieldsMismatch, schemaPath, {
				name,
				fields,
				previous: group.fields
			}, context.options);
			const declarations = collectDeclarations(context, {
				schema,
				schemaPath,
				context: declaration.context,
				gates: declaration.gates,
				order: [
					...declaration.order,
					0,
					host.childEntries.length + groups.size
				],
				role: "declaration",
				inherited: declaration.inherited,
				hostPath: host.path,
				fragment: context.fragments[declaration.fragmentId]
			}, appendSegment(host.path, name));
			if (group) group.declarations.push(...declarations);
			else groups.set(name, {
				fields: __SCHEMA_FORM_DEV__ ? Object.freeze([...fields]) : [...fields],
				declarations
			});
		}
	}
	for (const [name, group] of groups) {
		const childEntries = [];
		for (let field = 0; field < group.fields.length; field++) for (let index = 0; index < host.childEntries.length; index++) {
			const edge = host.childEntries[index];
			if (edge.name !== group.fields[field]) continue;
			const copy = {
				...edge,
				declarations: copyBlueprintDeclarations(edge.declarations)
			};
			childEntries.push(__SCHEMA_FORM_DEV__ ? Object.freeze(copy) : copy);
		}
		const node = {
			id: context.nodes.length,
			path: appendSegment(host.path, name),
			schemaPath: group.declarations[0].schemaPath,
			kind: "virtual",
			schemaType: void 0,
			nullable: false,
			strategy: resolveNodeStrategy(context, "virtual", group.declarations),
			declarations: __SCHEMA_FORM_DEV__ ? Object.freeze(group.declarations) : group.declarations,
			childEntries,
			fields: group.fields
		};
		context.nodes.push(node);
		const entry = {
			name,
			node,
			declarations: copyBlueprintDeclarations(node.declarations),
			hostPath: host.path
		};
		host.childEntries.push(__SCHEMA_FORM_DEV__ ? Object.freeze(entry) : entry);
	}
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/children/populateNodeChildren.ts
const populateNodeChildren = (context, node, build) => {
	if (node.kind === "object" && node.declarations.length === 1) {
		const declaration = node.declarations[0];
		const schema = readSchemaObject(declaration.schema);
		if (declaration.context === "conjunction" && declaration.gates.length === 0 && !schema.controls?.fields?.length && schema.properties && typeof schema.properties === "object") {
			const base = {
				context: declaration.context,
				gates: declaration.gates,
				inherited: declaration.inherited,
				hostPath: node.path,
				fragment: context.fragments[declaration.fragmentId],
				role: "declaration"
			};
			const propertiesPath = appendSegment(declaration.schemaPath, "properties");
			const properties = Object.entries(schema.properties);
			for (let index = 0; index < properties.length; index++) {
				const [name, child] = properties[index];
				assertAddressableName(context, declaration.schemaPath, name);
				const path = appendSegment(node.path, name);
				const input = {
					context: base.context,
					gates: base.gates,
					inherited: base.inherited,
					hostPath: base.hostPath,
					fragment: base.fragment,
					role: base.role,
					schema: child,
					schemaPath: rebasePointer(path, node.path, propertiesPath),
					order: [
						...declaration.order,
						0,
						index
					]
				};
				input.gates = [];
				appendChildEntries(node, name, path, input.schemaPath, build(context, [input], path), [input], context.declarationInputs);
			}
			populateVirtualNodes(context, node);
			return;
		}
	}
	const properties = /* @__PURE__ */ new Map();
	const itemInputs = [];
	const tuples = /* @__PURE__ */ new Map();
	const fieldControls = node.declarations.flatMap((owner) => (readSchemaObject(owner.schema).controls?.fields ?? []).map((entry, index) => ({
		entry,
		gate: entry.controls?.active === void 0 ? void 0 : createBlueprintGate({
			kind: "active",
			schemaPath: appendSegment(appendSegment(appendSegment(appendSegment(appendSegment(owner.schemaPath, "controls"), "fields"), index), "controls"), "active"),
			hostPath: node.path,
			condition: entry.controls.active,
			...owner.gates.length ? { appliesWhen: owner.gates } : {}
		})
	})));
	for (const declaration of node.declarations) {
		const schema = readSchemaObject(declaration.schema);
		if (schema.type === "null" || isArray(schema.type) && schema.type.length === 1 && schema.type[0] === "null") continue;
		const base = {
			context: declaration.context,
			gates: declaration.gates,
			inherited: declaration.inherited,
			hostPath: node.path,
			fragment: context.fragments[declaration.fragmentId],
			role: "declaration"
		};
		if (node.kind === "object" && schema.properties && typeof schema.properties === "object") Object.entries(schema.properties).forEach(([name, child], index) => {
			assertAddressableName(context, declaration.schemaPath, name);
			const existing = properties.get(name);
			const path = existing?.path ?? appendSegment(node.path, name);
			const input = {
				...base,
				schema: child,
				schemaPath: rebasePointer(path, node.path, appendSegment(declaration.schemaPath, "properties")),
				order: [
					...declaration.order,
					0,
					index
				]
			};
			const entryGates = fieldControls.filter(({ entry, gate }) => entry.targets.includes(name) && gate !== void 0).map(({ gate }) => gate);
			input.gates = [...input.gates, ...entryGates];
			if (existing) existing.inputs.push(input);
			else properties.set(name, {
				path,
				inputs: [input]
			});
			const discriminatorIndex = input.gates.findIndex((gate) => gate.kind === "discriminator" && gate.condition.propertyName === name);
			if (discriminatorIndex >= 0) properties.get(name).inputs.push({
				...input,
				gates: input.gates.slice(0, discriminatorIndex),
				context: "declaration"
			});
		});
		if (node.kind !== "array") continue;
		const tuple = schema.prefixItems ?? (isArray(schema.items) ? schema.items : void 0);
		if (schema.prefixItems !== void 0 && !isArray(schema.prefixItems)) throwBlueprintError(FormErrorCode.UnexpectedArraySchema, declaration.schemaPath, { prefixItems: schema.prefixItems }, context.options);
		if (tuple) tuple.forEach((child, index) => {
			const input = {
				...base,
				schema: child,
				schemaPath: appendSegment(appendSegment(declaration.schemaPath, schema.prefixItems ? "prefixItems" : "items"), index),
				order: [
					...declaration.order,
					0,
					index
				]
			};
			const existing = tuples.get(index);
			if (existing) existing.push(input);
			else tuples.set(index, [input]);
		});
		if (schema.items !== void 0 && typeof schema.items !== "boolean" && !isArray(schema.items)) {
			if (schema.items === null || typeof schema.items !== "object") throwBlueprintError(FormErrorCode.UnexpectedArraySchema, declaration.schemaPath, { items: schema.items }, context.options);
			itemInputs.push({
				...base,
				schema: schema.items,
				schemaPath: appendSegment(declaration.schemaPath, "items"),
				order: [
					...declaration.order,
					0,
					0
				]
			});
		}
		const additionalItems = isArray(schema.items) && schema.prefixItems === void 0 ? schema.additionalItems : void 0;
		if (additionalItems !== null && typeof additionalItems === "object" && !isArray(additionalItems)) itemInputs.push({
			...base,
			schema: additionalItems,
			schemaPath: appendSegment(declaration.schemaPath, "additionalItems"),
			order: [
				...declaration.order,
				0,
				schema.items.length
			]
		});
	}
	for (const [name, entry] of properties) {
		const { inputs, path } = entry;
		const children = build(context, inputs, path);
		appendChildEntries(node, name, path, inputs[0].schemaPath, children, inputs, context.declarationInputs);
	}
	if (itemInputs.length) {
		const candidates = build(context, itemInputs, joinPointer([...parsePointerSegments(node.path), PointerOperator.Wildcard]));
		node.item = candidates[0];
		if (candidates.length > 1) {
			node.itemCandidates = candidates;
			context.staticFirstLoad = false;
		}
	}
	if (tuples.size) {
		const candidates = [...tuples].sort(([a], [b]) => a - b).map(([index, inputs]) => build(context, inputs, appendSegment(node.path, index)));
		node.prefixItems = candidates.map((items) => items[0]);
		if (candidates.some((items) => items.length > 1)) {
			node.prefixItemCandidates = candidates;
			context.staticFirstLoad = false;
		}
	}
	if (__SCHEMA_FORM_DEV__) {
		if (node.itemCandidates) Object.freeze(node.itemCandidates);
		if (node.prefixItemCandidates) {
			for (const candidates of node.prefixItemCandidates) Object.freeze(candidates);
			Object.freeze(node.prefixItemCandidates);
		}
		if (node.prefixItems) Object.freeze(node.prefixItems);
	}
	if (node.kind === "object") populateVirtualNodes(context, node);
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/nodeTypes/resolveNodeTypes.ts
const resolveNodeTypes = (context, declarations) => {
	const fixed = context.capabilities.branchless ? declarations : declarations.filter((declaration) => declaration.context === "conjunction" && !declaration.gates.length);
	if (fixed.some((declaration) => declaration.role === "declaration")) {
		let allowed;
		for (const declaration of fixed) {
			allowed = intersectAllowedTypes(allowed, readAllowedTypes(declaration.schema, declaration.schemaPath, context.options));
			if (allowed?.length === 0) return throwBlueprintError(FormErrorCode.AllOfTypeRedefinition, declaration.schemaPath, { declarations: fixed.map((item) => item.schemaPath) }, context.options);
		}
		if (!allowed) allowed = inferAllowedTypes(context, fixed[0].schema, fixed[0].schemaPath);
		if (context.capabilities.branchless) return [{
			allowed,
			declarations
		}];
		const mask = foldAllowedTypes(allowed);
		for (const declaration of declarations) {
			if (declaration.context !== "declaration" || declaration.gates.length || declaration.role !== "declaration") continue;
			const types = inferAllowedTypes(context, declaration.schema, declaration.schemaPath, true);
			if (types && (foldAllowedTypes(types) & mask) !== foldAllowedTypes(types)) throwBlueprintError(FormErrorCode.SharedNodeKindConflict, declaration.schemaPath, {
				staticTypes: allowed,
				branchTypes: types
			}, context.options);
		}
		return [{
			allowed,
			declarations
		}];
	}
	const groups = /* @__PURE__ */ new Map();
	let ungatedMask;
	for (const declaration of declarations.filter((item) => item.role === "declaration")) {
		const allowed = inferAllowedTypes(context, declaration.schema, declaration.schemaPath);
		const mask = foldAllowedTypes(allowed);
		if (!declaration.gates.length) {
			if (ungatedMask !== void 0 && ungatedMask !== mask) throwBlueprintError(FormErrorCode.SharedNodeKindConflict, declaration.schemaPath, { types: allowed }, context.options);
			ungatedMask = mask;
		}
		const group = groups.get(mask);
		if (group) {
			group.allowed = unionAllowedTypes([group.allowed, allowed]);
			group.declarations.push(declaration);
		} else groups.set(mask, {
			allowed,
			declarations: [declaration]
		});
	}
	return [...groups.values()].map((group) => ({
		...group,
		declarations: declarations.filter((declaration) => group.declarations.includes(declaration) || declaration.role === "overlay" && group.declarations.some((owner) => context.declarationOwners?.get(declaration.id) === owner.id))
	}));
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/utils/references/getTemplateKey.ts
const CONJUNCTION = {
	key: "\"conjunction\"",
	boundKey: "\\\"conjunction\\\""
};
const DECLARATION = {
	key: "\"declaration\"",
	boundKey: "\\\"declaration\\\""
};
const encodeLeaf = (value) => {
	const key = JSON.stringify(value);
	let boundKey = "\\\"";
	let start = 1;
	for (let index = 1; index < key.length - 1; index++) {
		const code = key.charCodeAt(index);
		if (code === 34 || code === 92) {
			boundKey += key.slice(start, index) + "\\" + key[index];
			start = index + 1;
		}
	}
	boundKey += key.slice(start, -1) + "\\\"";
	return {
		key,
		boundKey
	};
};
const getTemplateKey = (context, inputs) => {
	let key = "[";
	let boundKey = "[\"[";
	let hostPaths = "[";
	for (let index = 0; index < inputs.length; index++) {
		const input = inputs[index];
		const schema = readSchemaObject(input.schema);
		const location = typeof schema.$ref === "string" && Object.keys(schema).length === 1 ? resolveReference(context, schema.$ref, input.schemaPath).schemaPath : input.schemaPath;
		const encoded = encodeLeaf(location);
		const contribution = input.context === "conjunction" ? CONJUNCTION : DECLARATION;
		if (index > 0) {
			key += ",";
			boundKey += ",";
			hostPaths += ",";
		}
		key += "[" + encoded.key + "," + contribution.key + ",[";
		boundKey += "[" + encoded.boundKey + "," + contribution.boundKey + ",[";
		hostPaths += "[";
		const gates = [];
		for (let gateIndex = 0; gateIndex < input.gates.length; gateIndex++) {
			const gate = input.gates[gateIndex];
			if (gateIndex > 0) hostPaths += ",";
			hostPaths += JSON.stringify(gate.hostPath);
			const owners = [];
			const appliesWhen = gate.appliesWhen;
			if (appliesWhen) for (let owner = 0; owner < appliesWhen.length; owner++) {
				const path = appliesWhen[owner].schemaPath;
				if (owners.indexOf(path) === -1) owners.push(path);
			}
			const descriptor = gate.kind + ":" + gate.schemaPath + ":" + Boolean(gate.negated) + ":" + owners.join(",");
			if (gates.indexOf(descriptor) !== -1) continue;
			const encodedGate = encodeLeaf(descriptor);
			if (gates.length > 0) {
				key += ",";
				boundKey += ",";
			}
			key += encodedGate.key;
			boundKey += encodedGate.boundKey;
			gates.push(descriptor);
		}
		key += "]]";
		boundKey += "]]";
		hostPaths += "]";
	}
	key += "]";
	boundKey += "]\"," + hostPaths + "]]";
	return {
		key,
		boundKey
	};
};

//#endregion
//#region src/core/engine/blueprint/buildNodes/buildNodes.ts
const NO_ACTIVE_DECLARATION_IDS$3 = [];
const buildNodes = (context, inputs, path) => {
	const { key, boundKey } = getTemplateKey(context, inputs);
	const cached = context.templates.get(boundKey) ?? context.constructing.get(key);
	if (context.constructing.has(key)) {
		context.staticFirstLoad = false;
		context.hasTemplateRecursion = true;
	}
	if (cached) return cached;
	const declarations = [];
	for (let index = 0; index < inputs.length; index++) {
		const start = declarations.length;
		collectDeclarations(context, inputs[index], path, void 0, void 0, declarations);
		for (let item = start; item < declarations.length; item++) context.declarationInputs.set(declarations[item].id, index);
	}
	const groups = resolveNodeTypes(context, declarations);
	const nodes = [];
	for (let index = 0; index < groups.length; index++) {
		const group = groups[index];
		const nonNull = [];
		let nullable = false;
		for (let type = 0; type < group.allowed.length; type++) {
			const allowed = group.allowed[type];
			if (allowed === "null") nullable = true;
			else nonNull.push(allowed);
		}
		const schemaType = nonNull.length > 1 ? Object.freeze(nonNull) : nonNull[0] ?? "null";
		const kind = isArray(schemaType) ? "union" : schemaType === "integer" ? "number" : schemaType;
		const ownedDeclarations = [];
		const conjunctions = [];
		for (let item = 0; item < group.declarations.length; item++) {
			const declaration = group.declarations[item];
			const owned = declaration.scope === "fragment" && declaration.context === "declaration" && kind !== "object" && kind !== "array" ? {
				...declaration,
				gates: [...declaration.gates],
				order: [...declaration.order],
				validationOnly: true
			} : declaration;
			if (__SCHEMA_FORM_DEV__ && owned !== declaration) {
				Object.freeze(owned.order);
				Object.freeze(owned.gates);
				Object.freeze(owned);
			}
			ownedDeclarations.push(owned);
			if (owned.context === "conjunction") conjunctions.push(owned);
		}
		const node = {
			id: context.nodes.length,
			path,
			schemaPath: inputs[0].schemaPath,
			kind,
			schemaType,
			nullable,
			strategy: resolveNodeStrategy(context, kind, group.declarations),
			declarations: __SCHEMA_FORM_DEV__ ? Object.freeze(ownedDeclarations) : ownedDeclarations,
			childEntries: []
		};
		context.nodes.push(node);
		const effective = mergeSchemaContributions(node, selectEffectiveDeclarations(node, NO_ACTIVE_DECLARATION_IDS$3, conjunctions), {
			mode: "static",
			isAtomic: context.options.isAtomic,
			collect: context.options.collect
		});
		if (ownedDeclarations.length === 1 && ownedDeclarations[0].gates.length === 0 && !node.nullable && context.options.isAtomic === void 0 && context.options.collect === void 0) {
			const declaration = ownedDeclarations[0];
			const schema = declaration.schema;
			if (declaration.context === "conjunction" && declaration.role === "declaration" && declaration.scope === "node" && !declaration.validationOnly && (typeof schema === "boolean" || schema.nullable === void 0 && schema.pattern === void 0 && !isArray(schema.type))) getHostDerived(node).defaultEffectiveSchema = effective;
		}
		nodes.push(node);
	}
	context.templates.set(boundKey, nodes);
	context.constructing.set(key, nodes);
	for (let index = 0; index < nodes.length; index++) {
		const node = nodes[index];
		if (node.strategy === "branch") populateNodeChildren(context, node, buildNodes);
	}
	context.constructing.delete(key);
	return nodes;
};

//#endregion
//#region src/core/engine/blueprint/collectBlueprintWarnings/utils/collectInactiveValueWarnings.ts
const collectInactiveValueWarnings = (controls, schemaPath, emit) => {
	if (!controls || typeof controls !== "object" || isArray(controls)) return;
	if (hasOwnProperty(controls, CONTROL_KEY.inactiveValue) && Reflect.get(controls, "unsetOnInactive") === true) emit({
		code: FormWarningCode.InactiveValueWithUnsetOnInactive,
		level: "warning",
		schemaPath: appendSegment(schemaPath, "controls"),
		details: {}
	});
	const fields = Reflect.get(controls, "fields");
	if (!isArray(fields)) return;
	for (let index = 0; index < fields.length; index++) {
		const field = fields[index];
		if (!field || typeof field !== "object") continue;
		collectInactiveValueWarnings(Reflect.get(field, "controls"), appendSegment(appendSegment(appendSegment(schemaPath, "controls"), "fields"), index), emit);
	}
};

//#endregion
//#region src/core/engine/blueprint/collectBlueprintWarnings/utils/collectInlineTerminalWarnings.ts
const FORM_GROUP_KEYS = [
	SCHEMA_GROUP.controls,
	SCHEMA_GROUP.options,
	SCHEMA_GROUP.presentation
];
const SCHEMA_MAP_KEYWORDS = [
	"properties",
	"patternProperties",
	"$defs",
	"definitions",
	"dependentSchemas"
];
const SCHEMA_LIST_KEYWORDS = [
	"allOf",
	"oneOf",
	"anyOf",
	"prefixItems"
];
const SCHEMA_SINGLE_KEYWORDS = [
	"items",
	"additionalItems",
	"additionalProperties",
	"contains",
	"not",
	"if",
	"then",
	"else",
	"unevaluatedProperties",
	"unevaluatedItems"
];
const collectInlineTerminalWarnings = (node, emit) => {
	const pending = node.declarations.filter((declaration) => declaration.role === "declaration").map(({ schema, schemaPath }) => ({
		schema,
		schemaPath,
		root: true,
		ancestors: []
	}));
	const keys = [];
	const paths = [];
	while (pending.length) {
		const entry = pending.pop();
		if (typeof entry.schema === "boolean" || entry.ancestors.includes(entry.schema)) continue;
		const ancestors = [...entry.ancestors, entry.schema];
		const record = readSchemaObject(entry.schema);
		if (!entry.root) {
			for (const keyword of FORM_GROUP_KEYS) if (record[keyword] !== void 0) {
				if (!keys.includes(keyword)) keys.push(keyword);
				if (!paths.includes(entry.schemaPath)) paths.push(entry.schemaPath);
			}
		}
		for (const keyword of SCHEMA_MAP_KEYWORDS) if (record[keyword] && typeof record[keyword] === "object") for (const [name, child] of Object.entries(record[keyword])) pending.push({
			schema: child,
			schemaPath: appendSegment(appendSegment(entry.schemaPath, keyword), name),
			root: false,
			ancestors
		});
		for (const keyword of SCHEMA_LIST_KEYWORDS) if (isArray(record[keyword])) record[keyword].forEach((child, index) => pending.push({
			schema: child,
			schemaPath: appendSegment(appendSegment(entry.schemaPath, keyword), index),
			root: false,
			ancestors
		}));
		for (const keyword of SCHEMA_SINGLE_KEYWORDS) {
			const child = record[keyword];
			if (isArray(child)) child.forEach((item, index) => pending.push({
				schema: item,
				schemaPath: appendSegment(appendSegment(entry.schemaPath, keyword), index),
				root: false,
				ancestors
			}));
			else if (typeof child === "boolean" || child && typeof child === "object") pending.push({
				schema: child,
				schemaPath: appendSegment(entry.schemaPath, keyword),
				root: false,
				ancestors
			});
		}
	}
	if (keys.length) emit({
		code: FormWarningCode.TerminalSubtreeKeyIgnoredForForm,
		level: "warning",
		schemaPath: node.schemaPath,
		details: {
			keys: __SCHEMA_FORM_DEV__ ? Object.freeze(keys.sort()) : keys.sort(),
			paths: __SCHEMA_FORM_DEV__ ? Object.freeze(paths.sort()) : paths.sort()
		}
	});
};

//#endregion
//#region src/core/engine/blueprint/collectBlueprintWarnings/utils/endsWithBranchIndex.ts
const BRANCH_INDEX = /^\d+$/;
const endsWithBranchIndex = (schemaPath, keywords) => {
	const keyword = readPointerSegment(schemaPath, -2);
	const index = readPointerSegment(schemaPath, -1);
	return typeof keyword === "string" && keywords.includes(keyword) && typeof index === "string" && BRANCH_INDEX.test(index);
};

//#endregion
//#region src/core/engine/blueprint/collectBlueprintWarnings/collectBlueprintWarnings.ts
const IGNORED_DEPENDENCY_KEYWORDS = ["dependentSchemas", "dependencies"];
const ALL_OF_IGNORED_KEYWORDS = [
	"not",
	"dependencies",
	"dependentRequired",
	"dependentSchemas",
	"unevaluatedProperties",
	"unevaluatedItems",
	"contains"
];
const ALL_OF_KEYWORDS = ["allOf"];
const UNION_KEYWORDS = ["oneOf", "anyOf"];
const collectBlueprintWarnings = (blueprint, collect) => {
	if (!collect) return;
	const seen = /* @__PURE__ */ new Set();
	const emit = (diagnostic) => {
		const key = `${diagnostic.code}:${diagnostic.schemaPath}:${diagnostic.details.keyword ?? ""}`;
		if (seen.has(key)) return;
		seen.add(key);
		collect(__SCHEMA_FORM_DEV__ ? Object.freeze(diagnostic) : diagnostic);
	};
	for (const node of blueprint.nodes) {
		if (node.strategy === "terminal") collectInlineTerminalWarnings(node, emit);
		for (const declaration of node.declarations) {
			const schema = readSchemaObject(declaration.schema);
			collectInactiveValueWarnings(schema.controls, declaration.schemaPath, emit);
			const warning = (code, details = {}) => emit({
				code,
				level: "warning",
				schemaPath: declaration.schemaPath,
				details
			});
			for (const keyword of IGNORED_DEPENDENCY_KEYWORDS) if (schema[keyword] !== void 0) warning(FormWarningCode.DependentSchemasIgnoredForForm, { keyword });
			if (endsWithBranchIndex(declaration.schemaPath, ALL_OF_KEYWORDS)) {
				for (const keyword of ALL_OF_IGNORED_KEYWORDS) if (schema[keyword] !== void 0) warning(FormWarningCode.AllOfKeywordIgnoredForForm, { keyword });
			}
			if (node.kind === "object" && node.strategy === "branch" && (schema.readOnly !== void 0 || schema.controls?.readOnly !== void 0 || schema.controls?.disabled !== void 0)) warning(FormWarningCode.LockOnNonTerminalObject);
			if (endsWithBranchIndex(declaration.schemaPath, UNION_KEYWORDS)) {
				if (schema.if !== void 0 && schema.else !== false) warning(FormWarningCode.IfWithoutElseFalse);
				if ((schema.type === "null" || isArray(schema.type) && schema.type.length === 1 && schema.type[0] === "null") && (schema.properties !== void 0 || schema.controls?.active !== void 0)) warning(FormWarningCode.NullBranchIgnoredForForm);
			}
			for (const gate of declaration.gates) {
				if (gate.kind !== "discriminator") continue;
				const descriptor = gate.condition;
				const tag = node.childEntries.find((entry) => entry.name === descriptor.propertyName)?.node;
				if (!tag) continue;
				const allowed = isArray(tag.schemaType) ? tag.schemaType : [tag.schemaType];
				if (descriptor.values.some((value) => value === null ? !tag.nullable : !allowed.includes(isArray(value) ? "array" : typeof value === "number" && Number.isInteger(value) && allowed.includes("integer") ? "integer" : typeof value))) emit({
					code: FormWarningCode.DiscriminatorBranchUnreachable,
					level: "warning",
					schemaPath: gate.schemaPath,
					details: { propertyName: descriptor.propertyName }
				});
			}
		}
	}
};

//#endregion
//#region src/helpers/error/utils/createDivider.ts
const DEFAULT_DIVIDER_WIDTH = 50;
const createDivider = (width = DEFAULT_DIVIDER_WIDTH) => "─".repeat(width);

//#endregion
//#region src/helpers/error/utils/getErrorMessage.ts
const getErrorMessage = (error) => error instanceof Error ? error.message : String(error ?? "Unknown error");

//#endregion
//#region src/helpers/error/formatValidationError/utils/replacePattern.ts
const replacePattern = (errorMessage, details, value) => {
	let message = errorMessage;
	if (details && typeof details === "object") {
		const keys = Object.keys(details);
		for (let i = 0, k = keys[0], l = keys.length; i < l; i++, k = keys[i]) message = message.replace("{" + k + "}", "" + details[k]);
	}
	message = message.replace("{value}", "" + value);
	return message;
};

//#endregion
//#region src/helpers/error/formatValidationError/utils/selectKeywordErrorMessage.ts
const selectKeywordErrorMessage = (keyword, errorMessages, context) => {
	const errorMessage = errorMessages[keyword] || errorMessages.default;
	if (typeof errorMessage === "string") return errorMessage;
	if (errorMessage && typeof errorMessage === "object" && context.locale !== void 0) {
		const localeErrorMessage = errorMessage[context.locale];
		if (typeof localeErrorMessage === "string") return localeErrorMessage;
	}
	return null;
};

//#endregion
//#region src/helpers/error/formatValidationError/formatValidationError.ts
const formatValidationError = (error, node, context) => {
	const errorMessages = node.jsonSchema.presentation?.errorMessages;
	if (!errorMessages || !error.keyword) return error.message;
	const errorMessage = selectKeywordErrorMessage(error.keyword, errorMessages, context);
	if (errorMessage) return replacePattern(errorMessage, error.details, node.value);
	return error.message;
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/createDynamicFunction/utils/formatCreateDynamicFunctionError.ts
const NEWLINE = /\n/g;
const formatCreateDynamicFunctionError = (fieldName, expression, functionBody, error) => {
	const divider = createDivider();
	const errorMessage = getErrorMessage(error);
	return `
Failed to create dynamic function for a controls expression.

  ╭${divider}
  │  Field:       ${fieldName}
  │  Expression:  '${expression}'
  ├${divider}
  │  Generated Function Body:
  │    ${formatMultiLine(functionBody)}
  ├${divider}
  │  Error: ${errorMessage}
  ╰${divider}

The expression could not be compiled into a valid JavaScript function.
This usually indicates a syntax error in the controls expression.

How to fix:
  1. Check the expression syntax for typos or invalid JavaScript
  2. Ensure all JSONPointer paths (e.g., '../fieldName') are valid
  3. Verify that the expression returns a valid value
  4. Check for unbalanced parentheses or brackets
`.trim();
};
const formatMultiLine = (text, prefix = "\n  │    ") => text.replace(NEWLINE, prefix);

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/createDynamicFunction/utils/wrapReturnStatements.ts
const wrapReturnStatements = (body) => body.replace(RETURN_PATTERN, (_, __, ___, expression) => expression ? "return !!(" + expression.trim() + ")" : "return false");
const RETURN_PATTERN = /\breturn([ \t]*)(?:([ \t]+)(.+?))?(?=;|\n|$)/g;

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/createDynamicFunction/utils/getFunctionBody.ts
const getFunctionBody = (expression, coerceToBoolean) => {
	if (expression.startsWith("{") && expression.endsWith("}")) {
		const functionBody = expression.slice(1, -1).trim();
		if (coerceToBoolean) return wrapReturnStatements(functionBody);
		return functionBody;
	}
	return coerceToBoolean ? "return !!(" + expression + ")" : "return " + expression;
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/createDynamicFunction/utils/substituteDependencyPaths.ts
const TRAILING_SEMICOLON = /;$/;
const substituteDependencyPaths = (pathManager, expression) => expression.replace(JSON_POINTER_PATH_REGEX, (path) => {
	pathManager.set(path);
	return "dependencies[" + pathManager.findIndex(path) + "]";
}).trim().replace(TRAILING_SEMICOLON, "");

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/createDynamicFunction/createDynamicFunction.ts
const createDynamicFunction = (pathManager, fieldName, expression, coerceToBoolean = false) => {
	if (typeof expression !== "string") return;
	const processedExpression = substituteDependencyPaths(pathManager, expression);
	if (processedExpression.length === 0) return;
	const functionBody = getFunctionBody(processedExpression, coerceToBoolean);
	try {
		return new Function("dependencies", functionBody);
	} catch (error) {
		throw new JSONSchemaError(FormErrorCode.CreateDynamicFunction, formatCreateDynamicFunctionError(fieldName, expression, functionBody, error), {
			fieldName,
			expression,
			functionBody,
			error
		});
	}
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/getPathManager/getPathManager.ts
const getPathManager = () => {
	const paths = new Array();
	return {
		get: () => paths,
		set: (path) => {
			path = stripFragment(path, true);
			if (!paths.includes(path)) paths.push(path);
		},
		findIndex: (path) => {
			path = stripFragment(path, true);
			return paths.indexOf(path);
		}
	};
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/recognizeEqualityExpression/utils/parseEqualityTree.ts
const parseEqualityTree = (tokens) => {
	const values = [];
	const operators = [];
	let expectsPrimary = true;
	for (const token of tokens) if (token.kind === "reference" || token.kind === "literal") {
		if (!expectsPrimary) return;
		values.push(token);
		expectsPrimary = false;
	} else if (token.kind === "(") {
		if (!expectsPrimary) return;
		operators.push("(");
	} else {
		if (expectsPrimary) return;
		while (operators.length && operators[operators.length - 1] !== "(" && (token.kind === ")" || token.kind === "||" || operators[operators.length - 1] === "===")) {
			const operator = operators.pop();
			const right = values.pop();
			const left = values.pop();
			if (!left || !right || operator === "(") return;
			values.push({
				kind: operator,
				left,
				right
			});
		}
		if (token.kind === ")") {
			if (operators.pop() !== "(") return;
		} else {
			operators.push(token.kind);
			expectsPrimary = true;
		}
	}
	if (expectsPrimary) return;
	while (operators.length) {
		const operator = operators.pop();
		const right = values.pop();
		const left = values.pop();
		if (operator === "(" || !left || !right) return;
		values.push({
			kind: operator,
			left,
			right
		});
	}
	return values.length === 1 ? values[0] : void 0;
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/recognizeEqualityExpression/utils/readEqualityNumber.ts
const readEqualityNumber = (source, start) => {
	let index = start;
	const negative = source[index] === "-";
	if (negative) {
		index++;
		while (index < source.length && source[index].trim() === "") index++;
	}
	const numberStart = index;
	const prefix = source[index + 1]?.toLowerCase();
	if (source[index] === "0" && (prefix === "x" || prefix === "o" || prefix === "b")) {
		const digits = prefix === "x" ? "0123456789abcdef" : prefix === "o" ? "01234567" : "01";
		index += 2;
		const digitStart = index;
		while (index < source.length && digits.includes(source[index].toLowerCase())) index++;
		if (index === digitStart) return;
	} else {
		if (source[index] === "0") {
			index++;
			if (source[index] >= "0" && source[index] <= "9") return;
		} else while (source[index] >= "0" && source[index] <= "9") index++;
		const integerEnd = index;
		if (source[index] === ".") {
			index++;
			const decimalStart = index;
			while (source[index] >= "0" && source[index] <= "9") index++;
			if (integerEnd === numberStart && decimalStart === index) return;
		} else if (integerEnd === numberStart) return;
		if (source[index] === "e" || source[index] === "E") {
			index++;
			if (source[index] === "+" || source[index] === "-") index++;
			const exponentStart = index;
			while (source[index] >= "0" && source[index] <= "9") index++;
			if (exponentStart === index) return;
		}
	}
	const number = Number(source.slice(numberStart, index));
	if (!Number.isFinite(number)) return;
	return {
		value: negative ? -number : number,
		end: index
	};
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/recognizeEqualityExpression/utils/readEqualityString.ts
const SIMPLE_ESCAPES = {
	"\\": "\\",
	"'": "'",
	"\"": "\"",
	b: "\b",
	f: "\f",
	n: "\n",
	r: "\r",
	t: "	",
	v: "\v"
};
const readEqualityString = (source, start) => {
	const quote = source[start];
	let value = "";
	let index = start + 1;
	while (index < source.length) {
		const character = source[index++];
		if (character === quote) return {
			value,
			end: index
		};
		if (character === "\n" || character === "\r" || character === "\u2028" || character === "\u2029") return;
		if (character !== "\\") {
			value += character;
			continue;
		}
		const escape = source[index++];
		const simple = SIMPLE_ESCAPES[escape];
		if (simple !== void 0) {
			value += simple;
			continue;
		}
		if (escape === "0") {
			if (source[index] >= "0" && source[index] <= "9") return;
			value += "\0";
			continue;
		}
		if (escape !== "x" && escape !== "u") return;
		const braced = escape === "u" && source[index] === "{";
		const length = escape === "x" ? 2 : 4;
		if (braced) index++;
		let code = 0;
		let digits = 0;
		while (index < source.length && (braced ? source[index] !== "}" : digits < length)) {
			const character = source[index++].toLowerCase();
			const digit = "0123456789abcdef".indexOf(character);
			if (digit < 0) return;
			code = code * 16 + digit;
			if (code > 1114111) return;
			digits++;
		}
		if (braced) {
			if (digits === 0 || source[index++] !== "}") return;
			value += String.fromCodePoint(code);
		} else {
			if (digits !== length) return;
			value += String.fromCharCode(code);
		}
	}
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/recognizeEqualityExpression/utils/scanEqualityTokens.ts
const scanEqualityTokens = (source) => {
	const tokens = [];
	let index = 0;
	while (index < source.length) {
		const character = source[index];
		if (character.trim() === "") {
			index++;
			continue;
		}
		if (source.startsWith("dependencies[0]", index)) {
			index += 15;
			if (source[index] === "." || source[index] === "[" || source[index] === "(") return;
			tokens.push({ kind: "reference" });
		} else if (source.startsWith("===", index)) {
			tokens.push({ kind: "===" });
			index += 3;
		} else if (source.startsWith("||", index)) {
			tokens.push({ kind: "||" });
			index += 2;
		} else if (character === "(" || character === ")") {
			tokens.push({ kind: character });
			index++;
		} else if (character === "'" || character === "\"") {
			const literal = readEqualityString(source, index);
			if (!literal) return;
			tokens.push({
				kind: "literal",
				value: literal.value
			});
			index = literal.end;
		} else if (character === "-" || character === "." || character >= "0" && character <= "9") {
			const literal = readEqualityNumber(source, index);
			if (!literal) return;
			tokens.push({
				kind: "literal",
				value: literal.value
			});
			index = literal.end;
		} else if (source.startsWith("true", index)) {
			tokens.push({
				kind: "literal",
				value: true
			});
			index += 4;
		} else if (source.startsWith("false", index)) {
			tokens.push({
				kind: "literal",
				value: false
			});
			index += 5;
		} else if (source.startsWith("null", index)) {
			tokens.push({
				kind: "literal",
				value: null
			});
			index += 4;
		} else return;
	}
	return tokens;
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/recognizeEqualityExpression/recognizeEqualityExpression.ts
const recognizeEqualityExpression = (source, dependencies) => {
	const manager = getPathManager();
	const substituted = substituteDependencyPaths(manager, source);
	const paths = manager.get();
	if (paths.length !== 1 || paths.length !== dependencies.length || paths.some((path, index) => path !== dependencies[index])) return;
	const tokens = scanEqualityTokens(substituted);
	if (!tokens) return;
	const tree = parseEqualityTree(tokens);
	if (!tree) return;
	const pending = [tree];
	const literals = [];
	while (pending.length) {
		const node = pending.pop();
		if (node.kind === "||") pending.push(node.right, node.left);
		else if (node.kind === "===") if (node.left.kind === "reference" && node.right.kind === "literal") literals.push(node.right.value);
		else if (node.right.kind === "reference" && node.left.kind === "literal") literals.push(node.left.value);
		else return;
		else return;
	}
	return { literals };
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/utils/hasCompleteExpressionReads.ts
const STRING_LITERAL = /"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'/g;
const KEYWORD_LITERAL = /\b(?:true|false|null|undefined)\b/g;
const FORBIDDEN_EXPRESSION_SYNTAX = /(?:[\d.)]\s*\(|\+\+|--|\/\/|\/\*|(^|[^=!<>])=([^=]|$))/;
const ALLOWED_EXPRESSION_CHARACTERS = /^[\s\d.()+\-*/%<>=!&|?:~]*$/;
const hasCompleteExpressionReads = (source) => {
	const expression = source.replace(JSON_POINTER_PATH_REGEX, "0").replace(STRING_LITERAL, "0").replace(KEYWORD_LITERAL, "0");
	return !FORBIDDEN_EXPRESSION_SYNTAX.test(expression) && ALLOWED_EXPRESSION_CHARACTERS.test(expression);
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/utils/registerBlueprintDependency.ts
const registerBlueprintDependency = (context, path, declaration, schemaPath) => {
	if (typeof path !== "string" || hasPointerOperator(path, PointerOperator.Wildcard)) throwBlueprintError(FormErrorCode.ObservedValues, schemaPath, {
		path,
		guidance: "Dependencies must be strings without wildcard path segments."
	}, context.options);
	const dependencies = context.dependencies ?? (context.dependencies = Object.create(null));
	context.capabilities.hasDependencies = true;
	const ids = dependencies[path] ?? (dependencies[path] = []);
	if (!ids.includes(declaration.id)) ids.push(declaration.id);
};

//#endregion
//#region src/core/engine/blueprint/compileBlueprintExpressions/compileBlueprintExpressions.ts
const compileBlueprintExpressions = (context) => {
	const expressions = [];
	const visited = /* @__PURE__ */ new Set();
	for (let nodeIndex = 0; nodeIndex < context.nodes.length; nodeIndex++) {
		const declarations = context.nodes[nodeIndex].declarations;
		for (let declarationIndex = 0; declarationIndex < declarations.length; declarationIndex++) {
			const declaration = declarations[declarationIndex];
			if (visited.has(declaration.id) || declaration.validationOnly) continue;
			visited.add(declaration.id);
			const controls = readSchemaObject(declaration.schema).controls;
			if (!controls) continue;
			const fields = controls.fields;
			for (let groupIndex = -1; groupIndex < (fields?.length ?? 0); groupIndex++) {
				const groupControls = groupIndex < 0 ? controls : fields[groupIndex].controls;
				if (!groupControls) continue;
				const groupPath = groupIndex < 0 ? appendSegment(declaration.schemaPath, "controls") : appendSegment(appendSegment(appendSegment(appendSegment(declaration.schemaPath, "controls"), "fields"), groupIndex), "controls");
				const watch = groupControls.watch;
				if (watch !== void 0) {
					const paths = isArray(watch) ? watch : [watch];
					for (let path = 0; path < paths.length; path++) registerBlueprintDependency(context, paths[path], declaration, appendSegment(groupPath, "watch"));
				}
				for (let keyIndex = 0; keyIndex < EXPRESSION_CONTROL_KEYS.length; keyIndex++) {
					const key = EXPRESSION_CONTROL_KEYS[keyIndex];
					const source = groupControls[key];
					if (typeof source !== "string") continue;
					const schemaPath = appendSegment(groupPath, key);
					const manager = getPathManager();
					let evaluate;
					try {
						evaluate = key === "derived" ? createDynamicFunction(manager, key, source) : createDynamicFunction(manager, key, source, true);
					} catch (cause) {
						throwBlueprintError(FormErrorCode.CreateDynamicFunction, schemaPath, {
							cause,
							expression: source
						}, context.options);
					}
					if (!evaluate) continue;
					const dependencies = [...manager.get()];
					for (let path = 0; path < dependencies.length; path++) registerBlueprintDependency(context, dependencies[path], declaration, schemaPath);
					const equality = key === "active" && dependencies.length === 1 ? recognizeEqualityExpression(source, dependencies) : void 0;
					const compiled = {
						declarationId: declaration.id,
						schemaPath,
						hostPath: declaration.path,
						key,
						dependencies,
						evaluate,
						...equality ? { equality } : {}
					};
					Object.defineProperty(compiled, "completeReads", { value: (context.capabilities.hasDerive || key === "active") && hasCompleteExpressionReads(source) });
					if (__SCHEMA_FORM_DEV__) {
						Object.freeze(dependencies);
						Object.freeze(compiled);
					}
					expressions.push(compiled);
				}
			}
		}
	}
	if (__SCHEMA_FORM_DEV__ && context.dependencies) for (const ids of Object.values(context.dependencies)) Object.freeze(ids);
	return __SCHEMA_FORM_DEV__ ? Object.freeze(expressions) : expressions;
};

//#endregion
//#region src/core/engine/blueprint/utils/diagnostics/replayBlueprintDiagnostics.ts
function replayBlueprintDiagnostics(entry, collect, gather) {
	if (!collect || entry.collectors.has(collect)) return;
	if (!entry.diagnostics) {
		const diagnostics = [];
		gather(entry.blueprint, (diagnostic) => diagnostics.push(diagnostic));
		entry.diagnostics = __SCHEMA_FORM_DEV__ ? Object.freeze(diagnostics) : diagnostics;
	}
	for (const diagnostic of entry.diagnostics) collect(diagnostic);
	entry.collectors.add(collect);
}

//#endregion
//#region src/core/engine/blueprint/utils/features/collectTemplateParents.ts
const collectTemplateParents = (nodes) => {
	const parents = /* @__PURE__ */ new Map();
	for (const node of nodes) {
		for (const entry of node.childEntries) appendParent(parents, entry.node, node);
		for (const child of node.itemCandidates ?? (node.item ? [node.item] : [])) appendParent(parents, child, node);
		const prefixItems = node.prefixItems;
		if (prefixItems) for (let index = 0; index < prefixItems.length; index++) for (const child of node.prefixItemCandidates?.[index] ?? [prefixItems[index]]) appendParent(parents, child, node);
	}
	return parents;
};
const appendParent = (parents, child, parent) => {
	const previous = parents.get(child);
	if (previous) previous.push(parent);
	else parents.set(child, [parent]);
};

//#endregion
//#region src/core/engine/blueprint/utils/features/markCandidateDescendants.ts
const markCandidateDescendants = (nodes) => {
	let pending;
	for (const node of nodes) if (node.hasPropertyCandidates || node.itemCandidates || node.prefixItemCandidates) {
		node.hasCandidateDescendants = true;
		(pending ?? (pending = [])).push(node);
	}
	if (!pending) return;
	const parents = collectTemplateParents(nodes);
	for (let index = 0; index < pending.length; index++) for (const parent of parents.get(pending[index]) ?? []) {
		let changed = false;
		if (pending[index].hasCandidateDescendants && !parent.hasCandidateDescendants) {
			parent.hasCandidateDescendants = true;
			changed = true;
		}
		if (changed) pending.push(parent);
	}
};

//#endregion
//#region src/core/engine/utils/controls/getFragmentOwnerPaths.ts
const getFragmentOwnerPaths = (schemaPath, segments = parsePointerSegments(schemaPath)) => {
	const owners = [];
	let prefix = "#";
	for (let index = 0; index < segments.length; index++) {
		const name = segments[index];
		if (typeof name !== "string") continue;
		if (name === "items" || name === "additionalItems" || (name === "properties" || name === "prefixItems") && index + 1 < segments.length) owners.push(prefix);
		prefix = appendSegment(prefix, name);
	}
	return owners;
};

//#endregion
//#region src/core/engine/blueprint/utils/features/markInactiveValueNodes.ts
const markInactiveValueNodes = (nodes) => {
	for (const node of nodes) for (const declaration of node.declarations) {
		const schema = declaration.schema;
		if (typeof schema !== "object") continue;
		const controls = schema.controls;
		if (!controls || typeof controls !== "object") continue;
		const own = hasOwnProperty(controls, CONTROL_KEY.inactiveValue);
		if (own && declaration.scope === "node") mark(node);
		const fields = Reflect.get(controls, "fields");
		if (isArray(fields)) for (const field of fields) {
			if (!field || typeof field !== "object") continue;
			const group = Reflect.get(field, "controls");
			const targets = Reflect.get(field, "targets");
			if (!group || typeof group !== "object" || !hasOwnProperty(group, CONTROL_KEY.inactiveValue) || !isArray(targets)) continue;
			for (const entry of node.childEntries) if (targets.includes(entry.name)) mark(entry.node);
		}
		if (!own || declaration.scope === "node") continue;
		const children = [
			...node.childEntries.map((entry) => entry.node),
			...node.itemCandidates ?? (node.item ? [node.item] : []),
			...node.prefixItemCandidates?.flat() ?? node.prefixItems ?? []
		];
		for (const child of children) if (child.declarations.some((candidate) => getFragmentOwnerPaths(candidate.schemaPath).includes(declaration.schemaPath))) mark(child);
	}
};
const mark = (node) => {
	Object.defineProperty(node, "hasInactiveValue", {
		value: true,
		configurable: true
	});
};

//#endregion
//#region src/core/engine/blueprint/utils/features/isKeepControls.ts
const isKeepControls = (controls) => controls !== null && typeof controls === "object" && !isArray(controls) && hasOwnProperty(controls, CONTROL_KEY.unsetOnInactive) && Reflect.get(controls, CONTROL_KEY.unsetOnInactive) !== true;

//#endregion
//#region src/core/engine/blueprint/utils/features/controls/hasKeepFields.ts
const hasKeepFields = (controls) => {
	if (controls === null || typeof controls !== "object") return false;
	const fields = Reflect.get(controls, CONTROL_KEY.fields);
	return isArray(fields) && fields.some((field) => field !== null && typeof field === "object" && isKeepControls(Reflect.get(field, SCHEMA_GROUP.controls)));
};

//#endregion
//#region src/core/engine/blueprint/utils/features/readKeepDeclarations.ts
const readKeepDeclarations = (declarations) => {
	let own = false;
	let child = false;
	for (const declaration of declarations) {
		if (!declaration.schema || typeof declaration.schema !== "object") continue;
		const controls = Reflect.get(declaration.schema, SCHEMA_GROUP.controls);
		if (isKeepControls(controls)) if (declaration.scope === "node") own = true;
		else child = true;
		if (!child && hasKeepFields(controls)) child = true;
	}
	return {
		own,
		child
	};
};

//#endregion
//#region src/core/engine/blueprint/utils/features/markKeepDescendants.ts
const markKeepDescendants = (nodes) => {
	let pending;
	for (const node of nodes) {
		const { own, child } = readKeepDeclarations(node.declarations);
		if (child) node.hasKeepDescendants = true;
		if (own || child) (pending ?? (pending = [])).push(node);
	}
	if (!pending) return;
	const parents = collectTemplateParents(nodes);
	for (let index = 0; index < pending.length; index++) for (const parent of parents.get(pending[index]) ?? []) if (!parent.hasKeepDescendants) {
		parent.hasKeepDescendants = true;
		pending.push(parent);
	}
};

//#endregion
//#region src/core/engine/blueprint/validateChildTargets/validateChildTargets.ts
const validateChildTargets = (context) => {
	for (const node of context.nodes) {
		let discriminator;
		for (const declaration of node.declarations) {
			const controls = readSchemaObject(declaration.schema).controls;
			if (controls?.discriminator !== void 0) {
				if (discriminator !== void 0 && discriminator !== controls.discriminator) throwBlueprintError(FormErrorCode.DiscriminatorMismatch, declaration.schemaPath, {
					propertyName: discriminator,
					other: controls.discriminator,
					reason: "key"
				}, context.options);
				discriminator = controls.discriminator;
			}
			controls?.fields?.forEach((entry, index) => {
				for (const target of entry.targets) if (node.strategy === "terminal" || !node.childEntries.some((edge) => edge.name === target)) throwBlueprintError(FormErrorCode.ChildrenTargetNotFound, appendSegment(appendSegment(appendSegment(declaration.schemaPath, "controls"), "fields"), index), { target }, context.options);
			});
		}
	}
};

//#endregion
//#region src/core/engine/blueprint/validateShape/utils/visitShape.ts
const visitShape = (context, node, complete, active) => {
	if (node.strategy === "terminal" || node.kind === "array" || complete.has(node)) return;
	if (active.has(node)) throwBlueprintError(FormErrorCode.RecursiveShapeUnbounded, node.schemaPath, { path: node.path }, context.options);
	active.add(node);
	for (const edge of node.childEntries) if (edge.declarations.some((declaration) => declaration.role === "declaration" && !declaration.gates.length)) visitShape(context, edge.node, complete, active);
	active.delete(node);
	complete.add(node);
};

//#endregion
//#region src/core/engine/blueprint/validateShape/validateShape.ts
const validateShape = (context) => {
	const complete = /* @__PURE__ */ new Set();
	const active = /* @__PURE__ */ new Set();
	for (const node of context.nodes) visitShape(context, node, complete, active);
};

//#endregion
//#region src/core/engine/blueprint/blueprint.ts
const DEFAULT_BLUEPRINT_OPTIONS = {};
const blueprint = (schema, options = DEFAULT_BLUEPRINT_OPTIONS) => {
	const entries = typeof schema === "object" ? options.cache?.get(schema) : void 0;
	const cached = entries?.find((entry) => entry.isTerminal === options.isTerminal && entry.isAtomic === options.isAtomic);
	if (cached) {
		replayBlueprintDiagnostics(cached, options.collect, collectBlueprintWarnings);
		return cached.blueprint;
	}
	const context = {
		hasChildTargets: false,
		staticFirstLoad: true,
		hasTemplateRecursion: false,
		capabilities: {
			branchless: true,
			hasExpressions: false,
			hasDerive: false,
			hasWatch: false,
			hasState: false,
			hasDependencies: false
		},
		schema,
		options,
		nodes: [],
		fragments: [],
		declarationId: 0,
		declarationOwners: void 0,
		templates: /* @__PURE__ */ new Map(),
		constructing: /* @__PURE__ */ new Map(),
		declarationInputs: /* @__PURE__ */ new Map(),
		dependencies: void 0
	};
	const [root] = buildNodes(context, [{
		schema,
		schemaPath: JSONPointer.Fragment,
		context: "conjunction",
		role: "declaration",
		gates: [],
		order: [],
		inherited: false,
		hostPath: ""
	}], "");
	if (context.hasTemplateRecursion) validateShape(context);
	if (context.hasChildTargets) validateChildTargets(context);
	markCandidateDescendants(context.nodes);
	markKeepDescendants(context.nodes);
	if (context.hasInactiveValues) markInactiveValueNodes(context.nodes);
	const expressions = context.capabilities.hasExpressions || context.capabilities.hasWatch ? compileBlueprintExpressions(context) : [];
	for (let index = 0; index < context.nodes.length; index++) {
		const node = context.nodes[index];
		if (node.kind === "virtual" || node.kind === "union" || (node.kind === "object" || node.kind === "array") && node.strategy !== "branch") context.staticFirstLoad = false;
		if (__SCHEMA_FORM_DEV__) {
			Object.freeze(node.childEntries);
			Object.freeze(node);
		}
	}
	if (__SCHEMA_FORM_DEV__) for (let index = 0; index < context.fragments.length; index++) {
		const fragment = context.fragments[index];
		Object.freeze(fragment.declares);
		Object.freeze(fragment.overlays);
		Object.freeze(fragment.inheritedOverlays);
		Object.freeze(fragment.children);
		Object.freeze(fragment);
	}
	const result = {
		capabilities: context.capabilities,
		isAtomic: options.isAtomic,
		isTerminal: options.isTerminal,
		schema,
		root,
		nodes: context.nodes,
		fragments: context.fragments,
		dependencies: context.dependencies ?? Object.create(null),
		expressions
	};
	Object.defineProperty(result, "staticFirstLoadEligible", { value: context.staticFirstLoad && context.capabilities.branchless && !context.capabilities.hasExpressions && !context.capabilities.hasDerive && !context.capabilities.hasWatch && !context.capabilities.hasState && !context.capabilities.hasDependencies });
	if (__SCHEMA_FORM_DEV__) {
		Object.freeze(context.capabilities);
		Object.freeze(context.nodes);
		Object.freeze(context.fragments);
		Object.freeze(result.dependencies);
		if (!context.capabilities.hasExpressions && !context.capabilities.hasWatch) Object.freeze(expressions);
		Object.freeze(result);
	}
	if (typeof schema === "object" && options.cache) {
		const entry = {
			blueprint: result,
			isTerminal: options.isTerminal,
			isAtomic: options.isAtomic,
			collectors: /* @__PURE__ */ new WeakSet()
		};
		replayBlueprintDiagnostics(entry, options.collect, collectBlueprintWarnings);
		options.cache.set(schema, entries ? [...entries, entry] : [entry]);
	} else collectBlueprintWarnings(result, options.collect);
	return result;
};

//#endregion
//#region src/core/engine/blueprint/StaticFirstLoadCapability/StaticFirstLoadCapability.ts
var StaticFirstLoadCapability = class {
	static has(blueprint) {
		return blueprint.staticFirstLoadEligible === true;
	}
};

//#endregion
//#region src/core/engine/blueprint/utils/features/HostStaticPartition.ts
var HostStaticPartition = class {
	static get(host) {
		const cached = getHostDerived(host).staticPartition;
		if (cached) return cached;
		const names = /* @__PURE__ */ new Map();
		let ambiguous = false;
		for (const entry of host.childEntries) {
			if (names.has(entry.name) || entry.node.kind === "virtual") ambiguous = true;
			names.set(entry.name, 1);
		}
		const staticEntries = ambiguous ? [] : host.childEntries.filter((entry) => entry.declarations.length > 0 && entry.declarations.every((declaration) => !declaration.gates.length) && entry.node.declarations.every((declaration) => !declaration.gates.length));
		const partition = {
			hasGatedOverlays: host.childEntries.some((entry) => {
				const declarations = entry.node.declarations;
				return declarations.some((declaration) => declaration.gates.length === 0) && declarations.some((declaration) => declaration.gates.length > 0);
			}),
			gated: staticEntries.length !== host.childEntries.length || host.declarations.some((declaration) => declaration.gates.length > 0),
			staticEntries
		};
		getHostDerived(host).staticPartition = partition;
		return partition;
	}
};

//#endregion
//#region src/core/engine/blueprint/utils/expressions/CompleteExpressionReads.ts
const CompleteExpressionReads = { has(expression) {
	return expression.completeReads === true;
} };

//#endregion
//#region src/core/engine/blueprint/utils/features/collectDeriveConvergenceTargets.ts
const resolveRead = (host, dependency) => resolvePointer(host, dependency);
const hasWildcardSegment = (path) => hasPointerOperator(path, PointerOperator.Wildcard);
const collectDeriveConvergenceTargets = (blueprint) => {
	if (!blueprint.capabilities.hasDerive) return void 0;
	const nodes = blueprint.nodes;
	const declarations = /* @__PURE__ */ new Map();
	const hosts = /* @__PURE__ */ new Set();
	for (let index = 0; index < nodes.length; index++) {
		const node = nodes[index];
		if (node.item || hasWildcardSegment(node.path)) return void 0;
		if (node.kind === "object" || node.kind === "array" || node.kind === "virtual" || node.kind === "union") hosts.add(node.path);
		for (let child = 0; child < node.childEntries.length; child++) {
			const entry = node.childEntries[child];
			if (entry.node.path !== appendSegment(node.path, entry.name)) return void 0;
		}
		for (let declaration = 0; declaration < node.declarations.length; declaration++) {
			const entry = node.declarations[declaration];
			if (entry.path !== node.path) return void 0;
			declarations.set(entry.id, entry);
		}
	}
	const reads = /* @__PURE__ */ new Set();
	const expressions = blueprint.expressions;
	const gateExpressions = blueprint.capabilities.branchless ? void 0 : /* @__PURE__ */ new Map();
	for (let index = 0; index < expressions.length; index++) {
		const expression = expressions[index];
		if (!CompleteExpressionReads.has(expression)) return void 0;
		if (expression.key === "active" && gateExpressions && !gateExpressions.has(expression.schemaPath)) gateExpressions.set(expression.schemaPath, expression);
		for (let dependency = 0; dependency < expression.dependencies.length; dependency++) {
			const path = expression.dependencies[dependency];
			if (readPointerSegment(path, 0) === PointerOperator.Context) return void 0;
			const read = resolveRead(expression.hostPath, path);
			if (!read || hosts.has(read)) return void 0;
			reads.add(read);
		}
	}
	const dependencies = Object.keys(blueprint.dependencies);
	for (let index = 0; index < dependencies.length; index++) {
		const dependency = dependencies[index];
		if (readPointerSegment(dependency, 0) === PointerOperator.Context) return void 0;
		const owners = blueprint.dependencies[dependency];
		for (let owner = 0; owner < owners.length; owner++) {
			const declaration = declarations.get(owners[owner]);
			if (!declaration) return void 0;
			reads.add(resolveRead(declaration.path, dependency));
		}
	}
	for (let index = 0; index < nodes.length; index++) {
		const node = nodes[index];
		for (let declaration = 0; declaration < node.declarations.length; declaration++) {
			const entry = node.declarations[declaration];
			const controls = typeof entry.schema === "object" ? entry.schema.controls : void 0;
			if (controls && typeof controls === "object") {
				if (typeof Reflect.get(controls, CONTROL_KEY.injectTo) === "function") reads.add(node.path);
				const fields = Reflect.get(controls, CONTROL_KEY.fields);
				if (isArray(fields)) for (let child = 0; child < fields.length; child++) {
					const childControls = fields[child]?.controls;
					if (!childControls || typeof childControls !== "object") continue;
					if (typeof childControls.injectTo === "function") reads.add(node.path);
					const watches = childControls.watch;
					if (watches === void 0) continue;
					const paths = isArray(watches) ? watches : [watches];
					const targets = fields[child].targets;
					if (!isArray(targets)) return void 0;
					for (let target = 0; target < targets.length; target++) {
						const targetPath = appendSegment(node.path, targets[target]);
						for (let watch = 0; watch < paths.length; watch++) {
							if (typeof paths[watch] !== "string" || readPointerSegment(paths[watch], 0) === PointerOperator.Context) return void 0;
							reads.add(resolveRead(targetPath, paths[watch]));
						}
					}
				}
			}
			for (let gateIndex = 0; gateIndex < entry.gates.length; gateIndex++) {
				const gate = entry.gates[gateIndex];
				if (gate.kind !== "active") {
					reads.add(gate.hostPath);
					continue;
				}
				if (typeof gate.condition !== "string") continue;
				const expression = gateExpressions?.get(gate.schemaPath);
				if (!expression && gate.condition.trim()) return void 0;
				if (expression) for (let path = 0; path < expression.dependencies.length; path++) reads.add(resolveRead(gate.hostPath, expression.dependencies[path]));
			}
		}
	}
	const readPaths = [...reads];
	const targets = /* @__PURE__ */ new Set();
	for (let index = 0; index < nodes.length; index++) {
		const node = nodes[index];
		if (hosts.has(node.path)) continue;
		let terminal = true;
		for (let read = 0; read < readPaths.length; read++) {
			const path = readPaths[read];
			if (!path || path === node.path || isDescendantPath(path, node.path) || isDescendantPath(node.path, path)) {
				terminal = false;
				break;
			}
		}
		if (terminal) targets.add(node.path);
	}
	return targets.size ? targets : void 0;
};

//#endregion
//#region src/core/engine/blueprint/utils/features/DeriveConvergenceTargets.ts
var DeriveConvergenceTargets = class {
	static set(blueprint, targets) {
		getBlueprintDerived(blueprint).deriveConvergenceTargets = targets ?? null;
	}
	static get(blueprint) {
		return getBlueprintDerived(blueprint).deriveConvergenceTargets ?? void 0;
	}
	static getOrCollect(blueprint) {
		const cached = getBlueprintDerived(blueprint).deriveConvergenceTargets;
		if (cached !== void 0) return cached ?? void 0;
		const targets = collectDeriveConvergenceTargets(blueprint);
		this.set(blueprint, targets);
		return targets;
	}
};

//#endregion
//#region src/core/engine/utils/emptyReadonlyMap.ts
const EMPTY_ENTRIES$1 = Object.freeze([]);
const emptyReadonlyMap = Object.freeze({
	size: 0,
	get: () => void 0,
	has: () => false,
	forEach: () => void 0,
	entries: () => EMPTY_ENTRIES$1.values(),
	keys: () => EMPTY_ENTRIES$1.values(),
	values: () => EMPTY_ENTRIES$1.values(),
	[Symbol.iterator]: () => EMPTY_ENTRIES$1.values()
});

//#endregion
//#region src/core/engine/utils/emptyReadonlySet.ts
const EMPTY_ENTRIES = Object.freeze([]);
const emptyReadonlySet = Object.freeze({
	size: 0,
	has: () => false,
	forEach: () => void 0,
	entries: () => EMPTY_ENTRIES.values(),
	keys: () => EMPTY_ENTRIES.values(),
	values: () => EMPTY_ENTRIES.values(),
	[Symbol.iterator]: () => EMPTY_ENTRIES.values()
});

//#endregion
//#region src/core/engine/blueprint/utils/features/buildFeatureNodeIndex.ts
const hasStateKeys = (controls) => controls !== null && typeof controls === "object" && !isArray(controls) && (Reflect.get(controls, CONTROL_KEY.visible) !== void 0 || Reflect.get(controls, CONTROL_KEY.readOnly) !== void 0 || Reflect.get(controls, CONTROL_KEY.disabled) !== void 0);
const buildFeatureNodeIndex = (blueprint) => {
	const stateKeyNodes = /* @__PURE__ */ new Set();
	const stateKeyChildren = /* @__PURE__ */ new Map();
	const watchNodes = /* @__PURE__ */ new Set();
	for (const node of blueprint.nodes) {
		const targets = /* @__PURE__ */ new Set();
		const children = [
			...node.childEntries,
			...(node.prefixItems ?? []).flatMap((item, index) => (node.prefixItemCandidates?.[index] ?? [item]).map((child) => ({
				name: String(index),
				node: child,
				declarations: child.declarations
			}))),
			...(node.itemCandidates ?? (node.item ? [node.item] : [])).map((item) => ({
				name: JSONPointer.Wildcard,
				node: item,
				declarations: item.declarations
			}))
		];
		const buildOwners = () => children.map((child) => {
			const paths = /* @__PURE__ */ new Set();
			for (const declaration of child.node.declarations) for (const path of getFragmentOwnerPaths(declaration.schemaPath)) paths.add(path);
			return paths;
		});
		let owners;
		for (const declaration of node.declarations) {
			if (declaration.validationOnly || typeof declaration.schema !== "object") continue;
			const schema = declaration.schema;
			const controls = schema.controls;
			if (schema.readOnly === true || declaration.scope === "node" && hasStateKeys(controls)) stateKeyNodes.add(node.id);
			if (!controls || typeof controls !== "object" || isArray(controls)) continue;
			if (declaration.scope === "node" && Reflect.get(controls, CONTROL_KEY.watch) !== void 0) watchNodes.add(node.id);
			if (declaration.scope === "fragment" && hasStateKeys(controls)) {
				for (let index = 0; index < children.length; index++) if ((owners ?? (owners = buildOwners()))[index].has(declaration.schemaPath)) targets.add(children[index].name);
			}
			const groups = Reflect.get(controls, CONTROL_KEY.fields);
			if (isArray(groups)) for (const group of groups) {
				if (!group || typeof group !== "object" || !hasStateKeys(Reflect.get(group, SCHEMA_GROUP.controls))) continue;
				const names = Reflect.get(group, "targets");
				if (isArray(names)) {
					for (const name of names) if (typeof name === "string") targets.add(name);
				}
			}
		}
		for (const child of children) for (const declaration of child.declarations) {
			if (declaration.validationOnly || declaration.scope !== "node" || typeof declaration.schema !== "object") continue;
			const controls = declaration.schema.controls;
			if (declaration.schema.readOnly === true || hasStateKeys(controls)) stateKeyNodes.add(child.node.id);
			if (controls && typeof controls === "object" && Reflect.get(controls, CONTROL_KEY.watch) !== void 0) watchNodes.add(child.node.id);
		}
		if (targets.size) stateKeyChildren.set(node.id, targets);
	}
	return {
		stateKeyNodes,
		stateKeyChildren,
		watchNodes
	};
};

//#endregion
//#region src/core/engine/blueprint/utils/features/getFeatureNodeIndex.ts
const EMPTY_INDEX$1 = Object.freeze({
	stateKeyNodes: emptyReadonlySet,
	stateKeyChildren: emptyReadonlyMap,
	watchNodes: emptyReadonlySet
});
const getFeatureNodeIndex = (blueprint) => {
	if (!blueprint.capabilities.hasState && !blueprint.capabilities.hasWatch) return EMPTY_INDEX$1;
	let index = getBlueprintDerived(blueprint).featureNodeIndex;
	if (!index) {
		index = buildFeatureNodeIndex(blueprint);
		getBlueprintDerived(blueprint).featureNodeIndex = index;
	}
	return index;
};

//#endregion
//#region src/core/engine/blueprint/utils/itemEntry/getItemSchemaPath.ts
const getItemSchemaPath = (template, index, node) => {
	const prefix = template.prefixItemCandidates?.[index]?.includes(node) ?? template.prefixItems?.[index] === node;
	let fallback;
	for (const declaration of template.declarations) {
		const schema = declaration.schema;
		if (typeof schema !== "object") continue;
		let child;
		let path;
		if (prefix) {
			if (isArray(schema.prefixItems) && index < schema.prefixItems.length) {
				child = schema.prefixItems[index];
				path = appendSegment(appendSegment(declaration.schemaPath, "prefixItems"), index);
			} else if (isArray(schema.items) && index < schema.items.length) {
				child = schema.items[index];
				path = appendSegment(appendSegment(declaration.schemaPath, "items"), index);
			}
		} else {
			if (schema.items !== null && typeof schema.items === "object" && !isArray(schema.items)) {
				child = schema.items;
				path = appendSegment(declaration.schemaPath, "items");
			}
			if (isArray(schema.items) && schema.prefixItems === void 0 && schema.additionalItems !== null && typeof schema.additionalItems === "object" && !isArray(schema.additionalItems)) {
				child = schema.additionalItems;
				path = appendSegment(declaration.schemaPath, "additionalItems");
			}
		}
		if (!path) continue;
		fallback ?? (fallback = path);
		if (node.declarations.some((candidate) => candidate.schema === child)) return path;
	}
	return fallback ?? node.schemaPath;
};

//#endregion
//#region src/core/engine/blueprint/utils/itemEntry/getItemEntries.ts
const getItemEntries = (template, index) => {
	let entries = getHostDerived(template).itemEntries;
	if (!entries) {
		entries = [];
		getHostDerived(template).itemEntries = entries;
	}
	if (index in entries) return entries[index];
	const first = template.prefixItems?.[index] ?? template.item;
	const candidates = template.prefixItems?.[index] ? template.prefixItemCandidates?.[index] ?? [template.prefixItems[index]] : template.itemCandidates ?? (first ? [first] : []);
	const result = [];
	for (const node of candidates) {
		const name = String(index);
		const schemaPath = getItemSchemaPath(template, index, node);
		const declarations = [];
		for (let position = 0; position < node.declarations.length; position++) {
			const declaration = node.declarations[position];
			const binding = {
				...declaration,
				gates: [...declaration.gates],
				order: [...declaration.order],
				name,
				path: node.path,
				hostPath: template.path,
				schemaPath: declaration.schemaPath === node.schemaPath ? schemaPath : declaration.schemaPath
			};
			if (__SCHEMA_FORM_DEV__) {
				Object.freeze(binding.order);
				Object.freeze(binding.gates);
				Object.freeze(binding);
			}
			declarations.push(binding);
		}
		const entry = {
			name,
			node,
			hostPath: template.path,
			declarations
		};
		if (__SCHEMA_FORM_DEV__) {
			Object.freeze(declarations);
			Object.freeze(entry);
		}
		result.push(entry);
	}
	if (__SCHEMA_FORM_DEV__) Object.freeze(result);
	entries[index] = result;
	return result;
};

//#endregion
//#region src/core/engine/blueprint/utils/itemEntry/getItemEntry.ts
const getItemEntry = (template, index) => getItemEntries(template, index)[0];

//#endregion
//#region src/core/engine/utils/paths/getCachedPointerSegments.ts
const POINTER_SEGMENT_LIMIT = 256;
const getCachedPointerSegments = (runtime, path) => {
	const derived = getHostDerived(runtime);
	const cache = derived.pointerSegments ?? (derived.pointerSegments = /* @__PURE__ */ new Map());
	let segments = cache.get(path);
	if (segments === void 0) {
		segments = parsePointerSegments(path);
		if (cache.size === POINTER_SEGMENT_LIMIT) {
			const oldest = cache.keys().next();
			if (!oldest.done) cache.delete(oldest.value);
		}
		cache.set(path, segments);
	}
	return segments;
};

//#endregion
//#region src/core/engine/settle/utils/templatePaths/expandTemplatePaths.ts
const expandTemplatePaths = (root, templatePath, preparedSegments) => {
	if (!hasPointerOperator(templatePath, PointerOperator.Wildcard)) return [templatePath];
	const segments = preparedSegments ?? getCachedPointerSegments(root.runtime, templatePath);
	const paths = [];
	const pending = [{
		node: root,
		depth: 0,
		path: ""
	}];
	while (pending.length) {
		const current = pending.pop();
		if (!current) continue;
		const { node, depth, path } = current;
		if (depth === segments.length) {
			paths.push(path);
			continue;
		}
		if (!node) continue;
		const segment = segments[depth];
		if (segment === PointerOperator.Wildcard && node.blueprintNode.item !== void 0) {
			for (let index = node.itemCount - 1; index >= 0; index--) {
				const name = String(index);
				const child = node.structure?.[name];
				if (depth + 1 === segments.length || child) pending.push({
					node: child,
					depth: depth + 1,
					path: appendSegment(path, name)
				});
			}
			continue;
		}
		const name = segment;
		if (typeof name !== "string") continue;
		const structure = node.structure;
		const child = structure && hasOwnProperty(structure, name) ? structure[name] : void 0;
		if (depth + 1 === segments.length || child) pending.push({
			node: child,
			depth: depth + 1,
			path: appendSegment(path, name)
		});
	}
	return paths;
};

//#endregion
//#region src/core/engine/utils/controls/getControlExpression.ts
const getControlExpression = (blueprint, declarationId, schemaPath, key) => {
	let expressions = getBlueprintDerived(blueprint).controlExpressions;
	if (!expressions) {
		expressions = new Map(blueprint.expressions.map((expression, index) => [JSON.stringify([
			expression.declarationId,
			expression.schemaPath,
			expression.key
		]), index]));
		getBlueprintDerived(blueprint).controlExpressions = expressions;
	}
	const index = expressions.get(JSON.stringify([
		declarationId,
		schemaPath,
		key
	]));
	return index === void 0 ? void 0 : blueprint.expressions[index];
};

//#endregion
//#region src/core/engine/derive/utils/rules/getWatchPaths.ts
const getWatchPaths = (node) => {
	const cached = getHostDerived(node).watchPaths;
	if (cached) return cached;
	const watches = [];
	for (const declaration of node.declarations) {
		const schema = declaration.schema;
		const controls = schema && typeof schema === "object" ? Reflect.get(schema, SCHEMA_GROUP.controls) : void 0;
		const watch = controls && typeof controls === "object" ? Reflect.get(controls, CONTROL_KEY.watch) : void 0;
		for (const path of isArray(watch) ? watch : []) if (typeof path === "string" && !watches.includes(path)) watches.push(path);
	}
	getHostDerived(node).watchPaths = watches;
	return watches;
};

//#endregion
//#region src/core/engine/derive/utils/rules/getDeriveRuleTable.ts
const EMPTY_TABLE = Object.freeze({
	rules: Object.freeze([]),
	byDeclaration: emptyReadonlyMap
});
const RULE_KEYS = [
	CONTROL_KEY.derived,
	CONTROL_KEY.unsetValue,
	CONTROL_KEY.resetInteraction,
	CONTROL_KEY.injectTo
];
const getDeriveRuleTable = (blueprint) => {
	if (!blueprint.capabilities.hasDerive) return EMPTY_TABLE;
	const cached = getBlueprintDerived(blueprint).deriveRuleTable;
	if (cached) return cached;
	const rules = [];
	const byDeclaration = /* @__PURE__ */ new Map();
	for (const node of blueprint.nodes) for (const declaration of node.declarations) {
		const schema = declaration.schema;
		const controls = schema && typeof schema === "object" ? Reflect.get(schema, SCHEMA_GROUP.controls) : void 0;
		if (!controls || typeof controls !== "object" || isArray(controls)) continue;
		const groups = [];
		const hasOwnRules = Reflect.get(controls, CONTROL_KEY.derived) !== void 0 || Reflect.get(controls, CONTROL_KEY.unsetValue) !== void 0 || Reflect.get(controls, CONTROL_KEY.resetInteraction) !== void 0 || Reflect.get(controls, CONTROL_KEY.injectTo) !== void 0;
		if (hasOwnRules && declaration.scope === "fragment") {
			const targets = [
				...node.childEntries,
				...(node.prefixItems ?? []).flatMap((first, index) => (node.prefixItemCandidates?.[index] ?? [first]).map((item) => ({
					name: String(index),
					node: item,
					declarations: item.declarations
				}))),
				...(node.itemCandidates ?? (node.item ? [node.item] : [])).map((item) => ({
					items: true,
					node: item,
					declarations: item.declarations
				}))
			];
			for (const entry of targets) {
				const selected = entry.declarations.filter((child) => getFragmentOwnerPaths(child.schemaPath).includes(declaration.schemaPath));
				if (selected.length) groups.push({
					controls,
					schemaPath: appendSegment(declaration.schemaPath, "controls"),
					layer: "fragment",
					targetName: entry.name,
					targetItems: entry.items,
					targetDeclarationIds: selected.map((child) => child.id),
					targetNodes: [entry.node]
				});
			}
		} else if (hasOwnRules) groups.push({
			controls,
			schemaPath: appendSegment(declaration.schemaPath, "controls"),
			layer: "node",
			targetNodes: [node]
		});
		const fields = Reflect.get(controls, CONTROL_KEY.fields);
		if (isArray(fields)) for (let index = 0; index < fields.length; index++) {
			const item = fields[index];
			if (!item || typeof item !== "object") continue;
			const itemControls = Reflect.get(item, SCHEMA_GROUP.controls);
			const names = Reflect.get(item, "targets");
			if (!itemControls || typeof itemControls !== "object" || !isArray(names)) continue;
			for (const name of names) {
				if (typeof name !== "string") continue;
				const targets = node.childEntries.filter((entry) => entry.name === name);
				if (targets.length) groups.push({
					controls: itemControls,
					schemaPath: appendSegment(appendSegment(appendSegment(appendSegment(declaration.schemaPath, "controls"), "fields"), index), "controls"),
					layer: "fields",
					targetName: name,
					targetNodes: targets.map((target) => target.node)
				});
			}
		}
		for (const group of groups) for (const kind of RULE_KEYS) {
			const literal = Reflect.get(group.controls, kind);
			if (literal === void 0) continue;
			const schemaPath = appendSegment(group.schemaPath, kind);
			const expression = getControlExpression(blueprint, declaration.id, schemaPath, kind);
			if (typeof literal === "string" && !expression) continue;
			if (kind === "injectTo" && typeof literal !== "function") continue;
			const dependencies = [...expression?.dependencies ?? []];
			const watchDependencies = [];
			if (kind === "derived") for (const targetNode of group.targetNodes) for (const watch of getWatchPaths(targetNode)) {
				if (!watchDependencies.includes(watch)) watchDependencies.push(watch);
				if (!dependencies.includes(watch)) dependencies.push(watch);
			}
			const rule = {
				declarationId: declaration.id,
				kind,
				schemaPath,
				layer: group.layer,
				targetName: group.targetName,
				targetItems: group.targetItems,
				targetDeclarationIds: group.targetDeclarationIds,
				dependencies,
				watchDependencies,
				expression,
				literal,
				order: rules.length
			};
			rules.push(rule);
			const owned = byDeclaration.get(declaration.id) ?? [];
			owned.push(rule);
			byDeclaration.set(declaration.id, owned);
		}
	}
	const table = {
		rules,
		byDeclaration
	};
	getBlueprintDerived(blueprint).deriveRuleTable = table;
	return table;
};

//#endregion
//#region src/core/engine/utils/compute/sameValue.ts
const sameValue = (left, right) => {
	if (left === right || Number.isNaN(left) && Number.isNaN(right)) return true;
	if (left === null || right === null || typeof left !== "object" || typeof right !== "object" || isArray(left) !== isArray(right)) return false;
	if (isArray(left) && isArray(right)) {
		if (left.length !== right.length) return false;
		for (let index = 0; index < left.length; index++) if (!sameValue(left[index], right[index])) return false;
		return true;
	}
	if (!isArray(left)) {
		const prototype = Object.getPrototypeOf(left);
		if (prototype !== Object.getPrototypeOf(right) || prototype !== Object.prototype && prototype !== null) return false;
	}
	const leftKeys = Object.keys(left);
	const rightKeys = Object.keys(right);
	if (leftKeys.length !== rightKeys.length) return false;
	for (let index = 0; index < leftKeys.length; index++) {
		const key = leftKeys[index];
		if (key !== rightKeys[index] || !sameValue(Reflect.get(left, key), Reflect.get(right, key))) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/utils/nodeIdentity/getBlueprintNodeIdentity.ts
const getBlueprintNodeIdentity = (node) => {
	if (node.kind !== "union") return node.kind;
	return "union:" + foldAllowedTypes(node.schemaType);
};

//#endregion
//#region src/core/engine/derive/utils/evaluate/addActiveRuleKey.ts
const addActiveRuleKey = (state, sourcePath, key) => {
	state.activeRuleKeys.add(key);
	let sourceKeys = state.activeRuleKeysBySource.get(sourcePath);
	if (!sourceKeys) {
		sourceKeys = /* @__PURE__ */ new Set();
		state.activeRuleKeysBySource.set(sourcePath, sourceKeys);
	}
	sourceKeys.add(key);
};

//#endregion
//#region src/core/engine/utils/paths/resolveDependencyPath.ts
const resolveDependencyPath = (hostPath, dependency) => {
	return resolvePointer(hostPath, dependency);
};

//#endregion
//#region src/core/engine/derive/utils/evaluate/readDeriveDependency.ts
const readDeriveDependency = (root, hostPath, dependency) => {
	const segments = parsePointerSegments(resolveDependencyPath(hostPath, dependency));
	if (segments[0] === PointerOperator.Context) return root.runtime.context;
	let value = root.emit;
	for (const name of segments) {
		if (value === null || typeof value !== "object") return void 0;
		if (typeof name !== "string") return void 0;
		if (!hasOwnProperty(value, name)) return void 0;
		value = Reflect.get(value, name);
	}
	return value;
};

//#endregion
//#region src/core/engine/derive/utils/evaluate/evaluateScopedExpression.ts
const evaluateScopedExpression = (root, host, rule, cache) => {
	if (!rule.expression) return {
		value: rule.literal,
		threw: false
	};
	const key = JSON.stringify([host.path, rule.schemaPath]);
	const cached = cache.get(key);
	if (cached) return cached;
	let result;
	try {
		result = {
			value: rule.expression.evaluate(rule.expression.dependencies.map((dependency) => readDeriveDependency(root, host.path, dependency))),
			threw: false
		};
	} catch (cause) {
		result = {
			value: void 0,
			threw: true,
			cause
		};
	}
	cache.set(key, result);
	return result;
};

//#endregion
//#region src/core/engine/derive/utils/evaluate/getDeriveSourceNodes.ts
const getDeriveSourceNodes = (root, state) => {
	if (!state.sourcePaths) return [root];
	const nodes = [];
	const seen = /* @__PURE__ */ new Set();
	for (const path of state.sourcePaths) {
		let node = root;
		for (const name of parsePointerSegments(path)) {
			if (typeof name !== "string") {
				node = void 0;
				break;
			}
			const children = node?.structure ?? null;
			node = children && hasOwnProperty(children, name) ? children[name] : void 0;
			if (!node) break;
		}
		if (node && !seen.has(node)) {
			seen.add(node);
			nodes.push(node);
		}
	}
	return nodes;
};

//#endregion
//#region src/core/engine/utils/controls/getCommittedDeclarationKey.ts
const getCommittedDeclarationKey = (node, runtime) => {
	const path = node.path;
	const kind = getBlueprintNodeIdentity(node.blueprintNode);
	const cached = runtime.committedDeclarationKeys?.get(node);
	if (cached?.path === path && cached.kind === kind) return cached.key;
	const key = JSON.stringify([path, kind]);
	(runtime.committedDeclarationKeys ?? (runtime.committedDeclarationKeys = /* @__PURE__ */ new WeakMap())).set(node, {
		path,
		kind,
		key
	});
	return key;
};

//#endregion
//#region src/core/engine/derive/utils/evaluate/getSelectedDeclarationIds.ts
const getSelectedDeclarationIds = (node, state) => state.selectedDeclarationIds.get(node) ?? node.runtime.committedDeclarationIds?.get(getCommittedDeclarationKey(node, node.runtime)) ?? node.blueprintNode.declarations.map((declaration) => declaration.id);

//#endregion
//#region src/core/engine/derive/utils/evaluate/getRuleTargets.ts
const NO_TARGETS = Object.freeze([]);
const getRuleTargets = (source, rule, state) => {
	if (rule.targetName === void 0 && !rule.targetItems) return [source];
	const children = source.structure;
	return (rule.targetItems ? source.children ?? NO_TARGETS : children && rule.targetName !== void 0 && hasOwnProperty(children, rule.targetName) ? [children[rule.targetName]] : NO_TARGETS).filter((target) => !target.detached && (rule.layer !== "fragment" || !rule.targetDeclarationIds || rule.targetDeclarationIds.some((id) => getSelectedDeclarationIds(target, state).includes(id))));
};

//#endregion
//#region src/core/engine/derive/utils/rules/getDeriveRuleKey.ts
let nextTargetId = 0;
const getDeriveRuleKey = (path, kind, rule, target, runtime) => {
	const TARGET_IDS = runtime.deriveTargetIds ?? (runtime.deriveTargetIds = /* @__PURE__ */ new WeakMap());
	let targetId = TARGET_IDS.get(target);
	if (targetId === void 0) {
		targetId = ++nextTargetId;
		TARGET_IDS.set(target, targetId);
	}
	return JSON.stringify([
		path,
		kind,
		rule.declarationId,
		rule.schemaPath,
		rule.targetName,
		target.path,
		getBlueprintNodeIdentity(target.blueprintNode),
		targetId
	]);
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/rank/getDeriveChildEntry.ts
const getDeriveChildEntry = (parent, name, template) => {
	let index = getHostDerived(parent).deriveChildren;
	if (!index) {
		const built = /* @__PURE__ */ new Map();
		parent.childEntries.forEach((entry, position) => {
			const positions = built.get(entry.name) ?? [];
			positions.push(position);
			built.set(entry.name, positions);
		});
		index = built;
		getHostDerived(parent).deriveChildren = index;
	}
	const positions = index.get(name);
	const position = template ? positions?.find((candidate) => parent.childEntries[candidate].node === template) : positions?.[0];
	return position === void 0 ? void 0 : {
		entry: parent.childEntries[position],
		position
	};
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/rank/getDeriveSourceOrder.ts
const getDeriveSourceOrder = (source) => {
	const order = [];
	let node = source;
	while (node?.parent) {
		const current = node;
		const parent = current.parent;
		if (!parent) break;
		const found = getDeriveChildEntry(parent.blueprintNode, current.name, current.blueprintNode);
		order.unshift(found?.position ?? (Number(current.name) || 0));
		node = parent;
	}
	return order;
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/rank/kindRank.ts
const KIND_RANK = {
	unsetValue: 4,
	derived: 3,
	injectTo: 2,
	fill: 1
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/rank/layerRank.ts
const LAYER_RANK = {
	fragment: 1,
	fields: 2,
	node: 3
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/writes/getVirtualWriteFailure.ts
const getVirtualWriteFailure = (sourcePath, schemaPath, targetPath, template, value) => {
	if (template.kind !== "virtual" || value === void 0 || isArray(value) && value.length === template.fields?.length) return void 0;
	return {
		sourcePath,
		schemaPath,
		targetPath,
		cause: value,
		kind: "writeShape",
		expectedLength: template.fields?.length
	};
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/inject/getInjectEntries.ts
const NO_ENTRIES = Object.freeze([]);
const getInjectEntries = (result) => {
	if (result === null || result === void 0) return NO_ENTRIES;
	if (!isArray(result)) return typeof result === "object" ? Object.entries(result) : NO_ENTRIES;
	const entries = [];
	for (const row of result) if (isArray(row) && typeof row[0] === "string") entries.push([row[0], row[1]]);
	return entries;
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/inject/getInjectTarget.ts
const getInjectTarget = (root, path) => {
	const segments = parsePointerSegments(path);
	if (segments[0] === PointerOperator.Context) return void 0;
	let template = root.blueprintNode;
	let live = root;
	let siblings = template.childEntries;
	const order = [];
	for (const name of segments) {
		if (template.strategy !== "branch") return void 0;
		if (typeof name !== "string") return void 0;
		siblings = template.childEntries;
		const index = Number(name);
		const items = template.kind === "array" && Number.isInteger(index) && index >= 0 && String(index) === name ? getItemEntries(template, index) : void 0;
		const selected = live?.structure?.[name]?.blueprintNode;
		const item = items?.find((entry) => entry.node === selected) ?? items?.[0];
		if (items) siblings = items;
		const found = item ? {
			entry: item,
			position: index
		} : getDeriveChildEntry(template, name);
		if (!found) return void 0;
		order.push(found.position);
		const structure = live?.structure ?? null;
		live = structure && hasOwnProperty(structure, name) ? structure[name] : void 0;
		template = live?.blueprintNode ?? found.entry.node;
	}
	return {
		target: live,
		template: live?.blueprintNode ?? template,
		siblings,
		order
	};
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/inject/getInjectToContext.ts
const getInjectToContext = (source, root) => ({
	dataPath: source.path,
	schemaPath: source.blueprintNode.schemaPath,
	jsonSchema: source.schema.schema,
	parentValue: source.parent ? source.parent.emit : null,
	parentJSONSchema: source.parent ? source.parent.schema.schema : null,
	rootValue: root.emit,
	rootJSONSchema: root.schema.schema,
	context: root.runtime.context
});

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/inject/evaluateInjectTo.ts
const NO_INJECT_WRITES = Object.freeze({ writes: Object.freeze([]) });
const evaluateInjectTo = (source, root, rule) => {
	if (typeof rule.literal !== "function") return NO_INJECT_WRITES;
	let result;
	try {
		result = rule.literal(source.emit, getInjectToContext(source, root));
	} catch (cause) {
		return {
			writes: [],
			failure: {
				sourcePath: source.path,
				schemaPath: rule.schemaPath,
				cause,
				kind: "expression"
			}
		};
	}
	const writes = [];
	const entries = getInjectEntries(result);
	for (let index = 0; index < entries.length; index++) {
		const [relative, value] = entries[index];
		if (value === void 0) continue;
		const targetPath = resolveDependencyPath(source.path, relative);
		const resolved = getInjectTarget(root, targetPath);
		if (!resolved) return {
			writes: [],
			failure: {
				sourcePath: source.path,
				schemaPath: rule.schemaPath,
				cause: relative,
				kind: "injectTarget",
				targetPath
			}
		};
		const invalid = getVirtualWriteFailure(source.path, rule.schemaPath, targetPath, resolved.template, value);
		if (invalid) return {
			writes: [],
			failure: invalid
		};
		writes.push({
			target: resolved.target,
			targetPath,
			template: resolved.template,
			siblings: resolved.siblings,
			targetOrder: resolved.order,
			value,
			kind: "injectTo",
			rank: KIND_RANK.injectTo,
			layer: LAYER_RANK[rule.layer],
			sourceOrder: getDeriveSourceOrder(source),
			ruleOrder: rule.order,
			returnOrder: index
		});
	}
	return { writes };
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/rank/compareDeriveWrites.ts
const compareDeriveWrites = (left, right) => {
	const kind = KIND_RANK[left.kind] - KIND_RANK[right.kind];
	if (kind) return kind;
	const limit = Math.min(left.sourceOrder.length, right.sourceOrder.length);
	for (let index = 0; index < limit; index++) {
		const difference = left.sourceOrder[index] - right.sourceOrder[index];
		if (difference) return difference;
	}
	const source = left.sourceOrder.length - right.sourceOrder.length;
	if (source) return source;
	return left.layer - right.layer || left.ruleOrder - right.ruleOrder || left.returnOrder - right.returnOrder;
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/utils/writes/chooseDeriveWrite.ts
const chooseDeriveWrite = (candidate, sourcePath, state, winners, trace, traceWinners) => {
	const path = candidate.targetPath;
	const prior = winners.get(path);
	const wins = !state.suppressAutomaticWrites && candidate.rank >= (state.appliedRanks.get(path) ?? 0) && (!prior || compareDeriveWrites(candidate, prior) >= 0);
	if (wins) {
		const previousIndex = traceWinners.get(path);
		if (previousIndex !== void 0) trace[previousIndex] = {
			...trace[previousIndex],
			result: "lost"
		};
		winners.set(path, candidate);
		if (state.trace) traceWinners.set(path, trace.length);
	}
	if (state.trace) trace.push({
		phase: "derive",
		kind: candidate.kind,
		sourcePath,
		targetPath: path,
		previousValue: candidate.target?.emit,
		nextValue: candidate.value,
		result: state.suppressAutomaticWrites ? "suppressed" : wins ? "applied" : "lost"
	});
};

//#endregion
//#region src/core/engine/derive/evaluateDeriveRound/evaluateDeriveRound.ts
const NO_FAILURES$2 = Object.freeze([]);
const EMPTY_DECISION = Object.freeze({
	writes: Object.freeze([]),
	trace: Object.freeze([]),
	failures: NO_FAILURES$2
});
const evaluateDeriveRound = (root, state) => {
	const table = getDeriveRuleTable(root.runtime.blueprint);
	if (table.rules.length === 0) return EMPTY_DECISION;
	const pending = getDeriveSourceNodes(root, state);
	const winners = /* @__PURE__ */ new Map();
	const trace = [];
	const traceWinners = /* @__PURE__ */ new Map();
	const evaluatedExpressions = /* @__PURE__ */ new Map();
	let failures;
	if (!state.sourcePaths) {
		state.activeRuleKeys.clear();
		state.activeRuleKeysBySource.clear();
	}
	state.activeUnsetTargets.clear();
	while (pending.length) {
		const node = pending.pop();
		if (!node || node.detached) continue;
		state.visitedSourcePaths.add(node.path);
		if (state.sourcePaths) {
			const sourceKeys = state.activeRuleKeysBySource.get(node.path);
			if (sourceKeys) {
				for (const key of sourceKeys) state.activeRuleKeys.delete(key);
				state.activeRuleKeysBySource.delete(node.path);
			}
		}
		const selected = getSelectedDeclarationIds(node, state);
		for (const id of selected) for (const rule of table.byDeclaration.get(id) ?? []) {
			if (rule.kind === "resetInteraction") continue;
			for (const target of rule.kind === "injectTo" ? [node] : getRuleTargets(node, rule, state)) {
				const key = getDeriveRuleKey(node.path, getBlueprintNodeIdentity(node.blueprintNode), rule, target, target.runtime);
				addActiveRuleKey(state, node.path, key);
				const consumed = state.consumedRuleValues.has(key);
				const priorExists = consumed || state.committedRuleValues.has(key);
				const prior = consumed ? state.consumedRuleValues.get(key) : state.committedRuleValues.get(key);
				const load = !consumed && Boolean(state.loadScope && (node.path === state.loadScope.path || isDescendantPath(node.path, state.loadScope.path)));
				const appeared = !consumed && (load || state.entered.has(target) || state.revived.has(target));
				if (rule.kind === "injectTo") {
					const current = node.emit;
					state.consumedRuleValues.set(key, current);
					if (state.loadScope && node.path !== state.loadScope.path && !isDescendantPath(node.path, state.loadScope.path)) continue;
					if (!appeared && (!priorExists || sameValue(prior, current))) continue;
					const evaluated = evaluateInjectTo(node, root, rule);
					if (evaluated.failure) {
						(failures ?? (failures = [])).push(evaluated.failure);
						continue;
					}
					for (const candidate of evaluated.writes) chooseDeriveWrite(candidate, node.path, state, winners, trace, traceWinners);
					if (evaluated.writes.length === 0 && state.trace) trace.push({
						phase: "derive",
						kind: "injectTo",
						sourcePath: node.path,
						targetPath: node.path,
						previousValue: current,
						nextValue: void 0,
						result: "undefined"
					});
					continue;
				}
				let current;
				let value;
				try {
					if (rule.kind === "derived") {
						const watchDependencies = getWatchPaths(target.blueprintNode);
						current = [...rule.expression?.dependencies.map((dependency) => readDeriveDependency(root, node.path, dependency)) ?? [], ...watchDependencies.filter((dependency) => target !== node || !rule.expression?.dependencies.includes(dependency)).map((dependency) => readDeriveDependency(root, target.path, dependency))];
						if (appeared || priorExists && !sameValue(prior, current)) {
							const evaluated = evaluateScopedExpression(root, node, rule, evaluatedExpressions);
							if (evaluated.threw) throw evaluated.cause;
							value = evaluated.value;
						}
					} else {
						const evaluated = evaluateScopedExpression(root, node, rule, evaluatedExpressions);
						if (evaluated.threw) throw evaluated.cause;
						current = Boolean(evaluated.value);
						if (!(current && (appeared || priorExists && !prior))) value = void 0;
					}
				} catch (cause) {
					(failures ?? (failures = [])).push({
						sourcePath: node.path,
						schemaPath: rule.schemaPath,
						cause,
						kind: "expression"
					});
					state.consumedRuleValues.set(key, current);
					continue;
				}
				state.consumedRuleValues.set(key, current);
				if (rule.kind === "unsetValue" && current) state.activeUnsetTargets.add(target);
				if (!(rule.kind === "derived" ? Boolean(appeared || priorExists && !sameValue(prior, current)) : current === true && Boolean(appeared || priorExists && !prior))) continue;
				if (rule.kind === "derived" && value === void 0) {
					if (state.trace) trace.push({
						phase: "derive",
						kind: rule.kind,
						sourcePath: node.path,
						targetPath: target.path,
						previousValue: target.emit,
						nextValue: value,
						result: "undefined"
					});
					continue;
				}
				const candidate = {
					target,
					targetPath: target.path,
					value: rule.kind === "unsetValue" ? void 0 : value,
					kind: rule.kind,
					rank: KIND_RANK[rule.kind],
					layer: LAYER_RANK[rule.layer],
					sourceOrder: getDeriveSourceOrder(node),
					ruleOrder: rule.order,
					returnOrder: 0
				};
				const invalid = getVirtualWriteFailure(node.path, rule.schemaPath, target.path, target.blueprintNode, candidate.value);
				if (invalid) {
					(failures ?? (failures = [])).push(invalid);
					continue;
				}
				chooseDeriveWrite(candidate, node.path, state, winners, trace, traceWinners);
			}
		}
		if (!state.sourcePaths) for (let index = (node.children?.length ?? 0) - 1; index >= 0; index--) pending.push(node.children[index]);
	}
	return {
		writes: [...winners.values()],
		trace,
		failures: failures ?? NO_FAILURES$2
	};
};

//#endregion
//#region src/core/engine/derive/utils/evaluate/evaluateResetInteraction.ts
const NO_FAILURES$1 = Object.freeze([]);
const evaluateResetInteraction = (root, state) => {
	const table = getDeriveRuleTable(root.runtime.blueprint);
	const pending = getDeriveSourceNodes(root, state);
	const nodes = [];
	const resetNodes = /* @__PURE__ */ new Set();
	const trace = [];
	const evaluatedExpressions = /* @__PURE__ */ new Map();
	let failures;
	while (pending.length) {
		const node = pending.pop();
		if (!node || node.detached) continue;
		state.visitedSourcePaths.add(node.path);
		const selected = getSelectedDeclarationIds(node, state);
		for (const id of selected) for (const rule of table.byDeclaration.get(id) ?? []) {
			if (rule.kind !== "resetInteraction") continue;
			for (const target of getRuleTargets(node, rule, state)) {
				const key = getDeriveRuleKey(node.path, getBlueprintNodeIdentity(node.blueprintNode), rule, target, target.runtime);
				addActiveRuleKey(state, node.path, key);
				const previous = state.committedRuleValues.get(key);
				const previousExists = state.committedRuleValues.has(key);
				let current;
				try {
					const evaluated = evaluateScopedExpression(root, node, rule, evaluatedExpressions);
					if (evaluated.threw) throw evaluated.cause;
					current = Boolean(evaluated.value);
				} catch (cause) {
					(failures ?? (failures = [])).push({
						sourcePath: node.path,
						schemaPath: rule.schemaPath,
						cause
					});
					state.consumedRuleValues.set(key, false);
					continue;
				}
				state.consumedRuleValues.set(key, current);
				const load = state.loadScope && (node.path === state.loadScope.path || isDescendantPath(node.path, state.loadScope.path));
				if (!current || !(load || state.entered.has(target) || state.revived.has(target) || previousExists && !previous)) continue;
				if (!resetNodes.has(target)) {
					resetNodes.add(target);
					nodes.push(target);
				}
				if (state.trace) trace.push({
					phase: "commit",
					kind: rule.kind,
					sourcePath: node.path,
					targetPath: target.path,
					previousValue: previous,
					nextValue: current,
					result: "applied"
				});
			}
		}
		if (!state.sourcePaths) for (let index = (node.children?.length ?? 0) - 1; index >= 0; index--) pending.push(node.children[index]);
	}
	return {
		nodes,
		trace,
		failures: failures ?? NO_FAILURES$1
	};
};

//#endregion
//#region src/core/engine/settle/utils/gates/getGateExpression.ts
const getGateExpression = (blueprint, schemaPath) => {
	if (blueprint.capabilities.branchless) return void 0;
	let expressions = getBlueprintDerived(blueprint).gateExpressions;
	if (!expressions) {
		const indexed = /* @__PURE__ */ new Map();
		for (const expression of blueprint.expressions) if (expression.key === "active" && !indexed.has(expression.schemaPath)) indexed.set(expression.schemaPath, expression);
		expressions = indexed;
		getBlueprintDerived(blueprint).gateExpressions = expressions;
	}
	return expressions.get(schemaPath);
};

//#endregion
//#region src/core/engine/settle/utils/templatePaths/bindTemplatePath.ts
const bindTemplatePath = bindPointerTemplate;

//#endregion
//#region src/core/engine/settle/utils/templatePaths/isCanonicalArrayIndex.ts
const CANONICAL_ARRAY_INDEX = /^(0|[1-9]\d*)$/;
const isCanonicalArrayIndex = (segment) => CANONICAL_ARRAY_INDEX.test(segment);

//#endregion
//#region src/core/engine/settle/utils/templatePaths/intersectsWatchedPath.ts
const intersectsWatchedPath = (watched, path, watchedSegments, pathSegments) => {
	if (watched === "" || path === "") return true;
	const left = watchedSegments ?? parsePointerSegments(watched);
	const right = pathSegments ?? parsePointerSegments(path);
	const length = Math.min(left.length, right.length);
	for (let index = 0; index < length; index++) {
		const leftSegment = left[index];
		const rightSegment = right[index];
		if (leftSegment !== rightSegment && !(leftSegment === PointerOperator.Wildcard && typeof rightSegment === "string" && isCanonicalArrayIndex(rightSegment))) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/getContextOwners.ts
const EMPTY_OWNERS = Object.freeze([]);
const getContextOwners = (blueprint) => {
	if (!blueprint.capabilities.hasDependencies) return EMPTY_OWNERS;
	const cached = getBlueprintDerived(blueprint).contextOwners;
	if (cached) return cached;
	const ids = blueprint.dependencies[JSONPointer.Context];
	if (!ids?.length) {
		getBlueprintDerived(blueprint).contextOwners = EMPTY_OWNERS;
		return EMPTY_OWNERS;
	}
	const owners = [];
	const rules = getDeriveRuleTable(blueprint);
	for (const node of blueprint.nodes) for (const declaration of node.declarations) if ((ids.includes(declaration.id) || rules.byDeclaration.get(declaration.id)?.some((rule) => rule.kind === "derived" && (rule.targetName !== void 0 || rule.targetItems) && rule.watchDependencies.some((path) => readPointerSegment(path, 0) === PointerOperator.Context))) && !owners.includes(declaration.path)) owners.push(declaration.path);
	getBlueprintDerived(blueprint).contextOwners = owners;
	return owners;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/getDependencyIndex.ts
const NO_OWNERS = Object.freeze([]);
var DependencyIndex = class {
	pathSegments(path, runtime) {
		return this.preparedSegments.get(path) ?? (runtime ? getCachedPointerSegments(runtime, path) : parsePointerSegments(path));
	}
	get hasSplitOwners() {
		return this.splitOwners.size > 0;
	}
	constructor(blueprint) {
		this.ordinaryOwners = /* @__PURE__ */ new Set();
		this.splitOwners = /* @__PURE__ */ new Map();
		this.registrationPrepared = false;
		this.preparedSegments = /* @__PURE__ */ new Map();
		this.blueprint = blueprint;
		this.root = void 0;
		if (!blueprint) return;
		this.root = {
			owners: [],
			ownerPaths: /* @__PURE__ */ new Set(),
			children: /* @__PURE__ */ new Map()
		};
		for (const node of blueprint.nodes) {
			if (!this.preparedSegments.has(node.path)) this.preparedSegments.set(node.path, parsePointerSegments(node.path));
			if (!this.preparedSegments.has(node.schemaPath)) this.preparedSegments.set(node.schemaPath, parsePointerSegments(node.schemaPath));
			for (const declaration of node.declarations) {
				if (!this.preparedSegments.has(declaration.path)) this.preparedSegments.set(declaration.path, parsePointerSegments(declaration.path));
				if (!this.preparedSegments.has(declaration.schemaPath)) this.preparedSegments.set(declaration.schemaPath, parsePointerSegments(declaration.schemaPath));
			}
		}
		getContextOwners(blueprint);
		const dependencies = Object.entries(blueprint.dependencies);
		if (dependencies.length === 0 && blueprint.expressions.length === 0) return;
		const declarations = new Map(blueprint.nodes.flatMap((node) => node.declarations.map((declaration) => [declaration.id, declaration])));
		for (const [dependency, ids] of dependencies) for (const id of ids) {
			const declaration = declarations.get(id);
			if (!declaration) continue;
			const watched = resolveDependencyPath(declaration.path, dependency);
			if (readPointerSegment(watched, 0) === PointerOperator.Context) continue;
			this.ordinaryOwners.add(declaration.path);
			this.add(watched, declaration.path);
		}
		const rules = getDeriveRuleTable(blueprint);
		for (const node of blueprint.nodes) for (const declaration of node.declarations) for (const rule of rules.byDeclaration.get(declaration.id) ?? []) {
			if (rule.kind !== "derived" || rule.targetName === void 0 && !rule.targetItems) continue;
			const targetPath = rule.targetItems ? joinPointer([...this.preparedSegments.get(declaration.path) ?? [], PointerOperator.Wildcard]) : appendSegment(declaration.path, rule.targetName ?? "");
			for (const watch of rule.watchDependencies) {
				const watched = resolveDependencyPath(targetPath, watch);
				if (readPointerSegment(watched, 0) !== PointerOperator.Context) {
					this.ordinaryOwners.add(declaration.path);
					this.add(watched, declaration.path);
				}
			}
		}
		for (const node of blueprint.nodes) for (const declaration of node.declarations) for (const gate of declaration.gates) {
			const expression = getGateExpression(blueprint, gate.schemaPath);
			if (!expression) continue;
			for (const dependency of expression.dependencies) {
				const watched = resolveDependencyPath(gate.hostPath, dependency);
				if (readPointerSegment(watched, 0) === PointerOperator.Context) continue;
				this.add(watched, declaration.path);
			}
		}
	}
	prepareRegistration(tables) {
		if (this.registrationPrepared || !this.blueprint || !tables.size) return;
		this.registrationPrepared = true;
		const candidates = /* @__PURE__ */ new Map();
		const plain = new Set(this.ordinaryOwners);
		for (const node of this.blueprint.nodes) for (const declaration of node.declarations) for (const gate of declaration.gates) {
			if (!getGateExpression(this.blueprint, gate.schemaPath)?.dependencies.some((dependency) => readPointerSegment(resolveDependencyPath(gate.hostPath, dependency), 0) !== PointerOperator.Context)) continue;
			let hostPath;
			for (const [host, table] of tables) {
				const name = readPointerSegment(declaration.path, -1);
				if (typeof name !== "string") continue;
				const stepIndex = table.stepIndexByName.get(name);
				if (stepIndex !== void 0 && table.tableSteps.has(stepIndex) && table.plan.steps[stepIndex].gate === gate && declaration.path === appendSegment(host.path, name) && !hasPointerOperator(declaration.path, PointerOperator.Wildcard)) {
					hostPath = host.path;
					break;
				}
			}
			if (hostPath === void 0) plain.add(declaration.path);
			else candidates.set(declaration.path, hostPath);
		}
		const pending = this.root ? [this.root] : [];
		const allNodes = [];
		while (pending.length) {
			const node = pending.pop();
			allNodes.push(node);
			for (const entry of node.owners) if (entry.watched) plain.add(entry.path);
			pending.push(...node.children.values());
		}
		const runNumbers = /* @__PURE__ */ new Map();
		pending.push(...allNodes);
		while (pending.length) {
			const node = pending.pop();
			const grouped = /* @__PURE__ */ new Map();
			node.plainOwners = [];
			for (let rank = 0; rank < node.owners.length; rank++) {
				const entry = node.owners[rank];
				const host = candidates.get(entry.path);
				if (host === void 0 || plain.has(entry.path) || entry.watched) {
					node.plainOwners.push({
						rank,
						entry
					});
					continue;
				}
				let names = grouped.get(host);
				if (!names) grouped.set(host, names = /* @__PURE__ */ new Map());
				const name = readPointerSegment(entry.path, -1);
				if (typeof name !== "string") continue;
				names.set(name, rank);
			}
			node.splitBuckets = [];
			for (const [hostPath, ranksByName] of grouped) {
				if (!this.preparedSegments.has(hostPath)) this.preparedSegments.set(hostPath, parsePointerSegments(hostPath));
				const runs = [];
				const runByName = /* @__PURE__ */ new Map();
				let previous = -1;
				for (const [name, rank] of ranksByName) {
					let foreign = previous < 0;
					for (let between = previous + 1; !foreign && between < rank; between++) if (!isDescendantPath(node.owners[between].path, hostPath)) foreign = true;
					if (foreign) {
						const id = runNumbers.get(hostPath) ?? 0;
						runNumbers.set(hostPath, id + 1);
						runs.push({
							ranks: [],
							firstRank: rank,
							id
						});
					}
					runs[runs.length - 1].ranks.push(rank);
					runByName.set(name, runs.length - 1);
					previous = rank;
				}
				const bucket = {
					hostPath,
					ranksByName,
					firstRank: ranksByName.values().next().value,
					runs,
					runByName
				};
				node.splitBuckets.push(bucket);
				for (const [name, rank] of ranksByName) this.splitOwners.set(appendSegment(hostPath, name), {
					bucket,
					rank,
					run: runByName.get(name)
				});
			}
		}
	}
	affectedForRegistration(changedPath, root, sink) {
		if (!this.root) return;
		const emitted = /* @__PURE__ */ new Set();
		const hostsEmitted = /* @__PURE__ */ new Set();
		const collect = (node) => {
			const events = [];
			for (const { rank, entry } of node.plainOwners ?? node.owners.map((entry, rank) => ({
				entry,
				rank
			}))) {
				const path = entry.bindable ? bindTemplatePath(entry.path, changedPath) : entry.path;
				const paths = hasPointerOperator(path, PointerOperator.Wildcard) ? expandTemplatePaths(root, path, this.pathSegments(path, root.runtime)) : [path];
				events.push({
					rank,
					emit: () => {
						for (const concrete of paths) if (!emitted.has(concrete)) {
							emitted.add(concrete);
							sink.owner(concrete, "plain");
						}
					}
				});
			}
			for (const bucket of node.splitBuckets ?? []) {
				let host = root;
				for (const segment of this.pathSegments(bucket.hostPath)) if (typeof segment === "string") host = host?.structure?.[segment];
				else {
					host = void 0;
					break;
				}
				const living = [];
				if (host?.structure) for (const name of Object.keys(host.structure)) {
					const rank = bucket.ranksByName.get(name);
					if (rank !== void 0) living.push({
						path: appendSegment(bucket.hostPath, name),
						rank
					});
				}
				living.sort((left, right) => left.rank - right.rank);
				for (const anchor of sink.hit(bucket, living.map((entry) => entry.rank))) events.push({
					rank: anchor.rank,
					emit: anchor.insert
				});
				events.push({
					rank: bucket.firstRank,
					emit: () => {
						if (!hostsEmitted.has(bucket.hostPath)) {
							hostsEmitted.add(bucket.hostPath);
							sink.owner(bucket.hostPath, "host", bucket);
						}
					}
				});
				for (const entry of living) events.push({
					rank: entry.rank,
					emit: () => {
						if (!emitted.has(entry.path)) {
							emitted.add(entry.path);
							sink.owner(entry.path, "split", bucket);
						}
					}
				});
			}
			events.sort((left, right) => left.rank - right.rank);
			for (const event of events) event.emit();
		};
		let current = [this.root];
		collect(this.root);
		for (const segment of this.pathSegments(changedPath, root.runtime)) {
			if (typeof segment !== "string") return;
			const next = this.presenceChildren(current, segment);
			if (!next.length) return;
			current = next;
			for (const node of current) collect(node);
		}
		const pending = current.flatMap((node) => [...node.children.values()]);
		while (pending.length) {
			const child = pending.pop();
			collect(child);
			pending.push(...child.children.values());
		}
	}
	affected(changedPath, root) {
		const rootIndex = this.root;
		if (!rootIndex || rootIndex.owners.length === 0 && rootIndex.children.size === 0) return NO_OWNERS;
		const owners = /* @__PURE__ */ new Set();
		let current = [rootIndex];
		const collect = (node) => {
			for (const entry of node.owners) {
				const path = entry.bindable ? bindTemplatePath(entry.path, changedPath) : entry.path;
				if (hasPointerOperator(path, PointerOperator.Wildcard)) for (const expanded of expandTemplatePaths(root, path, this.pathSegments(path, root.runtime))) owners.add(expanded);
				else owners.add(path);
			}
		};
		collect(rootIndex);
		for (const segment of this.pathSegments(changedPath, root.runtime)) {
			if (typeof segment !== "string") return [...owners];
			const next = [];
			for (const node of current) {
				const exact = node.children.get(segment);
				if (exact) next.push(exact);
				if (isCanonicalArrayIndex(segment)) {
					const wildcard = node.children.get(PointerOperator.Wildcard);
					if (wildcard) next.push(wildcard);
				}
			}
			if (next.length === 0) return [...owners];
			current = next;
			for (const node of current) collect(node);
		}
		const pending = current.flatMap((node) => [...node.children.values()]);
		while (pending.length) {
			const child = pending.pop();
			if (!child) continue;
			collect(child);
			pending.push(...child.children.values());
		}
		return [...owners];
	}
	affectedByPresence(hostPath, childSegment, metrics, settlement, runtime) {
		const owners = /* @__PURE__ */ new Set();
		const stateOnly = /* @__PURE__ */ new Set();
		const outerTemplates = /* @__PURE__ */ new Set();
		const directTemplates = /* @__PURE__ */ new Set();
		if (!this.root) return {
			owners,
			stateOnly,
			outerTemplates,
			directTemplates
		};
		const childName = parsePointerSegment(childSegment);
		if (typeof childName !== "string") return {
			owners,
			stateOnly,
			outerTemplates,
			directTemplates
		};
		const changedPath = appendSegment(hostPath, childName);
		const changedSegments = this.pathSegments(changedPath, runtime);
		const ancestorOwners = /* @__PURE__ */ new Set();
		let memo = settlement?.dependencyPresenceMemo;
		if (!memo) {
			memo = /* @__PURE__ */ new Map();
			if (settlement) settlement.dependencyPresenceMemo = memo;
		}
		const levels = this.presenceLevels(hostPath, memo);
		this.collectPresenceOwners(levels.flat(), changedPath, changedSegments, ancestorOwners, outerTemplates, metrics);
		for (const owner of ancestorOwners) if (isDescendantPath(owner, hostPath)) stateOnly.add(owner);
		else owners.add(owner);
		const depth = this.pathSegments(hostPath, runtime).length + 1;
		const reached = levels.length === depth ? levels[levels.length - 1] : [];
		const pending = this.presenceChildren(reached, childName);
		const direct = /* @__PURE__ */ new Set();
		const subtree = [];
		while (pending.length) {
			const child = pending.pop();
			subtree.push(child);
			for (const descendant of child.children.values()) pending.push(descendant);
		}
		if (subtree.length) this.collectPresenceOwners(subtree, changedPath, changedSegments, direct, directTemplates, metrics);
		for (const owner of direct) if (owner !== changedPath && !isDescendantPath(owner, changedPath)) owners.add(owner);
		return {
			owners,
			stateOnly,
			outerTemplates,
			directTemplates
		};
	}
	presenceLevels(path, memo) {
		const known = memo.get(path);
		if (known) return known;
		let levels;
		if (!path) levels = [[this.root]];
		else {
			const parent = this.presenceLevels(resolvePointer(path, ".."), memo);
			const last = parent[parent.length - 1];
			const name = readPointerSegment(path, -1);
			levels = last.length === 0 || typeof name !== "string" ? parent : [...parent, this.presenceChildren(last, name)];
		}
		memo.set(path, levels);
		return levels;
	}
	presenceChildren(nodes, segment) {
		const next = [];
		for (const node of nodes) {
			const exact = node.children.get(segment);
			if (exact) next.push(exact);
			const wildcard = isCanonicalArrayIndex(segment) ? node.children.get(PointerOperator.Wildcard) : void 0;
			if (wildcard) next.push(wildcard);
		}
		return next;
	}
	collectPresenceOwners(nodes, changedPath, changedSegments, owners, templates, metrics) {
		const sizeBefore = owners.size;
		for (const node of nodes) for (const entry of node.owners) {
			if (entry.watched && !entry.watched.some((watched) => intersectsWatchedPath(watched, changedPath, this.pathSegments(watched), changedSegments))) continue;
			const path = entry.bindable ? bindTemplatePath(entry.path, changedPath) : entry.path;
			if (hasPointerOperator(path, PointerOperator.Wildcard)) templates.add(path);
			else owners.add(path);
		}
		if (metrics) metrics.ownerInsertions += owners.size - sizeBefore;
	}
	add(watchedPath, owner) {
		let ownerParts = this.preparedSegments.get(owner);
		if (!ownerParts) {
			ownerParts = parsePointerSegments(owner);
			this.preparedSegments.set(owner, ownerParts);
		}
		let watchedParts = this.preparedSegments.get(watchedPath);
		if (!watchedParts) {
			watchedParts = parsePointerSegments(watchedPath);
			this.preparedSegments.set(watchedPath, watchedParts);
		}
		let indexedParts = watchedParts;
		const originalWatchedPath = watchedPath;
		for (let index = 0; index < ownerParts.length; index++) if (ownerParts[index] === PointerOperator.Wildcard && watchedParts[index] !== PointerOperator.Wildcard && ownerParts.slice(0, index).every((part, position) => part === watchedParts[position]) && watchedParts[index] !== void 0) {
			indexedParts = ownerParts.slice(0, index);
			watchedPath = joinPointer(indexedParts);
			break;
		}
		let current = this.root;
		for (const segment of indexedParts) {
			let child = current.children.get(segment);
			if (!child) {
				child = {
					owners: [],
					ownerPaths: /* @__PURE__ */ new Set(),
					children: /* @__PURE__ */ new Map()
				};
				current.children.set(segment, child);
			}
			current = child;
		}
		if (!current.ownerPaths.has(owner)) {
			current.ownerPaths.add(owner);
			current.owners.push({
				path: owner,
				bindable: ownerParts.every((part, index) => part !== PointerOperator.Wildcard || indexedParts[index] === PointerOperator.Wildcard),
				...watchedPath !== originalWatchedPath ? { watched: [originalWatchedPath] } : {}
			});
		} else {
			const entry = current.owners.find((candidate) => candidate.path === owner);
			if (watchedPath === originalWatchedPath) delete entry.watched;
			else if (entry.watched && !entry.watched.includes(originalWatchedPath)) entry.watched.push(originalWatchedPath);
		}
	}
};
const EMPTY_INDEX = new DependencyIndex();
Object.freeze(EMPTY_INDEX);
const getDependencyIndex = (blueprint, tables) => {
	if (!blueprint.capabilities.hasDependencies && !blueprint.capabilities.hasExpressions) return EMPTY_INDEX;
	let index = getBlueprintDerived(blueprint).dependencyIndex;
	if (!index) {
		index = new DependencyIndex(blueprint);
		getBlueprintDerived(blueprint).dependencyIndex = index;
	}
	if (tables) index.prepareRegistration(tables);
	return index;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/getLivePresenceNode.ts
const getLivePresenceNode = (root, path) => {
	let live = root;
	const segments = getDependencyIndex(root.runtime.blueprint).pathSegments(path, root.runtime);
	for (const segment of segments) {
		const name = segment;
		if (typeof name !== "string") return void 0;
		live = live?.structure && hasOwnProperty(live.structure, name) ? live.structure[name] : void 0;
		if (!live) break;
	}
	return live && !live.detached ? live : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/evaluatedPresenceAfter.ts
const evaluatedPresenceAfter = (owner, stamp, context) => {
	if (!owner) return false;
	const host = getLivePresenceNode(context.root, resolvePointer(owner, ".."));
	return host !== void 0 && (context.presenceRoundStarts?.get(host) ?? 0) > stamp;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/publishPresenceOwner.ts
const publishPresenceOwner = (owner, context) => {
	context.dependencyOwnerPaths.add(owner);
	context.shapeDirtyPaths.add(resolvePointer(owner, ".."));
	const live = getLivePresenceNode(context.root, owner);
	if (live) context.stateDirtyNodes.add(live);
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/flushPresenceTemplates.ts
const flushPresenceTemplates = (host, context) => {
	const pending = context.presenceTemplates;
	if (!pending?.size) return false;
	let found = false;
	let marked = false;
	const features = getFeatureNodeIndex(context.root.runtime.blueprint);
	const dependencies = getDependencyIndex(context.root.runtime.blueprint);
	for (const [key, entry] of pending) {
		if (host !== void 0 && entry.host !== host.path) continue;
		found = true;
		pending.delete(key);
		for (const owner of expandTemplatePaths(context.root, entry.template, dependencies.pathSegments(entry.template, context.root.runtime))) {
			if (context.presenceMetrics) context.presenceMetrics.ownerInsertions++;
			const deepest = entry.deepest;
			const excluded = deepest !== null && ((deepest === "" ? owner !== "" : isDescendantPath(owner, deepest)) || entry.kind === "direct" && owner === deepest);
			if (!excluded && host !== void 0 && evaluatedPresenceAfter(owner, entry.stamp, context)) {
				publishPresenceOwner(owner, context);
				continue;
			}
			if (!excluded) {
				context.dirtyPaths.add(owner);
				context.dependencyOwnerPaths.add(owner);
				context.shapeDirtyPaths.add(resolvePointer(owner, ".."));
				for (let ancestor = owner; ancestor;) {
					ancestor = resolvePointer(ancestor, "..");
					context.dirtyPaths.add(ancestor);
				}
				marked = true;
				continue;
			}
			if (entry.kind !== "outer") continue;
			const live = getLivePresenceNode(context.root, owner);
			if (!live) continue;
			if (features.stateKeyNodes.has(live.blueprintNode.id) || live.parent && features.stateKeyChildren.get(live.parent.blueprintNode.id)?.has(live.name)) {
				context.dependencyOwnerPaths.add(owner);
				context.stateDirtyNodes.add(live);
			}
		}
	}
	if (marked) context.presenceRegistrations = (context.presenceRegistrations ?? 0) + 1;
	return found;
};

//#endregion
//#region src/core/engine/validation/utils/copy/createValidatorCopy.ts
const SCHEMA_KEYS = /* @__PURE__ */ new Set([
	"additionalProperties",
	"unevaluatedProperties",
	"propertyNames",
	"contains",
	"items",
	"not",
	"if",
	"then",
	"else",
	"additionalItems",
	"unevaluatedItems",
	"contentSchema"
]);
const SCHEMA_MAP_KEYS = /* @__PURE__ */ new Set([
	"properties",
	"patternProperties",
	"$defs",
	"definitions",
	"dependentSchemas",
	"dependencies"
]);
const SCHEMA_ARRAY_KEYS = /* @__PURE__ */ new Set([
	"allOf",
	"anyOf",
	"oneOf",
	"prefixItems"
]);
const createValidatorCopy = (authored) => {
	if (typeof authored !== "object" || authored === null) return authored;
	const copy = {};
	const seen = /* @__PURE__ */ new Map([[authored, copy]]);
	const pending = [{
		source: authored,
		target: copy,
		kind: "schema"
	}];
	while (pending.length) {
		const current = pending.pop();
		if (!current) continue;
		for (const [key, value] of Object.entries(current.source)) {
			if (current.kind === "schema" && (key === SCHEMA_GROUP.controls || key === SCHEMA_GROUP.options || key === SCHEMA_GROUP.presentation)) continue;
			const childKind = current.kind === "schema" ? SCHEMA_KEYS.has(key) ? isArray(value) ? "array" : "schema" : SCHEMA_MAP_KEYS.has(key) ? "map" : SCHEMA_ARRAY_KEYS.has(key) ? "array" : "data" : current.kind === "map" || current.kind === "array" ? "schema" : "data";
			if (value === null || typeof value !== "object") {
				Object.defineProperty(current.target, key, {
					value,
					enumerable: true,
					configurable: true,
					writable: true
				});
				continue;
			}
			let child = seen.get(value);
			if (!child) {
				child = isArray(value) ? [] : {};
				seen.set(value, child);
				pending.push({
					source: value,
					target: child,
					kind: childKind
				});
			}
			Object.defineProperty(current.target, key, {
				value: child,
				enumerable: true,
				configurable: true,
				writable: true
			});
		}
	}
	return copy;
};

//#endregion
//#region src/core/engine/validation/utils/cache/validationEntries.ts
const validationEntries = /* @__PURE__ */ new WeakMap();

//#endregion
//#region src/core/engine/validation/utils/lifetime/recentReleaseList.ts
const lists = /* @__PURE__ */ new WeakMap();
const recentReleaseList = (validator) => {
	let list = lists.get(validator);
	if (!list) {
		list = {
			counts: /* @__PURE__ */ new Map(),
			recent: []
		};
		lists.set(validator, list);
	}
	return list;
};

//#endregion
//#region src/core/engine/validation/utils/lifetime/evictValidationRoot.ts
const evictValidationRoot = (validator, authoredRoot) => {
	const list = recentReleaseList(validator);
	if ((list.counts.get(authoredRoot) ?? 0) > 0) return;
	const index = list.recent.indexOf(authoredRoot);
	if (index >= 0) list.recent.splice(index, 1);
	list.counts.delete(authoredRoot);
	const roots = validationEntries.get(validator);
	const entry = typeof authoredRoot === "object" && authoredRoot !== null ? roots?.get(authoredRoot) : void 0;
	try {
		if (entry) validator.release?.(entry.copy);
	} finally {
		if (typeof authoredRoot === "object" && authoredRoot !== null) roots?.delete(authoredRoot);
	}
};

//#endregion
//#region src/core/engine/validation/utils/cache/readValidationEntry.ts
const readValidationEntry = (validator, authoredRoot) => {
	let roots = validationEntries.get(validator);
	if (!roots) {
		roots = /* @__PURE__ */ new WeakMap();
		validationEntries.set(validator, roots);
	}
	if (typeof authoredRoot !== "object" || authoredRoot === null) throw new TypeError("Validation cache requires an authored root object");
	const existing = roots.get(authoredRoot);
	if (existing) return existing;
	const list = recentReleaseList(validator);
	if (typeof authoredRoot.$id === "string") {
		for (const oldRoot of [...list.recent]) if (oldRoot !== authoredRoot && typeof oldRoot === "object" && oldRoot !== null && oldRoot.$id === authoredRoot.$id) evictValidationRoot(validator, oldRoot);
	}
	list.counts.set(authoredRoot, 0);
	list.recent.push(authoredRoot);
	if (list.recent.length > 8) evictValidationRoot(validator, list.recent[0]);
	const copy = createValidatorCopy(authoredRoot);
	let validate;
	let failure;
	try {
		validate = validator.compile(copy);
	} catch (error) {
		failure = error;
	}
	const entry = {
		copy,
		guards: /* @__PURE__ */ new Map(),
		validate,
		failure,
		eagerCompiled: false
	};
	roots.set(authoredRoot, entry);
	return entry;
};

//#endregion
//#region src/core/engine/validation/utils/guard/isValidator.ts
const isValidator = (candidate) => candidate !== null && typeof candidate === "object" && "compile" in candidate && typeof candidate.compile === "function" && "compileGuard" in candidate && typeof candidate.compileGuard === "function";

//#endregion
//#region src/core/engine/validation/utils/guard/readFieldNodeGuard.ts
const readFieldNodeGuard = (runtime, gate) => {
	const validator = runtime.validator;
	if (!isValidator(validator)) return void 0;
	const root = runtime.blueprint.schema;
	const entry = readValidationEntry(validator, root);
	const pointer = stripFragment(gate.schemaPath);
	const cached = entry.guards.get(pointer);
	if (cached) {
		if ("failure" in cached) throw cached.failure;
		return cached.guard;
	}
	try {
		const guard = validator.compileGuard(entry.copy, pointer);
		entry.guards.set(pointer, { guard });
		return guard;
	} catch (failure) {
		entry.guards.set(pointer, { failure });
		throw failure;
	}
};

//#endregion
//#region src/core/engine/validation/utils/guard/compileEntryGuards.ts
const compileEntryGuards = (entry, validator, analysis) => {
	if (entry.eagerCompiled) return;
	entry.eagerCompiled = true;
	const gates = [];
	for (const node of analysis.nodes) {
		for (const declaration of node.declarations) gates.push(...declaration.gates);
		for (const child of node.childEntries) for (const declaration of child.declarations) gates.push(...declaration.gates);
	}
	for (const gate of gates) {
		if (gate.kind !== "if") continue;
		const pointer = stripFragment(gate.schemaPath);
		if (entry.guards.has(pointer)) continue;
		try {
			entry.guards.set(pointer, { guard: validator.compileGuard(entry.copy, pointer) });
		} catch (failure) {
			entry.guards.set(pointer, { failure });
		}
	}
};

//#endregion
//#region src/core/engine/types/state.ts
let ValidationMode = /* @__PURE__ */ function(ValidationMode) {
	ValidationMode[ValidationMode["None"] = 0] = "None";
	ValidationMode[ValidationMode["OnChange"] = 1] = "OnChange";
	ValidationMode[ValidationMode["OnRequest"] = 2] = "OnRequest";
	return ValidationMode;
}({});
let FieldNodeState = /* @__PURE__ */ function(FieldNodeState) {
	FieldNodeState[FieldNodeState["Dirty"] = 1] = "Dirty";
	FieldNodeState[FieldNodeState["Touched"] = 2] = "Touched";
	FieldNodeState[FieldNodeState["ErrorVisible"] = 4] = "ErrorVisible";
	return FieldNodeState;
}({});

//#endregion
//#region src/core/engine/validation/utils/route/retainEqualValidationIssues.ts
const retainEqualValidationIssues = (node, issues) => {
	const previous = node.rootNode.runtime.validationResult?.issues;
	return isEqualVerdict(previous, issues) ? previous : issues;
};
const isEqualVerdict = (previous, next) => {
	if (previous === void 0 || previous.length !== next.length) return false;
	for (let index = 0; index < next.length; index++) if (!equals(previous[index], next[index])) return false;
	return true;
};

//#endregion
//#region src/core/engine/validation/utils/route/isOffUnionBranchIssue.ts
const UNION_BRANCH_FRAGMENT_PATH = /^.*\/(?:oneOf|anyOf)\/\d+$/;
const NUMERIC_KEY$1 = /^\d+$/;
const isOffUnionBranchIssue = (issue, blueprint, activeIds) => {
	if (!issue.schemaPath || !activeIds) return false;
	const matches = blueprint.fragments.filter((fragment) => issue.schemaPath === fragment.schemaPath || issue.schemaPath !== void 0 && isDescendantPath(issue.schemaPath, fragment.schemaPath));
	if (!matches.length) return false;
	const longest = Math.max(...matches.map((fragment) => fragment.schemaPath.length));
	const owners = matches.filter((fragment) => fragment.schemaPath.length === longest);
	const branches = [];
	for (const fragment of blueprint.fragments) {
		if (!UNION_BRANCH_FRAGMENT_PATH.test(fragment.schemaPath)) continue;
		const pending = [fragment.id];
		const visited = /* @__PURE__ */ new Set();
		while (pending.length) {
			const id = pending.pop();
			if (id === void 0 || visited.has(id)) continue;
			visited.add(id);
			pending.push(...blueprint.fragments[id].children);
		}
		if (owners.some((owner) => visited.has(owner.id))) branches.push(fragment);
	}
	if (!branches.length) return false;
	const nearest = Math.max(...branches.map((fragment) => fragment.schemaPath.length));
	const candidates = branches.filter((fragment) => fragment.schemaPath.length === nearest);
	if (candidates.length !== 1) return false;
	const owner = candidates[0];
	if (!owner.gates.length) return false;
	const unionPath = resolvePointer(owner.schemaPath, "..");
	const siblings = blueprint.fragments.filter((fragment) => fragment.id !== owner.id && NUMERIC_KEY$1.test(fragment.schemaPath.slice(unionPath.length + 1)) && isDescendantPath(fragment.schemaPath, unionPath));
	const isActive = (fragment) => fragment.declares.some((id) => activeIds.has(id)) || fragment.overlays.some((id) => activeIds.has(id));
	return !isActive(owner) && siblings.some(isActive);
};

//#endregion
//#region src/core/engine/validation/utils/route/constants.ts
const EMPTY_GLOBAL_ERRORS = Object.freeze([]);

//#endregion
//#region src/core/engine/validation/utils/route/updateFieldNodeGlobalErrors.ts
const updateFieldNodeGlobalErrors = (root) => {
	const runtime = root.runtime;
	const external = runtime.nodeErrors?.get(root);
	const validation = runtime.routedValidationErrors;
	runtime.globalErrors = external?.length ? validation?.length ? [...external, ...validation] : external : validation ?? EMPTY_GLOBAL_ERRORS;
};

//#endregion
//#region src/core/engine/validation/utils/route/routeValidationIssues.ts
const isOwnedNode = (candidate, runtime) => candidate !== null && typeof candidate === "object" && Reflect.get(candidate, "runtime") === runtime;
const routeValidationIssues = (target, issues) => {
	const root = target.rootNode;
	const runtime = root.runtime;
	const before = runtime.validationErrors ?? /* @__PURE__ */ new Map();
	const next = new Map(before);
	let activeIds;
	if (issues.length > 0 && runtime.committedDeclarationIds?.size) {
		activeIds = /* @__PURE__ */ new Set();
		for (const ids of runtime.committedDeclarationIds.values()) for (let index = 0; index < ids.length; index++) activeIds.add(ids[index]);
	}
	const inScope = (node) => node === target || isDescendantPath(node.path, target.path);
	for (const node of before.keys()) if (isOwnedNode(node, runtime) && inScope(node)) next.delete(node);
	for (let index = 0; index < issues.length; index++) {
		const issue = issues[index];
		if (isOffUnionBranchIssue(issue, runtime.blueprint, activeIds)) continue;
		const path = issue.dataPath;
		let node = root;
		if (path) {
			const parsed = parsePointer(path);
			if (!parsed.absolute) continue;
			const segments = parsed.segments;
			for (let segmentIndex = 0; segmentIndex < segments.length; segmentIndex++) {
				const key = segments[segmentIndex];
				if (typeof key !== "string") {
					node = root;
					break;
				}
				if (node.structure === null) break;
				if (!hasOwnProperty(node.structure, key)) {
					node = root;
					break;
				}
				const child = node.structure[key];
				if (!child) {
					node = root;
					break;
				}
				node = child;
			}
			if (node === root && path !== "") continue;
		}
		if (issue.rejectedKey) while (node.parent && node.structure === null) node = node.parent;
		if (!inScope(node)) continue;
		const previous = next.get(node) ?? [];
		next.set(node, [...previous, issue]);
	}
	const changed = /* @__PURE__ */ new Set();
	const candidates = new Set(before.keys());
	for (const node of next.keys()) candidates.add(node);
	for (const node of candidates) {
		if (!isOwnedNode(node, runtime) || !inScope(node)) continue;
		const current = node;
		const oldIssues = before.get(node) ?? [];
		const newIssues = next.get(node) ?? [];
		if (oldIssues.length !== newIssues.length) changed.add(current);
		else if (isSameItems(oldIssues, newIssues)) {
			if (newIssues.length) next.set(node, oldIssues);
		} else changed.add(current);
	}
	runtime.validationErrors = next;
	if (runtime.validationChangedNodes) for (const node of changed) runtime.validationChangedNodes.add(node);
	else runtime.validationChangedNodes = changed;
	if (runtime.routedValidationErrors !== issues) {
		runtime.routedValidationErrors = issues;
		runtime.validationListChanged = true;
		updateFieldNodeGlobalErrors(root);
	}
	for (const node of changed) runtime.combinedErrors?.delete(node);
	return changed;
};
const isSameItems = (before, after) => {
	for (let index = 0; index < before.length; index++) if (before[index] !== after[index]) return false;
	return true;
};

//#endregion
//#region src/core/engine/validation/utils/route/normalizeValidationIssue.ts
const rewritePointer = (pointer, keepFragment) => {
	if (pointer !== "" && !isAbsolutePointer(pointer)) return void 0;
	try {
		const segments = parseStandardPointer(pointer);
		return keepFragment ? joinPointerWithPrefixOf(pointer, segments) : joinPointer(segments);
	} catch {
		return;
	}
};
const normalizeValidationIssue = (issue) => {
	const dataPath = rewritePointer(issue.dataPath, false);
	if (dataPath === void 0) return issue;
	const schemaPath = issue.schemaPath ? rewritePointer(issue.schemaPath, true) ?? issue.schemaPath : issue.schemaPath;
	return dataPath === issue.dataPath && schemaPath === issue.schemaPath ? issue : {
		...issue,
		dataPath,
		...schemaPath === void 0 ? {} : { schemaPath }
	};
};

//#endregion
//#region src/core/engine/validation/utils/run/assertValidationRootReady.ts
const DUPLICATE_SCHEMA_ID_MESSAGE = /already exists|duplicate/i;
const assertValidationRootReady = (node) => {
	const root = node.rootNode;
	const validator = root.runtime.validator;
	if (!isValidator(validator)) return null;
	const authoredRoot = root.runtime.blueprint.schema;
	const entry = readValidationEntry(validator, authoredRoot);
	if (entry.validate && !entry.failure) return entry.validate;
	const id = typeof authoredRoot === "object" && authoredRoot !== null && typeof authoredRoot.$id === "string" ? authoredRoot.$id : void 0;
	const duplicate = !!id && entry.failure instanceof Error && DUPLICATE_SCHEMA_ID_MESSAGE.test(entry.failure.message) && [...recentReleaseList(validator).counts].some(([other, count]) => other !== authoredRoot && count > 0 && typeof other === "object" && other !== null && other.$id === id);
	throw new SchemaFormError(FormErrorCode.ValidatorCompileFailed, "Whole-schema validation could not be compiled", {
		error: entry.failure,
		...duplicate ? {
			reason: "duplicateSchemaId",
			$id: id
		} : {}
	});
};

//#endregion
//#region src/core/engine/validation/utils/run/runFieldNodeValidation.ts
const runFieldNodeValidation = async (node) => {
	const validate = assertValidationRootReady(node);
	if (!validate) return null;
	try {
		const issues = await validate(node.rootNode.emit) ?? [];
		let normalized;
		for (let index = 0; index < issues.length; index++) {
			const issue = normalizeValidationIssue(issues[index]);
			if (issue !== issues[index] && !normalized) normalized = issues.slice();
			if (normalized) normalized[index] = issue;
		}
		return normalized ?? issues;
	} catch (error) {
		throw new SchemaFormError(FormErrorCode.ValidatorThrew, "Whole-schema validator threw while checking the emitted value", { error });
	}
};

//#endregion
//#region src/core/engine/validation/utils/run/requestFieldNodeValidation.ts
const requestFieldNodeValidation = (node, deliver) => {
	const runtime = node.rootNode.runtime;
	if (runtime.validationMode === ValidationMode.None || runtime.validationUnavailable) return;
	runtime.validationStamp = (runtime.validationStamp ?? 0) + 1;
	runtime.validationRequestStamp = runtime.validationStamp;
	(runtime.validationPendingTargets ?? (runtime.validationPendingTargets = /* @__PURE__ */ new Set())).add(node);
	if (runtime.validationQueued) return;
	runtime.validationQueued = true;
	queueMicrotask(() => {
		runtime.validationQueued = false;
		if (runtime.validationStamp !== runtime.validationRequestStamp) {
			runtime.validationPendingTargets = void 0;
			return;
		}
		const targets = runtime.validationPendingTargets ?? /* @__PURE__ */ new Set([node]);
		runtime.validationPendingTargets = void 0;
		const stamp = runtime.validationStamp;
		const commit = runtime.commitNumber ?? 0;
		runFieldNodeValidation(node).then((result) => {
			if (result === null) return;
			if (runtime.validationStamp !== stamp || (runtime.commitNumber ?? 0) !== commit) return;
			const issues = retainEqualValidationIssues(node, result);
			for (const target of targets) routeValidationIssues(target, issues);
			runtime.validationResult = {
				commit,
				issues
			};
			deliver(issues, commit);
		}).catch((failure) => {
			if (runtime.validationStamp !== stamp) return;
			if (failure !== null && typeof failure === "object" && "code" in failure && failure.code === FormErrorCode.ValidatorCompileFailed) {
				runtime.validationUnavailable = true;
				if (runtime.validationCompileReported) return;
				runtime.validationCompileReported = true;
			}
			runtime.reportValidationFailure?.(failure);
		});
	});
};

//#endregion
//#region src/core/engine/validation/utils/read/readFieldNodeErrors.ts
const EMPTY_ISSUES = Object.freeze([]);
const readFieldNodeErrors = (node) => {
	const runtime = node.rootNode.runtime;
	if (node.detached) return runtime.detachedReads?.get(node)?.errors ?? EMPTY_ISSUES;
	const external = runtime.nodeErrors?.get(node);
	const validation = runtime.validationErrors?.get(node);
	const isIssues = (items) => !!items && items.every((item) => item !== null && typeof item === "object" && "dataPath" in item && typeof item.dataPath === "string");
	if (!isIssues(external)) return isIssues(validation) ? validation : EMPTY_ISSUES;
	if (!isIssues(validation)) return external;
	const cached = runtime.combinedErrors?.get(node);
	if (cached?.external === external && cached.validation === validation && isIssues(cached.errors)) return cached.errors;
	const errors = [...external, ...validation];
	(runtime.combinedErrors ?? (runtime.combinedErrors = /* @__PURE__ */ new Map())).set(node, {
		external,
		validation,
		errors
	});
	return errors;
};

//#endregion
//#region src/core/engine/validation/utils/lifetime/retainValidationRoot.ts
const retainValidationRoot = (validator, authoredRoot) => {
	readValidationEntry(validator, authoredRoot);
	const list = recentReleaseList(validator);
	const index = list.recent.indexOf(authoredRoot);
	if (index >= 0) list.recent.splice(index, 1);
	list.counts.set(authoredRoot, (list.counts.get(authoredRoot) ?? 0) + 1);
};

//#endregion
//#region src/core/engine/validation/utils/lifetime/releaseValidationRoot.ts
const releaseValidationRoot = (validator, authoredRoot) => {
	const list = recentReleaseList(validator);
	const count = list.counts.get(authoredRoot);
	if (!count || count <= 0) return;
	list.counts.set(authoredRoot, count - 1);
	if (count > 1) return;
	list.recent.push(authoredRoot);
	if (list.recent.length > 8) evictValidationRoot(validator, list.recent[0]);
};

//#endregion
//#region src/core/engine/settle/utils/gates/predicates/collectIfGateReadNames.ts
const VALUE_KEYWORDS = [
	"type",
	"const",
	"enum",
	"minimum",
	"maximum",
	"exclusiveMinimum",
	"exclusiveMaximum",
	"multipleOf",
	"minLength",
	"maxLength",
	"pattern"
];
const collectIfGateReadNames = (schema, names, property) => {
	if (typeof schema === "boolean") return true;
	if (!schema || typeof schema !== "object" || isArray(schema)) return false;
	for (const [key, value] of Object.entries(schema)) if (key === "allOf" || key === "anyOf" || key === "oneOf") {
		if (!isArray(value) || !value.every((entry) => collectIfGateReadNames(entry, names, property))) return false;
	} else if (key === "not") {
		if (!collectIfGateReadNames(value, names, property)) return false;
	} else if (property && VALUE_KEYWORDS.includes(key)) continue;
	else if (key === "type") {
		if (value !== "object") return false;
	} else if (key === "properties") {
		if (!value || typeof value !== "object" || isArray(value)) return false;
		for (const [name, condition] of Object.entries(value)) {
			if (!collectIfGateReadNames(condition, names, true)) return false;
			if (!property && !names.includes(name)) names.push(name);
		}
	} else if (key === "required") {
		if (!isArray(value) || value.some((name) => typeof name !== "string")) return false;
		if (!property) {
			for (const name of value) if (!names.includes(name)) names.push(name);
		}
	} else if (key === "dependentRequired") {
		if (!value || typeof value !== "object" || isArray(value)) return false;
		for (const [name, required] of Object.entries(value)) {
			if (!isArray(required) || required.some((entry) => typeof entry !== "string")) return false;
			if (!property) {
				if (!names.includes(name)) names.push(name);
				for (const entry of required) if (!names.includes(entry)) names.push(entry);
			}
		}
	} else return false;
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/gates/predicates/getIfGateReadNames.ts
const EMPTY_NAMES = Object.freeze([]);
const getIfGateReadNames = (condition, blueprint) => {
	if (typeof condition === "boolean") return EMPTY_NAMES;
	if (!condition || typeof condition !== "object") return void 0;
	const record = blueprint ? getBlueprintDerived(blueprint) : void 0;
	const memo = record ? record.ifGateReadNames ?? (record.ifGateReadNames = /* @__PURE__ */ new Map()) : void 0;
	const cached = memo?.get(condition);
	if (cached !== void 0) return cached ?? void 0;
	const names = [];
	const result = collectIfGateReadNames(condition, names, false) ? names : void 0;
	memo?.set(condition, result ?? null);
	return result;
};

//#endregion
//#region src/core/engine/settle/utils/gates/predicates/createGatePredicate.ts
const createGatePredicate = (runtime, occurrence, reads) => {
	const gate = occurrence.gate;
	const expression = gate.kind === "active" ? getGateExpression(runtime.blueprint, gate.schemaPath) : void 0;
	const names = gate.kind === "if" && engineModes.gatePredicate !== "off" ? getIfGateReadNames(gate.condition, runtime.blueprint) : void 0;
	let guard;
	const inputs = [];
	const referenceDiscriminator = gate.kind === "discriminator" && engineModes.gatePredicate === "off";
	const inputReads = referenceDiscriminator ? [occurrence.hostPath] : reads;
	for (let index = 0; index < inputReads.length; index++) {
		const path = inputReads[index];
		const kind = readPointerSegment(path, 0) === PointerOperator.Context ? "context" : names ? "property" : "value";
		inputs.push({
			path,
			kind,
			key: kind === "value" ? path : kind + ":" + path,
			...names ? {
				hostPath: occurrence.hostPath,
				name: names[index]
			} : {}
		});
		if (names) inputs.push({
			path,
			kind: "presence",
			key: "presence:" + path,
			hostPath: occurrence.hostPath,
			name: names[index]
		});
	}
	if (gate.kind === "if" && !names || referenceDiscriminator) inputs.push({
		path: occurrence.hostPath,
		kind: "extra",
		key: "extra:" + occurrence.hostPath
	});
	return {
		reads,
		names,
		inputs,
		arguments: {
			values: new Array(inputs.length),
			view: void 0
		},
		memoizable: engineModes.gatePredicate !== "off" && (gate.kind !== "active" || expression?.completeReads === true && !reads.some((path) => readPointerSegment(path, 0) === PointerOperator.Context)),
		evaluate: (input) => {
			if (gate.kind === "if") {
				guard ?? (guard = readFieldNodeGuard(runtime, gate));
				if (!guard) return void 0;
				const result = guard(input.view);
				if (typeof result !== "boolean") throw new TypeError(`Guard at ${gate.schemaPath} did not return a boolean`);
				return gate.negated ? !result : result;
			}
			if (gate.kind === "discriminator") {
				const value = input.view && hasOwnProperty(input.view, gate.condition.propertyName) ? input.view[gate.condition.propertyName] : void 0;
				for (const tag of gate.condition.values) if (tag === value) return true;
				return false;
			}
			return expression ? Boolean(expression.evaluate(input.values)) : gate.condition === true;
		}
	};
};

//#endregion
//#region src/core/engine/settle/utils/gates/bindGateHostPath.ts
const bindGateHostPath = (gate, templatePath, occurrencePath, childHostPath) => {
	const suffix = gate.hostPath === templatePath ? "" : isDescendantPath(gate.hostPath, templatePath) ? gate.hostPath.slice(templatePath.length) : void 0;
	return childHostPath ?? bindTemplatePath(suffix === void 0 ? gate.hostPath : occurrencePath + suffix, occurrencePath);
};

//#endregion
//#region src/core/engine/settle/utils/gates/resolveGateOccurrence.ts
const resolveGateOccurrence = (gate, templatePath, occurrencePath, childHostPath, readSegments = parsePointerSegments) => {
	const hostPath = bindGateHostPath(gate, templatePath, occurrencePath, childHostPath);
	let common = readSegments(hostPath);
	for (const read of gate.evaluationReads) {
		if (typeof read === "number") {
			common = common.slice(0, Math.max(0, common.length - read));
			continue;
		}
		const target = readSegments(bindTemplatePath(read, childHostPath ?? occurrencePath));
		let index = 0;
		while (index < common.length && index < target.length && common[index] === target[index]) index++;
		common = common.slice(0, index);
	}
	return {
		gate,
		hostPath,
		evaluationHostPath: joinPointer(common)
	};
};

//#endregion
//#region src/core/engine/settle/utils/gates/getGateRegistry.ts
var RegisteredGateOccurrence = class {
	constructor(runtime, location, watchPaths) {
		this.runtime = runtime;
		this.watchPaths = watchPaths;
		this.gate = location.gate;
		this.hostPath = location.hostPath;
		this.evaluationHostPath = location.evaluationHostPath;
	}
	get predicate() {
		return this.boundPredicate ?? (this.boundPredicate = createGatePredicate(this.runtime, this, this.watchPaths));
	}
};
const bumpWatchCount = (map, key, by) => {
	const next = (map.get(key) ?? 0) + by;
	if (next > 0) map.set(key, next);
	else map.delete(key);
};
var GateRegistry = class {
	constructor(blueprint, runtime) {
		this.blueprint = blueprint;
		this.runtime = runtime;
		this.watchIndex = /* @__PURE__ */ new Map();
		this.byNode = /* @__PURE__ */ new WeakMap();
		this.byEdge = /* @__PURE__ */ new WeakMap();
		this.byPath = /* @__PURE__ */ new Map();
		this.byLocation = /* @__PURE__ */ new Map();
		this.relocatedBuckets = /* @__PURE__ */ new Map();
		this.relocatedLists = /* @__PURE__ */ new Map();
		this.resolvedReads = /* @__PURE__ */ new Map();
		this.segments = /* @__PURE__ */ new Map();
		this.readSegments = (path) => this.pathSegments(path);
	}
	resolveRead(hostPath, dependency) {
		let reads = this.resolvedReads.get(hostPath);
		if (!reads) {
			reads = /* @__PURE__ */ new Map();
			this.resolvedReads.set(hostPath, reads);
		}
		let path = reads.get(dependency);
		if (path === void 0) {
			path = resolveDependencyPath(hostPath, dependency);
			reads.set(dependency, path);
		}
		return path;
	}
	pathSegments(path) {
		let segments = this.segments.get(path);
		if (!segments) {
			segments = getDependencyIndex(this.blueprint).pathSegments(path, this.runtime);
			this.segments.set(path, segments);
		}
		return segments;
	}
	hasRegisteredPathKind(path, kind) {
		if (this.byPath.size === 0) return void 0;
		return this.byPath.get(path)?.kind === kind;
	}
	register(node) {
		if (this.byPath.get(node.path)?.node === node) return;
		this.removePath(node.path);
		const memo = /* @__PURE__ */ new Map();
		const edges = /* @__PURE__ */ new Map();
		for (const declaration of node.blueprintNode.declarations) for (const gate of declaration.gates) this.add(node, gate, memo, gate.schemaPath === appendSegment(appendSegment(node.blueprintNode.schemaPath, "controls"), "active") ? node.path : void 0);
		const ownOccurrences = [...memo.values()];
		for (const entry of node.blueprintNode.childEntries) {
			let edgeMemo = edges.get(entry.name);
			if (!edgeMemo) {
				edgeMemo = /* @__PURE__ */ new Map();
				edges.set(entry.name, edgeMemo);
			}
			for (const declaration of entry.declarations) for (const gate of declaration.gates) if (gate.schemaPath === appendSegment(appendSegment(declaration.schemaPath, "controls"), "active")) this.add(node, gate, edgeMemo, appendSegment(node.path, entry.name));
			else this.add(node, gate, memo);
		}
		this.byNode.set(node, memo);
		this.byEdge.set(node, edges);
		this.byPath.set(node.path, {
			node,
			kind: getBlueprintNodeIdentity(node.blueprintNode),
			ownOccurrences,
			occurrences: [...memo.values(), ...[...edges.values()].flatMap((edge) => [...edge.values()])]
		});
	}
	occurrenceCount(path) {
		return this.byPath.get(path)?.occurrences.length ?? 0;
	}
	locate(node, gate, edgeName) {
		this.register(node);
		const edge = edgeName ? this.byEdge.get(node)?.get(edgeName)?.get(gate) : void 0;
		if (edge) return edge;
		const existing = this.byNode.get(node)?.get(gate);
		if (existing) return existing;
		const memo = this.byNode.get(node);
		if (!memo) throw new Error(`Missing gate memo at ${node.path}`);
		this.add(node, gate, memo);
		const edges = this.byEdge.get(node);
		this.byPath.set(node.path, {
			node,
			kind: getBlueprintNodeIdentity(node.blueprintNode),
			ownOccurrences: this.byPath.get(node.path)?.ownOccurrences ?? [],
			occurrences: [...memo.values(), ...[...edges?.values() ?? []].flatMap((edgeMemo) => [...edgeMemo.values()])]
		});
		const occurrence = memo.get(gate);
		if (!occurrence) throw new Error(`Missing gate at ${node.path}`);
		return occurrence;
	}
	relocated(path) {
		const bucket = this.relocatedBuckets.get(path);
		if (!bucket?.size) return EMPTY_OCCURRENCES;
		let list = this.relocatedLists.get(path);
		if (!list) {
			list = [...bucket];
			this.relocatedLists.set(path, list);
		}
		return list;
	}
	mayChangeAt(path, changedRaw, changedAncestors) {
		for (const occurrence of this.byLocation.get(path) ?? []) if (this.readsChanged(occurrence, changedRaw, changedAncestors)) return true;
		return false;
	}
	mayPresenceChangeAt(path, changed, prefixes, changedLog, prefixLog, cursor, metrics) {
		if (changed.size === 0) return false;
		let index = this.watchIndex.get(path);
		if (!index) {
			const entries = this.byLocation.get(path);
			if (!entries?.size) return false;
			index = {
				exact: /* @__PURE__ */ new Map(),
				strictPrefixes: /* @__PURE__ */ new Map(),
				root: 0,
				log: [],
				epoch: 0
			};
			for (const occurrence of entries) this.indexWatched(index, occurrence, 1);
			this.watchIndex.set(path, index);
		}
		if (cursor.epoch !== index.epoch) {
			cursor.epoch = index.epoch;
			cursor.index = 0;
		}
		if (index.root > 0) return true;
		for (; cursor.changed < changedLog.length; cursor.changed++) {
			if (metrics) metrics.indexLookups++;
			const entry = changedLog[cursor.changed];
			if (index.exact.has(entry) || index.strictPrefixes.has(entry)) return true;
		}
		for (; cursor.prefixes < prefixLog.length; cursor.prefixes++) {
			if (metrics) metrics.indexLookups++;
			if (index.exact.has(prefixLog[cursor.prefixes])) return true;
		}
		for (; cursor.index < index.log.length; cursor.index++) {
			if (metrics) metrics.indexLookups++;
			const watched = index.log[cursor.index];
			if (!index.exact.has(watched)) continue;
			if (changed.has(watched) || prefixes.has(watched)) return true;
			if (isAbsolutePath(watched)) for (let prefix = watched; prefix;) {
				prefix = resolvePointer(prefix, "..");
				if (changed.has(prefix)) return true;
			}
		}
		return false;
	}
	mayChangeOwnDeclarationAt(path, changedRaw, changedAncestors) {
		for (const occurrence of this.byPath.get(path)?.ownOccurrences ?? []) if (this.readsChanged(occurrence, changedRaw, changedAncestors)) return true;
		return false;
	}
	remove(node) {
		for (const child of node.children ?? []) if (child.parent === node) this.remove(child);
		if (this.byPath.get(node.path)?.node === node) this.removePath(node.path);
	}
	add(node, gate, memo, childHostPath) {
		if (memo.has(gate)) return;
		const location = resolveGateOccurrence(gate, node.blueprintNode.path, node.path, childHostPath, this.readSegments);
		const watchPaths = this.watchPaths(location);
		const occurrence = new RegisteredGateOccurrence(this.runtime, location, watchPaths);
		memo.set(gate, occurrence);
		let entries = this.byLocation.get(occurrence.evaluationHostPath);
		if (!entries) {
			entries = /* @__PURE__ */ new Set();
			this.byLocation.set(occurrence.evaluationHostPath, entries);
		}
		entries.add(occurrence);
		if (occurrence.hostPath !== occurrence.evaluationHostPath) {
			let bucket = this.relocatedBuckets.get(occurrence.evaluationHostPath);
			if (!bucket) {
				bucket = /* @__PURE__ */ new Set();
				this.relocatedBuckets.set(occurrence.evaluationHostPath, bucket);
			}
			bucket.add(occurrence);
			this.relocatedLists.delete(occurrence.evaluationHostPath);
		}
		this.indexOccurrence(occurrence, 1);
	}
	indexOccurrence(occurrence, by) {
		const index = this.watchIndex.get(occurrence.evaluationHostPath);
		if (index) this.indexWatched(index, occurrence, by);
	}
	indexWatched(index, occurrence, by) {
		for (const watched of occurrence.watchPaths) {
			if (watched === "") {
				index.root += by;
				continue;
			}
			if (by > 0 && !index.exact.has(watched)) index.log.push(watched);
			bumpWatchCount(index.exact, watched, by);
			if (isAbsolutePath(watched)) for (let prefix = watched; prefix;) {
				prefix = resolvePointer(prefix, "..");
				bumpWatchCount(index.strictPrefixes, prefix, by);
			}
		}
		if (by > 0 && index.log.length > 2 * index.exact.size + 8) {
			index.log = [...index.exact.keys()];
			index.epoch++;
		}
	}
	watchPaths(location) {
		const gate = location.gate;
		if (gate.kind === "if") {
			const names = engineModes.gatePredicate === "off" ? void 0 : getIfGateReadNames(gate.condition, this.blueprint);
			return names ? names.map((name) => appendSegment(location.hostPath, name)) : [location.hostPath];
		}
		if (gate.kind === "discriminator" && gate.condition !== null && typeof gate.condition === "object" && "propertyName" in gate.condition && typeof gate.condition.propertyName === "string") return [appendSegment(location.hostPath, gate.condition.propertyName)];
		const expression = getGateExpression(this.blueprint, gate.schemaPath);
		return expression ? expression.dependencies.map((dependency) => {
			return this.resolveRead(location.hostPath, dependency);
		}) : [location.hostPath];
	}
	readsChanged(occurrence, changedRaw, changedAncestors) {
		if (changedRaw.size === 0) return false;
		for (const watched of occurrence.watchPaths) {
			if (watched === "" || changedRaw.has(watched) || changedAncestors.has(watched)) return true;
			if (isAbsolutePath(watched)) for (let prefix = watched; prefix;) {
				prefix = resolvePointer(prefix, "..");
				if (changedRaw.has(prefix)) return true;
			}
		}
		return false;
	}
	removePath(path) {
		const previous = this.byPath.get(path);
		if (!previous) return;
		for (const occurrence of previous.occurrences) {
			if (this.byLocation.get(occurrence.evaluationHostPath)?.delete(occurrence)) this.indexOccurrence(occurrence, -1);
			if (this.relocatedBuckets.get(occurrence.evaluationHostPath)?.delete(occurrence)) {
				this.relocatedLists.delete(occurrence.evaluationHostPath);
				if (!this.relocatedBuckets.get(occurrence.evaluationHostPath)?.size) this.relocatedBuckets.delete(occurrence.evaluationHostPath);
			}
		}
		this.byPath.delete(path);
	}
};
const REGISTRIES = /* @__PURE__ */ new WeakMap();
const decodePointerSegments = (path) => parsePointerSegments(path);
const EMPTY_REGISTRY = Object.freeze({
	hasRegisteredPathKind: () => void 0,
	register: () => void 0,
	locate: () => {
		throw new Error("A branchless blueprint has no gate occurrences");
	},
	relocated: () => EMPTY_OCCURRENCES,
	mayChangeAt: () => false,
	mayPresenceChangeAt: () => false,
	mayChangeOwnDeclarationAt: () => false,
	remove: () => void 0,
	resolveRead: resolveDependencyPath,
	pathSegments: decodePointerSegments,
	occurrenceCount: () => 0
});
const EMPTY_OCCURRENCES = Object.freeze([]);
const getGateRegistry = (runtime) => {
	if (runtime.blueprint.capabilities.branchless) return EMPTY_REGISTRY;
	let registry = REGISTRIES.get(runtime);
	if (!registry) {
		registry = new GateRegistry(runtime.blueprint, runtime);
		REGISTRIES.set(runtime, registry);
	}
	return registry;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/deferPresenceTemplate.ts
const deferPresenceTemplate = (template, kind, origin, context, stamp) => {
	const pending = context.presenceTemplates ?? (context.presenceTemplates = /* @__PURE__ */ new Map());
	const key = kind + "\0" + template;
	const entry = pending.get(key);
	if (!entry) {
		const segments = getDependencyIndex(context.root.runtime.blueprint).pathSegments(template, context.root.runtime);
		const wildcard = segments.indexOf(PointerOperator.Wildcard);
		const host = joinPointer(segments.slice(0, wildcard < 0 ? void 0 : wildcard));
		pending.set(key, {
			template,
			kind,
			deepest: origin,
			host,
			stamp
		});
		context.dirtyPaths.add(host);
		context.shapeDirtyPaths.add(host);
		for (let ancestor = host; ancestor;) {
			ancestor = resolvePointer(ancestor, "..");
			context.dirtyPaths.add(ancestor);
		}
		return true;
	}
	entry.stamp = Math.max(entry.stamp, stamp);
	const deepest = entry.deepest;
	if (deepest !== null && deepest !== origin && !(origin === "" || isDescendantPath(deepest, origin))) entry.deepest = deepest === "" || isDescendantPath(origin, deepest) ? origin : null;
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/registerProjectionChanges.ts
const registerProjectionChanges = (host, names, context) => {
	const baselines = context.projectionBaselines?.get(host);
	if (!baselines) return;
	for (const [child, previous] of baselines) {
		if (host.structure?.[child.name] !== child) continue;
		if (child.schema !== previous.schema && child.emit !== previous.emit) {
			const name = formatSegment(child.name);
			if (!names.includes(name)) names.push(name);
		}
		previous.schema = child.schema;
		previous.emit = child.emit;
	}
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/registerPresenceChanges.ts
const parentOf = (path) => resolvePointer(path, "..");
const registerPresenceChanges = (host, previous, context) => {
	if (!context.hasGates) return false;
	if (context.presenceMetrics) context.presenceMetrics.calls++;
	const structure = host.structure ?? {};
	const names = [];
	for (const name in previous) if (!hasOwnProperty(structure, name) || previous[name] !== structure[name]) names.push(formatSegment(name));
	for (const name in structure) if (!hasOwnProperty(previous, name)) names.push(formatSegment(name));
	registerProjectionChanges(host, names, context);
	if (names.length === 0) return false;
	const accumulated = context.changedPresence ?? (context.changedPresence = /* @__PURE__ */ new Set());
	const prefixes = context.presencePrefixes ?? (context.presencePrefixes = /* @__PURE__ */ new Set());
	const changedLog = context.presenceLog ?? (context.presenceLog = []);
	const prefixLog = context.presencePrefixLog ?? (context.presencePrefixLog = []);
	const dependencies = getDependencyIndex(context.root.runtime.blueprint);
	const owners = /* @__PURE__ */ new Set();
	const ownerStamps = /* @__PURE__ */ new Map();
	const stateOnly = /* @__PURE__ */ new Set();
	let marked = false;
	for (const name of names) {
		const rawName = parsePointerSegment(name);
		if (typeof rawName !== "string") continue;
		const path = appendSegment(host.path, rawName);
		const child = hasOwnProperty(structure, rawName) ? structure[rawName] : void 0;
		const computeStart = child ? context.presenceComputeStarts?.get(child) ?? 0 : 0;
		let stamp = computeStart;
		if (computeStart <= (context.presenceRoundStarts?.get(host) ?? 0)) {
			context.presenceClock = (context.presenceClock ?? 0) + 1;
			stamp = context.presenceClock;
		}
		if (!accumulated.has(path)) {
			accumulated.add(path);
			changedLog.push(path);
			for (let prefix = path; prefix;) {
				prefix = parentOf(prefix);
				if (prefixes.has(prefix)) break;
				prefixes.add(prefix);
				prefixLog.push(prefix);
			}
		}
		const affected = dependencies.affectedByPresence(host.path, name, context.presenceMetrics, context, context.root.runtime);
		for (const owner of affected.owners) {
			owners.add(owner);
			ownerStamps.set(owner, Math.max(ownerStamps.get(owner) ?? 0, stamp));
		}
		for (const owner of affected.stateOnly) stateOnly.add(owner);
		for (const template of affected.outerTemplates) marked = deferPresenceTemplate(template, "outer", host.path, context, stamp) || marked;
		for (const template of affected.directTemplates) marked = deferPresenceTemplate(template, "direct", path, context, stamp) || marked;
	}
	for (const owner of owners) {
		if (owner !== "" && parentOf(owner) === host.path || evaluatedPresenceAfter(owner, ownerStamps.get(owner), context)) {
			publishPresenceOwner(owner, context);
			continue;
		}
		context.dirtyPaths.add(owner);
		context.dependencyOwnerPaths.add(owner);
		context.shapeDirtyPaths.add(parentOf(owner));
		for (let ancestor = owner; ancestor;) {
			ancestor = parentOf(ancestor);
			context.dirtyPaths.add(ancestor);
		}
		marked = true;
	}
	const features = getFeatureNodeIndex(context.root.runtime.blueprint);
	for (const owner of stateOnly) {
		if (owners.has(owner)) continue;
		const live = getLivePresenceNode(context.root, owner);
		if (!live) continue;
		if (features.stateKeyNodes.has(live.blueprintNode.id) || live.parent && features.stateKeyChildren.get(live.parent.blueprintNode.id)?.has(live.name)) {
			context.dependencyOwnerPaths.add(owner);
			context.stateDirtyNodes.add(live);
		}
	}
	const registry = getGateRegistry(context.root.runtime);
	for (let ancestor = parentOf(host.path); host.path; ancestor = parentOf(ancestor)) {
		if (!context.shapeDirtyPaths.has(ancestor)) {
			const cursors = context.presenceQueryCursors ?? (context.presenceQueryCursors = /* @__PURE__ */ new Map());
			let cursor = cursors.get(ancestor);
			if (!cursor) {
				cursor = {
					changed: 0,
					prefixes: 0,
					index: 0
				};
				cursors.set(ancestor, cursor);
			}
			if (registry.mayPresenceChangeAt(ancestor, accumulated, prefixes, changedLog, prefixLog, cursor, context.presenceMetrics)) {
				context.shapeDirtyPaths.add(ancestor);
				marked = true;
			}
		}
		if (ancestor && !context.shapeDirtyPaths.has(parentOf(ancestor)) && registry.mayChangeOwnDeclarationAt(ancestor, accumulated, prefixes)) {
			context.shapeDirtyPaths.add(parentOf(ancestor));
			marked = true;
		}
		if (!ancestor) break;
	}
	if (marked) context.presenceRegistrations = (context.presenceRegistrations ?? 0) + 1;
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/gates/gateSelectionTable.ts
const gateSelectionTable = {
	violations: 0,
	assertions: Object.create(null)
};

//#endregion
//#region src/core/engine/settle/utils/gates/verifyGateSelection.ts
const verifyGateSelection = (valid, message) => {
	if (engineModes.gateSelection !== "verify") return;
	const invariant = message.split(" ", 1)[0];
	gateSelectionTable.assertions[invariant] = (gateSelectionTable.assertions[invariant] ?? 0) + 1;
	if (valid) return;
	gateSelectionTable.violations++;
	throw new Error(message);
};

//#endregion
//#region src/core/engine/settle/utils/scratch/DirtyPathSet.ts
var DirtyPathSet = class extends Set {
	constructor(childrenByParent) {
		super();
		this.splitRuns = /* @__PURE__ */ new Map();
		this.memberAnchors = /* @__PURE__ */ new Map();
		this.postOrder = false;
		this.childrenByParent = childrenByParent;
	}
	get isPostOrder() {
		return this.postOrder;
	}
	configureSplitOwners(owners) {
		this.splitOwners = owners;
	}
	planSplitAnchors(bucket, liveRanks, epoch) {
		if (!bucket.hostPath) return [];
		let states = this.splitRuns.get(bucket);
		const first = !states;
		if (!states) {
			states = bucket.runs.map(() => ({
				excluded: /* @__PURE__ */ new Set(),
				released: /* @__PURE__ */ new Map()
			}));
			this.splitRuns.set(bucket, states);
		}
		const living = new Set(liveRanks);
		const events = [];
		let liveCursor = 0;
		for (let run = 0; run < bucket.runs.length; run++) {
			const definition = bucket.runs[run];
			const state = states[run];
			let rank;
			let count = 0;
			const represented = [];
			if (first) {
				const lastRank = definition.ranks[definition.ranks.length - 1];
				while (liveCursor < liveRanks.length && liveRanks[liveCursor] <= lastRank) state.excluded.add(liveRanks[liveCursor++]);
				count = definition.ranks.length - state.excluded.size;
				if (count) {
					for (const candidate of definition.ranks) if (!state.excluded.has(candidate)) {
						rank = candidate;
						break;
					}
				}
			} else {
				for (const [releasedRank, path] of state.released) if (!living.has(releasedRank)) {
					represented.push(path);
					count++;
					if (rank === void 0 || releasedRank < rank) rank = releasedRank;
				}
				state.released.clear();
			}
			if (rank === void 0 || !count) continue;
			const anchor = {
				key: "\0" + bucket.hostPath + "\0" + epoch + "\0" + (definition.id ?? run),
				hostPath: bucket.hostPath,
				count
			};
			if (first) state.initial = anchor;
			else for (const path of represented) this.memberAnchors.set(path, anchor);
			events.push({
				rank,
				insert: () => this.insertSplitAnchor(anchor)
			});
		}
		return events;
	}
	insertSplitAnchor(anchor) {
		let parent = "";
		while (parent !== anchor.hostPath) {
			const child = getChildPointer(anchor.hostPath, parent);
			if (child === void 0) break;
			const segment = readFormattedNameSegment(child, -1);
			if (segment === void 0) break;
			let children = this.childrenByParent.get(parent);
			if (!children) this.childrenByParent.set(parent, children = /* @__PURE__ */ new Map());
			children.set(anchor.key, segment);
			parent = child;
		}
	}
	releaseSplitMember(path) {
		const owner = this.splitOwners?.get(path);
		if (!owner) return;
		const state = this.splitRuns.get(owner.bucket)?.[owner.run];
		if (!state) return;
		let anchor = this.memberAnchors.get(path);
		if (anchor) this.memberAnchors.delete(path);
		else if (state.initial && !state.excluded.has(owner.rank)) {
			anchor = state.initial;
			state.excluded.add(owner.rank);
		}
		state.released.set(owner.rank, path);
		if (!anchor || --anchor.count !== 0) return;
		let parent = "";
		while (parent !== anchor.hostPath) {
			const child = getChildPointer(anchor.hostPath, parent);
			if (child === void 0) break;
			const children = this.childrenByParent.get(parent);
			children?.delete(anchor.key);
			if (children?.size === 0) this.childrenByParent.delete(parent);
			parent = child;
		}
	}
	beginPostOrder() {
		if (this.postOrder) return;
		this.postOrder = true;
		this.childrenByParent.clear();
		const linked = /* @__PURE__ */ new Set();
		for (const path of this) {
			let current = path;
			while (current && !linked.has(current)) {
				linked.add(current);
				const parent = resolvePointer(current, "..");
				const segment = readFormattedNameSegment(current, -1);
				if (segment === void 0) break;
				super.add(parent);
				let children = this.childrenByParent.get(parent);
				if (!children) {
					children = /* @__PURE__ */ new Map();
					this.childrenByParent.set(parent, children);
				}
				children.set(current, segment);
				current = parent;
			}
		}
	}
	add(path) {
		if (this.has(path)) return this;
		if (this.postOrder) {
			let current = path;
			while (!this.has(current)) {
				super.add(current);
				if (!current) break;
				const parent = resolvePointer(current, "..");
				const segment = readFormattedNameSegment(current, -1);
				if (segment === void 0) break;
				let children = this.childrenByParent.get(parent);
				if (!children) {
					children = /* @__PURE__ */ new Map();
					this.childrenByParent.set(parent, children);
				}
				if (children.has(current)) children.delete(current);
				children.set(current, segment);
				current = parent;
			}
			return this;
		}
		super.add(path);
		let parent = "";
		while (parent !== path) {
			const child = getChildPointer(path, parent);
			if (child === void 0) break;
			const segment = readFormattedNameSegment(child, -1);
			if (segment === void 0) break;
			let children = this.childrenByParent.get(parent);
			if (!children) {
				children = /* @__PURE__ */ new Map();
				this.childrenByParent.set(parent, children);
			}
			children.set(path, segment);
			parent = child;
		}
		return this;
	}
	delete(path) {
		if (!super.delete(path)) return false;
		if (this.postOrder) {
			if (path) {
				const parent = resolvePointer(path, "..");
				const children = this.childrenByParent.get(parent);
				children?.delete(path);
				if (children?.size === 0) this.childrenByParent.delete(parent);
			}
			return true;
		}
		if (this.splitOwners) this.releaseSplitMember(path);
		let parent = "";
		while (parent !== path) {
			const child = getChildPointer(path, parent);
			if (child === void 0) break;
			const children = this.childrenByParent.get(parent);
			children?.delete(path);
			if (children?.size === 0) this.childrenByParent.delete(parent);
			parent = child;
		}
		return true;
	}
	consume(path) {
		if (!this.postOrder) return this.delete(path);
		if (engineModes.gateSelection === "verify") for (const child of this.childrenByParent.get(path)?.keys() ?? []) verifyGateSelection(!this.has(child), "S6 consume has an unconsumed child: " + child);
		if (!super.delete(path)) return false;
		this.childrenByParent.delete(path);
		return true;
	}
	clear() {
		super.clear();
		this.childrenByParent.clear();
		this.postOrder = false;
		this.splitOwners = void 0;
		this.splitRuns.clear();
		this.memberAnchors.clear();
	}
};

//#endregion
//#region src/core/engine/settle/utils/compute/dirtyChildren.ts
const dirtyChildren = (node, context) => {
	const children = [];
	const seen = /* @__PURE__ */ new Set();
	for (const encoded of context.dirtyChildrenByParent.get(node.path)?.values() ?? []) {
		const name = parsePointerSegment(encoded);
		if (typeof name !== "string") continue;
		const child = node.structure && hasOwnProperty(node.structure, name) ? node.structure[name] : void 0;
		if (child && !seen.has(child)) {
			if (engineModes.gateSelection === "verify" && context.dirtyPaths instanceof DirtyPathSet && context.dirtyPaths.isPostOrder) verifyGateSelection(context.dirtyPaths.has(child.path), "S6 dirtyChildren returned a consumed child: " + child.path);
			seen.add(child);
			children.push(child);
		}
	}
	const shadow = engineModes.gateSelection === "verify" ? context.registrationShadow : void 0;
	if (shadow) {
		const expected = dirtyChildren(node, {
			...context,
			registrationShadow: void 0,
			dirtyChildrenByParent: shadow.dirty.childrenByParent
		});
		verifyGateSelection(children.length === expected.length && children.every((child, index) => child === expected[index]), "S3 dirtyChildren members/order differ at: " + node.path);
	}
	return children;
};

//#endregion
//#region src/core/engine/settle/utils/gates/readGateProjectedExtra.ts
const readGateProjectedExtra = (context, hostPath, raw, owner) => {
	let hostNode;
	if (hostPath === owner?.path) hostNode = owner;
	else {
		hostNode = context.root;
		const segments = hostPath ? context.root.runtime.blueprint.capabilities.branchless ? getCachedPointerSegments(context.root.runtime, hostPath) : getGateRegistry(context.root.runtime).pathSegments(hostPath) : [];
		for (let index = 0; index < segments.length; index++) {
			const structure = hostNode?.structure;
			const name = segments[index];
			if (typeof name !== "string") return void 0;
			hostNode = structure && hasOwnProperty(structure, name) ? structure[name] : void 0;
		}
	}
	for (let ancestor = hostNode; ancestor; ancestor = ancestor.parent) if (ancestor.behavior.strategy === "branch" && ancestor.raw !== void 0 && (ancestor.parent !== null || raw === null || typeof raw !== "object" || isArray(raw))) return void 0;
	return hostNode?.undeclaredValues;
};

//#endregion
//#region src/core/engine/settle/utils/declarations/getDeclaredChildNames.ts
const getDeclaredChildNames = (template) => {
	let names = getHostDerived(template).declaredNames;
	if (!names) {
		names = new Set(template.childEntries.map((entry) => entry.name));
		getHostDerived(template).declaredNames = names;
	}
	return names;
};

//#endregion
//#region src/core/engine/record/constants/emptyRevisionLedger.ts
const EMPTY_REVISION_LEDGER = Object.freeze({});

//#endregion
//#region src/core/engine/record/constants/FieldNodeEventType.ts
let FieldNodeEventType = /* @__PURE__ */ function(FieldNodeEventType) {
	FieldNodeEventType[FieldNodeEventType["Initialized"] = 1] = "Initialized";
	FieldNodeEventType[FieldNodeEventType["UpdatePath"] = 2] = "UpdatePath";
	FieldNodeEventType[FieldNodeEventType["UpdateValue"] = 4] = "UpdateValue";
	FieldNodeEventType[FieldNodeEventType["UpdateState"] = 8] = "UpdateState";
	FieldNodeEventType[FieldNodeEventType["UpdateGlobalState"] = 16] = "UpdateGlobalState";
	FieldNodeEventType[FieldNodeEventType["UpdateError"] = 32] = "UpdateError";
	FieldNodeEventType[FieldNodeEventType["UpdateGlobalError"] = 64] = "UpdateGlobalError";
	FieldNodeEventType[FieldNodeEventType["UpdateChildren"] = 128] = "UpdateChildren";
	FieldNodeEventType[FieldNodeEventType["UpdateControlledProperties"] = 256] = "UpdateControlledProperties";
	FieldNodeEventType[FieldNodeEventType["Focused"] = 512] = "Focused";
	FieldNodeEventType[FieldNodeEventType["Blurred"] = 1024] = "Blurred";
	FieldNodeEventType[FieldNodeEventType["RequestFocus"] = 2048] = "RequestFocus";
	FieldNodeEventType[FieldNodeEventType["RequestSelect"] = 4096] = "RequestSelect";
	FieldNodeEventType[FieldNodeEventType["RequestRefresh"] = 8192] = "RequestRefresh";
	FieldNodeEventType[FieldNodeEventType["RequestRemount"] = 16384] = "RequestRemount";
	FieldNodeEventType[FieldNodeEventType["UpdateJsonSchema"] = 32768] = "UpdateJsonSchema";
	FieldNodeEventType[FieldNodeEventType["UpdateDiagnostics"] = 65536] = "UpdateDiagnostics";
	return FieldNodeEventType;
}({});

//#endregion
//#region src/core/engine/record/utils/FieldNodeRevisionLedger.ts
let _FieldNodeEventType$I;
let _FieldNodeEventType$U;
let _FieldNodeEventType$U2;
let _FieldNodeEventType$U3;
let _FieldNodeEventType$U4;
let _FieldNodeEventType$U5;
let _FieldNodeEventType$U6;
let _FieldNodeEventType$U7;
let _FieldNodeEventType$U8;
let _FieldNodeEventType$F;
let _FieldNodeEventType$B;
let _FieldNodeEventType$R;
let _FieldNodeEventType$R2;
let _FieldNodeEventType$R3;
let _FieldNodeEventType$R4;
let _FieldNodeEventType$U9;
let _FieldNodeEventType$U10;
const KNOWN_BITS = (65536 << 1) - 1;
_FieldNodeEventType$I = 1;
_FieldNodeEventType$U = 2;
_FieldNodeEventType$U2 = 4;
_FieldNodeEventType$U3 = 8;
_FieldNodeEventType$U4 = 16;
_FieldNodeEventType$U5 = 32;
_FieldNodeEventType$U6 = 64;
_FieldNodeEventType$U7 = 128;
_FieldNodeEventType$U8 = 256;
_FieldNodeEventType$F = 512;
_FieldNodeEventType$B = 1024;
_FieldNodeEventType$R = 2048;
_FieldNodeEventType$R2 = 4096;
_FieldNodeEventType$R3 = 8192;
_FieldNodeEventType$R4 = 16384;
_FieldNodeEventType$U9 = 32768;
_FieldNodeEventType$U10 = 65536;
var FieldNodeRevisionLedger = class FieldNodeRevisionLedger {
	constructor(previous, mask) {
		const counts = previous === EMPTY_REVISION_LEDGER ? [] : previous instanceof FieldNodeRevisionLedger ? previous.counts.slice() : Array.from({ length: 17 }, (_, index) => previous[1 << index]);
		let remaining = mask & KNOWN_BITS;
		while (remaining) {
			const bit = remaining & -remaining;
			const index = 31 - Math.clz32(bit);
			counts[index] = (counts[index] ?? 0) + 1;
			remaining &= remaining - 1;
		}
		this.counts = counts;
	}
	read(mask) {
		let revision = 0;
		let remaining = mask & KNOWN_BITS;
		while (remaining) {
			const bit = remaining & -remaining;
			revision += this.counts[31 - Math.clz32(bit)] ?? 0;
			remaining &= remaining - 1;
		}
		return revision;
	}
	get [_FieldNodeEventType$I]() {
		return this.counts[0];
	}
	get [_FieldNodeEventType$U]() {
		return this.counts[1];
	}
	get [_FieldNodeEventType$U2]() {
		return this.counts[2];
	}
	get [_FieldNodeEventType$U3]() {
		return this.counts[3];
	}
	get [_FieldNodeEventType$U4]() {
		return this.counts[4];
	}
	get [_FieldNodeEventType$U5]() {
		return this.counts[5];
	}
	get [_FieldNodeEventType$U6]() {
		return this.counts[6];
	}
	get [_FieldNodeEventType$U7]() {
		return this.counts[7];
	}
	get [_FieldNodeEventType$U8]() {
		return this.counts[8];
	}
	get [_FieldNodeEventType$F]() {
		return this.counts[9];
	}
	get [_FieldNodeEventType$B]() {
		return this.counts[10];
	}
	get [_FieldNodeEventType$R]() {
		return this.counts[11];
	}
	get [_FieldNodeEventType$R2]() {
		return this.counts[12];
	}
	get [_FieldNodeEventType$R3]() {
		return this.counts[13];
	}
	get [_FieldNodeEventType$R4]() {
		return this.counts[14];
	}
	get [_FieldNodeEventType$U9]() {
		return this.counts[15];
	}
	get [_FieldNodeEventType$U10]() {
		return this.counts[16];
	}
};

//#endregion
//#region src/core/engine/record/utils/advanceFieldNodeRevision.ts
const advanceFieldNodeRevision = (node, mask, share) => {
	var _node$runtime;
	const previous = node.revisionLedger;
	if (!share) {
		node.revisionLedger = new FieldNodeRevisionLedger(previous, mask);
		return;
	}
	const transitions = (_node$runtime = node.runtime).revisionTransitions ?? (_node$runtime.revisionTransitions = /* @__PURE__ */ new WeakMap());
	let byMask = transitions.get(previous);
	let next = byMask?.get(mask);
	if (!next) {
		next = new FieldNodeRevisionLedger(previous, mask);
		if (!byMask) {
			byMask = /* @__PURE__ */ new Map();
			transitions.set(previous, byMask);
		}
		byMask.set(mask, next);
	}
	node.revisionLedger = next;
};

//#endregion
//#region src/core/engine/record/utils/canOmitFieldNodePayload.ts
const canOmitFieldNodePayload = (node) => node.runtime.entryDepth === 1 && !node.runtime.listeners?.size && !node.runtime.revisionObserved && !node.pendingDelivery;

//#endregion
//#region src/core/engine/record/constants/FieldNodeRequestType.ts
let FieldNodeRequestType = /* @__PURE__ */ function(FieldNodeRequestType) {
	FieldNodeRequestType[FieldNodeRequestType["Focus"] = 2048] = "Focus";
	FieldNodeRequestType[FieldNodeRequestType["Select"] = 4096] = "Select";
	FieldNodeRequestType[FieldNodeRequestType["Refresh"] = 8192] = "Refresh";
	FieldNodeRequestType[FieldNodeRequestType["Remount"] = 16384] = "Remount";
	return FieldNodeRequestType;
}({});

//#endregion
//#region src/core/engine/record/utils/markFieldNodeEvent.ts
const markFieldNodeEvent = (node, bit, payload, options) => {
	var _node$runtime, _node$runtime2;
	const deliveries = (_node$runtime = node.runtime).deliveries ?? (_node$runtime.deliveries = /* @__PURE__ */ new Set());
	const previous = node.pendingDelivery;
	if (previous) {
		previous.type |= bit;
		if (payload !== void 0) (previous.payload ?? (previous.payload = {}))[bit] = payload;
		if (options !== void 0) (previous.options ?? (previous.options = {}))[bit] = options;
	} else node.pendingDelivery = {
		type: bit,
		payload: payload === void 0 ? void 0 : { [bit]: payload },
		options: options === void 0 ? void 0 : { [bit]: options }
	};
	deliveries.add(node);
	node.pendingRevision |= bit;
	((_node$runtime2 = node.runtime).revisionNodes ?? (_node$runtime2.revisionNodes = /* @__PURE__ */ new Set())).add(node);
};

//#endregion
//#region src/core/engine/record/utils/indexFieldNodeWarning.ts
const indexFieldNodeWarning = (runtime, key, path, record, remove = false) => {
	if (remove) {
		runtime.warningKeys?.delete(key);
		runtime.pendingWarningRecords?.delete(key);
	} else if (record) (runtime.pendingWarningRecords ?? (runtime.pendingWarningRecords = /* @__PURE__ */ new Map())).set(key, record);
	if (path === void 0) return;
	const index = remove ? runtime.warningKeysByPath : runtime.warningKeysByPath ?? (runtime.warningKeysByPath = /* @__PURE__ */ new Map());
	if (!index) return;
	let ancestor = path;
	while (true) {
		if (remove) {
			const keys = index.get(ancestor);
			keys?.delete(key);
			if (keys?.size === 0) index.delete(ancestor);
		} else {
			let keys = index.get(ancestor);
			if (!keys) index.set(ancestor, keys = /* @__PURE__ */ new Set());
			keys.add(key);
		}
		if (!ancestor) break;
		ancestor = resolvePointer(ancestor, "..");
	}
};

//#endregion
//#region src/core/engine/record/utils/captureFieldNodeChange.ts
const CHANGE_BITS = {
	local: 4,
	emit: 4,
	path: 2,
	children: 128,
	active: 256,
	visible: 256,
	readOnly: 256,
	disabled: 256,
	schema: 32768,
	interactionState: 8
};
const captureFieldNodeChange = (node, field, value) => {
	var _node$runtime;
	if (node[field] === value || !node.deliveryInitialized || node.detached) return value;
	const bit = CHANGE_BITS[field];
	if (!(node.deliveryChanges & bit)) {
		switch (bit) {
			case 4:
				node.deliveryPreviousLocal = node.local;
				node.deliveryPreviousEmit = node.emit;
				break;
			case 2:
				node.deliveryPreviousPath = node.path;
				break;
			case 128:
				node.deliveryPreviousChildren = node.children;
				break;
			case 256:
				node.deliveryPreviousComputed = +node.active | +node.visible << 1 | +node.readOnly << 2 | +node.disabled << 3;
				break;
			case 32768:
				node.deliveryPreviousSchema = node.schema;
				break;
			case 8: node.deliveryPreviousState = node.interactionState;
		}
		node.deliveryChanges |= bit;
	}
	if (node.runtime.deliveryWatchIndex?.allNodes.size && (bit === 4 || bit === 8 || bit === 256)) ((_node$runtime = node.runtime).deliveryAffectedPaths ?? (_node$runtime.deliveryAffectedPaths = /* @__PURE__ */ new Set())).add(node.path);
	return value;
};

//#endregion
//#region src/core/engine/record/utils/updateFieldNodeNameAndPath.ts
const updateFieldNodeNameAndPath = (node, name, parent) => {
	node.parent = parent;
	node.name = name;
	node.escapedName = formatSegment(name);
	node.path = captureFieldNodeChange(node, "path", parent === null ? "" : appendFormattedSegment(parent.path, node.escapedName));
	node.depth = parent === null ? 0 : parent.depth + 1;
};

//#endregion
//#region src/core/engine/record/utils/shallowPatch.ts
const shallowPatch = (previous, patch) => {
	let result = previous;
	for (const key of Object.keys(patch)) {
		const value = Reflect.get(patch, key);
		const present = hasOwnProperty(previous, key);
		if (value === void 0 ? !present : present && Object.is(Reflect.get(previous, key), value)) continue;
		if (result === previous) result = { ...previous };
		if (value === void 0) Reflect.deleteProperty(result, key);
		else Reflect.set(result, key, value);
	}
	return result;
};

//#endregion
//#region src/core/engine/record/utils/patchFieldNodeInteractionState.ts
const patchFieldNodeInteractionState = (node, patch) => {
	if (node.detached) return;
	node.interactionState = shallowPatch(node.interactionState, patch);
};

//#endregion
//#region src/core/engine/record/utils/accumulateGlobalStateDeltas.ts
const accumulateGlobalStateDeltas = (deltas, previous, next, changedKeys) => {
	if (changedKeys) {
		for (const key in changedKeys) {
			if (!hasOwnProperty(changedKeys, key)) continue;
			const before = Boolean(previous[key]);
			const after = Boolean(next[key]);
			if (before !== after) deltas.set(key, (deltas.get(key) ?? 0) + (after ? 1 : -1));
		}
		return;
	}
	for (const [key, value] of Object.entries(previous)) if (value && !next[key]) deltas.set(key, (deltas.get(key) ?? 0) - 1);
	for (const [key, value] of Object.entries(next)) if (value && !previous[key]) deltas.set(key, (deltas.get(key) ?? 0) + 1);
};

//#endregion
//#region src/core/engine/record/utils/publishGlobalStateDeltas.ts
const publishGlobalStateDeltas = (root, deltas) => {
	const runtime = root.runtime;
	let nextState;
	for (const [key, delta] of deltas) {
		if (!delta) continue;
		const previous = runtime.globalStateCounts.get(key) ?? 0;
		const count = previous + delta;
		if (count < 0) throw new Error(`Negative global state count for ${key}`);
		if (count) runtime.globalStateCounts.set(key, count);
		else runtime.globalStateCounts.delete(key);
		if (previous === 0 === (count === 0)) continue;
		nextState ?? (nextState = { ...runtime.globalState });
		if (count) nextState[key] = true;
		else delete nextState[key];
	}
	if (!nextState) return;
	runtime.globalState = nextState;
	const queued = runtime.queuedNonSettleEvents ?? /* @__PURE__ */ new Set();
	const previous = root.pendingNonSettleDelivery;
	root.pendingNonSettleDelivery = {
		type: (previous?.type ?? 0) | 16,
		payload: {
			...previous?.payload,
			[16]: nextState
		}
	};
	queued.add(root);
	runtime.queuedNonSettleEvents = queued;
};

//#endregion
//#region src/core/engine/record/utils/clearFieldNodeChanges.ts
const clearFieldNodeChanges = (node) => {
	const changes = node.deliveryChanges;
	if (changes & 4) {
		node.deliveryPreviousLocal = void 0;
		node.deliveryPreviousEmit = void 0;
	}
	if (changes & 2) node.deliveryPreviousPath = void 0;
	if (changes & 128) node.deliveryPreviousChildren = void 0;
	if (changes & 256) node.deliveryPreviousComputed = void 0;
	if (changes & 32768) node.deliveryPreviousSchema = void 0;
	if (changes & 8) node.deliveryPreviousState = void 0;
	node.deliveryChanges = 0;
};

//#endregion
//#region src/core/engine/settle/utils/structure/isSameChildList.ts
const isSameChildList = (published, selected) => {
	if (published?.length !== selected.length) return false;
	for (let index = 0; index < selected.length; index++) if (published[index] !== selected[index]) return false;
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/commit/utils/isSameDeliveryValue.ts
const isSameDeliveryValue = (previous, current) => previous === current || Number.isNaN(previous) && Number.isNaN(current);

//#endregion
//#region src/core/engine/settle/utils/output/utils/keepsChildEmissions.ts
const keepsChildEmissions = (host, children) => {
	if (host === null || typeof host !== "object") return true;
	for (const child of children) {
		const emission = child.emit;
		if (emission !== void 0 && !isSameDeliveryValue(Reflect.get(host, child.name), emission)) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/output/updateOutput.ts
const updateOutput = (node, context, recalculated) => {
	context.pendingOutputs?.delete(node);
	const host = (node.behavior.type === "array" || node.behavior.type === "object") && node.behavior.strategy === "branch";
	const append = context.arrayAppend;
	const appending = append !== void 0 && append.host === node && append.valid && !recalculated && node.children === append.children && (node.local === append.local || node.local === append.assembled);
	const pop = context.arrayPop;
	const truncating = pop !== void 0 && pop.host === node && pop.valid && !recalculated && node.children === pop.children && (node.local === pop.local || node.local === pop.assembled);
	const hint = recalculated && host ? { incremental: false } : appending ? {
		incremental: false,
		append: append.count
	} : truncating ? {
		incremental: false,
		truncate: pop.count - 1
	} : void 0;
	const assembled = node.behavior.assemble(node, node.children ?? [], recalculated, hint);
	if (appending && hint?.incremental) append.assembled = assembled;
	if (truncating && hint?.incremental) pop.assembled = assembled;
	const previousLocal = node.local;
	let local = (hint?.incremental ? node.behavior.type === "object" && previousLocal !== null && typeof previousLocal === "object" && assembled !== null && typeof assembled === "object" && recalculated?.every((child) => sameValue(Reflect.get(previousLocal, child.name), Reflect.get(assembled, child.name))) : sameValue(node.local, assembled)) ? node.local : assembled;
	const baseline = node.deliveryPreviousLocal;
	const revisit = (node.deliveryChanges & 4) !== 0 && local !== baseline && !(isArray(baseline) && isArray(local) && baseline.length !== local.length);
	if (revisit && (!host || (!recalculated || keepsChildEmissions(node.deliveryPreviousLocal, recalculated)) && keepsChildEmissions(node.deliveryPreviousLocal, node.children ?? [])) && sameValue(node.deliveryPreviousLocal, local)) local = node.deliveryPreviousLocal;
	let projected = node.behavior.project(node, local);
	if (node.parent === null && projected === void 0 && (node.behavior.type === "object" || node.behavior.type === "array")) projected = local;
	let emit = node.emit === node.local && projected === local ? local : sameValue(node.emit, projected) ? node.emit : projected;
	if (node.deliveryChanges & 4 && emit !== node.deliveryPreviousEmit && !(revisit && emit === local && node.deliveryPreviousEmit === node.deliveryPreviousLocal) && sameValue(node.deliveryPreviousEmit, emit)) emit = node.deliveryPreviousEmit;
	const changed = local !== node.local || emit !== node.emit;
	node.local = captureFieldNodeChange(node, "local", local);
	node.emit = captureFieldNodeChange(node, "emit", emit);
	if (changed) {
		context.changedNodes.add(node);
		const parent = node.parent;
		const index = context.virtualReferenceIndex;
		if (node.behavior.type !== "virtual" && parent && index) {
			const names = index.get(parent.blueprintNode)?.get(node.name);
			if (names) for (const name of names) {
				const virtual = parent.structure?.[name];
				if (virtual?.behavior.type === "virtual" && !virtual.detached) updateOutput(virtual, context);
			}
		}
	}
	return changed;
};

//#endregion
//#region src/core/engine/settle/utils/output/flushPendingOutput.ts
const flushPendingOutput = (node, context) => {
	if (!context.pendingOutputs?.delete(node)) return false;
	const children = Object.values(node.structure ?? {});
	const published = node.children;
	node.children = captureFieldNodeChange(node, "children", isSameChildList(published, children) ? published : children);
	updateOutput(node, context);
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/gates/readProjectedValue.ts
const projectedEmission = (node, context) => node.emit === void 0 || context.changedRaw.has(node.path) && !context.changedNodes.has(node) ? void 0 : node.emit;
const readProjectedValue = (context, path) => {
	let node = context.root;
	if (!path) flushPendingOutput(node, context);
	let value = projectedEmission(node, context);
	if (!path) return value;
	let atNode = true;
	const segments = node.runtime.blueprint.capabilities.branchless ? getCachedPointerSegments(node.runtime, path) : getGateRegistry(node.runtime).pathSegments(path);
	for (let index = 0; index < segments.length; index++) {
		const name = segments[index];
		if (typeof name !== "string") return void 0;
		if (node.behavior.strategy === "branch" && node.raw !== void 0 && flushPendingOutput(node, context)) value = projectedEmission(node, context);
		if (node.behavior.strategy === "branch" && node.raw !== void 0 && (node.parent !== null || value === null || typeof value !== "object" || !hasOwnProperty(value, name))) return void 0;
		const child = node.structure && hasOwnProperty(node.structure, name) ? node.structure[name] : void 0;
		if (child) {
			node = child;
			atNode = true;
			value = projectedEmission(node, context);
		} else {
			if (flushPendingOutput(node, context)) value = projectedEmission(node, context);
			atNode = false;
			if (value !== null && typeof value === "object" && hasOwnProperty(value, name)) value = Reflect.get(value, name);
			else if (!getDeclaredChildNames(node.blueprintNode).has(name) && node.undeclaredValues !== null && typeof node.undeclaredValues === "object" && hasOwnProperty(node.undeclaredValues, name)) value = Reflect.get(node.undeclaredValues, name);
			else return void 0;
		}
	}
	if (atNode && flushPendingOutput(node, context)) value = projectedEmission(node, context);
	return value;
};

//#endregion
//#region src/core/engine/settle/utils/gates/readGateHostView.ts
const readGateHostView = (context, hostPath, owner) => {
	const projected = readProjectedValue(context, hostPath);
	const extra = readGateProjectedExtra(context, hostPath, projected, owner);
	const views = context.gateHostViews ?? (context.gateHostViews = /* @__PURE__ */ new Map());
	const cached = views.get(hostPath);
	if (cached && Object.is(cached.projected, projected) && Object.is(cached.extra, extra)) return cached;
	const host = projected !== null && typeof projected === "object" && !isArray(projected) ? projected : void 0;
	const extras = extra !== null && typeof extra === "object" && !isArray(extra) ? extra : void 0;
	const view = {
		projected,
		extra,
		value: {
			...host,
			...extras
		}
	};
	views.set(hostPath, view);
	return view;
};

//#endregion
//#region src/core/engine/settle/utils/gates/canSkipGateWheel.ts
const canSkipGateWheel = (node, context, frame, round, cap, gateCount) => {
	if (round + 1 >= cap || gateCount !== frame.gateCount || dirtyChildren(node, context).length !== 0 || context.gateThrowVersion !== frame.throwVersion || (context.pendingOutputs?.size ?? 0) !== 0 || !frame.consistent || context.kind === "load" || context.distributedInputs.has(node) || context.exceededBudget) return false;
	for (const input of frame.inputs.values()) {
		const view = input.kind === "property" || input.kind === "presence" ? readGateHostView(context, input.hostPath, node).value : void 0;
		const value = input.kind === "context" ? context.root.runtime.context : input.kind === "property" ? view[input.name] : input.kind === "presence" ? hasOwnProperty(view, input.name) : input.kind === "extra" ? readGateProjectedExtra(context, input.path, readProjectedValue(context, input.path), node) : readProjectedValue(context, input.path);
		if (!Object.is(input.value, value)) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/gates/finishGateTableRound.ts
const finishGateTableRound = (node, context) => {
	const round = context.gateSelectionRounds?.get(node);
	if (!round) return;
	if (engineModes.gateSelection === "verify") {
		const frame = context.gateWheelFrame;
		const shadow = frame?.selectionShadow;
		if (frame && shadow) {
			verifyGateSelection(frame.consistent === shadow.consistent, "S5 consistent differs");
			verifyGateSelection(frame.inputs.size === shadow.inputs.size, "S5 input key count differs");
			for (const [key, input] of shadow.inputs) verifyGateSelection(frame.inputs.has(key) && Object.is(frame.inputs.get(key).value, input.value), "S5 input differs: " + key);
		}
	}
	round.active = false;
	context.gateSelectionRounds.delete(node);
};

//#endregion
//#region src/core/engine/settle/utils/gates/gateWheelEvaluation.ts
const gateWheelEvaluation = {
	skipped: 0,
	predictions: 0,
	confirmations: 0,
	missed: 0,
	nonNoop: 0
};

//#endregion
//#region src/core/engine/settle/utils/gates/getGateBudgetCap.ts
const getIndex = (blueprint) => {
	const cached = getBlueprintDerived(blueprint).gateBudgetIndex;
	if (cached) return cached;
	const decisionsByGate = /* @__PURE__ */ new Map();
	const decisions = /* @__PURE__ */ new Set();
	const fieldControls = /* @__PURE__ */ new Map();
	const add = (gate, key) => {
		let keys = decisionsByGate.get(gate);
		if (!keys) {
			keys = /* @__PURE__ */ new Set();
			decisionsByGate.set(gate, keys);
		}
		keys.add(key);
		decisions.add(key);
	};
	const collect = (declaration) => {
		if (declaration.scope === "fragment" && declaration.gates.length > 0) for (const gate of declaration.gates) add(gate, "fragment:" + declaration.fragmentId);
		for (const gate of declaration.gates) {
			if (gate.kind !== "active") continue;
			let fieldControl = fieldControls.get(gate);
			if (fieldControl === void 0) {
				const segments = parsePointerSegments(gate.schemaPath);
				fieldControl = segments[segments.length - 2] === "controls" && segments[segments.length - 1] === "active" && segments.some((segment, index) => segment === "controls" && segments[index + 1] === "fields");
				fieldControls.set(gate, fieldControl);
			}
			if (fieldControl) add(gate, "node:" + gate.schemaPath);
			else if (declaration.scope === "node" && gate.schemaPath === appendSegment(appendSegment(declaration.schemaPath, "controls"), "active")) add(gate, "node:" + gate.schemaPath);
		}
	};
	for (const node of blueprint.nodes) {
		for (const declaration of node.declarations) collect(declaration);
		for (const entry of node.childEntries) for (const declaration of entry.declarations) collect(declaration);
	}
	const index = {
		decisionsByGate,
		transitionCap: decisions.size + 1
	};
	getBlueprintDerived(blueprint).gateBudgetIndex = index;
	return index;
};
const getTransitionBudgetCap = (blueprint) => blueprint.capabilities.branchless ? 1 : getIndex(blueprint).transitionCap;
const getHostWheelBudgetCap = (host, blueprint, gates, runtime) => {
	if (blueprint.capabilities.branchless) return 1;
	const cached = runtime.hostBudgetCaps?.get(host);
	if (cached && cached.gates.length === gates.length && cached.gates.every((gate, index) => gate === gates[index])) return cached.cap;
	const index = getIndex(blueprint);
	const decisions = /* @__PURE__ */ new Set();
	for (const gate of gates) for (const key of index.decisionsByGate.get(gate) ?? []) decisions.add(key);
	const cap = decisions.size + 1;
	(runtime.hostBudgetCaps ?? (runtime.hostBudgetCaps = /* @__PURE__ */ new WeakMap())).set(host, {
		gates: [...gates],
		cap
	});
	return cap;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/computeRootGateSelection.ts
const computeRootGateSelection = (host, blueprint, groups) => {
	if (host !== blueprint.root) return;
	const groupByGate = /* @__PURE__ */ new Map();
	for (const group of groups) for (const gate of group.literalsByGate.keys()) groupByGate.set(gate, group);
	const ungatedIndices = [];
	const rootGroups = /* @__PURE__ */ new Map();
	for (let index = 0; index < host.declarations.length; index++) {
		const gates = host.declarations[index].gates;
		if (gates.length === 0) {
			ungatedIndices.push(index);
			continue;
		}
		if (gates.length !== 1 || gates[0].appliesWhen?.length) return;
		const gate = gates[0];
		const group = groupByGate.get(gate);
		if (!group) return;
		let rootGroup = rootGroups.get(group.watchedName);
		if (!rootGroup) {
			rootGroup = {
				watchedName: group.watchedName,
				firstGate: gate,
				buckets: /* @__PURE__ */ new Map()
			};
			rootGroups.set(group.watchedName, rootGroup);
		}
		for (const literal of group.literalsByGate.get(gate)) {
			const bucket = rootGroup.buckets.get(literal);
			if (bucket) bucket.push(index);
			else rootGroup.buckets.set(literal, [index]);
		}
	}
	return {
		ungatedIndices,
		groups: [...rootGroups.values()]
	};
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/utils/isStableDiscriminatorEntry.ts
const isStableDiscriminatorEntry = (entry, host) => {
	const declarations = entry.declarations;
	const type = entry.node.schemaType;
	if (entry.node.strategy !== "terminal" || typeof type !== "string" || type === "object" || type === "array" || declarations.length < 2 || entry.node.declarations.length !== declarations.length || !declarations.some((declaration) => declaration.gates.length === 0) || !declarations.some((declaration) => declaration.gates.length > 0)) return false;
	for (let index = 0; index < declarations.length; index++) {
		const declaration = declarations[index];
		const schema = declaration.schema;
		if (declaration.id !== entry.node.declarations[index].id || !schema || typeof schema !== "object" || schema.type !== type) return false;
		for (const key of Object.keys(schema)) if (key !== "type" && key !== "const" && key !== "enum" && !(key === "default" && declaration.gates.length === 0)) return false;
		for (const gate of declaration.gates) if (gate.kind !== "discriminator" || gate.hostPath !== host.path || gate.appliesWhen?.length || gate.condition.propertyName !== entry.name || !gate.condition.values.every((value) => value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value))) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/utils/prepareDiscriminatorEntrySelection.ts
const prepareDiscriminatorEntrySelection = (entry) => {
	const baseline = [];
	const buckets = /* @__PURE__ */ new Map();
	for (let index = 0; index < entry.declarations.length; index++) {
		const declaration = entry.declarations[index];
		const first = declaration.gates[0];
		if (!first) {
			baseline.push(index);
			continue;
		}
		if (first.kind !== "discriminator") continue;
		for (let tag = 0; tag < first.condition.values.length; tag++) {
			const value = first.condition.values[tag];
			if (first.condition.values.indexOf(value) !== tag || !declaration.gates.every((gate) => gate.kind === "discriminator" && gate.condition.values.some((candidate) => candidate === value))) continue;
			const bucket = buckets.get(value);
			if (bucket) bucket.push(index);
			else buckets.set(value, [index]);
		}
	}
	return {
		baseline,
		buckets,
		prepared: /* @__PURE__ */ new WeakMap()
	};
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/getDirectChildSelectionPlan.ts
const getDirectChildSelectionPlan = (host, blueprint, prepare) => {
	const cached = getHostDerived(host).directChildSelectionPlan;
	if (cached !== void 0) return cached;
	if (!prepare) return null;
	const schema = host.declarations[0]?.schema;
	if (typeof schema !== "object" || schema === null || !(isArray(schema.oneOf) && schema.oneOf.length > 1 || isArray(schema.anyOf) && schema.anyOf.length > 1 || isArray(schema.allOf) && schema.allOf.length > 1 && host.childEntries.some((entry) => entry.declarations.some((declaration) => declaration.gates.some((gate) => gate.kind === "if"))))) {
		getHostDerived(host).directChildSelectionPlan = null;
		return null;
	}
	const steps = [];
	const baseline = [];
	const names = Object.create(null);
	for (let index = 0; index < host.childEntries.length; index++) {
		const entry = host.childEntries[index];
		const declarations = entry.declarations;
		if (engineModes.gatePredicate !== "off" && !hasOwnProperty(names, entry.name) && isStableDiscriminatorEntry(entry, host)) {
			names[entry.name] = true;
			baseline.push(entry);
			steps.push({
				entry,
				gate: void 0,
				ids: [],
				general: true,
				discriminatorSelection: prepareDiscriminatorEntrySelection(entry)
			});
			continue;
		}
		if (hasOwnProperty(names, entry.name) || declarations.length !== 1 || entry.node.kind === "virtual" || entry.node.childEntries.length > 0 || entry.node.item || entry.node.prefixItems?.length || entry.node.declarations.length !== 1 || entry.node.declarations[0].id !== declarations[0].id || declarations[0].gates.length > 1 || entry.node.declarations[0].gates.length !== declarations[0].gates.length || entry.node.declarations[0].gates[0] !== declarations[0].gates[0]) {
			getHostDerived(host).directChildSelectionPlan = null;
			return null;
		}
		const declaration = declarations[0];
		const gate = declaration.gates[0];
		if (gate) {
			const expression = getGateExpression(blueprint, gate.schemaPath);
			if (engineModes.gatePredicate === "off" && gate.kind !== "active" || gate.appliesWhen?.length || gate.hostPath !== host.path || gate.schemaPath === appendSegment(appendSegment(declaration.schemaPath, "controls"), "active") || gate.kind === "active" && (!expression || expression.dependencies.length !== 1 && !expression.completeReads) || gate.kind === "if" && getIfGateReadNames(gate.condition, blueprint) === void 0) {
				getHostDerived(host).directChildSelectionPlan = null;
				return null;
			}
		} else baseline.push(entry);
		names[entry.name] = true;
		steps.push({
			entry,
			gate,
			ids: [declaration.id]
		});
	}
	const plan = {
		steps,
		baseline
	};
	getHostDerived(host).directChildSelectionPlan = plan;
	return plan;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/getGateSelectionTable.ts
const isGateSelectionLiteral = (value) => value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value);
const getGateSelectionTable = (host, blueprint) => {
	const cached = getHostDerived(host).gateSelectionTable;
	if (cached !== void 0) return cached;
	const plan = getDirectChildSelectionPlan(host, blueprint, true);
	if (!plan) {
		getHostDerived(host).gateSelectionTable = null;
		return null;
	}
	const watchedNames = /* @__PURE__ */ new Map();
	for (const entry of plan.baseline) if (entry.node.strategy === "terminal") watchedNames.set(appendSegment(host.path, entry.name), entry.name);
	const groups = /* @__PURE__ */ new Map();
	const alwaysSteps = [];
	const stableSchemaNames = [];
	const stepIndexByName = /* @__PURE__ */ new Map();
	const tableSteps = /* @__PURE__ */ new Set();
	const predicateGroups = /* @__PURE__ */ new Map();
	for (let index = 0; index < plan.steps.length; index++) {
		const step = plan.steps[index];
		if (step.general) stableSchemaNames.push(step.entry.name);
		const gate = step.gate;
		stepIndexByName.set(step.entry.name, index);
		const expression = gate ? getGateExpression(blueprint, gate.schemaPath) : void 0;
		const equality = gate?.kind === "discriminator" && gate.condition.values.every(isGateSelectionLiteral) ? { literals: gate.condition.values } : expression?.equality;
		const watchedName = gate?.kind === "discriminator" ? watchedNames.get(appendSegment(host.path, gate.condition.propertyName)) : equality && expression ? watchedNames.get(resolveDependencyPath(host.path, expression.dependencies[0])) : void 0;
		const ifReads = gate?.kind === "if" ? getIfGateReadNames(gate.condition, blueprint) : engineModes.gatePredicate !== "off" && expression?.completeReads && !equality ? expression.dependencies.map((dependency) => watchedNames.get(resolveDependencyPath(host.path, dependency))) : void 0;
		if (gate && ifReads && ifReads.every((name) => name !== void 0 && watchedNames.has(appendSegment(host.path, name)))) {
			let group = predicateGroups.get(gate);
			if (!group) {
				group = {
					gate,
					steps: [],
					watchedNames: ifReads
				};
				predicateGroups.set(gate, group);
			}
			group.steps.push(index);
			tableSteps.add(index);
			continue;
		}
		if (!gate || !equality || watchedName === void 0) {
			alwaysSteps.push(index);
			continue;
		}
		let group = groups.get(watchedName);
		if (!group) {
			group = {
				watchedName,
				firstGate: gate,
				firstStepIndex: index,
				buckets: /* @__PURE__ */ new Map(),
				literalsByGate: /* @__PURE__ */ new Map()
			};
			groups.set(watchedName, group);
		}
		let literals = group.literalsByGate.get(gate);
		if (!literals) {
			literals = new Set(equality.literals);
			group.literalsByGate.set(gate, literals);
		}
		for (const literal of literals) {
			const bucket = group.buckets.get(literal);
			if (bucket) bucket.push(index);
			else group.buckets.set(literal, [index]);
		}
		tableSteps.add(index);
	}
	for (const [gate, group] of predicateGroups) if (group.steps[group.steps.length - 1] - group.steps[0] + 1 !== group.steps.length) {
		for (const index of group.steps) {
			alwaysSteps.push(index);
			tableSteps.delete(index);
		}
		predicateGroups.delete(gate);
	}
	alwaysSteps.sort((left, right) => left - right);
	if (groups.size === 0 && predicateGroups.size === 0) {
		getHostDerived(host).gateSelectionTable = null;
		return null;
	}
	const orderedGroups = [...groups.values()];
	const roundWatchedNames = orderedGroups.map((group) => group.watchedName);
	for (const group of predicateGroups.values()) for (const name of group.watchedNames) if (!roundWatchedNames.includes(name)) roundWatchedNames.push(name);
	const root = computeRootGateSelection(host, blueprint, orderedGroups);
	const table = {
		watchedNames: roundWatchedNames,
		stableSchemaNames,
		predicateGroups: [...predicateGroups.values()],
		plan,
		groups: orderedGroups,
		alwaysSteps,
		stepIndexByName,
		tableSteps,
		...root ? { root } : {}
	};
	getHostDerived(host).gateSelectionTable = table;
	return table;
};

//#endregion
//#region src/core/engine/settle/utils/gates/watchGateSelectionDirty.ts
const watchGateSelectionDirty = (context) => {
	if (context.restoreGateSelectionDirty) return;
	const dirty = context.dirtyPaths;
	const add = dirty.add;
	dirty.add = function(path) {
		for (const round of context.gateSelectionRounds?.values() ?? []) if (round.active) verifyGateSelection(!round.watchedPaths.includes(path) || round.stableSchemaPaths.includes(path), "S2 watched path became dirty: " + path);
		return add.call(this, path);
	};
	context.restoreGateSelectionDirty = () => {
		dirty.add = add;
		context.restoreGateSelectionDirty = void 0;
	};
};

//#endregion
//#region src/core/engine/settle/utils/gates/prepareGateTableRound.ts
const NO_SCHEMA_PATHS = Object.freeze([]);
const prepareGateTableRound = (node, context, round) => {
	context.gateSelectionRounds?.delete(node);
	if (engineModes.gateSelection === "off" || context.kind === "load" && !getHostDerived(node.blueprintNode).directChildSelectionPlan || !context.hasGates || node.behavior.type !== "object") return;
	for (let ancestor = node; ancestor; ancestor = ancestor.parent) if (ancestor.raw !== void 0) return;
	const table = getGateSelectionTable(node.blueprintNode, node.runtime.blueprint);
	if (!table) return;
	const watchedPaths = table.watchedNames.map((name) => appendSegment(node.path, name));
	if (watchedPaths.some((path) => context.dirtyPaths.has(path))) return;
	(context.gateSelectionRounds ?? (context.gateSelectionRounds = /* @__PURE__ */ new Map())).set(node, {
		round,
		table,
		values: /* @__PURE__ */ new Map(),
		watchedPaths,
		stableSchemaPaths: table.stableSchemaNames.length ? table.stableSchemaNames.map((name) => appendSegment(node.path, name)) : NO_SCHEMA_PATHS,
		active: true
	});
	if (engineModes.gateSelection === "verify") {
		if (context.gateWheelFrame) context.gateWheelFrame.selectionShadow = {
			inputs: /* @__PURE__ */ new Map(),
			consistent: true
		};
		watchGateSelectionDirty(context);
	}
};

//#endregion
//#region src/core/engine/settle/utils/gates/verifyGateWheelConfirmation.ts
const verifyGateWheelConfirmation = (expected, actual, changed) => {
	const before = expected.evaluations;
	const after = actual.evaluations;
	if (changed || before.length !== after.length || before.some((entry, index) => {
		const next = after[index];
		return entry.gate !== next.gate || entry.path !== next.path || entry.edgeName !== next.edgeName || entry.value !== next.value;
	})) {
		gateWheelEvaluation.nonNoop++;
		throw new Error("Gate wheel predicate predicted a non-no-op confirmation");
	}
	gateWheelEvaluation.confirmations++;
};

//#endregion
//#region src/core/engine/settle/utils/input/isWithinReplacePaths.ts
const isWithinReplacePaths = (context, path) => {
	const paths = context.replacePaths;
	if (paths === void 0) return true;
	for (let index = 0; index < paths.length; index++) {
		const written = paths[index];
		if (path === written || isDescendantPath(path, written) || isDescendantPath(written, path)) return true;
	}
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/input/getChildDistribution.ts
const getChildDistribution = (host, name, context, path) => {
	if (context.replacePaths !== void 0 && !isWithinReplacePaths(context, path ?? appendSegment(host.path, name))) return void 0;
	const distribution = context.distributedInputs.get(host);
	return distribution?.retainedItemNames?.includes(name) ? void 0 : distribution;
};

//#endregion
//#region src/core/engine/settle/utils/input/isPlain.ts
const isPlain = (value) => value !== null && typeof value === "object" && !isArray(value);

//#endregion
//#region src/core/engine/settle/utils/input/hasDistributedChildInput.ts
const hasDistributedChildInput = (input, name, arrayHost) => {
	if (isArray(input)) {
		if (!arrayHost) return false;
		const index = Number(name);
		return Number.isInteger(index) && index >= 0 && String(index) === name && index < input.length;
	}
	return !arrayHost && isPlain(input) && hasOwnProperty(input, name);
};

//#endregion
//#region src/core/engine/settle/utils/scratch/updatePendingExitIndex.ts
const updatePendingExitIndex = (context, path, delta) => {
	let index = context.pendingExitPaths;
	if (!index) {
		if (delta < 0) return;
		index = context.pendingExitPaths = /* @__PURE__ */ new Map();
		if (context.pendingExitScratch) context.pendingExitScratch.pendingExitPaths = index;
	}
	const host = resolvePointer(path, "..");
	let children = index.get(host);
	if (!children) {
		if (delta < 0) return;
		index.set(host, children = /* @__PURE__ */ new Map());
	}
	const count = (children.get(path) ?? 0) + delta;
	if (count > 0) children.set(path, count);
	else children.delete(path);
	if (children.size === 0) index.delete(host);
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotChildIndex.ts
const getSlotChildIndex = (host, name, template) => {
	const record = getHostDerived(host);
	let index = record.childOrderIndex;
	if (!index) {
		const collected = /* @__PURE__ */ new Map();
		for (let position = 0; position < host.childEntries.length; position++) {
			const entry = host.childEntries[position];
			let templates = collected.get(entry.name);
			if (!templates) collected.set(entry.name, templates = /* @__PURE__ */ new Map());
			if (!templates.has(entry.node)) templates.set(entry.node, position);
		}
		record.childOrderIndex = index = collected;
	}
	return index.get(name)?.get(template) ?? -1;
};

//#endregion
//#region src/core/engine/settle/utils/slots/getRetainedChildEntry.ts
const getRetainedChildEntry = (host, name, template) => {
	for (const binding of host.inactiveSlots?.keys() ?? []) if (binding.name === name && binding.node === template) return binding;
	for (const binding of host.inactiveSlotOverlays?.keys() ?? []) if (binding.name === name && binding.node === template) return binding;
	if (host.behavior.type === "array") return getItemEntries(host.blueprintNode, Number(name)).find((entry) => entry.node === template);
	const index = getSlotChildIndex(host.blueprintNode, name, template);
	return index >= 0 ? host.blueprintNode.childEntries[index] : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotEntries.ts
const getSlotEntries = (host, overlay, template = host?.blueprintNode) => {
	const entries = /* @__PURE__ */ new Set();
	if (!overlay?.replace) for (const child of host?.children ?? []) {
		if (child.parent !== host || !host) continue;
		const entry = getRetainedChildEntry(host, child.name, child.blueprintNode);
		if (entry) entries.add(entry);
	}
	if (!overlay?.replace) {
		for (const entry of host?.inactiveSlots?.keys() ?? []) entries.add(entry);
		for (const entry of host?.inactiveSlotOverlays?.keys() ?? []) entries.add(entry);
	}
	for (const entry of overlay?.children?.keys() ?? []) entries.add(entry);
	const ordered = [...entries];
	if (template) ordered.sort((left, right) => {
		if (template.kind === "array") {
			const difference = Number(left.name) - Number(right.name);
			if (difference) return difference;
			const candidates = getItemEntries(template, Number(left.name));
			return candidates.indexOf(left) - candidates.indexOf(right);
		}
		return getSlotChildIndex(template, left.name, left.node) - getSlotChildIndex(template, right.name, right.node);
	});
	return ordered;
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotPathEntry.ts
const getSlotPathEntry = (template, source, overlay, name, selected) => {
	const declared = template.kind === "array" ? getItemEntries(template, Number(name)) : template.childEntries.filter((entry) => entry.name === name);
	if (!selected) return declared[0] ?? getSlotEntries(source, overlay, template).find((entry) => entry.name === name);
	const exact = declared.find((entry) => entry.name === name && entry.node === selected);
	if (exact) return exact;
	const retained = getSlotEntries(source, overlay, template).filter((entry) => entry.name === name);
	return retained.find((entry) => entry.node === selected) ?? declared.find((entry) => getBlueprintNodeIdentity(entry.node) === getBlueprintNodeIdentity(selected)) ?? retained.find((entry) => getBlueprintNodeIdentity(entry.node) === getBlueprintNodeIdentity(selected));
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotPathNames.ts
const isName = (segment) => typeof segment === "string";
const getSlotPathNames = (runtime, path) => {
	const segments = runtime.blueprint && !runtime.blueprint.capabilities.branchless ? getDependencyIndex(runtime.blueprint).pathSegments(path, runtime) : getCachedPointerSegments(runtime, path);
	return segments.every(isName) ? segments : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotBinding.ts
const getSlotBinding = (host, entry, overlay) => {
	if (overlay?.children?.has(entry) || !overlay?.replace && (host?.inactiveSlots?.has(entry) || host?.inactiveSlotOverlays?.has(entry))) return entry;
	const token = getBlueprintNodeIdentity(entry.node);
	for (const binding of overlay?.children?.keys() ?? []) if (binding.name === entry.name && getBlueprintNodeIdentity(binding.node) === token) return binding;
	if (!overlay?.replace) {
		for (const binding of host?.inactiveSlots?.keys() ?? []) if (binding.name === entry.name && getBlueprintNodeIdentity(binding.node) === token) return binding;
		for (const binding of host?.inactiveSlotOverlays?.keys() ?? []) if (binding.name === entry.name && getBlueprintNodeIdentity(binding.node) === token) return binding;
	}
	return entry;
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotSource.ts
const getSlotSource = (host, entry, overlay) => {
	const binding = getSlotBinding(host, entry, overlay);
	const supplied = overlay?.children?.get(binding);
	if (overlay?.replace && !supplied) return {
		source: void 0,
		overlay: void 0
	};
	const live = host?.structure?.[entry.name];
	return {
		source: live?.blueprintNode === entry.node ? live : host?.inactiveSlots?.get(binding),
		overlay: supplied ?? host?.inactiveSlotOverlays?.get(binding)
	};
};

//#endregion
//#region src/core/engine/settle/utils/slots/resolveSlotSource.ts
const resolveSlotSource = (root, path, target) => {
	const names = getSlotPathNames(root.runtime, path);
	if (names === void 0) return {
		source: void 0,
		overlay: void 0
	};
	let template = root.blueprintNode;
	let source = root;
	let overlay;
	for (let depth = 0; depth < names.length; depth++) {
		const name = names[depth];
		const selected = depth === names.length - 1 ? target : source?.structure?.[name]?.blueprintNode;
		const entry = getSlotPathEntry(template, source, overlay, name, selected);
		if (!entry) return {
			source: void 0,
			overlay: void 0
		};
		const child = getSlotSource(source, entry, overlay);
		source = child.source;
		overlay = child.overlay;
		template = entry.node;
	}
	return {
		source,
		overlay
	};
};

//#endregion
//#region src/core/engine/behaviors/utils/slots/finishNoInput.ts
const finishNoInput = () => void 0;

//#endregion
//#region src/core/engine/behaviors/utils/slots/interpretIdentity.ts
const interpretIdentity = (input) => input;

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/plan/copyArraySlots.ts
const copyArraySlots = (count, removedIndex = -1) => {
	const slots = [];
	for (let index = 0; index < count; index++) if (index !== removedIndex) slots.push({ from: index });
	return slots;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/plan/isValidArrayIndex.ts
const isValidArrayIndex = (index, length) => Number.isInteger(index) && index >= 0 && index < length;

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/plan/isValidInsertIndex.ts
const isValidInsertIndex = (index, length) => Number.isInteger(index) && index >= 0 && index <= length;

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/plan/arrangeBranchArray.ts
const NOOP_PLAN$1 = { kind: "noop" };
const LENGTH_RESULT$3 = { source: "length" };
const CLEAR_SLOTS_PLAN = {
	kind: "slots",
	slots: [],
	result: { source: "void" }
};
const arrangeBranchArray = (node, operation) => {
	if (node.raw === null && operation.kind !== "push" && operation.kind !== "insert") return NOOP_PLAN$1;
	const count = node.itemCount;
	switch (operation.kind) {
		case "push": return {
			kind: "slots",
			slots: [...copyArraySlots(count), { value: operation.value }],
			result: LENGTH_RESULT$3
		};
		case "pop": return count === 0 ? NOOP_PLAN$1 : {
			kind: "slots",
			slots: copyArraySlots(count - 1),
			result: {
				source: "removed",
				index: count - 1
			}
		};
		case "remove": return isValidArrayIndex(operation.index, count) ? {
			kind: "slots",
			slots: copyArraySlots(count, operation.index),
			result: {
				source: "removed",
				index: operation.index
			}
		} : NOOP_PLAN$1;
		case "insert": {
			if (!isValidInsertIndex(operation.index, count)) return NOOP_PLAN$1;
			const slots = copyArraySlots(count);
			slots.splice(operation.index, 0, { value: operation.value });
			return {
				kind: "slots",
				slots,
				result: LENGTH_RESULT$3
			};
		}
		case "update": return isValidArrayIndex(operation.index, count) ? {
			kind: "update",
			index: operation.index,
			value: operation.value
		} : NOOP_PLAN$1;
		case "clear": return count === 0 ? NOOP_PLAN$1 : CLEAR_SLOTS_PLAN;
	}
};

//#endregion
//#region src/core/engine/behaviors/utils/options/getStaticChoices.ts
const NO_KEYS = Object.freeze([]);
const DEFAULT_CHOICES = Object.freeze({
	omitEmpty: true,
	omitTrailing: false,
	trim: false,
	propertyOrder: NO_KEYS
});
const getStaticChoices = (effective) => {
	const cached = staticChoices.get(effective);
	if (cached) return cached;
	const schema = effective.schema;
	const options = typeof schema === "object" && schema !== null ? schema.options : void 0;
	if (options === void 0) {
		staticChoices.set(effective, DEFAULT_CHOICES);
		return DEFAULT_CHOICES;
	}
	const hints = typeof options === "object" && options !== null && !isArray(options) ? options : void 0;
	const propertyOrder = hints && "propertyOrder" in hints ? hints.propertyOrder : void 0;
	const choices = Object.freeze({
		omitEmpty: !hints || !("omitEmpty" in hints) || hints.omitEmpty !== false,
		omitTrailing: !!hints && "omitTrailing" in hints && hints.omitTrailing === true,
		trim: !!hints && "trim" in hints && hints.trim === true,
		propertyOrder: isArray(propertyOrder) ? Object.freeze(propertyOrder.filter((key) => typeof key === "string")) : NO_KEYS
	});
	staticChoices.set(effective, choices);
	return choices;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/projection/omitEmptyArray.ts
const omitEmptyArray = (value) => value.length === 0 ? void 0 : value;

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/value/getArrayItemTemplate.ts
const getArrayItemTemplate = (node, index) => {
	const child = node.structure?.[String(index)];
	const candidates = node.blueprintNode.prefixItems?.[index] ? node.blueprintNode.prefixItemCandidates?.[index] : node.blueprintNode.itemCandidates;
	const selected = child !== null && typeof child === "object" && "blueprintNode" in child ? candidates?.find((candidate) => candidate === child.blueprintNode) : void 0;
	if (candidates) return selected ?? candidates[0];
	return node.blueprintNode.prefixItems?.[index] ?? node.blueprintNode.item;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/projection/omitTrailingArray.ts
const omitTrailingArray = (value, node) => {
	let end = value.length;
	while (end > 0) {
		const index = end - 1;
		if (!node) {
			if (value[index] != null) break;
		} else {
			const template = getArrayItemTemplate(node, index);
			if (!template) {
				if (value[index] != null) break;
			} else {
				const child = node.structure?.[String(index)];
				const emission = child !== null && typeof child === "object" && "emit" in child ? child.emit : void 0;
				if (emission !== void 0 && !(emission === null && template.kind !== "object" && template.kind !== "array")) break;
			}
		}
		end--;
	}
	if (end === value.length) return value;
	const cached = trimmedArrays.get(value);
	if (cached?.end === end && cached.result.every((item, index) => Object.is(item, value[index]))) return cached.result;
	const result = value.slice(0, end);
	trimmedArrays.set(value, {
		end,
		result
	});
	return result;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/projection/projectBranchArray.ts
const projectBranchArray = (node, local) => {
	if (node.raw !== void 0 && !isArray(node.raw)) return node.raw;
	if (!isArray(local)) return void 0;
	const choices = getStaticChoices(node.schema);
	const projected = choices.omitTrailing ? omitTrailingArray(local, node) : local;
	return choices.omitEmpty ? omitEmptyArray(projected) : projected;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/value/holeValue.ts
const holeValue = (kind, previous) => {
	if (kind === "array") return isArray(previous) && previous.length === 0 && !Object.isFrozen(previous) ? previous : [];
	if (kind === "object") {
		if (previous !== null && typeof previous === "object" && !isArray(previous) && !Object.isFrozen(previous)) {
			const prototype = Object.getPrototypeOf(previous);
			if ((prototype === Object.prototype || prototype === null) && Object.keys(previous).length === 0) return previous;
		}
		return {};
	}
	return null;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/value/assembleArray.ts
const rememberShape = (node, children) => {
	var _node$runtime;
	((_node$runtime = node.runtime).arrayShapes ?? (_node$runtime.arrayShapes = /* @__PURE__ */ new WeakMap())).set(node, {
		children,
		schema: node.schema,
		undeclaredValues: node.undeclaredValues,
		raw: node.raw,
		itemCount: node.itemCount
	});
};
const assembleArray = (node, children, recalculated, hint) => {
	const previous = isArray(node.local) ? node.local : void 0;
	const truncate = hint?.truncate;
	if (hint && truncate !== void 0 && previous && node.itemCount === truncate && (previous.length === truncate + 1 || previous.length === truncate)) {
		rememberShape(node, children);
		hint.incremental = true;
		return previous.length === truncate ? previous : previous.slice(0, truncate);
	}
	const append = hint?.append;
	if (hint && append !== void 0 && previous && node.itemCount === append + 1 && (previous.length === append || previous.length === append + 1)) {
		const extras = node.undeclaredValues;
		if (!node.blueprintNode.item && !node.blueprintNode.prefixItems?.length && children.length === 0 && isArray(extras) && extras.length === append + 1) {
			const value = extras[append];
			rememberShape(node, children);
			hint.incremental = true;
			if (previous.length === append) return previous.concat([value]);
			if (Object.is(value, previous[append])) return previous;
			const result = previous.slice();
			result[append] = value;
			return result;
		}
		const template = getArrayItemTemplate(node, append);
		const child = node.structure?.[String(append)];
		if (template && child !== null && typeof child === "object") {
			const emission = "emit" in child ? child.emit : void 0;
			const value = emission === void 0 ? holeValue(template.kind, previous[append]) : emission;
			rememberShape(node, children);
			hint.incremental = true;
			if (previous.length === append + 1 && Object.is(value, previous[append])) return previous;
			if (previous.length === append) return previous.concat([value]);
			const result = previous.slice();
			result[append] = value;
			return result;
		}
	}
	const stable = node.runtime.arrayShapes?.get(node);
	if (recalculated && previous?.length === node.itemCount && stable?.children === children && stable.schema === node.schema && stable.undeclaredValues === node.undeclaredValues && stable.raw === node.raw && stable.itemCount === node.itemCount) {
		let patch;
		let valid = true;
		for (const child of recalculated) {
			if (child === null || typeof child !== "object" || !("name" in child) || typeof child.name !== "string" || !("emit" in child)) {
				valid = false;
				break;
			}
			const index = Number(child.name);
			if (!Number.isInteger(index) || index < 0 || index >= node.itemCount || node.structure?.[child.name] !== child) {
				valid = false;
				break;
			}
			const template = getArrayItemTemplate(node, index);
			if (!template) {
				valid = false;
				break;
			}
			const emission = child.emit;
			const value = emission === void 0 ? holeValue(template.kind, previous[index]) : emission;
			if (!Object.is(value, previous[index])) {
				if (!patch) patch = previous.slice();
				patch[index] = value;
			}
		}
		if (valid) {
			if (hint) hint.incremental = true;
			return patch ?? previous;
		}
	}
	const extras = isArray(node.undeclaredValues) ? node.undeclaredValues : [];
	const result = [];
	let tailStart = 0;
	for (let index = 0; index < node.itemCount; index++) {
		const template = getArrayItemTemplate(node, index);
		if (!template) {
			result.push(extras[index - tailStart]);
			continue;
		}
		tailStart++;
		const child = node.structure?.[String(index)];
		const emission = child !== null && typeof child === "object" && "emit" in child ? child.emit : void 0;
		result.push(emission === void 0 ? holeValue(template.kind, previous?.[index]) : emission);
	}
	rememberShape(node, children);
	if (previous?.length === result.length && result.every((value, index) => Object.is(value, previous[index]))) return previous;
	return result;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/branch/utils/declareArrayChildren.ts
const EMPTY$2 = Object.freeze([]);
const declareArrayChildren = (node) => {
	var _node$runtime;
	const template = node.blueprintNode;
	if (template.item === void 0 && template.prefixItems === void 0 && template.itemCandidates === void 0 && template.prefixItemCandidates === void 0) return EMPTY$2;
	const count = node.itemCount;
	const cached = node.runtime.arrayChildEntries?.get(node);
	if (cached?.count === count) return cached.result;
	const entries = [];
	for (let index = 0; index < count; index++) {
		const candidates = getItemEntries(template, index);
		for (const entry of candidates) entries.push(entry);
	}
	const result = entries.length === 0 ? EMPTY$2 : Object.freeze(entries);
	((_node$runtime = node.runtime).arrayChildEntries ?? (_node$runtime.arrayChildEntries = /* @__PURE__ */ new WeakMap())).set(node, {
		count,
		result
	});
	return result;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/branch/arrayBranchBehavior.ts
const arrayBranchBehavior = Object.freeze({
	interpret: interpretIdentity,
	assemble: assembleArray,
	project: projectBranchArray,
	finishInput: finishNoInput,
	declareChildren: declareArrayChildren,
	arrange: arrangeBranchArray,
	type: "array",
	strategy: "branch"
});

//#endregion
//#region src/core/engine/behaviors/utils/slots/assembleRaw.ts
const assembleRaw = (node) => node.raw;

//#endregion
//#region src/core/engine/behaviors/utils/slots/declareNoChildren.ts
const NO_CHILDREN$1 = Object.freeze([]);
const declareNoChildren = () => NO_CHILDREN$1;

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/plan/arrangeTerminalArray.ts
const NOOP_PLAN = { kind: "noop" };
const LENGTH_RESULT$2 = { source: "length" };
const arrangeTerminalArray = (node, operation) => {
	const raw = node.raw;
	if (!isArray(raw) && raw !== void 0 && operation.kind !== "push" && operation.kind !== "insert") return NOOP_PLAN;
	const source = isArray(raw) ? raw : [];
	const length = source.length;
	if (operation.kind === "push") return {
		kind: "raw",
		raw: [...source, operation.value],
		result: LENGTH_RESULT$2
	};
	if (operation.kind === "clear") return length === 0 ? NOOP_PLAN : {
		kind: "raw",
		raw: [],
		result: { source: "void" }
	};
	if (operation.kind === "pop") return length === 0 ? NOOP_PLAN : {
		kind: "raw",
		raw: source.slice(0, -1),
		result: {
			source: "removed",
			index: length - 1
		}
	};
	if (operation.kind === "insert") {
		if (!isValidInsertIndex(operation.index, length)) return NOOP_PLAN;
		const inserted = source.slice();
		inserted.splice(operation.index, 0, operation.value);
		return {
			kind: "raw",
			raw: inserted,
			result: LENGTH_RESULT$2
		};
	}
	if (!isValidArrayIndex(operation.index, length)) return NOOP_PLAN;
	const copy = source.slice();
	if (operation.kind === "remove") {
		copy.splice(operation.index, 1);
		return {
			kind: "raw",
			raw: copy,
			result: {
				source: "removed",
				index: operation.index
			}
		};
	}
	copy[operation.index] = operation.value;
	return {
		kind: "raw",
		raw: copy,
		result: {
			source: "updated",
			index: operation.index
		}
	};
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/utils/projection/projectTerminalArray.ts
const projectTerminalArray = (node, local) => {
	if (node.raw !== void 0 && !isArray(node.raw)) return node.raw;
	if (!isArray(local)) return void 0;
	const choices = getStaticChoices(node.schema);
	const projected = choices.omitTrailing ? omitTrailingArray(local) : local;
	return choices.omitEmpty ? omitEmptyArray(projected) : projected;
};

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/terminal/arrayTerminalBehavior.ts
const arrayTerminalBehavior = Object.freeze({
	interpret: interpretIdentity,
	assemble: assembleRaw,
	project: projectTerminalArray,
	finishInput: finishNoInput,
	declareChildren: declareNoChildren,
	arrange: arrangeTerminalArray,
	type: "array",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/arrayBehavior/arrayBehavior.ts
const arrayBehavior = Object.freeze({
	branch: arrayBranchBehavior,
	terminal: arrayTerminalBehavior
});

//#endregion
//#region src/core/engine/behaviors/utils/parse/utils/number/parseNumber.ts
const JSON_NUMBER = /^-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?$/;
const DECIMAL_OR_EXPONENT_MARK = /[.eE]/;
const parseNumber = (value) => {
	const text = value.trim();
	if (!JSON_NUMBER.test(text)) return void 0;
	const parsed = Number(text);
	if (!Number.isFinite(parsed)) return void 0;
	if (!DECIMAL_OR_EXPONENT_MARK.test(text) && !Number.isSafeInteger(parsed)) return void 0;
	return parsed;
};

//#endregion
//#region src/core/engine/behaviors/utils/parse/convert.ts
const convert = (value, kind) => {
	switch (kind) {
		case "number":
		case "integer": {
			if (typeof value !== "string") return value;
			const parsed = parseNumber(value);
			return parsed !== void 0 && (kind === "number" || Number.isSafeInteger(parsed)) ? parsed : value;
		}
		case "string": return typeof value === "number" && Number.isFinite(value) || typeof value === "boolean" ? String(value) : value;
		case "boolean":
			if (value === "true" || value === 1) return true;
			if (value === "false" || value === 0) return false;
			return value;
		default: return value;
	}
};

//#endregion
//#region src/core/engine/behaviors/utils/parse/isMember.ts
const isMember = (value, kind) => {
	switch (kind) {
		case "string": return typeof value === "string";
		case "number": return typeof value === "number" && Number.isFinite(value);
		case "integer": return typeof value === "number" && Number.isInteger(value);
		case "boolean": return typeof value === "boolean";
		case "object":
		case "array": try {
			const array = isArray(value);
			return kind === "array" ? array : value !== null && typeof value === "object" && !array;
		} catch {
			return false;
		}
	}
};

//#endregion
//#region src/core/engine/behaviors/utils/parse/interpret.ts
const interpret = (value, spec) => {
	if (value === void 0 || value === null) return value;
	const kinds = spec.kinds;
	if (typeof kinds === "string") {
		if (isMember(value, kinds)) return value;
		const converted = convert(value, kinds);
		return isMember(converted, kinds) ? converted : value;
	}
	for (const kind of kinds) if (isMember(value, kind)) return value;
	let candidate;
	let found = false;
	for (const kind of kinds) {
		const converted = convert(value, kind);
		if (!isMember(converted, kind)) continue;
		if (!found) {
			candidate = converted;
			found = true;
		} else if (candidate !== converted) return value;
	}
	return found ? candidate : value;
};

//#endregion
//#region src/core/engine/behaviors/utils/slots/projectIdentity.ts
const projectIdentity = (_node, local) => local;

//#endregion
//#region src/core/engine/behaviors/utils/slots/rejectArrayOperation.ts
const rejectArrayOperation = (node, operation) => {
	throw new SchemaFormError(FormErrorCode.ArrayMethodOnNonArray, `Cannot ${operation.kind} non-array node at ${node.path}`, {
		path: node.path,
		method: operation.kind
	});
};

//#endregion
//#region src/core/engine/behaviors/booleanBehavior/booleanBehavior.ts
const booleanBehavior = Object.freeze({
	interpret,
	assemble: assembleRaw,
	project: projectIdentity,
	finishInput: finishNoInput,
	declareChildren: declareNoChildren,
	arrange: rejectArrayOperation,
	type: "boolean",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/nullBehavior/nullBehavior.ts
const nullBehavior = Object.freeze({
	interpret: interpretIdentity,
	assemble: assembleRaw,
	project: projectIdentity,
	finishInput: finishNoInput,
	declareChildren: declareNoChildren,
	arrange: rejectArrayOperation,
	type: "null",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/numberBehavior/numberBehavior.ts
const numberBehavior = Object.freeze({
	interpret,
	assemble: assembleRaw,
	project: projectIdentity,
	finishInput: finishNoInput,
	declareChildren: declareNoChildren,
	arrange: rejectArrayOperation,
	type: "number",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/utils/slots/declareBlueprintChildren.ts
const declareBlueprintChildren = (node) => node.blueprintNode.childEntries;

//#endregion
//#region src/core/engine/behaviors/objectBehavior/utils/omitEmptyObject.ts
const omitEmptyObject = (value) => {
	const count = value !== null && typeof value === "object" ? objectKeyCounts.get(value) : void 0;
	return (count === void 0 ? isEmptyObject(value) : count === 0) ? void 0 : value;
};

//#endregion
//#region src/core/engine/behaviors/objectBehavior/utils/projectObject.ts
const projectObject = (node, local) => {
	if (node.raw !== void 0 && (node.raw === null || typeof node.raw !== "object" || isArray(node.raw))) return node.raw;
	return getStaticChoices(node.schema).omitEmpty ? omitEmptyObject(local) : local;
};

//#endregion
//#region src/core/engine/utils/writeObjectKey.ts
const writeObjectKey = (target, name, value) => {
	if (name === "__proto__") Object.defineProperty(target, name, {
		value,
		enumerable: true,
		configurable: true,
		writable: true
	});
	else target[name] = value;
};

//#endregion
//#region src/core/engine/behaviors/objectBehavior/branch/utils/assembleObject.ts
const assembleObject = (node, children, recalculated, hint) => {
	var _node$runtime4;
	const previous = node.local;
	const stable = node.runtime.objectShapes?.get(node);
	if (recalculated && hint && stable?.children === children && stable.schema === node.schema && stable.undeclaredValues === node.undeclaredValues && previous !== null && typeof previous === "object" && objectKeyCounts.get(previous) === stable.names.length) {
		let patch;
		let sameKeys = true;
		for (const child of recalculated) {
			if (child === null || typeof child !== "object" || !("name" in child) || typeof child.name !== "string" || !("emit" in child)) {
				sameKeys = false;
				break;
			}
			const oldHasKey = hasOwnProperty(previous, child.name);
			if (child.emit === void 0 === oldHasKey) {
				sameKeys = false;
				break;
			}
			if (oldHasKey && !Object.is(child.emit, Reflect.get(previous, child.name))) {
				if (!patch) patch = { ...previous };
				writeObjectKey(patch, child.name, child.emit);
			}
		}
		if (sameKeys) {
			hint.incremental = true;
			if (patch) objectKeyCounts.set(patch, stable.names.length);
			return patch ?? previous;
		}
	}
	if (stable?.children === children && stable.schema === node.schema && stable.undeclaredValues === void 0 && node.undeclaredValues === void 0 && previous !== null && typeof previous === "object" && !isArray(previous)) {
		let patch;
		let sameKeys = true;
		const oldNames = Object.keys(previous);
		if (oldNames.length !== stable.names.length) sameKeys = false;
		else for (let index = 0; index < oldNames.length; index++) if (oldNames[index] !== stable.names[index]) {
			sameKeys = false;
			break;
		}
		if (sameKeys) for (const child of children) {
			if (child === null || typeof child !== "object" || !("name" in child) || typeof child.name !== "string" || !("emit" in child)) {
				sameKeys = false;
				break;
			}
			const oldHasKey = hasOwnProperty(previous, child.name);
			if (child.emit === void 0 === oldHasKey) {
				sameKeys = false;
				break;
			}
			if (oldHasKey && !Object.is(child.emit, Reflect.get(previous, child.name))) {
				if (!patch) patch = { ...previous };
				writeObjectKey(patch, child.name, child.emit);
			}
		}
		if (sameKeys) {
			objectKeyCounts.set(patch ?? previous, stable.names.length);
			return patch ?? previous;
		}
	}
	const preferred = getStaticChoices(node.schema).propertyOrder;
	const entries = node.blueprintNode.childEntries;
	if (previous === void 0 && node.undeclaredValues === void 0 && preferred.length === 0 && entries.length === children.length) {
		const result = {};
		const names = [];
		let aligned = true;
		for (let index = 0; index < children.length; index++) {
			const child = children[index];
			if (child === null || typeof child !== "object" || !("name" in child) || typeof child.name !== "string" || !("emit" in child) || entries[index].name !== child.name) {
				aligned = false;
				break;
			}
			if (child.emit !== void 0) {
				names.push(child.name);
				writeObjectKey(result, child.name, child.emit);
			}
		}
		if (aligned) {
			var _node$runtime;
			((_node$runtime = node.runtime).objectShapes ?? (_node$runtime.objectShapes = /* @__PURE__ */ new WeakMap())).set(node, {
				children,
				schema: node.schema,
				undeclaredValues: node.undeclaredValues,
				names
			});
			objectKeyCounts.set(result, names.length);
			return result;
		}
	}
	const extra = node.undeclaredValues;
	const extras = extra !== null && typeof extra === "object" && !isArray(extra) ? extra : void 0;
	if (previous === void 0 && children.length === 0 && preferred.length === 0 && entries.length === 0 && extras) {
		var _node$runtime2;
		const names = Object.keys(extras);
		const result = {};
		for (const name of names) writeObjectKey(result, name, Reflect.get(extras, name));
		((_node$runtime2 = node.runtime).objectShapes ?? (_node$runtime2.objectShapes = /* @__PURE__ */ new WeakMap())).set(node, {
			children,
			schema: node.schema,
			undeclaredValues: node.undeclaredValues,
			names
		});
		objectKeyCounts.set(result, names.length);
		return result;
	}
	const childValues = /* @__PURE__ */ new Map();
	for (const child of children) if (child !== null && typeof child === "object" && "name" in child && typeof child.name === "string" && "emit" in child) childValues.set(child.name, child.emit);
	const names = [];
	const seen = /* @__PURE__ */ new Set();
	for (const name of preferred) if (childValues.has(name)) {
		if (childValues.get(name) !== void 0 && !seen.has(name)) {
			names.push(name);
			seen.add(name);
		}
	} else if (extras && hasOwnProperty(extras, name) && !seen.has(name)) {
		names.push(name);
		seen.add(name);
	}
	for (const entry of node.blueprintNode.childEntries) {
		const name = entry.name;
		if (childValues.has(name) && childValues.get(name) !== void 0 && !seen.has(name)) {
			names.push(name);
			seen.add(name);
		}
	}
	if (extras) {
		for (const name of Object.keys(extras)) if (!childValues.has(name) && !seen.has(name)) {
			names.push(name);
			seen.add(name);
		}
	}
	if (previous !== null && typeof previous === "object" && !isArray(previous)) {
		const oldNames = Object.keys(previous);
		if (names.length === oldNames.length && names.every((name, index) => name === oldNames[index])) {
			var _node$runtime3;
			let patch;
			for (const name of names) {
				const value = childValues.has(name) ? childValues.get(name) : extras ? Reflect.get(extras, name) : void 0;
				if (!Object.is(value, Reflect.get(previous, name))) {
					if (!patch) patch = { ...previous };
					writeObjectKey(patch, name, value);
				}
			}
			((_node$runtime3 = node.runtime).objectShapes ?? (_node$runtime3.objectShapes = /* @__PURE__ */ new WeakMap())).set(node, {
				children,
				schema: node.schema,
				undeclaredValues: node.undeclaredValues,
				names
			});
			objectKeyCounts.set(patch ?? previous, names.length);
			return patch ?? previous;
		}
	}
	const result = {};
	for (const name of names) writeObjectKey(result, name, childValues.has(name) ? childValues.get(name) : extras ? Reflect.get(extras, name) : void 0);
	((_node$runtime4 = node.runtime).objectShapes ?? (_node$runtime4.objectShapes = /* @__PURE__ */ new WeakMap())).set(node, {
		children,
		schema: node.schema,
		undeclaredValues: node.undeclaredValues,
		names
	});
	objectKeyCounts.set(result, names.length);
	return result;
};

//#endregion
//#region src/core/engine/behaviors/objectBehavior/branch/objectBranchBehavior.ts
const objectBranchBehavior = Object.freeze({
	interpret: interpretIdentity,
	assemble: assembleObject,
	project: projectObject,
	finishInput: finishNoInput,
	declareChildren: declareBlueprintChildren,
	arrange: rejectArrayOperation,
	type: "object",
	strategy: "branch"
});

//#endregion
//#region src/core/engine/behaviors/objectBehavior/terminal/objectTerminalBehavior.ts
const objectTerminalBehavior = Object.freeze({
	interpret: interpretIdentity,
	assemble: assembleRaw,
	project: projectObject,
	finishInput: finishNoInput,
	declareChildren: declareNoChildren,
	arrange: rejectArrayOperation,
	type: "object",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/objectBehavior/objectBehavior.ts
const objectBehavior = Object.freeze({
	branch: objectBranchBehavior,
	terminal: objectTerminalBehavior
});

//#endregion
//#region src/core/engine/behaviors/utils/slots/finishStringInput.ts
const finishStringInput = (node) => {
	if (!getStaticChoices(node.schema).trim || typeof node.raw !== "string") return void 0;
	const trimmed = node.raw.trim();
	return trimmed === node.raw ? void 0 : trimmed;
};

//#endregion
//#region src/core/engine/behaviors/utils/slots/projectEmpty.ts
const projectEmpty = (node, local) => {
	if (!getStaticChoices(node.schema).omitEmpty) return local;
	if (local === "" || isArray(local) && local.length === 0 || local !== null && typeof local === "object" && !isArray(local) && isEmptyObject(local)) return void 0;
	return local;
};

//#endregion
//#region src/core/engine/behaviors/stringBehavior/stringBehavior.ts
const stringBehavior = Object.freeze({
	interpret,
	assemble: assembleRaw,
	project: projectEmpty,
	finishInput: finishStringInput,
	declareChildren: declareNoChildren,
	arrange: rejectArrayOperation,
	type: "string",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/unionBehavior/unionBehavior.ts
const unionBehavior = Object.freeze({
	interpret,
	assemble: assembleRaw,
	project: projectEmpty,
	finishInput: finishStringInput,
	declareChildren: declareNoChildren,
	arrange: rejectArrayOperation,
	type: "union",
	strategy: "terminal"
});

//#endregion
//#region src/core/engine/behaviors/virtualBehavior/utils/tuple/readVirtualValue.ts
const readVirtualValue = (child) => child !== null && typeof child === "object" && "value" in child ? child.value : void 0;

//#endregion
//#region src/core/engine/behaviors/virtualBehavior/utils/tuple/assembleVirtualTuple.ts
const assembleVirtualTuple = (node, children) => {
	const previous = node.local;
	if (isArray(previous) && previous.length === children.length) {
		let unchanged = true;
		for (let index = 0; index < children.length; index++) if (previous[index] !== readVirtualValue(children[index])) {
			unchanged = false;
			break;
		}
		if (unchanged) return previous;
	}
	const values = [];
	for (const child of children) values.push(readVirtualValue(child));
	return values;
};

//#endregion
//#region src/core/engine/behaviors/virtualBehavior/utils/value/projectNoEmit.ts
const projectNoEmit = () => void 0;

//#endregion
//#region src/core/engine/behaviors/virtualBehavior/virtualBehavior.ts
const virtualBehavior = Object.freeze({
	interpret: interpretIdentity,
	assemble: assembleVirtualTuple,
	project: projectNoEmit,
	finishInput: finishNoInput,
	declareChildren: declareBlueprintChildren,
	arrange: rejectArrayOperation,
	type: "virtual",
	strategy: "branch"
});

//#endregion
//#region src/core/engine/behaviors/behaviors.ts
const BEHAVIORS = Object.freeze({
	string: Object.freeze({ terminal: stringBehavior }),
	number: Object.freeze({ terminal: numberBehavior }),
	boolean: Object.freeze({ terminal: booleanBehavior }),
	null: Object.freeze({ terminal: nullBehavior }),
	union: Object.freeze({ terminal: unionBehavior }),
	virtual: Object.freeze({ branch: virtualBehavior }),
	object: objectBehavior,
	array: arrayBehavior
});

//#endregion
//#region src/core/engine/behaviors/utils/options/isOmittedEmpty.ts
const NO_ACTIVE_DECLARATION_IDS$2 = Object.freeze([]);
const RUNTIME_MERGE_OPTIONS = { mode: "runtime" };
const isOmittedEmpty = (template, value) => {
	if (!getStaticChoices(mergeEffectiveSchema(template, NO_ACTIVE_DECLARATION_IDS$2, RUNTIME_MERGE_OPTIONS)).omitEmpty) return false;
	if (value === "") return true;
	if (isArray(value)) return value.length === 0;
	if (value === null || typeof value !== "object") return false;
	const prototype = Object.getPrototypeOf(value);
	return (prototype === Object.prototype || prototype === null) && Object.keys(value).length === 0;
};

//#endregion
//#region src/core/engine/settle/utils/input/nextExtras.ts
const nextExtras = (previous, input, declared, merge) => {
	const result = {};
	let hasOwnKey = false;
	if (merge && previous !== null && typeof previous === "object") for (const name of Object.keys(previous)) {
		writeObjectKey(result, name, Reflect.get(previous, name));
		hasOwnKey || (hasOwnKey = hasOwnProperty(result, name));
	}
	for (const name of Object.keys(input)) {
		if (declared.has(name)) continue;
		writeObjectKey(result, name, Reflect.get(input, name));
		hasOwnKey || (hasOwnKey = hasOwnProperty(result, name));
	}
	const next = hasOwnKey ? result : void 0;
	return sameValue(previous, next) ? previous : next;
};

//#endregion
//#region src/core/engine/settle/utils/input/staticSpec.ts
const NO_KINDS = Object.freeze([]);
const NO_KIND_SPECS = [{
	kinds: NO_KINDS,
	mask: 0,
	nullable: false
}, {
	kinds: NO_KINDS,
	mask: 0,
	nullable: true
}];
const staticSpec = (schemaType, nullable) => {
	const index = nullable ? 1 : 0;
	if (schemaType === void 0) return NO_KIND_SPECS[index];
	if (typeof schemaType === "string") {
		const cached = scalarSpecs[index].get(schemaType);
		if (cached) return cached;
		const spec = {
			kinds: schemaType === "null" ? NO_KINDS : schemaType,
			mask: 0,
			nullable
		};
		scalarSpecs[index].set(schemaType, spec);
		return spec;
	}
	const cached = unionSpecs[index].get(schemaType);
	if (cached) return cached;
	const kinds = schemaType.filter((kind) => kind !== "null");
	const spec = {
		kinds: kinds.length === 1 ? kinds[0] : kinds,
		mask: 0,
		nullable
	};
	unionSpecs[index].set(schemaType, spec);
	return spec;
};

//#endregion
//#region src/core/engine/settle/utils/slots/createSlotValueOverlay.ts
const createSlotValueOverlay = (template, input, source, previous, whole, automatic = false, seen = /* @__PURE__ */ new WeakSet()) => {
	if (template.kind === "virtual") return {
		overlay: {},
		wrote: false
	};
	if (template.strategy === "terminal") {
		const behavior = BEHAVIORS[template.kind]?.[template.strategy];
		const raw = behavior ? behavior.interpret(input, staticSpec(template.schemaType, template.nullable)) : input;
		return {
			overlay: {
				replace: true,
				raw
			},
			wrote: raw !== void 0 && !isOmittedEmpty(template, raw)
		};
	}
	if (template.kind === "array" && template.hasCandidateDescendants && isArray(input)) {
		if (seen.has(input)) return {
			overlay: { replace: true },
			wrote: false
		};
		seen.add(input);
		const raw = input.slice();
		const children = /* @__PURE__ */ new Map();
		let wrote = false;
		for (let index = 0; index < input.length; index++) {
			const entry = getItemEntries(template, index)[0];
			if (!entry) continue;
			const child = createSlotValueOverlay(entry.node, input[index], void 0, void 0, whole, automatic, seen);
			children.set(entry, child.overlay);
			if (child.wrote) wrote = true;
			raw[index] = void 0;
		}
		seen.delete(input);
		return {
			overlay: {
				replace: true,
				raw: Object.freeze(raw),
				itemCount: input.length,
				children
			},
			wrote
		};
	}
	if (!isPlain(input)) return {
		overlay: {
			replace: true,
			raw: input
		},
		wrote: false
	};
	if (seen.has(input)) return {
		overlay: { replace: true },
		wrote: false
	};
	seen.add(input);
	const previousRaw = previous && hasOwnProperty(previous, "raw") ? previous.raw : previous?.replace ? void 0 : source?.raw;
	const previousExtras = previous && hasOwnProperty(previous, "undeclaredValues") ? previous.undeclaredValues : previous?.replace ? void 0 : source?.undeclaredValues;
	const extras = nextExtras(whole ? void 0 : previousExtras, input, getDeclaredChildNames(template), !whole);
	const children = new Map(whole ? void 0 : previous?.children);
	let wrote = false;
	for (const name of Object.keys(input)) {
		const entry = template.childEntries.find((entry) => entry.name === name);
		if (!entry) continue;
		const prior = whole ? void 0 : getSlotSource(source, entry, previous);
		const child = createSlotValueOverlay(entry.node, Reflect.get(input, name), prior?.source, prior?.overlay, whole, automatic, seen);
		children.set(entry, child.overlay);
		if (child.wrote) wrote = true;
		for (const sibling of template.childEntries) {
			if (sibling.name !== name || sibling.node === entry.node) continue;
			const prior = getSlotSource(source, sibling, previous);
			if (prior.source || prior.overlay) children.set(sibling, {
				replace: true,
				raw: void 0
			});
		}
	}
	seen.delete(input);
	return {
		overlay: {
			...!whole ? previous : void 0,
			replace: whole || previous?.replace,
			raw: whole || wrote && !automatic ? void 0 : previousRaw,
			undeclaredValues: extras,
			children
		},
		wrote
	};
};

//#endregion
//#region src/core/engine/settle/utils/slots/markSlotChange.ts
const markSlotChange = (host, entry, active, context) => {
	var _host$runtime;
	if (context?.inTransition) {
		const journal = context.slotAutomaticLog ?? (context.slotAutomaticLog = /* @__PURE__ */ new Map());
		let bindings = journal.get(host);
		if (!bindings) journal.set(host, bindings = /* @__PURE__ */ new Map());
		if (!bindings.has(entry)) bindings.set(entry, {
			source: host.inactiveSlots?.get(entry),
			overlay: host.inactiveSlotOverlays?.get(entry)
		});
	}
	const baselines = host.inactiveSlotBaselines ?? (host.inactiveSlotBaselines = /* @__PURE__ */ new Map());
	if (!baselines.has(entry)) baselines.set(entry, {
		active: active ?? (host.deliveryInitialized ? (host.deliveryPreviousChildren ?? host.children)?.find((child) => child.parent === host && child.name === entry.name) : void 0),
		source: host.inactiveSlots?.get(entry),
		overlay: host.inactiveSlotOverlays?.get(entry)
	});
	((_host$runtime = host.runtime).slotDirtyHosts ?? (_host$runtime.slotDirtyHosts = /* @__PURE__ */ new Set())).add(host);
	for (let child = host; !child.detached && child.parent; child = child.parent) {
		const parent = child.parent;
		if (parent.detached || parent.structure?.[child.name] !== child) break;
		(parent.inactiveSlotChildren ?? (parent.inactiveSlotChildren = /* @__PURE__ */ new Map())).set(child.name, child);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/writeSlotPath.ts
const writeSlotPath = (root, path, target, input, whole, context, automatic = false, preserveCandidates = false) => {
	const names = getSlotPathNames(root.runtime, path);
	if (names === void 0) return false;
	let host = root;
	for (let depth = 0; depth < names.length; depth++) {
		var _host;
		const template = host.blueprintNode;
		const name = names[depth];
		const entries = template.kind === "array" ? getItemEntries(template, Number(name)) : template.childEntries;
		const selected = depth === names.length - 1 ? target : void 0;
		const requested = getSlotPathEntry(template, host, void 0, name, selected);
		const entry = requested && getSlotBinding(host, requested);
		if (!entry) return false;
		const live = host.structure?.[name];
		if (depth < names.length - 1 && live?.blueprintNode === entry.node && !live.detached) {
			host = live;
			continue;
		}
		const source = host.inactiveSlots?.get(entry);
		const previous = host.inactiveSlotOverlays?.get(entry);
		let wrote = false;
		const patch = (template, source, previous, index) => {
			if (index === names.length) {
				const result = createSlotValueOverlay(template, input, source, previous, whole, automatic);
				wrote = result.wrote;
				return result.overlay;
			}
			const name = names[index];
			const entries = template.kind === "array" ? getItemEntries(template, Number(name)) : template.childEntries;
			const requested = getSlotPathEntry(template, source, previous, name, index === names.length - 1 ? target : void 0);
			const binding = requested && getSlotBinding(source, requested, previous);
			if (!binding) return previous ?? {};
			const prior = getSlotSource(source, binding, previous);
			const children = new Map(previous?.children);
			children.set(binding, patch(binding.node, prior.source, prior.overlay, index + 1));
			for (const other of entries) {
				if (preserveCandidates || other.name !== name || getBlueprintNodeIdentity(other.node) === getBlueprintNodeIdentity(binding.node) || source?.structure?.[name]?.blueprintNode === other.node) continue;
				const prior = getSlotSource(source, other, previous);
				if (prior.source || prior.overlay) children.set(other, { replace: true });
			}
			return {
				...previous,
				children
			};
		};
		markSlotChange(host, entry, void 0, context);
		((_host = host).inactiveSlotOverlays ?? (_host.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, patch(entry.node, source, previous, depth + 1));
		for (const other of entries) {
			if (preserveCandidates || other.name !== name || getBlueprintNodeIdentity(other.node) === getBlueprintNodeIdentity(entry.node)) continue;
			if (!host.inactiveSlots?.has(other) && !host.inactiveSlotOverlays?.has(other)) continue;
			markSlotChange(host, other, void 0, context);
			host.inactiveSlots?.delete(other);
			host.inactiveSlotOverlays?.delete(other);
		}
		return wrote;
	}
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/slots/distributeMovedSource.ts
const distributeMovedSource = (context, path, template, composed, _order) => {
	const retained = resolveSlotSource(context.root, path, template);
	if (retained.source || retained.overlay) return;
	writeSlotPath(context.root, path, template, composed, false, context, false, true);
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotOrder.ts
const getSlotOrder = (parent, name, template) => {
	const order = [];
	let host = parent;
	let childName = name;
	let childTemplate = template;
	while (host) {
		const index = getSlotChildIndex(host.blueprintNode, childName, childTemplate);
		const arrayIndex = Number(childName);
		order.push(index >= 0 ? index : Number.isInteger(arrayIndex) && arrayIndex >= 0 ? arrayIndex : 0);
		childName = host.name;
		childTemplate = host.blueprintNode;
		host = host.parent;
	}
	return order.reverse();
};

//#endregion
//#region src/core/engine/settle/utils/slots/writeInactiveSource.ts
const writeInactiveSource = (context, path, template, value, _order, whole, _siblings, automatic = false) => writeSlotPath(context.root, path, template, value, whole, context, automatic);

//#endregion
//#region src/core/engine/settle/utils/loadValues/getLoadValue.ts
const getLoadValue = (snapshot, path, segments) => {
	if (!path) return snapshot;
	let value = snapshot;
	for (const name of segments ?? parsePointerSegments(path)) {
		if (value === null || typeof value !== "object") return void 0;
		if (typeof name !== "string") return void 0;
		value = Reflect.get(value, name);
	}
	return value;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/canReuseAppendedChild.ts
const canReuseAppendedChild = (node, context, prior, proof) => {
	const name = String(proof.count);
	const path = appendSegment(node.path, name);
	const child = prior[name];
	const dirty = context.dirtyChildrenByParent.get(node.path);
	return !context.hasGates && node.raw === void 0 && node.itemCount === proof.count + 1 && node.structure === prior && node.children === proof.children && !context.distributedInputs.has(node) && context.pathChanges.length === 0 && context.pendingExits.size === 0 && (dirty === void 0 || dirty.size === 0 || dirty.size === 1 && dirty.has(path)) && (proof.entry === void 0 ? child === void 0 && node.children?.length === 0 && isArray(node.undeclaredValues) && node.undeclaredValues.length === node.itemCount && !dirty?.size : child !== void 0 && child.blueprintNode === proof.entry.node && child.name === name && child.parent === node && child.path === path && child.schema === proof.schema && child.active && !child.detached);
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/canReuseSplicedChildren.ts
const NO_ACTIVE_IDS$5 = Object.freeze([]);
const canReuseSplicedChildren = (node, context, prior, proof) => {
	const children = node.children;
	if (context.hasGates || node.raw !== void 0 || node.itemCount !== (proof.entry ? proof.count + 1 : proof.count - 1) || node.structure !== prior || !children || children !== proof.children || context.distributedInputs.has(node) || context.pathChanges.length !== proof.pathChanges || context.pendingExits.size > 0) return false;
	for (const name of context.dirtyChildrenByParent.get(node.path)?.values() ?? []) if (!(Number(name) >= proof.index)) return false;
	for (let index = proof.index; index < node.itemCount; index++) {
		const entry = getItemEntry(node.blueprintNode, index);
		if (!entry) return false;
		const child = children[index];
		const schema = mergeEffectiveSchema(entry.node, NO_ACTIVE_IDS$5, {
			mode: "runtime",
			isAtomic: node.runtime.blueprint.isAtomic
		});
		if (!child || child !== prior[entry.name] || child.blueprintNode !== entry.node || child.name !== entry.name || child.parent !== node || child.path !== appendSegment(node.path, entry.name) || child.schema !== schema || !child.active || child.detached || schema.typeConflict || entry.node.kind === "virtual" || !entry.declarations.length || context.entered.has(child) && !(proof.entry && index === proof.index)) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/canReuseTruncatedChildren.ts
const canReuseTruncatedChildren = (node, context, prior, proof) => {
	const dirty = context.dirtyChildrenByParent.get(node.path);
	return !context.hasGates && node.raw === void 0 && node.itemCount === proof.count - 1 && node.structure === prior && node.children === proof.children && !context.distributedInputs.has(node) && context.pathChanges.length === 0 && context.pendingExits.size === 0 && (dirty === void 0 || dirty.size === 0);
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/canReuseArrayChildren.ts
const NO_ACTIVE_IDS$4 = Object.freeze([]);
const canReuseArrayChildren = (node, context, prior) => {
	const append = context.arrayAppend;
	if (append?.host === node && append.valid) {
		if (canReuseAppendedChild(node, context, prior, append)) return true;
		append.valid = false;
	}
	const pop = context.arrayPop;
	if (pop?.host === node && pop.valid) {
		if (canReuseTruncatedChildren(node, context, prior, pop)) return true;
		pop.valid = false;
	}
	const splice = context.arraySplice;
	if (splice?.host === node && splice.valid) {
		if (canReuseSplicedChildren(node, context, prior, splice)) return true;
		splice.valid = false;
	}
	const capabilities = node.runtime.blueprint.capabilities;
	const oldCount = context.arrayCounts.get(node);
	const children = node.children;
	if (context.hasGates || !capabilities.branchless || capabilities.hasExpressions || capabilities.hasDerive || oldCount === void 0 || oldCount === node.itemCount || node.raw !== void 0 || context.distributedInputs.has(node) || context.pathChanges.length > 0 || context.pendingExits.size > 0 || node.structure !== prior || !children || !isArray(getLoadValue(context.previousEmit, node.path))) return false;
	const prefixCount = Math.min(oldCount, node.itemCount);
	let position = 0;
	for (let index = 0; index < node.itemCount; index++) {
		const entry = getItemEntry(node.blueprintNode, index);
		if (!entry) {
			if (prior[String(index)] !== void 0) return false;
			continue;
		}
		const child = children[position++];
		const schema = mergeEffectiveSchema(entry.node, NO_ACTIVE_IDS$4, {
			mode: "runtime",
			isAtomic: node.runtime.blueprint.isAtomic
		});
		if (!child || child !== prior[entry.name] || child.blueprintNode !== entry.node || child.name !== entry.name || child.parent !== node || child.path !== appendSegment(node.path, entry.name) || child.schema !== schema || !child.active || child.detached || schema.typeConflict || entry.node.kind === "virtual" || !entry.declarations.length || index < prefixCount && context.entered.has(child)) return false;
	}
	return position === children.length;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/readGateBucket.ts
const EMPTY$1 = Object.freeze([]);
const readGateBucket = (buckets, value) => value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean" ? buckets.get(value) ?? EMPTY$1 : EMPTY$1;

//#endregion
//#region src/core/engine/settle/utils/gates/recordGateFrameInput.ts
const recordGateFrameInput = (frame, input) => {
	if (!frame) return;
	const key = input.key ?? (input.kind === "value" ? input.path : `${input.kind}:${input.path}`);
	const previous = frame.inputs.get(key);
	if (previous) {
		if (!Object.is(previous.value, input.value)) frame.consistent = false;
	} else frame.inputs.set(key, input);
};

//#endregion
//#region src/core/engine/settle/utils/gates/recordGateInput.ts
const recordGateInput = (context, path, value, kind = "value", site) => {
	const frame = context.gateWheelFrame;
	if (!frame) return;
	if (!site) {
		const input = {
			path,
			kind,
			value
		};
		recordGateFrameInput(frame, input);
		if (frame.selectionShadow) recordGateFrameInput(frame.selectionShadow, input);
		return;
	}
	const key = site?.key ?? (kind === "value" ? path : kind + ":" + path);
	const previous = frame.inputs.get(key);
	if (previous) {
		if (!Object.is(previous.value, value)) frame.consistent = false;
		if (frame.selectionShadow) {
			const shadow = frame.selectionShadow.inputs.get(key);
			if (shadow) {
				if (!Object.is(shadow.value, value)) frame.selectionShadow.consistent = false;
			} else recordGateFrameInput(frame.selectionShadow, {
				path,
				kind,
				value,
				key,
				hostPath: site?.hostPath,
				name: site?.name
			});
		}
		return;
	}
	const input = {
		path,
		kind,
		value,
		key,
		hostPath: site?.hostPath,
		name: site?.name
	};
	recordGateFrameInput(frame, input);
	if (frame.selectionShadow) recordGateFrameInput(frame.selectionShadow, input);
};

//#endregion
//#region src/core/engine/settle/utils/gates/readGateSelectionGroup.ts
const readGateSelectionGroup = (node, context, group) => {
	const round = context.gateSelectionRounds.get(node);
	const cached = round.values.get(group.watchedName);
	if (cached) return cached.value;
	const registry = getGateRegistry(node.runtime);
	const path = registry.locate(node, group.firstGate).watchPaths[0];
	const value = readProjectedValue(context, path);
	recordGateInput(context, path, value, "value");
	round.values.set(group.watchedName, {
		path,
		value,
		occurrences: engineModes.gateSelection === "verify" ? registry.occurrenceCount(node.path) : 0
	});
	if (engineModes.gateSelection === "verify") {
		const childGroup = round.table.groups.find((candidate) => candidate.watchedName === group.watchedName);
		const admitted = readGateBucket(childGroup.buckets, value);
		const indices = /* @__PURE__ */ new Set();
		for (const bucket of childGroup.buckets.values()) for (const index of bucket) indices.add(index);
		for (const index of indices) {
			const step = round.table.plan.steps[index];
			if (!step.gate || !childGroup.literalsByGate.has(step.gate)) continue;
			const expression = step.gate.kind === "discriminator" ? void 0 : getGateExpression(node.runtime.blueprint, step.gate.schemaPath);
			verifyGateSelection(admitted.includes(index) === (step.gate.kind === "discriminator" ? step.gate.condition.values.some((tag) => tag === value) : Boolean(expression.evaluate([value]))), "S1 table step verdict: " + index);
		}
	}
	return value;
};

//#endregion
//#region src/core/engine/settle/utils/errors/recordSettlementFailure.ts
const recordSettlementFailure = (context, failure, cause, identity = [
	failure.code,
	String(failure.details.path),
	String(failure.details.schemaPath),
	failure.message
].join("\0")) => {
	const keys = context.failureKeys ?? (context.failureKeys = /* @__PURE__ */ new Set());
	if (keys.has(identity)) return;
	keys.add(identity);
	(context.failures ?? (context.failures = [])).push(failure);
	context.cause ?? (context.cause = cause);
	const runtime = context.root.runtime;
	if (!runtime.entryDepth) return;
	runtime.chainErrors?.push(failure);
	if (runtime.errorReporter?.hasConsumer()) runtime.chainOccurrences?.push({
		kind: "error",
		error: failure
	});
};

//#endregion
//#region src/core/engine/settle/utils/gates/evaluateGate.ts
const evaluateGateValue = (gate, context, owner, edgeName, reference = false) => {
	if (gate.appliesWhen?.some((parentGate) => !evaluateGate(parentGate, context, owner, void 0, reference))) return false;
	const occurrence = getGateRegistry(owner.runtime).locate(owner, gate, edgeName);
	const hostPath = occurrence.hostPath;
	const predicate = occurrence.predicate;
	const reusable = !reference && !!context.kind && predicate.memoizable;
	const input = reusable ? predicate.arguments : void 0;
	try {
		const view = gate.kind === "active" ? void 0 : readGateHostView(context, hostPath, owner);
		const dependencies = input?.values ?? new Array(predicate.inputs.length);
		const memo = occurrence.memo;
		let identical = !!memo && memo.values.length === predicate.inputs.length;
		for (let index = 0; index < predicate.inputs.length; index++) {
			const site = predicate.inputs[index];
			const value = site.kind === "context" ? context.root.runtime.context : site.kind === "extra" ? view?.extra : site.kind === "property" ? view?.value[site.name] : site.kind === "presence" ? hasOwnProperty(view.value, site.name) : gate.kind === "if" || gate.kind === "discriminator" && site.path === hostPath ? view?.projected : gate.kind === "discriminator" ? hasOwnProperty(view.value, gate.condition.propertyName) ? view.value[gate.condition.propertyName] : void 0 : readProjectedValue(context, site.path);
			if (identical && !Object.is(memo.values[index], value)) identical = false;
			dependencies[index] = value;
			recordGateInput(context, site.path, value, site.kind, site);
		}
		if (gate.kind === "active" && occurrence.evaluationHostPath !== occurrence.hostPath) (context.relocatedReads ?? (context.relocatedReads = /* @__PURE__ */ new Map())).set(occurrence, {
			paths: occurrence.watchPaths,
			values: dependencies
		});
		if (reusable && identical && memo) return memo.value;
		if (!reference) occurrence.memo = void 0;
		const args = input ?? {
			values: dependencies,
			view: void 0
		};
		args.view = view?.value;
		const result = predicate.evaluate(args);
		if (result === void 0 && gate.kind === "if") {
			const runtime = context.root.runtime;
			const keys = runtime.errorReporter?.hasConsumer() ? runtime.warningKeys ?? (runtime.warningKeys = /* @__PURE__ */ new Set()) : void 0;
			if (runtime.validationMode !== ValidationMode.None && keys && !keys.has(FormWarningCode.ValidatorMissing)) {
				keys.add(FormWarningCode.ValidatorMissing);
				const record = {
					level: "warning",
					code: FormWarningCode.ValidatorMissing,
					message: "Validation is disabled because no validator was selected"
				};
				(runtime.pendingWarningRecords ?? (runtime.pendingWarningRecords = /* @__PURE__ */ new Map())).set(FormWarningCode.ValidatorMissing, record);
				runtime.chainOccurrences?.push({
					kind: "record",
					record
				});
			}
			if (keys && !keys.has(FormWarningCode.ConditionalSchemaWithoutValidator)) {
				keys.add(FormWarningCode.ConditionalSchemaWithoutValidator);
				const record = {
					level: "warning",
					code: FormWarningCode.ConditionalSchemaWithoutValidator,
					message: "Conditional schema is inactive without a validator",
					schemaPath: gate.schemaPath
				};
				(runtime.pendingWarningRecords ?? (runtime.pendingWarningRecords = /* @__PURE__ */ new Map())).set(FormWarningCode.ConditionalSchemaWithoutValidator, record);
				runtime.chainOccurrences?.push({
					kind: "record",
					record
				});
			}
			return false;
		}
		const value = result ?? false;
		if (!reference && context.kind && predicate.memoizable && result !== void 0) if (memo) {
			memo.value = value;
			occurrence.memo = memo;
		} else occurrence.memo = {
			values: dependencies,
			value
		};
		return value;
	} catch (cause) {
		if (!reference) occurrence.memo = void 0;
		const runtime = context.root.runtime;
		context.gateThrowVersion = (context.gateThrowVersion ?? 0) + 1;
		const code = gate.kind === "if" ? FormErrorCode.GuardFailed : FormErrorCode.ExpressionThrew;
		const repeated = context.failures?.some((error) => error.code === code && error.details.path === hostPath && error.details.schemaPath === gate.schemaPath);
		const failure = runtime.mountingGuardPass || repeated ? void 0 : new SchemaFormError(code, `Gate evaluation failed at ${gate.schemaPath}`, {
			path: hostPath,
			schemaPath: gate.schemaPath,
			cause
		});
		if (gate.kind === "if" && runtime.errorReporter?.hasConsumer() && !runtime.reportedGuardFailures?.has(gate.schemaPath) && !runtime.guardFailureRecords?.has(gate.schemaPath)) {
			const record = {
				level: "error",
				code: FormErrorCode.GuardFailed,
				message: "Gate evaluation failed at " + gate.schemaPath,
				schemaPath: gate.schemaPath,
				path: hostPath,
				details: { cause },
				surface: runtime.mountingGuardPass ? "sink" : "thrown"
			};
			(runtime.guardFailureRecords ?? (runtime.guardFailureRecords = /* @__PURE__ */ new Map())).set(gate.schemaPath, record);
			runtime.chainOccurrences?.push({
				kind: "record",
				record
			});
		}
		if (failure) recordSettlementFailure(context, failure, "expression");
		return false;
	} finally {
		if (input) {
			input.view = void 0;
			if (!occurrence.memo) input.values.fill(void 0);
		}
	}
};
const evaluateGate = (gate, context, owner, edgeName, reference = false) => {
	const version = context.gateThrowVersion;
	const value = evaluateGateValue(gate, context, owner, edgeName, reference);
	const frame = context.gateWheelFrame;
	if (!reference && frame && context.gateSelectionRounds?.get(owner)?.active && version === context.gateThrowVersion) {
		const occurrence = getGateRegistry(owner.runtime).locate(owner, gate, edgeName);
		if (occurrence.predicate.memoizable) (frame.predicateResults ?? (frame.predicateResults = /* @__PURE__ */ new Map())).set(occurrence, value);
	}
	context.gateWheelFrame?.evaluations?.push({
		gate,
		path: owner.path,
		edgeName,
		value
	});
	return value;
};

//#endregion
//#region src/core/engine/settle/utils/gates/verifyTableGate.ts
const verifyTableGate = (node, context, gate, value) => {
	if (context.gateSelectionRounds.get(node).table.predicateGroups.some((group) => group.gate === gate)) {
		verifyGateSelection(evaluateGate(gate, context, node, void 0, true) === value, "S1 predicate verdict: " + gate.schemaPath);
		return;
	}
	if (engineModes.gateSelection === "verify") {
		const round = context.gateSelectionRounds.get(node);
		const registry = getGateRegistry(node.runtime);
		const path = registry.locate(node, gate).watchPaths[0];
		const name = readPointerSegment(path, -1);
		if (typeof name !== "string") throw new TypeError("Expected a named node path");
		const cached = round.values.get(name);
		const pending = [...context.pendingOutputs ?? []];
		const changed = [...context.changedNodes];
		const read = readProjectedValue(context, path);
		verifyGateSelection(Object.is(cached.value, read), "S2 positional value: " + path);
		verifyGateSelection(pending.length === (context.pendingOutputs?.size ?? 0) && pending.every((entry) => context.pendingOutputs.has(entry)), "S2 pendingOutputs changed: " + path);
		verifyGateSelection(changed.length === context.changedNodes.size && changed.every((entry) => context.changedNodes.has(entry)), "S2 read published output: " + path);
		verifyGateSelection(!context.dirtyPaths.has(path), "S2 watched path dirty: " + path);
		verifyGateSelection(cached.occurrences === registry.occurrenceCount(node.path), "S2 host occurrence count changed: " + node.path);
		recordGateFrameInput(context.gateWheelFrame?.selectionShadow, {
			path,
			kind: "value",
			value: read
		});
	}
	context.gateWheelFrame?.evaluations?.push({
		gate,
		path: node.path,
		edgeName: void 0,
		value
	});
};

//#endregion
//#region src/core/engine/settle/utils/gates/flushPendingGateReads.ts
const flushPendingGateReads = (template, path, context) => {
	if (context.root.runtime.blueprint.capabilities.branchless) return;
	if (!context.pendingOutputs?.size) return;
	let plan = getHostDerived(template).readPlans;
	if (!plan) {
		const built = {
			occurrences: [],
			recursive: false
		};
		const ancestors = /* @__PURE__ */ new Set();
		const visit = (node, suffix) => {
			if (ancestors.has(node)) {
				built.recursive = true;
				return;
			}
			ancestors.add(node);
			for (const declaration of node.declarations) for (const gate of declaration.gates) built.occurrences.push({
				gate,
				node,
				suffix,
				childSuffix: gate.schemaPath === appendSegment(appendSegment(node.schemaPath, "controls"), "active") ? suffix : void 0
			});
			for (const entry of node.childEntries) {
				const childSuffix = appendSegment(suffix, entry.name);
				for (const declaration of entry.declarations) for (const gate of declaration.gates) built.occurrences.push({
					gate,
					node,
					suffix,
					childSuffix: gate.schemaPath === appendSegment(appendSegment(declaration.schemaPath, "controls"), "active") ? childSuffix : void 0
				});
				visit(entry.node, childSuffix);
			}
			for (const [index, item] of (node.prefixItems ?? []).entries()) for (const candidate of node.prefixItemCandidates?.[index] ?? [item]) visit(candidate, appendSegment(suffix, index));
			for (const item of node.itemCandidates ?? (node.item ? [node.item] : [])) visit(item, appendSegment(suffix, node.prefixItems?.length ?? 0));
			ancestors.delete(node);
		};
		visit(template, "");
		plan = built;
		getHostDerived(template).readPlans = plan;
	}
	if (plan.recursive) {
		for (const host of context.pendingOutputs) flushPendingOutput(host, context);
		return;
	}
	const flushRead = (read) => {
		if (readPointerSegment(read, 0) === PointerOperator.Context) return;
		const local = read === path || isDescendantPath(read, path);
		for (const host of context.pendingOutputs ?? []) {
			if (local && host.raw === void 0) continue;
			if (read === host.path) flushPendingOutput(host, context);
			else if (isDescendantPath(read, host.path)) {
				const name = readPointerSegment(read.slice(host.path.length + 1), 0);
				if (typeof name !== "string") continue;
				if (host.raw !== void 0 || !host.structure || !hasOwnProperty(host.structure, name)) flushPendingOutput(host, context);
			}
		}
	};
	const blueprint = context.root.runtime.blueprint;
	const registry = getGateRegistry(context.root.runtime);
	const flushGate = (gate, node, occurrencePath, childHostPath) => {
		for (const parent of gate.appliesWhen ?? []) flushGate(parent, node, occurrencePath);
		const hostPath = bindGateHostPath(gate, node.path, occurrencePath, childHostPath);
		if (gate.kind !== "active") flushRead(hostPath);
		else {
			const expression = getGateExpression(blueprint, gate.schemaPath);
			for (const dependency of expression?.dependencies ?? []) flushRead(registry.resolveRead(hostPath, dependency));
		}
	};
	for (const occurrence of plan.occurrences) flushGate(occurrence.gate, occurrence.node, path + occurrence.suffix, occurrence.childSuffix === void 0 ? void 0 : path + occurrence.childSuffix);
};

//#endregion
//#region src/core/engine/settle/utils/gates/verifyTablePrePublication.ts
const verifyTablePrePublication = (node, context, entry) => {
	const path = appendSegment(node.path, entry.name);
	const pending = [...context.pendingOutputs];
	const changed = [...context.changedNodes];
	flushPendingGateReads(entry.node, path, context);
	const afterPending = [...context.pendingOutputs ?? []];
	const afterChanged = [...context.changedNodes];
	verifyGateSelection(pending.length === afterPending.length && pending.every((host, index) => host === afterPending[index]) && changed.length === afterChanged.length && changed.every((host, index) => host === afterChanged[index]), "S2 table pre-publication: " + path);
};

//#endregion
//#region src/core/engine/settle/utils/gates/verifyUnvisitedGateStep.ts
const verifyUnvisitedGateStep = (frame, step) => {
	const { node, context, prior, next } = frame;
	const { entry } = step;
	const path = appendSegment(node.path, entry.name);
	verifyGateSelection(!hasOwnProperty(prior, entry.name) || prior[entry.name].blueprintNode !== entry.node, "S2′ prior child: " + path);
	verifyGateSelection(!hasOwnProperty(next, entry.name), "S2′ current structure: " + path);
	verifyGateSelection(!context.pendingExits.has(JSON.stringify([path, getBlueprintNodeIdentity(entry.node)])), "S2′ pending exit: " + path);
	const distribution = context.distributedInputs.get(node);
	verifyGateSelection(!distribution || !hasDistributedChildInput(distribution.input, entry.name, false), "S2′ distributed input: " + path);
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/captureProjectionBaseline.ts
const captureProjectionBaseline = (host, child, retained, context) => {
	if (!context.hasGates || !retained) return;
	const hosts = context.projectionBaselines ?? (context.projectionBaselines = /* @__PURE__ */ new Map());
	let children = hosts.get(host);
	if (!children) hosts.set(host, children = /* @__PURE__ */ new Map());
	if (!children.has(child)) children.set(child, {
		schema: child.schema,
		emit: child.emit
	});
	(context.presenceHosts ?? (context.presenceHosts = /* @__PURE__ */ new Set())).add(host);
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/supplementSplitOwner.ts
const supplementSplitOwner = (child, context) => {
	if (!context.splitHitEpochs) return;
	const owner = getDependencyIndex(child.runtime.blueprint).splitOwners.get(child.path);
	if (!owner) return;
	const lastHit = context.splitHitEpochs.get(owner.bucket);
	if (lastHit === void 0) return;
	const dirtyBefore = context.dirtyPaths.has(child.path);
	verifyGateSelection(dirtyBefore, "S4 entry/revival must already be dirty: " + child.path);
	if (lastHit > (context.splitMarks?.get(child.path) ?? -1)) {
		context.dirtyPaths.add(child.path);
		(context.splitMarks ?? (context.splitMarks = /* @__PURE__ */ new Map())).set(child.path, lastHit);
		if (!dirtyBefore && context.registrationShadow) context.registrationShadow.supplementInsertions++;
	}
};

//#endregion
//#region src/core/engine/settle/utils/compute/createChildNode.ts
const createChildNode = (host, entry) => {
	const child = host.runtime.nodeFactory(entry, host, host.runtime);
	if (host.behavior.type === "array" && host.behavior.strategy === "branch") child.itemKey = host.nextItemKey++;
	return child;
};

//#endregion
//#region src/core/engine/settle/utils/slots/pruneSlotSources.ts
const pruneSlotSources = (root, path, names, context) => {
	if (names) {
		for (const name of names) pruneSlotSources(root, appendSegment(path, name), void 0, context);
		return;
	}
	const parts = getSlotPathNames(root.runtime, path);
	if (parts === void 0) return;
	const clear = (host) => {
		const entries = new Set(host.inactiveSlots?.keys());
		for (const entry of host.inactiveSlotOverlays?.keys() ?? []) entries.add(entry);
		for (const entry of entries) markSlotChange(host, entry, void 0, context);
		host.inactiveSlots?.clear();
		host.inactiveSlotOverlays?.clear();
		for (const child of host.inactiveSlotChildren?.values() ?? []) if (host.structure?.[child.name] === child && !child.detached) clear(child);
	};
	const patch = (source, overlay, position) => {
		if (position === parts.length) return { replace: true };
		const children = new Map(overlay?.children);
		for (const entry of getSlotEntries(source, overlay)) {
			if (entry.name !== parts[position]) continue;
			const prior = getSlotSource(source, entry, overlay);
			children.set(entry, patch(prior.source, prior.overlay, position + 1));
		}
		return {
			...overlay,
			children
		};
	};
	const visit = (host, position) => {
		if (position === parts.length) {
			clear(host);
			return;
		}
		const name = parts[position];
		const entries = new Set(host.inactiveSlots?.keys());
		for (const entry of host.inactiveSlotOverlays?.keys() ?? []) entries.add(entry);
		for (const entry of entries) {
			if (entry.name !== name) continue;
			markSlotChange(host, entry, void 0, context);
			if (position + 1 === parts.length) {
				host.inactiveSlots?.delete(entry);
				host.inactiveSlotOverlays?.delete(entry);
			} else (host.inactiveSlotOverlays ?? (host.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, patch(host.inactiveSlots?.get(entry), host.inactiveSlotOverlays?.get(entry), position + 1));
		}
		const live = host.structure?.[name];
		if (live && !live.detached) visit(live, position + 1);
	};
	visit(root, 0);
};

//#endregion
//#region src/core/engine/settle/utils/slots/pruneInactiveSources.ts
const pruneInactiveSources = (_runtime, path, names, context) => {
	if (context && (context.root.inactiveSlots?.size || context.root.inactiveSlotOverlays?.size || context.root.inactiveSlotChildren?.size)) pruneSlotSources(context.root, path, names, context);
};

//#endregion
//#region src/core/engine/settle/utils/input/arrayExtras.ts
const arrayExtras = (node, value) => {
	if (node.blueprintNode.item) return void 0;
	const start = isArray(node.blueprintNode.prefixItems) ? node.blueprintNode.prefixItems.length : 0;
	const next = value.length > start ? value.slice(start) : void 0;
	const previous = node.undeclaredValues;
	return isArray(previous) && sameValue(previous, next) ? previous : next;
};

//#endregion
//#region src/core/engine/settle/utils/input/utils/admitsSameValueWrite.ts
const admitsSameValueWrite = (node, context) => {
	const runtime = node.runtime;
	const scope = context.target.path;
	return !(context.kind === "load" || context.kind === "automatic" || context.automatic || context.hasGates || context.loadScope !== void 0 || context.replacePaths !== void 0 || node.detached || runtime.batchDepth || runtime.visitDepth || !StaticFirstLoadCapability.has(runtime.blueprint) || context.target.inactiveSlots?.size || context.target.inactiveSlotOverlays?.size || context.target.inactiveSlotChildren?.size || runtime.misfitPaths.pathIndex.under(scope).size > 0);
};

//#endregion
//#region src/core/engine/settle/utils/input/utils/keepsHostKeys.ts
const keepsHostKeys = (node, value, isMerge) => {
	const local = node.local;
	if (node.behavior.type === "array") return isArray(value) && isArray(local) && local.length === node.itemCount;
	if (!isPlain(value) || !isPlain(local)) return false;
	const keys = Object.keys(value);
	for (let index = 0; index < keys.length; index++) {
		const key = keys[index];
		if (value[key] === void 0 || !hasOwnProperty(local, key)) return false;
	}
	return isMerge || keys.length === Object.keys(local).length;
};

//#endregion
//#region src/core/engine/settle/utils/input/utils/restoreWriteEpochPaths.ts
const restoreWriteEpochPaths = (context) => {
	const epoch = context.writeEpoch;
	context.writeEpoch = void 0;
	for (const node of context.writtenInputs.keys()) if (node.writeEpoch === epoch) context.dirtyPaths.add(node.path);
};

//#endregion
//#region src/core/engine/settle/utils/input/markWrite.ts
const UNINTERPRETED = Symbol("uninterpreted");
const markWrite = (node, input, context, spec = staticSpec(node.schemaType, node.nullable), changedValue = UNINTERPRETED) => {
	if (context.writeEpoch !== void 0 && context.automatic) restoreWriteEpochPaths(context);
	if (node.behavior.type === "virtual" && !context.automatic && context.kind !== "load") assertVirtualWriteShape(node, input);
	if (context.loadScope) context.entered.add(node);
	if (context.kind === "load") context.changedNodes.add(node);
	if (context.kind === "load" && node.behavior.strategy === "branch") context.shapeDirtyPaths.add(node.path);
	const isMerge = context.kind === "callerPartial" && !context.automatic;
	if (!context.automatic) context.writtenInputs.set(node, input);
	else context.automaticLog.push({
		node,
		previousRaw: node.raw,
		previousExtras: node.undeclaredValues,
		previousDistributed: context.distributedInputs.get(node)
	});
	const known = changedValue !== UNINTERPRETED;
	const value = known ? changedValue : node.behavior.interpret(input, spec);
	if (node.behavior.strategy !== "branch") {
		if (known || !sameValue(node.raw, value)) {
			node.raw = value;
			context.changedRaw.add(node.path);
			context.changedNodes.add(node);
			if (context.automatic) context.automaticChanged = true;
		}
		if (context.writeEpoch !== void 0) node.writeEpoch = context.writeEpoch;
		else context.dirtyPaths.add(node.path);
		return;
	}
	if (node.behavior.type === "virtual") {
		context.dirtyPaths.add(node.path);
		const fields = node.blueprintNode.fields ?? [];
		const values = isArray(value) ? value : void 0;
		for (let index = 0; index < fields.length; index++) {
			const sibling = node.parent?.structure?.[fields[index]];
			if (!sibling) continue;
			if (!context.automatic && context.kind !== "load" && !isMerge) {
				(context.virtualReplacePaths ?? (context.virtualReplacePaths = [])).push(sibling.path);
				pruneInactiveSources(sibling.runtime, sibling.path, void 0, context);
			}
			markWrite(sibling, values?.[index], context);
		}
		return;
	}
	let nextRaw;
	let extras;
	let whole;
	let countChanged = false;
	if (node.behavior.type === "array") {
		const previousItemCount = node.itemCount;
		if (context.automatic) context.arrayStructureLog.push({
			host: node,
			previousItems: [...node.children ?? []],
			previousItemCount,
			previousExtras: node.undeclaredValues
		});
		if (!context.arrayCounts.has(node)) context.arrayCounts.set(node, previousItemCount);
		node.itemCount = isArray(value) ? value.length : 0;
		countChanged = node.itemCount !== previousItemCount;
		nextRaw = isArray(value) ? void 0 : value;
		extras = isArray(value) ? arrayExtras(node, value) : void 0;
		whole = true;
		if (isMerge && node !== context.replaceScope) pruneInactiveSources(node.runtime, node.path, void 0, context);
	} else if (!isPlain(value)) {
		nextRaw = value;
		extras = void 0;
		whole = true;
		if (isMerge && node !== context.replaceScope) pruneInactiveSources(node.runtime, node.path, void 0, context);
	} else {
		const declared = getDeclaredChildNames(node.blueprintNode);
		whole = !isMerge && (context.replacePaths === void 0 || context.replacePaths.some((path) => node.path === path || isDescendantPath(node.path, path)));
		nextRaw = isMerge ? node.raw : void 0;
		if (isMerge && nextRaw !== void 0) context.wrongKindHosts.add(node);
		extras = nextExtras(node.undeclaredValues, value, declared, isMerge);
	}
	const rawChanged = !sameValue(node.raw, nextRaw);
	const extrasChanged = node.undeclaredValues !== extras;
	const sameShape = node.raw === void 0 && nextRaw === void 0 && node.undeclaredValues === void 0 && extras === void 0 && !countChanged && admitsSameValueWrite(node, context) && keepsHostKeys(node, value, isMerge);
	if (!sameShape && context.writeEpoch !== void 0) restoreWriteEpochPaths(context);
	if (rawChanged || extrasChanged || countChanged) {
		node.raw = nextRaw;
		node.undeclaredValues = extras;
		context.changedRaw.add(node.path);
		context.changedNodes.add(node);
		if (context.automatic) context.automaticChanged = true;
	}
	context.distributedInputs.set(node, {
		input: value,
		whole,
		automatic: context.automatic
	});
	if (context.writeEpoch !== void 0) node.writeEpoch = context.writeEpoch;
	else context.dirtyPaths.add(node.path);
	if (!sameShape) context.shapeDirtyPaths.add(node.path);
	if (node.structure === null) return;
	for (const name of Object.keys(node.structure)) {
		if (node.behavior.type === "array" && Number(name) >= node.itemCount) continue;
		if (!whole && !hasDistributedChildInput(value, name, node.behavior.type === "array")) continue;
		const child = node.structure[name];
		if (child.behavior.type === "virtual") continue;
		const childInput = hasDistributedChildInput(value, name, node.behavior.type === "array") ? Reflect.get(value, name) : void 0;
		let childSpec;
		let interpreted = UNINTERPRETED;
		if (sameShape && child.behavior.strategy !== "branch") {
			childSpec = staticSpec(child.schemaType, child.nullable);
			interpreted = child.behavior.interpret(childInput, childSpec);
		}
		if (interpreted !== UNINTERPRETED && sameValue(child.raw, interpreted)) continue;
		if (context.automatic) {
			context.writtenInputs.set(child, childInput);
			context.filledNodes.add(child);
		}
		markWrite(child, childInput, context, childSpec, interpreted);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/markRestoredSlotRaw.ts
const markRestoredSlotRaw = (node, context) => {
	const preceding = context.slotRestoredRaw ?? (context.slotRestoredRaw = /* @__PURE__ */ new Map());
	if (!preceding.has(node)) preceding.set(node, context.changedRaw.has(node.path));
	if (node.raw !== void 0 || node.undeclaredValues !== void 0 || node.behavior.type === "array" && node.itemCount > 0) {
		context.changedRaw.add(node.path);
		context.changedNodes.add(node);
	} else if (!preceding.get(node)) context.changedRaw.delete(node.path);
};

//#endregion
//#region src/core/engine/settle/utils/slots/applySlotOverlay.ts
const applySlotOverlay = (node, overlay, context) => {
	markRestoredSlotRaw(node, context);
	const ownsRaw = hasOwnProperty(overlay, "raw");
	const arrayInput = ownsRaw && node.behavior.type === "array" && node.behavior.strategy === "branch" && isArray(overlay.raw);
	if (arrayInput) {
		markWrite(node, overlay.raw, context);
		if (overlay.children?.size) {
			const names = [];
			for (const entry of overlay.children.keys()) if (!names.includes(entry.name)) names.push(entry.name);
			const distribution = context.distributedInputs.get(node);
			if (distribution) context.distributedInputs.set(node, {
				...distribution,
				retainedItemNames: names
			});
		}
	} else if (ownsRaw || overlay.replace) node.raw = ownsRaw ? overlay.raw : void 0;
	if (hasOwnProperty(overlay, "undeclaredValues") || overlay.replace && !arrayInput) node.undeclaredValues = overlay.undeclaredValues;
	if (overlay.itemCount !== void 0) node.itemCount = overlay.itemCount;
	else if (overlay.replace && node.behavior.type === "array" && !isArray(overlay.raw)) node.itemCount = 0;
	if (overlay.replace) {
		node.inactiveSlotOverlays?.clear();
		for (const entry of node.inactiveSlots?.keys() ?? []) if (!overlay.children?.has(entry)) node.inactiveSlots?.delete(entry);
	}
	for (const child of node.children ?? []) {
		if (child.parent !== node) continue;
		const entry = getRetainedChildEntry(node, child.name, child.blueprintNode);
		if (!entry) continue;
		const patch = overlay.children?.get(entry);
		if (patch) applySlotOverlay(child, patch, context);
		else if (overlay.replace && !arrayInput) applySlotOverlay(child, { replace: true }, context);
	}
	for (const [entry, patch] of overlay.children ?? []) {
		if ((node.structure?.[entry.name])?.blueprintNode === entry.node) continue;
		(node.inactiveSlotOverlays ?? (node.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, patch);
	}
	markRestoredSlotRaw(node, context);
	context.changedNodes.add(node);
	context.dirtyPaths.add(node.path);
	if (node.behavior.strategy === "branch") context.shapeDirtyPaths.add(node.path);
};

//#endregion
//#region src/core/engine/settle/utils/commit/isMisfit.ts
const isMisfit = (value, effective, nullable) => {
	if (value === void 0 || effective === void 0) return false;
	if (value === null) return !nullable;
	return !(typeof effective === "string" ? [effective] : effective).some((kind) => {
		switch (kind) {
			case "string": return typeof value === "string";
			case "boolean": return typeof value === "boolean";
			case "integer": return typeof value === "number" && Number.isInteger(value);
			case "number": return typeof value === "number" && Number.isFinite(value);
			case "array": return isArray(value);
			case "object": return value !== null && typeof value === "object" && !isArray(value);
			case "null": return false;
		}
	});
};

//#endregion
//#region src/core/engine/settle/utils/slots/hasAdditionalInactiveSources.ts
const hasAdditionalInactiveSources = (source, overlay = source.retainedSourceOverlay) => {
	const own = overlay && hasOwnProperty(overlay, "raw");
	const raw = own ? overlay.raw : overlay?.replace ? void 0 : source.raw;
	if (source.behavior.strategy === "terminal") return raw !== void 0;
	if (source.behavior.type === "array" && !own && !overlay?.replace) return true;
	if (raw !== void 0 && isMisfit(raw, source.schemaType, source.nullable)) return true;
	if (overlay?.replace) return false;
	for (const child of source.children ?? []) {
		if (child.parent !== source) continue;
		const binding = getRetainedChildEntry(source, child.name, child.blueprintNode);
		if (hasAdditionalInactiveSources(child, binding ? overlay?.children?.get(binding) : void 0)) return true;
	}
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/slots/cloneSlotSubtree.ts
const cloneSlotSubtree = (host, entry, source, context, entering, compactions) => {
	const node = host.runtime.nodeFactory(entry, host, host.runtime, source);
	node.raw = source.raw;
	node.undeclaredValues = source.undeclaredValues;
	node.itemCount = source.itemCount;
	node.nextItemKey = source.nextItemKey;
	if (source.inactiveValueMemo !== void 0) node.inactiveValueMemo = source.inactiveValueMemo;
	if (source.inactiveValuesCache?.length && !hasAdditionalInactiveSources(source)) {
		node.inactiveValuesCache = source.inactiveValuesCache;
		node.inactiveValuesDirty = true;
	}
	if (host.behavior.type === "array" && host.behavior.strategy === "branch") node.itemKey = host.nextItemKey++;
	if (!entering) {
		node.active = false;
		node.detached = true;
		node.retainedSourceOverlay = source.retainedSourceOverlay;
		if (hasOwnProperty(source, "retainedExitPolicy")) node.retainedExitPolicy = source.retainedExitPolicy;
	}
	const compaction = compactions?.get(source);
	if (compaction) {
		node.itemCount = compaction.itemCount;
		node.structure = Object.create(null);
		node.children = [];
		node.inactiveSlots = /* @__PURE__ */ new Map();
		node.inactiveSlotOverlays = new Map(compaction.overlays);
		for (const [binding, retained] of compaction.sources) node.inactiveSlots.set(binding, cloneSlotSubtree(node, binding, retained, context, false, compactions));
	}
	if (!compaction && source.inactiveSlotOverlays?.size) node.inactiveSlotOverlays = new Map(source.inactiveSlotOverlays);
	if (!compaction && source.inactiveSlots?.size) {
		node.inactiveSlots = /* @__PURE__ */ new Map();
		for (const [binding, retained] of source.inactiveSlots) node.inactiveSlots.set(binding, cloneSlotSubtree(node, binding, retained, context, false, compactions));
	}
	if (!compaction && source.children && source.structure) {
		const structure = Object.create(null);
		const children = [];
		for (const child of source.children) {
			if (child.parent !== source) continue;
			const binding = getRetainedChildEntry(node, child.name, child.blueprintNode);
			if (!binding) continue;
			const copied = cloneSlotSubtree(node, binding, child, context, entering, compactions);
			structure[binding.name] = copied;
			children.push(copied);
			if (copied.inactiveSlots?.size || copied.inactiveSlotOverlays?.size || copied.inactiveSlotChildren?.size) (node.inactiveSlotChildren ?? (node.inactiveSlotChildren = /* @__PURE__ */ new Map())).set(binding.name, copied);
		}
		node.structure = structure;
		node.children = children;
	}
	if (entering) {
		if (node.behavior.type === "array" && node.behavior.strategy === "branch") context.arrayCounts.set(node, 0);
		markRestoredSlotRaw(node, context);
		context.entered.add(node);
		context.changedNodes.add(node);
		context.dirtyPaths.add(node.path);
		if (node.behavior.strategy === "branch") context.shapeDirtyPaths.add(node.path);
	}
	return node;
};

//#endregion
//#region src/core/engine/settle/utils/slots/readSlotRawTree.ts
const readSlotRawTree = (template, source, overlay) => {
	const raw = overlay && hasOwnProperty(overlay, "raw") ? overlay.raw : overlay?.replace ? void 0 : source?.raw;
	if (raw !== void 0 || template.strategy === "terminal") return raw;
	const extras = overlay && hasOwnProperty(overlay, "undeclaredValues") ? overlay.undeclaredValues : overlay?.replace ? void 0 : source?.undeclaredValues;
	if (template.kind === "array") {
		const count = overlay?.itemCount ?? (overlay?.replace ? 0 : source?.itemCount ?? 0);
		const value = [];
		let declaredCount = 0;
		for (let index = 0; index < count; index++) {
			const entries = getItemEntries(template, index);
			if (!entries.length) {
				value.push(isArray(extras) ? extras[index - declaredCount] : void 0);
				continue;
			}
			declaredCount++;
			let item;
			const active = !overlay?.replace && source?.structure?.[String(index)];
			if (active) {
				const entry = entries.find((entry) => entry.node === active.blueprintNode);
				const patch = entry ? getSlotSource(source, entry, overlay).overlay : void 0;
				item = readSlotRawTree(active.blueprintNode, active, patch);
				value.push(item);
				continue;
			}
			for (const entry of entries) {
				const child = getSlotSource(source, entry, overlay);
				item = readSlotRawTree(entry.node, child.source, child.overlay);
				if (item !== void 0) break;
			}
			value.push(item);
		}
		return value;
	}
	const value = isPlain(extras) ? { ...extras } : {};
	let found = Object.keys(value).length > 0;
	for (const entry of getSlotEntries(source, overlay, template)) {
		if (hasOwnProperty(value, entry.name)) continue;
		const child = getSlotSource(source, entry, overlay);
		const active = !overlay?.replace && source?.structure?.[entry.name];
		let raw;
		if (active && source) {
			const binding = getRetainedChildEntry(source, active.name, active.blueprintNode) ?? entry;
			raw = readSlotRawTree(active.blueprintNode, active, getSlotSource(source, binding, overlay).overlay);
		} else raw = readSlotRawTree(entry.node, child.source, child.overlay);
		if (raw === void 0) continue;
		Object.defineProperty(value, entry.name, {
			value: raw,
			enumerable: true,
			configurable: true,
			writable: true
		});
		found = true;
	}
	return found ? value : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/slots/restoreTransferredSlotSource.ts
const restoreTransferredSlotSource = (node, source, overlay, context) => {
	const template = source?.blueprintNode ?? node.blueprintNode;
	const input = readSlotRawTree(template, source, overlay);
	for (const entry of getSlotEntries(source, overlay, template)) {
		const prior = getSlotSource(source, entry, overlay);
		if (prior.source) (node.inactiveSlots ?? (node.inactiveSlots = /* @__PURE__ */ new Map())).set(entry, cloneSlotSubtree(node, entry, prior.source, context, false));
		if (prior.overlay) (node.inactiveSlotOverlays ?? (node.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, prior.overlay);
	}
	markWrite(node, input, context);
	const distribution = context.distributedInputs.get(node);
	if (distribution) context.distributedInputs.set(node, {
		...distribution,
		preserveLatent: true
	});
	markRestoredSlotRaw(node, context);
};

//#endregion
//#region src/core/engine/settle/utils/slots/cloneFromSlot.ts
const cloneFromSlot = (host, entry, source, context) => {
	const binding = getSlotBinding(host, entry);
	const overlay = host.inactiveSlotOverlays?.get(binding);
	const same = source.blueprintNode === entry.node;
	const node = same ? cloneSlotSubtree(host, entry, source, context, true) : createChildNode(host, entry);
	if (same) {
		if (overlay) applySlotOverlay(node, overlay, context);
	} else restoreTransferredSlotSource(node, source, overlay, context);
	markSlotChange(host, binding, void 0, context);
	host.inactiveSlots?.delete(binding);
	host.inactiveSlotOverlays?.delete(binding);
	return node;
};

//#endregion
//#region src/core/engine/settle/utils/slots/createFromSlotOverlay.ts
const createFromSlotOverlay = (host, entry, overlay, context) => {
	const binding = getSlotBinding(host, entry);
	const node = createChildNode(host, entry);
	applySlotOverlay(node, overlay, context);
	markSlotChange(host, binding, void 0, context);
	host.inactiveSlotOverlays?.delete(binding);
	return node;
};

//#endregion
//#region src/core/engine/settle/utils/slots/enterSlotClone.ts
const enterSlotClone = (host, child, name, context) => {
	const distribution = getChildDistribution(host, name, context, child.path);
	if (!distribution || distribution.preserveLatent) return;
	const supplied = hasDistributedChildInput(distribution.input, name, host.behavior.type === "array");
	if (!supplied && !distribution.whole) return;
	const value = supplied ? Reflect.get(distribution.input, name) : void 0;
	if (distribution.automatic) {
		context.automatic = true;
		context.writtenInputs.set(child, value);
		context.filledNodes.add(child);
	}
	markWrite(child, value, context);
	if (distribution.automatic) context.automatic = false;
};

//#endregion
//#region src/core/engine/settle/utils/slots/replayTransferredSlotInput.ts
const replayTransferredSlotInput = (node, context) => {
	const host = node.parent;
	if (!host) return false;
	const entry = getRetainedChildEntry(host, node.name, node.blueprintNode);
	if (!entry) return false;
	const binding = getSlotBinding(host, entry);
	const source = host.inactiveSlots?.get(binding);
	const overlay = host.inactiveSlotOverlays?.get(binding);
	if (!source && !overlay) return false;
	restoreTransferredSlotSource(node, source, overlay, context);
	markSlotChange(host, binding, void 0, context);
	host.inactiveSlots?.delete(binding);
	host.inactiveSlotOverlays?.delete(binding);
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/slots/replayMovedSource.ts
const replayMovedSource = (node, composed, context) => {
	if (replayTransferredSlotInput(node, context)) return;
	markWrite(node, composed, context);
	const distribution = context.distributedInputs.get(node);
	if (distribution) context.distributedInputs.set(node, {
		...distribution,
		preserveLatent: true
	});
};

//#endregion
//#region src/core/engine/settle/utils/compute/enterFieldNode.ts
const enterFieldNode = (host, child, name, context) => {
	const distribution = getChildDistribution(host, name, context, child.path);
	const write = distribution && hasDistributedChildInput(distribution.input, name, host.behavior.type === "array");
	if (distribution?.preserveLatent) replayMovedSource(child, write ? Reflect.get(distribution.input, name) : void 0, context);
	else if (write || distribution?.whole) {
		const value = write ? Reflect.get(distribution.input, name) : void 0;
		if (distribution.automatic) {
			context.automatic = true;
			context.writtenInputs.set(child, value);
			context.filledNodes.add(child);
		}
		markWrite(child, value, context);
		if (distribution.automatic) context.automatic = false;
	} else if (child.behavior.strategy === "terminal") markWrite(child, void 0, context);
	else {
		context.dirtyPaths.add(child.path);
		context.shapeDirtyPaths.add(child.path);
	}
};

//#endregion
//#region src/core/engine/settle/utils/compute/utils/getRecursiveRelativeSpan.ts
const getRecursiveRelativeSpan = (blueprint) => {
	let span = getBlueprintDerived(blueprint).recursiveRelativeSpan;
	if (span !== void 0) return span;
	span = 0;
	const templates = blueprint.nodes;
	for (let index = 0; index < templates.length; index++) {
		const declarations = templates[index].declarations;
		for (let declarationIndex = 0; declarationIndex < declarations.length; declarationIndex++) {
			const gates = declarations[declarationIndex].gates;
			for (let gateIndex = 0; gateIndex < gates.length; gateIndex++) {
				const reads = gates[gateIndex].evaluationReads;
				for (let readIndex = 0; readIndex < reads.length; readIndex++) {
					const read = reads[readIndex];
					if (typeof read === "number" && read > span) span = read;
				}
			}
		}
	}
	getBlueprintDerived(blueprint).recursiveRelativeSpan = span;
	return span;
};

//#endregion
//#region src/core/engine/settle/utils/compute/hasRecursiveExpansion.ts
const hasTemplateCycle = (node, visiting, visited) => {
	if (visiting.has(node)) return true;
	if (visited.has(node)) return false;
	visiting.add(node);
	for (let index = 0; index < node.childEntries.length; index++) if (hasTemplateCycle(node.childEntries[index].node, visiting, visited)) return true;
	for (const item of node.itemCandidates ?? (node.item ? [node.item] : [])) if (hasTemplateCycle(item, visiting, visited)) return true;
	const prefixItems = node.prefixItems;
	for (let index = 0; prefixItems && index < prefixItems.length; index++) for (const item of node.prefixItemCandidates?.[index] ?? [prefixItems[index]]) if (hasTemplateCycle(item, visiting, visited)) return true;
	visiting.delete(node);
	visited.add(node);
	return false;
};
const hasOriginalInput = (node, context) => {
	const distribution = context.distributedInputs.get(node);
	if (distribution && !distribution.automatic && distribution.input !== void 0) return true;
	if (node.behavior.type === "array" && node.itemCount > 0 && !distribution?.automatic && !context.filledNodes.has(node)) return true;
	if (!context.filledNodes.has(node) && (node.raw !== void 0 || node.undeclaredValues !== void 0)) return true;
	const children = node.children;
	for (let index = 0; children && index < children.length; index++) if (hasOriginalInput(children[index], context)) return true;
	return false;
};
const hasRecursiveExpansion = (parent, template, input, context, schema, hosts) => {
	if (input !== void 0) return false;
	const analysis = parent.runtime.blueprint;
	let cyclic = getBlueprintDerived(analysis).recursiveExpansion;
	if (cyclic === void 0) {
		cyclic = hasTemplateCycle(analysis.root, /* @__PURE__ */ new Set(), /* @__PURE__ */ new Set());
		getBlueprintDerived(analysis).recursiveExpansion = cyclic;
	}
	if (!cyclic) return false;
	let relativeSpan;
	const depth = parent.depth + 1;
	let ancestor = parent;
	while (ancestor) {
		if (ancestor.blueprintNode === template && (!schema || ancestor.schema === schema) && (!hosts || hosts.has(ancestor)) && !hasOriginalInput(ancestor, context)) {
			relativeSpan ?? (relativeSpan = getRecursiveRelativeSpan(analysis));
			if (depth - ancestor.depth >= relativeSpan) return true;
		}
		ancestor = ancestor.parent;
	}
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/staticIds.ts
const staticIds = (entry, owner) => {
	const record = getHostDerived(owner);
	const entries = record.staticIds ?? (record.staticIds = /* @__PURE__ */ new WeakMap());
	let ids = entries.get(entry);
	if (!ids) {
		const collected = [];
		for (let index = 0; index < entry.declarations.length; index++) collected.push(entry.declarations[index].id);
		ids = Object.freeze(collected);
		entries.set(entry, ids);
	}
	return ids;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/readAdmittedEdgeSchema.ts
const readAdmittedEdgeSchema = (entry, node, isAtomic, owner) => {
	if (node !== entry.node) return void 0;
	const record = getHostDerived(owner);
	const entries = record.admittedEdgeSchemas ?? (record.admittedEdgeSchemas = /* @__PURE__ */ new WeakMap());
	const cached = entries.get(entry);
	if (cached && cached.isAtomic === isAtomic) return cached;
	const schema = mergeEffectiveSchema(entry.node, staticIds(entry, owner), {
		mode: "runtime",
		isAtomic
	});
	const admitted = {
		schema,
		conflict: schema.typeConflict,
		isAtomic
	};
	entries.set(entry, admitted);
	return admitted;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/mergeGateSteps.ts
const mergeGateSteps = (left, right) => {
	const merged = [];
	let a = 0;
	let b = 0;
	while (a < left.length || b < right.length) {
		const next = b >= right.length || a < left.length && left[a] <= right[b] ? left[a++] : right[b++];
		if (merged[merged.length - 1] !== next) merged.push(next);
	}
	return merged;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/utils/readDiscriminatorEntrySelection.ts
const EMPTY_BUCKET = Object.freeze([]);
const readDiscriminatorEntrySelection = (entry, selection, value, isAtomic) => {
	const bucket = selection.buckets.get(value) ?? EMPTY_BUCKET;
	const cached = selection.prepared.get(bucket);
	if (cached) return cached;
	const ids = mergeGateSteps(selection.baseline, bucket).map((index) => entry.declarations[index].id);
	const prepared = {
		ids,
		schema: mergeEffectiveSchema(entry.node, ids, {
			mode: "runtime",
			isAtomic
		})
	};
	selection.prepared.set(bucket, prepared);
	return prepared;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/selectEntryStep.ts
const NO_ACTIVE_IDS$3 = Object.freeze([]);
const NO_DECLARATIONS = [];
const selectEntryStep = (entry, step, frame) => {
	const { node, context, prior, computeChild, immediate, next, seen, inactiveEntries, flushReads } = frame;
	if (flushReads && context.pendingOutputs?.size) flushPendingGateReads(entry.node, appendSegment(node.path, entry.name), context);
	let threw = false;
	let declarations;
	let activeIds;
	let fullyAdmitted = false;
	let discriminator;
	if (step?.discriminatorSelection) {
		const round = context.gateSelectionRounds?.get(node);
		const tagGroup = round?.active ? round.table.groups.find((group) => group.watchedName === entry.name) : void 0;
		if (tagGroup) discriminator = readDiscriminatorEntrySelection(entry, step.discriminatorSelection, readGateSelectionGroup(node, context, tagGroup), node.runtime.blueprint.isAtomic);
	}
	if (discriminator) {
		declarations = entry.declarations;
		activeIds = discriminator.ids;
	} else if (step && !step.general) {
		const version = context.gateThrowVersion;
		const admitted = frame.tableVerdict ?? (!step.gate || evaluateGate(step.gate, context, node));
		declarations = admitted ? entry.declarations : NO_DECLARATIONS;
		activeIds = admitted ? step.ids : NO_ACTIVE_IDS$3;
		threw = !admitted && (frame.tableThrew === true || context.gateThrowVersion !== version);
	} else if (context.hasGates) {
		let active;
		let ids;
		for (let index = 0; index < entry.declarations.length; index++) {
			const declaration = entry.declarations[index];
			const version = context.gateThrowVersion;
			let admitted = true;
			for (let gateIndex = 0; gateIndex < declaration.gates.length; gateIndex++) {
				const gate = declaration.gates[gateIndex];
				if (!((step?.general ? context.gateWheelFrame?.predicateResults?.get(getGateRegistry(node.runtime).locate(node, gate)) : void 0) ?? evaluateGate(gate, context, node, gate.schemaPath === appendSegment(appendSegment(declaration.schemaPath, "controls"), "active") ? entry.name : void 0))) {
					admitted = false;
					break;
				}
			}
			if (admitted) {
				active?.push(declaration);
				ids?.push(declaration.id);
			} else {
				active ?? (active = entry.declarations.slice(0, index));
				ids ?? (ids = active.map((kept) => kept.id));
				if (context.gateThrowVersion !== version) threw = true;
			}
		}
		fullyAdmitted = active === void 0;
		declarations = active ?? entry.declarations;
		activeIds = ids ?? staticIds(entry, node.blueprintNode);
	} else declarations = entry.declarations;
	if (declarations.length === 0) {
		const priorChild = hasOwnProperty(prior, entry.name) ? prior[entry.name] : void 0;
		const exiting = priorChild?.blueprintNode === entry.node ? priorChild : !context.pendingExitPaths?.get(node.path)?.has(appendSegment(node.path, entry.name)) ? void 0 : context.pendingExits.get(JSON.stringify([appendSegment(node.path, entry.name), getBlueprintNodeIdentity(entry.node)]));
		if (exiting) if (threw) (context.throwingGateExits ?? (context.throwingGateExits = /* @__PURE__ */ new Set())).add(exiting);
		else context.throwingGateExits?.delete(exiting);
		if (context.distributedInputs.has(node) || next[entry.name]) inactiveEntries.push(entry);
		if (next[entry.name] && !seen.has(entry.name) && next[entry.name].blueprintNode === entry.node) {
			delete next[entry.name];
			frame.changed = true;
			if (immediate) (context.pendingOutputs ?? (context.pendingOutputs = /* @__PURE__ */ new Set())).add(node);
		}
		return;
	}
	const retained = hasOwnProperty(prior, entry.name) ? prior[entry.name] : void 0;
	if (retained?.blueprintNode === entry.node) context.throwingGateExits?.delete(retained);
	if (seen.has(entry.name)) {
		if (seen.get(entry.name) !== entry.node) {
			const path = appendSegment(node.path, entry.name);
			recordSettlementFailure(context, new SchemaFormError(FormErrorCode.SharedNodeConflict, `Active declarations conflict at ${path}`, { path }), "sharedConflict");
		}
		return;
	}
	seen.set(entry.name, entry.node);
	const priorChild = hasOwnProperty(prior, entry.name) && prior[entry.name].blueprintNode === entry.node ? prior[entry.name] : void 0;
	if (!priorChild && context.hasGates) (context.presenceHosts ?? (context.presenceHosts = /* @__PURE__ */ new Set())).add(node);
	const currentChild = next[entry.name]?.blueprintNode === entry.node ? next[entry.name] : void 0;
	const distribution = getChildDistribution(node, entry.name, context);
	const ownsInput = distribution && hasDistributedChildInput(distribution.input, entry.name, node.behavior.type === "array");
	const slotState = !priorChild && !currentChild ? getSlotSource(node, entry) : void 0;
	const slotSource = slotState?.source;
	const slotOverlay = slotState?.overlay;
	const input = ownsInput ? Reflect.get(distribution.input, entry.name) : void 0;
	if (!priorChild && !currentChild && !slotSource && !slotOverlay && hasRecursiveExpansion(node, entry.node, input, context)) {
		if (!context.exceededBudget) {
			const path = appendSegment(node.path, entry.name);
			recordSettlementFailure(context, new SchemaFormError(FormErrorCode.RecursiveShapeDiverged, `Recursive shape diverged at ${path}`, { path }), "budget");
			context.exceededBudget = "recursion";
		}
		return;
	}
	const key = context.pendingExits.size > 0 ? JSON.stringify([appendSegment(node.path, entry.name), getBlueprintNodeIdentity(entry.node)]) : void 0;
	const pending = key === void 0 ? void 0 : context.pendingExits.get(key);
	const child = currentChild ?? priorChild ?? pending ?? (slotSource ? cloneFromSlot(node, entry, slotSource, context) : slotOverlay ? createFromSlotOverlay(node, entry, slotOverlay, context) : createChildNode(node, entry));
	context.perished.delete(child);
	if (key !== void 0 && context.pendingExits.delete(key)) updatePendingExitIndex(context, appendSegment(node.path, entry.name), -1);
	if (pending && child === pending) context.revived.add(child);
	if (context.hasGates) getGateRegistry(child.runtime).register(child);
	let entryChanged = false;
	if (!priorChild && !currentChild && !pending) {
		context.entered.add(child);
		if (child.behavior.type === "virtual") context.dirtyPaths.add(child.path);
		else if (slotSource || slotOverlay) enterSlotClone(node, child, entry.name, context);
		else enterFieldNode(node, child, entry.name, context);
		if (child.behavior.strategy === "branch") context.shapeDirtyPaths.add(child.path);
		frame.changed = true;
		entryChanged = true;
	}
	const ids = activeIds ?? staticIds(entry, node.blueprintNode);
	if (!priorChild && !currentChild || pending && child === pending) supplementSplitOwner(child, context);
	if (context.selectedDeclarationIds.get(child) !== ids) context.selectedDeclarationIds.set(child, ids);
	const isAtomic = node.runtime.blueprint?.isAtomic;
	const admittedEdge = fullyAdmitted ? readAdmittedEdgeSchema(entry, child.blueprintNode, isAtomic, node.blueprintNode) : void 0;
	const effective = discriminator?.schema ?? admittedEdge?.schema ?? mergeEffectiveSchema(child.blueprintNode, context.hasGates ? ids : NO_ACTIVE_IDS$3, {
		mode: "runtime",
		isAtomic
	});
	if (child.schema !== effective) {
		captureProjectionBaseline(node, child, !!(priorChild || currentChild), context);
		if (!context.originalSchemas.has(child.path)) context.originalSchemas.set(child.path, child.schema);
		child.schema = captureFieldNodeChange(child, "schema", effective);
		context.dirtyPaths.add(child.path);
		if (child.behavior.strategy === "branch") context.shapeDirtyPaths.add(child.path);
		context.changedNodes.add(child);
		frame.changed = true;
		entryChanged = true;
	}
	if (admittedEdge ? admittedEdge.conflict : effective.typeConflict) recordSettlementFailure(context, new SchemaFormError(FormErrorCode.SharedNodeConflict, `Active declarations conflict at ${child.path}`, { path: child.path }), "sharedConflict");
	child.active = captureFieldNodeChange(child, "active", true);
	child.detached = false;
	if (next[entry.name] !== child) {
		frame.changed = true;
		entryChanged = true;
	}
	next[entry.name] = child;
	if (child.behavior.type === "virtual") {
		context.dirtyPaths.add(child.path);
		context.shapeDirtyPaths.add(child.path);
	}
	if (context.dirtyPaths.has(child.path)) {
		computeChild(child);
		entryChanged = true;
	}
	if (immediate && entryChanged) (context.pendingOutputs ?? (context.pendingOutputs = /* @__PURE__ */ new Set())).add(node);
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/getTableVisitSteps.ts
const getTableVisitSteps = (frame, table) => {
	const { node, context, prior, next } = frame;
	const required = [];
	const prepared = frame.preparedStatic;
	for (const name of frame.priorDynamicNames ?? Object.keys(prior)) {
		const index = table.stepIndexByName.get(name);
		if (index !== void 0 && prior[name].blueprintNode === table.plan.steps[index].entry.node) required.push(index);
	}
	for (const name of prepared ? prepared.dynamicNames : Object.keys(next)) {
		if (!next[name]) continue;
		const index = table.stepIndexByName.get(name);
		if (index !== void 0) required.push(index);
	}
	for (const path of context.pendingExitPaths?.get(node.path)?.keys() ?? []) {
		const name = readPointerSegment(path, -1);
		if (typeof name !== "string") throw new TypeError("Expected a named node path");
		const index = table.stepIndexByName.get(name);
		if (index !== void 0 && context.pendingExits.has(JSON.stringify([path, getBlueprintNodeIdentity(table.plan.steps[index].entry.node)]))) required.push(index);
	}
	const input = context.distributedInputs.get(node)?.input;
	if (isPlain(input)) for (const name of Object.getOwnPropertyNames(input)) {
		const index = table.stepIndexByName.get(name);
		if (index !== void 0) required.push(index);
	}
	required.sort((a, b) => a - b);
	return mergeGateSteps(prepared?.alwaysSteps ?? table.alwaysSteps, required);
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/selectLiteralTableChildren.ts
const selectLiteralTableChildren = (frame, round) => {
	const { table } = round;
	const reuse = frame.reuseStatic;
	let selected = getTableVisitSteps(frame, table);
	const active = /* @__PURE__ */ new Set();
	const verify = engineModes.gateSelection === "verify";
	const shadow = engineModes.gateWheel === "shadow";
	let groupIndex = 0;
	let cursor = 0;
	let fullIndex = 0;
	while (verify || shadow ? fullIndex < table.plan.steps.length : cursor < selected.length || groupIndex < table.groups.length) {
		const index = verify || shadow ? fullIndex++ : Math.min(selected[cursor] ?? Infinity, table.groups[groupIndex]?.firstStepIndex ?? Infinity);
		const step = table.plan.steps[index];
		const tableStep = table.tableSteps.has(index);
		if (verify && engineModes.gateWheel === "skip" && tableStep && frame.flushReads && frame.context.pendingOutputs?.size) verifyTablePrePublication(frame.node, frame.context, step.entry);
		while (groupIndex < table.groups.length && table.groups[groupIndex].firstStepIndex <= index) {
			const group = table.groups[groupIndex++];
			const value = readGateSelectionGroup(frame.node, frame.context, group);
			const bucket = readGateBucket(group.buckets, value);
			for (const entry of bucket) active.add(entry);
			selected = mergeGateSteps(selected, bucket);
		}
		const listed = selected[cursor] === index;
		if (listed) cursor++;
		const admitted = active.has(index);
		if (tableStep && (verify || shadow)) verifyTableGate(frame.node, frame.context, step.gate, admitted);
		if (frame.preparedStatic?.entries.has(step.entry.name)) continue;
		if (!listed && !shadow) {
			if (verify) verifyUnvisitedGateStep(frame, step);
			continue;
		}
		frame.tableVerdict = tableStep ? admitted : void 0;
		if (reuse?.(step.entry)) continue;
		selectEntryStep(step.entry, step, frame);
	}
	frame.tableVerdict = void 0;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/selectPredicateTableChildren.ts
const selectPredicateTableChildren = (frame, round) => {
	const { table } = round;
	const reuse = frame.reuseStatic;
	let selected = getTableVisitSteps(frame, table);
	const active = /* @__PURE__ */ new Set();
	let throwing;
	let firstThrow;
	let predicateSteps;
	let predicateCursor = 0;
	const verify = engineModes.gateSelection === "verify";
	const shadow = engineModes.gateWheel === "shadow";
	let groupIndex = 0;
	let predicateIndex = 0;
	let cursor = 0;
	let fullIndex = 0;
	while (verify || shadow ? fullIndex < table.plan.steps.length : cursor < selected.length || groupIndex < table.groups.length || predicateIndex < table.predicateGroups.length || predicateCursor < (predicateSteps?.length ?? 0)) {
		const index = verify || shadow ? fullIndex++ : Math.min(selected[cursor] ?? Infinity, table.groups[groupIndex]?.firstStepIndex ?? Infinity, table.predicateGroups[predicateIndex]?.steps[0] ?? Infinity, predicateSteps?.[predicateCursor] ?? Infinity);
		const step = table.plan.steps[index];
		const tableStep = table.tableSteps.has(index);
		if (verify && engineModes.gateWheel === "skip" && tableStep && frame.flushReads && frame.context.pendingOutputs?.size) verifyTablePrePublication(frame.node, frame.context, step.entry);
		while (groupIndex < table.groups.length && table.groups[groupIndex].firstStepIndex <= index) {
			const group = table.groups[groupIndex++];
			const value = readGateSelectionGroup(frame.node, frame.context, group);
			const bucket = readGateBucket(group.buckets, value);
			for (const entry of bucket) active.add(entry);
			selected = mergeGateSteps(selected, bucket);
		}
		while (predicateIndex < table.predicateGroups.length && table.predicateGroups[predicateIndex].steps[0] <= index) {
			const group = table.predicateGroups[predicateIndex++];
			const version = frame.context.gateThrowVersion;
			const occurrence = getGateRegistry(frame.node.runtime).locate(frame.node, group.gate);
			if (frame.context.gateWheelFrame?.predicateResults?.get(occurrence) ?? evaluateGate(group.gate, frame.context, frame.node)) {
				predicateSteps = group.steps;
				predicateCursor = 0;
			} else if (frame.context.gateThrowVersion !== version) {
				selected = mergeGateSteps(selected, group.steps);
				(firstThrow ?? (firstThrow = /* @__PURE__ */ new Set())).add(index);
				for (const entry of group.steps) (throwing ?? (throwing = /* @__PURE__ */ new Set())).add(entry);
			}
		}
		const selectedStep = selected[cursor] === index;
		const predicateStep = predicateSteps?.[predicateCursor] === index;
		const listed = selectedStep || predicateStep;
		if (selectedStep) cursor++;
		if (predicateStep) predicateCursor++;
		const admitted = active.has(index) || predicateStep;
		const failedPredicate = throwing?.has(index) === true;
		if (tableStep && !failedPredicate && (verify || shadow)) verifyTableGate(frame.node, frame.context, step.gate, admitted);
		if (frame.preparedStatic?.entries.has(step.entry.name)) continue;
		if (!listed && !shadow) {
			if (verify) verifyUnvisitedGateStep(frame, step);
			continue;
		}
		frame.tableVerdict = tableStep && (!failedPredicate || firstThrow?.has(index)) ? admitted : void 0;
		frame.tableThrew = firstThrow?.has(index);
		if (reuse?.(step.entry)) continue;
		selectEntryStep(step.entry, step, frame);
	}
	frame.tableVerdict = void 0;
	frame.tableThrew = void 0;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/selectTableChildren.ts
const selectTableChildren = (frame, round) => {
	if (round.table.predicateGroups.length) selectPredicateTableChildren(frame, round);
	else selectLiteralTableChildren(frame, round);
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/reuseArrayChildren.ts
const reuseArrayChildren = (node, context, prior, computeChild) => {
	const append = context.arrayAppend;
	if (append?.host === node && append.valid) {
		if (!append.entry) return;
		const child = prior[String(append.count)];
		const ids = staticIds(append.entry, node.blueprintNode);
		if (context.selectedDeclarationIds.get(child) !== ids) context.selectedDeclarationIds.set(child, ids);
		if (context.dirtyPaths.has(child.path)) computeChild(child);
		return;
	}
	const pop = context.arrayPop;
	if (pop?.host === node && pop.valid) return;
	const splice = context.arraySplice;
	const start = splice?.host === node && splice.valid ? splice.index : 0;
	for (let index = start; index < node.itemCount; index++) {
		const entry = getItemEntry(node.blueprintNode, index);
		if (!entry) continue;
		const child = prior[entry.name];
		const ids = staticIds(entry, node.blueprintNode);
		if (context.selectedDeclarationIds.get(child) !== ids) context.selectedDeclarationIds.set(child, ids);
		if (context.dirtyPaths.has(child.path)) computeChild(child);
	}
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/staticShape.ts
const NO_ACTIVE_IDS$2 = Object.freeze([]);
const staticShape = (host, isAtomic, candidates = host.childEntries) => {
	var _getHostDerived;
	const memo = (_getHostDerived = getHostDerived(host)).staticShape ?? (_getHostDerived.staticShape = {});
	if (memo.entries !== void 0) return memo.entries;
	const selected = Object.create(null);
	const entries = candidates;
	for (let index = 0; index < entries.length; index++) {
		const entry = entries[index];
		const schema = mergeEffectiveSchema(entry.node, NO_ACTIVE_IDS$2, {
			mode: "runtime",
			isAtomic
		});
		let hasGate = false;
		for (let declarationIndex = 0; declarationIndex < entry.declarations.length; declarationIndex++) if (entry.declarations[declarationIndex].gates.length > 0) {
			hasGate = true;
			break;
		}
		if (hasOwnProperty(selected, entry.name) || entry.node.kind === "virtual" || !entry.declarations.length || schema.typeConflict || hasGate) continue;
		selected[entry.name] = {
			entry,
			ids: staticIds(entry, host),
			schema
		};
	}
	const shape = Object.values(selected);
	memo.entries = shape;
	return shape;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/utils/createStaticEntryReuser.ts
const createStaticEntryReuser = (node, prior, context, next, computeChild, immediate = false, hasRelocated = true) => {
	if (node.behavior.type !== "object" || context.kind === "load" || context.distributedInputs.has(node) || context.pathChanges.length > 0 || hasRelocated) return void 0;
	const partition = HostStaticPartition.get(node.blueprintNode);
	if (!partition.staticEntries.length) return void 0;
	const shape = staticShape(node.blueprintNode, node.runtime.blueprint.isAtomic, partition.staticEntries);
	if (!shape) return void 0;
	const memo = getHostDerived(node.blueprintNode).staticShape;
	let entries = memo.byEntry;
	if (!entries) {
		entries = new Map(shape.map((selected) => [selected.entry, selected]));
		memo.byEntry = entries;
	}
	const registered = context.presenceRegistrations;
	const ownNames = Object.getPrototypeOf(prior) === null;
	return (entry) => {
		if (context.presenceRegistrations !== registered || context.pathChanges.length > 0 || context.distributedInputs.has(node)) return false;
		const selected = entries.get(entry);
		const child = ownNames || hasOwnProperty(prior, entry.name) ? prior[entry.name] : void 0;
		if (!selected || !child || child.parent !== node || child.name !== entry.name || child.path !== appendSegment(node.path, entry.name) || child.blueprintNode !== entry.node || child.schema !== selected.schema || !child.active || child.detached || node.structure?.[entry.name] !== child || next[entry.name] !== void 0 && next[entry.name] !== child) return false;
		next[entry.name] = child;
		if (context.selectedDeclarationIds.get(child) !== selected.ids) context.selectedDeclarationIds.set(child, selected.ids);
		if (computeChild && context.dirtyPaths.has(child.path)) {
			computeChild(child);
			if (immediate) (context.pendingOutputs ?? (context.pendingOutputs = /* @__PURE__ */ new Set())).add(node);
		}
		return true;
	};
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/utils/prepareStaticHost.ts
const prepareStaticHost = (node, prior, context, hasRelocated) => {
	const record = getHostDerived(node);
	if (node.behavior.type !== "object" || context.kind === "load" || context.distributedInputs.has(node) || context.pathChanges.length > 0 || hasRelocated || context.failures?.length) {
		delete record.preparedStaticHost;
		return;
	}
	let prepared = record.preparedStaticHost;
	if (prepared && (prepared.blueprint !== node.runtime.blueprint || prepared.template !== node.blueprintNode || prepared.path !== node.path)) {
		delete record.preparedStaticHost;
		prepared = void 0;
	}
	const verify = engineModes.gateSelection === "verify";
	if (prepared && !verify) {
		(context.preparedStaticHosts ?? (context.preparedStaticHosts = /* @__PURE__ */ new Set())).add(node);
		return prepared;
	}
	const partition = HostStaticPartition.get(node.blueprintNode);
	if (!partition.gated || partition.hasGatedOverlays || !partition.staticEntries.length) return void 0;
	const plan = getHostDerived(node.blueprintNode).directChildSelectionPlan;
	if (!plan) return void 0;
	const shape = staticShape(node.blueprintNode, node.runtime.blueprint.isAtomic, partition.staticEntries);
	if (!shape || shape.length !== partition.staticEntries.length) return void 0;
	const baseline = Object.create(null);
	const entries = /* @__PURE__ */ new Map();
	for (const selected of shape) {
		const { entry, schema } = selected;
		const child = prior[entry.name];
		if (!child || child.parent !== node || child.name !== entry.name || child.path !== appendSegment(node.path, entry.name) || child.blueprintNode !== entry.node || child.schema !== schema || !child.active || child.detached || prepared && prepared.baseline[entry.name] !== child) {
			if (prepared && verify) throw new Error("Static host witness mismatch");
			return;
		}
		baseline[entry.name] = child;
		entries.set(entry.name, selected);
	}
	if (prepared) {
		(context.preparedStaticHosts ?? (context.preparedStaticHosts = /* @__PURE__ */ new Set())).add(node);
		return prepared;
	}
	prepared = {
		blueprint: node.runtime.blueprint,
		template: node.blueprintNode,
		path: node.path,
		baseline,
		entries,
		dynamicNames: Object.keys(prior).filter((name) => !entries.has(name)),
		alwaysSteps: (getHostDerived(node.blueprintNode).gateSelectionTable?.alwaysSteps ?? []).filter((index) => !entries.has(plan.steps[index].entry.name))
	};
	record.preparedStaticHost = prepared;
	(context.preparedStaticHosts ?? (context.preparedStaticHosts = /* @__PURE__ */ new Set())).add(node);
	return prepared;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/selectChildren.ts
const selectChildren = (node, context, prior, computeChild, immediate, hasRelocated = true, preserveStructure = true, publication) => {
	if (node.behavior.type === "array" && canReuseArrayChildren(node, context, prior)) {
		reuseArrayChildren(node, context, prior, computeChild);
		return false;
	}
	if (node.behavior.type === "object" && (!context.hasGates || !HostStaticPartition.get(node.blueprintNode).gated)) {
		const shape = staticShape(node.blueprintNode, node.runtime.blueprint?.isAtomic);
		const children = node.children;
		let matches = !!shape && !!children && children.length === shape.length;
		if (matches && shape && children) for (let index = 0; index < shape.length; index++) {
			const { entry, schema } = shape[index];
			const child = children[index];
			if (child.name !== entry.name || child.blueprintNode !== entry.node || child.schema !== schema || !child.active || child.detached || node.structure?.[entry.name] !== child) {
				matches = false;
				break;
			}
		}
		if (matches && shape && children) if (context.hasGates) {
			const reuse = createStaticEntryReuser(node, prior, context, node.structure, computeChild, false, hasRelocated);
			let reused = true;
			for (const { entry } of shape) if (!reuse?.(entry)) {
				reused = false;
				break;
			}
			if (reused) return false;
		} else {
			for (let index = 0; index < shape.length; index++) {
				const child = children[index];
				if (context.selectedDeclarationIds.get(child) !== shape[index].ids) context.selectedDeclarationIds.set(child, shape[index].ids);
				if (context.dirtyPaths.has(child.path)) computeChild(child);
			}
			return false;
		}
	}
	if (node.behavior.type === "virtual") {
		const before = node.children ?? [];
		const next = Object.create(null);
		const children = [];
		const fields = node.blueprintNode.fields;
		for (let index = 0; fields && index < fields.length; index++) {
			const field = fields[index];
			const sibling = node.parent?.structure?.[field];
			if (!sibling) continue;
			next[field] = sibling;
			children.push(sibling);
		}
		let changed = children.length !== before.length;
		for (let index = 0; !changed && index < children.length; index++) if (children[index] !== before[index]) changed = true;
		node.structure = next;
		node.children = captureFieldNodeChange(node, "children", changed ? children : before);
		if (changed) {
			context.changedNodes.add(node);
			if (context.hasGates) (context.presenceHosts ?? (context.presenceHosts = /* @__PURE__ */ new Set())).add(node);
		}
		return changed;
	}
	const before = node.children ?? [];
	const current = node.structure;
	const prepared = prepareStaticHost(node, prior, context, hasRelocated);
	let reuse = prepared ? (entry) => prepared.entries.has(entry.name) : !preserveStructure && current && current !== prior ? createStaticEntryReuser(node, prior, context, current, computeChild, immediate, hasRelocated) : void 0;
	const next = reuse && current ? current : { ...current };
	if (next !== current) Object.setPrototypeOf(next, null);
	if (node.behavior.type === "array") {
		const names = Object.keys(next);
		for (let index = 0; index < names.length; index++) {
			const name = names[index];
			if (Number(name) >= node.itemCount) delete next[name];
		}
	}
	node.structure = next;
	reuse ?? (reuse = createStaticEntryReuser(node, prior, context, next, computeChild, immediate, hasRelocated));
	const seen = /* @__PURE__ */ new Map();
	const inactiveEntries = [];
	let changed = false;
	const cached = context.hasGates && node.behavior.type === "object" ? getHostDerived(node.blueprintNode).directChildSelectionPlan : null;
	const direct = cached === void 0 ? context.kind === "load" ? null : getDirectChildSelectionPlan(node.blueprintNode, node.runtime.blueprint, true) : cached;
	const entries = direct ? node.blueprintNode.childEntries : node.behavior.declareChildren(node);
	const count = direct ? direct.steps.length : entries.length;
	const flushReads = immediate && (!direct || context.kind === "load");
	const frame = {
		preparedStatic: prepared,
		priorDynamicNames: prepared ? context.preparedStaticPriorNames?.get(node) : void 0,
		node,
		context,
		prior,
		computeChild,
		immediate,
		next,
		seen,
		inactiveEntries,
		changed,
		flushReads,
		reuseStatic: reuse
	};
	const round = direct && context.gateSelectionRounds?.get(node);
	if (round?.active) selectTableChildren(frame, round);
	else for (let entryIndex = 0; entryIndex < count; entryIndex++) {
		const step = direct?.steps[entryIndex];
		const entry = step ? step.entry : entries[entryIndex];
		if (reuse?.(entry)) continue;
		selectEntryStep(entry, step, frame);
	}
	changed = frame.changed;
	const flushed = flushPendingOutput(node, context);
	if (publication) publication.flushed = flushed;
	for (let index = 0; index < inactiveEntries.length; index++) {
		const entry = inactiveEntries[index];
		if (next[entry.name] || seen.has(entry.name) || context.kind !== "load" && hasOwnProperty(prior, entry.name)) continue;
		seen.set(entry.name, entry.node);
		const distribution = getChildDistribution(node, entry.name, context);
		if (!distribution || !hasDistributedChildInput(distribution.input, entry.name, node.behavior.type === "array")) continue;
		const path = appendSegment(node.path, entry.name);
		if (distribution.preserveLatent) {
			distributeMovedSource(context, path, entry.node, Reflect.get(distribution.input, entry.name), getSlotOrder(node, entry.name, entry.node));
			continue;
		}
		writeInactiveSource(context, path, entry.node, Reflect.get(distribution.input, entry.name), getSlotOrder(node, entry.name, entry.node), distribution.whole, node.behavior.type === "array" ? getItemEntries(node.blueprintNode, Number(entry.name)) : node.blueprintNode.childEntries, distribution.automatic);
	}
	const priorNames = frame.priorDynamicNames ?? Object.keys(prior);
	for (let index = 0; index < priorNames.length; index++) {
		const name = priorNames[index];
		const child = prior[name];
		if (next[name] !== child) {
			if (context.hasGates) (context.presenceHosts ?? (context.presenceHosts = /* @__PURE__ */ new Set())).add(node);
			if (node.behavior.type === "array" && Number(name) >= node.itemCount) context.perished.add(child);
			else {
				const key = JSON.stringify([child.path, getBlueprintNodeIdentity(child.blueprintNode)]);
				const added = !context.pendingExits.has(key);
				context.pendingExits.set(key, child);
				if (added) updatePendingExitIndex(context, child.path, 1);
			}
		}
	}
	const nextChildren = flushed ? node.children ?? [] : Object.values(next);
	if (prepared) prepared.dynamicNames = [...seen.keys()].filter((name) => !prepared.entries.has(name));
	const published = node.children;
	const sameAsBefore = isSameChildList(before, nextChildren);
	if (!sameAsBefore) changed = true;
	node.children = captureFieldNodeChange(node, "children", published === before ? sameAsBefore ? before : nextChildren : isSameChildList(published, nextChildren) ? published : nextChildren);
	if (changed) context.changedNodes.add(node);
	return changed;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/utils/discardStaticHostPreparation.ts
const discardStaticHostPreparation = (context) => {
	for (const host of context.preparedStaticHosts ?? []) delete getHostDerived(host).preparedStaticHost;
};

//#endregion
//#region src/core/engine/settle/utils/compute/preserveReferences.ts
const preserveReferences = (node, previous, context) => {
	if (sameValue(previous.local, node.local)) node.local = captureFieldNodeChange(node, "local", previous.local);
	if (sameValue(previous.emit, node.emit)) node.emit = captureFieldNodeChange(node, "emit", previous.emit);
	if (previous.children !== node.children && previous.children && node.children && previous.children.length === node.children.length && previous.children.every((child, index) => child === node.children?.[index])) node.children = captureFieldNodeChange(node, "children", previous.children);
	if (node.local === previous.local && node.emit === previous.emit && node.children === previous.children && node.schema === (context.originalSchemas.get(node.path) ?? previous.schema) && node.active === previous.active && !context.changedRaw.has(node.path) && !context.entered.has(node)) context.changedNodes.delete(node);
};

//#endregion
//#region src/core/engine/settle/utils/compute/primeHost.ts
const NO_ACTIVE_DECLARATION_IDS$1 = Object.freeze([]);
const primeHost = (node, prior, context, hasRelocated = true) => {
	const prepared = prepareStaticHost(node, prior, context, hasRelocated);
	if (prepared) {
		(context.preparedStaticPriorNames ?? (context.preparedStaticPriorNames = /* @__PURE__ */ new Map())).set(node, prepared.dynamicNames);
		node.structure = Object.assign(Object.create(null), prepared.baseline);
		const children = Object.values(node.structure);
		node.children = captureFieldNodeChange(node, "children", isSameChildList(node.children, children) ? node.children : children);
		return;
	}
	const baseline = {};
	Object.setPrototypeOf(baseline, null);
	const cached = node.behavior.type === "object" ? getHostDerived(node.blueprintNode).directChildSelectionPlan : null;
	const direct = cached === void 0 ? context.kind === "load" ? null : getDirectChildSelectionPlan(node.blueprintNode, node.runtime.blueprint, false) : cached;
	const entries = direct?.baseline ?? node.behavior.declareChildren(node);
	const reuse = createStaticEntryReuser(node, prior, context, baseline, void 0, false, hasRelocated);
	for (let index = 0; index < entries.length; index++) {
		const entry = entries[index];
		if (baseline[entry.name] || !direct && !entry.declarations.some((declaration) => declaration.gates.length === 0)) continue;
		if (reuse?.(entry)) continue;
		const priorChild = hasOwnProperty(prior, entry.name) ? prior[entry.name] : void 0;
		const key = context.pendingExits.size === 0 ? void 0 : JSON.stringify([appendSegment(node.path, entry.name), getBlueprintNodeIdentity(entry.node)]);
		const pending = key === void 0 ? void 0 : context.pendingExits.get(key);
		const retained = !priorChild && !pending ? getSlotSource(node, entry) : void 0;
		const slotSource = retained?.source;
		const slotOverlay = retained?.overlay;
		const child = priorChild ?? pending ?? (slotSource ? cloneFromSlot(node, entry, slotSource, context) : slotOverlay ? createFromSlotOverlay(node, entry, slotOverlay, context) : createChildNode(node, entry));
		context.perished.delete(child);
		if (key !== void 0 && context.pendingExits.delete(key)) updatePendingExitIndex(context, appendSegment(node.path, entry.name), -1);
		if (pending && child === pending) context.revived.add(child);
		if (context.hasGates) getGateRegistry(child.runtime).register(child);
		if (!priorChild && !pending) {
			context.entered.add(child);
			if (child.behavior.type === "virtual") context.dirtyPaths.add(child.path);
			else if (slotSource || slotOverlay) enterSlotClone(node, child, entry.name, context);
			else enterFieldNode(node, child, entry.name, context);
			if (child.behavior.strategy === "branch") context.shapeDirtyPaths.add(child.path);
		}
		const schema = mergeEffectiveSchema(child.blueprintNode, NO_ACTIVE_DECLARATION_IDS$1, {
			mode: "runtime",
			isAtomic: node.runtime.blueprint?.isAtomic
		});
		if (child.schema !== schema) {
			captureProjectionBaseline(node, child, !!priorChild, context);
			if (!context.originalSchemas.has(child.path)) context.originalSchemas.set(child.path, child.schema);
			child.schema = captureFieldNodeChange(child, "schema", schema);
			context.dirtyPaths.add(child.path);
			context.changedNodes.add(child);
		}
		child.active = captureFieldNodeChange(child, "active", true);
		child.detached = false;
		baseline[entry.name] = child;
	}
	node.structure = baseline;
	const children = Object.values(baseline);
	const published = node.children;
	node.children = captureFieldNodeChange(node, "children", isSameChildList(published, children) ? published : children);
};

//#endregion
//#region src/core/engine/settle/utils/compute/relocatedGates.ts
const relocatedGates = (node) => getGateRegistry(node.runtime).relocated(node.path);

//#endregion
//#region src/core/engine/settle/utils/compute/scheduleRelocatedGates.ts
const scheduleRelocatedGates = (gates, context) => {
	for (const gate of gates) {
		let path = gate.hostPath;
		while (path !== gate.evaluationHostPath) {
			context.dirtyPaths.add(path);
			path = resolvePointer(path, "..");
		}
		context.dirtyPaths.add(gate.evaluationHostPath);
	}
};

//#endregion
//#region src/core/engine/settle/utils/compute/scheduleChangedRelocatedGates.ts
const scheduleChangedRelocatedGates = (gates, context) => {
	if (!context.relocatedReads?.size) return false;
	const changed = [];
	for (const gate of gates) {
		const recorded = context.relocatedReads.get(gate);
		if (!recorded) continue;
		for (let index = 0; index < recorded.paths.length; index++) {
			const path = recorded.paths[index];
			const value = readPointerSegment(path, 0) === PointerOperator.Context ? context.root.runtime.context : readProjectedValue(context, path);
			if (!Object.is(value, recorded.values[index])) {
				changed.push(gate);
				break;
			}
		}
	}
	if (changed.length === 0) return false;
	scheduleRelocatedGates(changed, context);
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/gateSelection/selectRootGateDeclarations.ts
const selectRootGateDeclarations = (node, context) => {
	const round = context.gateSelectionRounds?.get(node);
	const root = round?.active ? round.table.root : void 0;
	if (!round || !root) return void 0;
	let selected = root.ungatedIndices;
	for (const group of root.groups) selected = mergeGateSteps(selected, readGateBucket(group.buckets, readGateSelectionGroup(node, context, group)));
	if (engineModes.gateSelection === "verify" || engineModes.gateWheel === "shadow") {
		const admitted = new Set(selected);
		for (let index = 0; index < node.blueprintNode.declarations.length; index++) {
			const gate = node.blueprintNode.declarations[index].gates[0];
			if (gate) verifyTableGate(node, context, gate, admitted.has(index));
		}
	}
	return selected.map((index) => node.blueprintNode.declarations[index]);
};

//#endregion
//#region src/core/engine/settle/utils/compute/utils/readOneOfBranch.ts
const BRANCH_POSITION = /^\d+$/;
const readOneOfBranch = (schemaPath, segments) => {
	for (let index = segments.length - 2; index >= 0; index--) {
		const position = segments[index + 1];
		if (segments[index] === "oneOf" && typeof position === "string" && BRANCH_POSITION.test(position)) return {
			oneOfPath: joinPointerWithPrefixOf(schemaPath, segments.slice(0, index + 1)),
			position
		};
	}
};

//#endregion
//#region src/core/engine/settle/utils/compute/selectNodeSchema.ts
const selectNodeSchema = (node, context) => {
	const active = selectRootGateDeclarations(node, context) ?? node.blueprintNode.declarations.filter((declaration) => declaration.gates.every((gate) => evaluateGate(gate, context, node)));
	if (node.runtime.errorReporter?.hasConsumer()) {
		const branches = /* @__PURE__ */ new Map();
		for (const declaration of active) {
			const crossed = readOneOfBranch(declaration.schemaPath, getGateRegistry(node.runtime).pathSegments(declaration.schemaPath));
			if (!crossed || !declaration.gates.some((gate) => isDescendantPath(gate.schemaPath, appendSegment(crossed.oneOfPath, crossed.position)))) continue;
			const branch = Number(crossed.position);
			const selected = branches.get(crossed.oneOfPath) ?? [];
			if (!selected.includes(branch)) selected.push(branch);
			branches.set(crossed.oneOfPath, selected);
		}
		for (const [schemaPath, selected] of branches) {
			var _node$runtime;
			if (selected.length < 2) continue;
			const code = FormWarningCode.MultipleGatedBranchesActive;
			const key = JSON.stringify([
				code,
				node.path,
				schemaPath
			]);
			if (node.runtime.warningKeys?.has(key)) continue;
			((_node$runtime = node.runtime).warningKeys ?? (_node$runtime.warningKeys = /* @__PURE__ */ new Set())).add(key);
			const record = {
				level: "warning",
				code,
				path: node.path,
				schemaPath,
				message: "Multiple gated oneOf branches are active at " + schemaPath,
				details: { branches: selected }
			};
			indexFieldNodeWarning(node.runtime, key, node.path, record);
			node.runtime.chainOccurrences?.push({
				kind: "record",
				record
			});
		}
	}
	context.selectedDeclarationIds.set(node, active.map((declaration) => declaration.id));
	const effective = mergeEffectiveSchema(node.blueprintNode, active.map((declaration) => declaration.id), {
		mode: "runtime",
		isAtomic: node.runtime.blueprint?.isAtomic
	});
	if (effective.typeConflict) recordSettlementFailure(context, new SchemaFormError(FormErrorCode.SharedNodeConflict, `Active declarations conflict at ${node.path}`, { path: node.path }), "sharedConflict");
	if (node.parent === null) node.active = captureFieldNodeChange(node, "active", active.some((declaration) => declaration.role === "declaration"));
	if (node.schema === effective) return false;
	node.schema = captureFieldNodeChange(node, "schema", effective);
	context.changedNodes.add(node);
	return true;
};

//#endregion
//#region src/core/engine/settle/utils/compute/utils/computeStableNode.ts
const computeStableNode = (node, context) => {
	const epoch = context.writeEpoch;
	const marked = epoch !== void 0 && node.writeEpoch === epoch;
	if (!marked && !context.dirtyPaths.has(node.path)) return;
	context.stateDirtyNodes.add(node);
	if (node.behavior.strategy === "branch") {
		const recalculated = marked ? node.children ?? [] : dirtyChildren(node, context);
		for (let index = 0; index < recalculated.length; index++) {
			const child = recalculated[index];
			if (!marked || child.writeEpoch === epoch) computeStableNode(child, context);
		}
		updateOutput(node, context, recalculated);
	} else {
		if (node.parent === null) selectNodeSchema(node, context);
		updateOutput(node, context);
	}
	if (marked) {
		node.writeEpoch = 0;
		if (node !== context.target || node.parent === null) return;
	}
	if (context.dirtyPaths instanceof DirtyPathSet) context.dirtyPaths.consume(node.path);
	else context.dirtyPaths.delete(node.path);
};

//#endregion
//#region src/core/engine/settle/utils/compute/utils/hasIndependentLeafDefaults.ts
const hasIndependentLeafDefaults = (blueprint) => {
	const cached = getBlueprintDerived(blueprint).independentLeafDefaults;
	if (cached !== void 0) return cached;
	let hasDefault = false;
	let independent = blueprint.expressions.length === 0;
	for (let index = 0; independent && index < blueprint.nodes.length; index++) {
		const node = blueprint.nodes[index];
		if (node.kind !== "object" && node.kind !== "string" && node.kind !== "number" && node.kind !== "boolean" && node.kind !== "null" || node.kind === "object" && node.strategy !== "branch") {
			independent = false;
			break;
		}
		for (let declarationIndex = 0; declarationIndex < node.declarations.length; declarationIndex++) {
			const declaration = node.declarations[declarationIndex];
			if (declaration.gates.length) {
				independent = false;
				break;
			}
			const schema = declaration.schema;
			if (!schema || typeof schema !== "object") continue;
			if (schema.controls !== void 0) {
				independent = false;
				break;
			}
			const value = schema.default;
			if (value === void 0) continue;
			if (node.kind === "object" || value !== null && typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") {
				independent = false;
				break;
			}
			hasDefault = true;
		}
	}
	independent = independent && hasDefault;
	getBlueprintDerived(blueprint).independentLeafDefaults = independent;
	return independent;
};

//#endregion
//#region src/core/engine/settle/utils/compute/utils/getStaticGateList.ts
const getStaticGateList = (node) => {
	const fixed = node.behavior.type === "object" && node.behavior.strategy === "branch";
	const cached = fixed ? getHostDerived(node.blueprintNode).staticGateList : void 0;
	if (cached) return cached;
	const gates = [];
	const seenGates = /* @__PURE__ */ new Set();
	const entries = node.behavior.declareChildren(node);
	for (let entryIndex = 0; entryIndex <= entries.length; entryIndex++) {
		const declarations = entryIndex < entries.length ? entries[entryIndex].declarations : node.blueprintNode.declarations;
		for (let index = 0; index < declarations.length; index++) {
			const declaredGates = declarations[index].gates;
			for (let gateIndex = 0; gateIndex < declaredGates.length; gateIndex++) {
				const gate = declaredGates[gateIndex];
				if (!seenGates.has(gate)) {
					seenGates.add(gate);
					gates.push(gate);
				}
			}
		}
	}
	const list = {
		gates,
		seenGates
	};
	if (fixed) getHostDerived(node.blueprintNode).staticGateList = list;
	return list;
};

//#endregion
//#region src/core/engine/settle/utils/compute/utils/prepareHostWheelPlan.ts
const prepareHostWheelPlan = (node, previous) => {
	const record = getHostDerived(node);
	const cached = previous ?? record.wheelPlan;
	const relocated = relocatedGates(node);
	if (cached && (previous !== void 0 || node.behavior.type === "object") && cached.blueprint === node.runtime.blueprint && cached.path === node.path && cached.itemCount === node.itemCount && cached.relocated === relocated) return cached;
	const list = getStaticGateList(node);
	let gates = previous?.gates ?? list.gates;
	if (relocated.length) {
		const collected = [...gates];
		const seen = new Set(gates);
		for (const occurrence of relocated) if (!seen.has(occurrence.gate)) {
			seen.add(occurrence.gate);
			collected.push(occurrence.gate);
		}
		gates = collected;
	}
	const partition = HostStaticPartition.get(node.blueprintNode);
	const plan = {
		blueprint: node.runtime.blueprint,
		path: node.path,
		itemCount: node.itemCount,
		relocated,
		gates,
		baselineEligible: gates.length > 0 && node.behavior.type === "object" && relocated.length === 0 && !partition.hasGatedOverlays && partition.staticEntries.length > 0 && gates.every((gate) => Boolean(getGateExpression(node.runtime.blueprint, gate.schemaPath)?.equality))
	};
	if (!previous) record.wheelPlan = plan;
	return plan;
};

//#endregion
//#region src/core/engine/settle/utils/compute/computeNode.ts
const computeNodeBody = (node, context) => {
	if (!context.hasGates && context.root.runtime.blueprint.capabilities.branchless && context.shapeDirtyPaths.size === 0 && context.entered.size === 0) {
		computeStableNode(node, context);
		return;
	}
	if (!context.dirtyPaths.has(node.path)) return;
	if (context.hasGates) {
		context.presenceClock = (context.presenceClock ?? 0) + 1;
		(context.presenceComputeStarts ?? (context.presenceComputeStarts = /* @__PURE__ */ new Map())).set(node, context.presenceClock);
	}
	if (engineModes.gateWheel === "record") {
		const metrics = context.presenceMetrics ?? (context.presenceMetrics = {
			computes: /* @__PURE__ */ new Map(),
			ancestorRechecks: 0,
			ancestorWheels: 0,
			calls: 0,
			ownerInsertions: 0,
			indexLookups: 0
		});
		metrics.computes.set(node.path, (metrics.computes.get(node.path) ?? 0) + 1);
	}
	if (node === context.root && context.kind === "load" && node.behavior.type === "object" && node.behavior.strategy === "branch" && !node.deliveryInitialized && !context.suppressAutomaticWrites && !context.hasGates && context.writtenInputs.get(node) === void 0 && hasIndependentLeafDefaults(node.runtime.blueprint)) context.initialOutputs = [];
	context.stateDirtyNodes.add(node);
	if (!context.hasGates && node.parent !== null && node.behavior.strategy === "terminal" && context.entered.has(node)) {
		if (context.initialOutputs) context.initialOutputs.push(node);
		else updateOutput(node, context);
		context.dirtyPaths.delete(node.path);
		return;
	}
	if (!context.hasGates && !context.shapeDirtyPaths.has(node.path)) {
		if (node.behavior.strategy === "branch") {
			const recalculated = dirtyChildren(node, context);
			for (let index = 0; index < recalculated.length; index++) computeNode(recalculated[index], context);
			updateOutput(node, context, recalculated);
		} else {
			if (node.parent === null) selectNodeSchema(node, context);
			updateOutput(node, context);
		}
		context.dirtyPaths.delete(node.path);
		return;
	}
	if (!context.originalSchemas.has(node.path)) context.originalSchemas.set(node.path, node.schema);
	if (node.behavior.strategy !== "branch") {
		if (node.parent === null) selectNodeSchema(node, context);
		updateOutput(node, context);
		context.dirtyPaths.delete(node.path);
		return;
	}
	const previousLocal = node.local;
	const previousEmit = node.emit;
	const previousChildren = node.children;
	const previousSchema = node.schema;
	const previousActive = node.active;
	if (!context.shapeDirtyPaths.has(node.path)) {
		const recalculated = dirtyChildren(node, context);
		let registrations = context.presenceRegistrations ?? 0;
		for (let index = 0; index < recalculated.length; index++) computeNode(recalculated[index], context);
		let wheel = context.shapeDirtyPaths.has(node.path);
		let computed;
		while (!wheel && (context.presenceRegistrations ?? 0) !== registrations) {
			if (context.presenceMetrics) context.presenceMetrics.ancestorRechecks++;
			registrations = context.presenceRegistrations ?? 0;
			computed ?? (computed = new Set(recalculated));
			const pending = [];
			const candidates = dirtyChildren(node, context);
			for (let index = 0; index < candidates.length; index++) {
				const child = candidates[index];
				if (!context.dirtyPaths.has(child.path)) continue;
				if (computed.has(child)) {
					wheel = true;
					break;
				}
				pending.push(child);
			}
			if (wheel) break;
			for (let index = 0; index < pending.length; index++) {
				computed.add(pending[index]);
				recalculated.push(pending[index]);
				computeNode(pending[index], context);
			}
			wheel = context.shapeDirtyPaths.has(node.path);
		}
		if (!wheel) {
			updateOutput(node, context, recalculated);
			context.dirtyPaths.delete(node.path);
			return;
		}
		if (context.presenceMetrics) context.presenceMetrics.ancestorWheels++;
	}
	const previous = {
		local: previousLocal,
		emit: previousEmit,
		children: previousChildren,
		schema: previousSchema,
		active: previousActive
	};
	const prior = node.structure ?? {};
	let wheelPlan = context.hasGates ? prepareHostWheelPlan(node) : void 0;
	let gates = wheelPlan?.gates ?? [];
	const relocated = wheelPlan?.relocated ?? [];
	if (gates.length > 0) primeHost(node, prior, context, relocated.length > 0);
	const initialDirty = dirtyChildren(node, context);
	for (let index = 0; index < initialDirty.length; index++) computeNode(initialDirty[index], context);
	const deferBaseline = wheelPlan?.baselineEligible === true && context.kind !== "load" && !context.distributedInputs.has(node) && context.pathChanges.length === 0;
	if (deferBaseline) (context.pendingOutputs ?? (context.pendingOutputs = /* @__PURE__ */ new Set())).add(node);
	else if (gates.length > 0 && updateOutput(node, context)) scheduleRelocatedGates(relocatedGates(node), context);
	let cap = wheelPlan ? context.distributedInputs.size > 0 || wheelPlan.cap === void 0 ? wheelPlan.cap = getHostWheelBudgetCap(node, node.runtime.blueprint, gates, node.runtime) : wheelPlan.cap : 1;
	let confirmation;
	let previousPredicate;
	let lastStructure = prior;
	let registered = false;
	let hasRelocated = relocated.length > 0;
	for (let round = 0; round < cap; round++) {
		const roundLocal = node.local;
		const roundEmit = node.emit;
		const frame = gates.length > 0 && context.kind !== "load" ? {
			inputs: /* @__PURE__ */ new Map(),
			consistent: true,
			gateCount: gates.length,
			throwVersion: context.gateThrowVersion,
			...engineModes.gateWheel === "shadow" ? { evaluations: [] } : {}
		} : void 0;
		context.gateWheelFrame = frame;
		prepareGateTableRound(node, context, round);
		const schemaChanged = node.parent === null && selectNodeSchema(node, context);
		if (context.hasGates) {
			context.presenceClock = (context.presenceClock ?? 0) + 1;
			(context.presenceRoundStarts ?? (context.presenceRoundStarts = /* @__PURE__ */ new Map())).set(node, context.presenceClock);
		}
		const publication = { flushed: false };
		const changed = selectChildren(node, context, prior, (child) => computeNode(child, context), gates.length > 0, hasRelocated, registered, publication);
		if (context.presenceHosts?.delete(node) === true || registered) registered = registerPresenceChanges(node, lastStructure, context) || registered;
		if (registered) lastStructure = node.structure ?? {};
		flushPresenceTemplates(node, context);
		const dirty = dirtyChildren(node, context);
		for (let index = 0; index < dirty.length; index++) computeNode(dirty[index], context);
		let outputChanged = false;
		const unchangedPublication = deferBaseline && !hasRelocated && !schemaChanged && !changed && dirty.length === 0 && !context.pendingOutputs?.has(node) && node.local === roundLocal && node.emit === roundEmit && !context.distributedInputs.has(node) && context.pathChanges.length === 0;
		if (context.initialOutputs) context.initialOutputs.push(node);
		else if (!unchangedPublication && (!deferBaseline || hasRelocated || !publication.flushed || dirty.length > 0 || context.pendingOutputs?.has(node))) outputChanged = updateOutput(node, context);
		if (wheelPlan) wheelPlan = prepareHostWheelPlan(node, wheelPlan);
		gates = wheelPlan?.gates ?? gates;
		const currentRelocated = wheelPlan?.relocated ?? [];
		hasRelocated = currentRelocated.length > 0;
		cap = wheelPlan ? context.distributedInputs.size > 0 || wheelPlan.cap === void 0 ? wheelPlan.cap = getHostWheelBudgetCap(node, node.runtime.blueprint, gates, node.runtime) : wheelPlan.cap : 1;
		if (outputChanged) scheduleRelocatedGates(currentRelocated, context);
		const publishedChanged = !outputChanged && context.kind !== "load" && (node.local !== roundLocal || node.emit !== roundEmit) && scheduleChangedRelocatedGates(currentRelocated, context);
		const wheelChanged = schemaChanged || changed || outputChanged || publishedChanged;
		finishGateTableRound(node, context);
		if (frame && confirmation) verifyGateWheelConfirmation(confirmation, frame, wheelChanged);
		if (frame && previousPredicate === false && !wheelChanged) gateWheelEvaluation.missed++;
		const skip = frame !== void 0 && wheelChanged && canSkipGateWheel(node, context, frame, round, cap, gates.length);
		if (skip) {
			gateWheelEvaluation.predictions++;
			if (engineModes.gateWheel === "skip") {
				gateWheelEvaluation.skipped++;
				preserveReferences(node, previous, context);
				context.dirtyPaths.delete(node.path);
				return;
			}
		}
		confirmation = skip && engineModes.gateWheel === "shadow" ? frame : void 0;
		previousPredicate = skip;
		if (!schemaChanged && !changed && !outputChanged && !publishedChanged) {
			preserveReferences(node, previous, context);
			context.dirtyPaths.delete(node.path);
			return;
		}
	}
	if (gates.length > 0) context.hostWheelExceeded = cap;
	preserveReferences(node, previous, context);
	context.dirtyPaths.delete(node.path);
};
const computeNode = (node, context) => {
	const parentFrame = context.gateWheelFrame;
	let computed = false;
	context.gateWheelFrame = void 0;
	try {
		computeNodeBody(node, context);
		if (node === context.root) flushPresenceTemplates(void 0, context);
		computed = true;
	} finally {
		context.gateWheelFrame = parentFrame;
		if (node === context.root) {
			if (!computed) discardStaticHostPreparation(context);
			context.restoreGateSelectionDirty?.();
			context.gateSelectionRounds?.clear();
		}
	}
};

//#endregion
//#region src/core/engine/settle/utils/input/utils/verifyWriteEpoch.ts
const verifyWriteEpoch = (context) => {
	const shadow = context.writeEpochShadow;
	if (!shadow) return;
	const actual = new Set(context.dirtyPaths);
	const pending = [context.target];
	while (pending.length) {
		const node = pending.pop();
		if (node.writeEpoch === context.writeEpoch) actual.add(node.path);
		if (node.children) for (const child of node.children) pending.push(child);
	}
	verifyGateSelection(actual.size === shadow.size && [...shadow].every((path) => actual.has(path)), "S7 write epoch members differ from the general path");
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/registerRecalculation.ts
const registerRecalculation = (context) => {
	if (context.writeEpoch !== void 0) {
		if (context.target.parent !== null) context.dirtyPaths.add(context.target.path);
		let parent = context.target.parent;
		while (parent) {
			context.dirtyPaths.add(parent.path);
			parent = parent.parent;
		}
		if (engineModes.gateSelection === "verify") verifyWriteEpoch(context);
		return;
	}
	if (!context.hasGates && context.dirtyPaths instanceof DirtyPathSet) context.dirtyPaths.beginPostOrder();
	const blueprint = context.root.runtime.blueprint;
	const dependencies = getDependencyIndex(blueprint);
	const epoch = context.registrationEpoch = (context.registrationEpoch ?? 0) + 1;
	const shadow = engineModes.gateSelection === "verify" && !context.shadowRegistration ? context.registrationShadow : void 0;
	if (shadow) {
		registerRecalculation({
			...context,
			dirtyPaths: shadow.dirty,
			dirtyChildrenByParent: shadow.dirty.childrenByParent,
			shapeDirtyPaths: shadow.shape,
			dependencyOwnerPaths: shadow.owners,
			registrationShadow: void 0,
			shadowRegistration: true
		});
		shadow.registering = true;
	}
	if (!context.shadowRegistration && context.hasGates && engineModes.gateSelection !== "off" && dependencies.hasSplitOwners) {
		const dirty = context.dirtyPaths;
		if (dirty instanceof DirtyPathSet) dirty.configureSplitOwners(dependencies.splitOwners);
		for (const changed of context.changedRaw) dependencies.affectedForRegistration(changed, context.root, {
			hit: (bucket, liveRanks) => {
				(context.splitHitEpochs ?? (context.splitHitEpochs = /* @__PURE__ */ new Map())).set(bucket, epoch);
				return dirty instanceof DirtyPathSet ? dirty.planSplitAnchors(bucket, liveRanks, epoch) : [];
			},
			owner: (path, kind) => {
				dirty.add(path);
				if (kind === "plain") context.dependencyOwnerPaths.add(path);
				else if (kind === "split") (context.splitMarks ?? (context.splitMarks = /* @__PURE__ */ new Map())).set(path, epoch);
				context.shapeDirtyPaths.add(kind === "host" ? path : resolvePointer(path, ".."));
			}
		});
	} else for (const changed of context.changedRaw) for (const declarationPath of dependencies.affected(changed, context.root)) {
		context.dirtyPaths.add(declarationPath);
		context.dependencyOwnerPaths.add(declarationPath);
		context.shapeDirtyPaths.add(resolvePointer(declarationPath, ".."));
	}
	const expanded = /* @__PURE__ */ new Set();
	for (const path of context.dirtyPaths) {
		let ancestor = path;
		while (ancestor && !expanded.has(ancestor)) {
			expanded.add(ancestor);
			ancestor = resolvePointer(ancestor, "..");
			context.dirtyPaths.add(ancestor);
		}
	}
	if (context.hasGates) {
		const changedAncestors = /* @__PURE__ */ new Set();
		for (const changed of context.changedRaw) for (let prefix = changed; prefix;) {
			prefix = resolvePointer(prefix, "..");
			if (changedAncestors.has(prefix)) break;
			changedAncestors.add(prefix);
		}
		const registry = getGateRegistry(context.root.runtime);
		for (const path of context.dirtyPaths) {
			if (registry.mayChangeAt(path, context.changedRaw, changedAncestors)) context.shapeDirtyPaths.add(path);
			if (path && registry.mayChangeOwnDeclarationAt(path, context.changedRaw, changedAncestors)) context.shapeDirtyPaths.add(resolvePointer(path, ".."));
		}
	}
	if (shadow) {
		shadow.registering = false;
		verifyGateSelection(context.shapeDirtyPaths.size === shadow.shape.size && [...shadow.shape].every((path) => context.shapeDirtyPaths.has(path)), "S3 shape dirty differs after registration");
		for (const path of context.dirtyPaths) verifyGateSelection(shadow.dirty.has(path), "S3 optimized dirty adds an unknown path: " + path);
		for (const path of shadow.dirty) if (!context.dirtyPaths.has(path)) {
			const owner = dependencies.splitOwners.get(path);
			verifyGateSelection(!!owner && !!context.splitHitEpochs?.has(owner.bucket), "S3 removed a non-split owner: " + path);
			let node = context.root;
			for (const segment of dependencies.pathSegments(path, context.root.runtime)) {
				if (typeof segment !== "string") {
					node = void 0;
					break;
				}
				node = node?.structure?.[segment];
			}
			verifyGateSelection(!node, "S3 removed a living split owner: " + path);
		}
	}
};

//#endregion
//#region src/core/engine/settle/utils/dispose/assertFieldNodeWritable.ts
const assertFieldNodeWritable = (node) => {
	if (node.disposed || node.rootNode.disposed) throw new SchemaFormError(FormErrorCode.DisposedNodeWrite, `Cannot write disposed node at ${node.path}`, { path: node.path });
};

//#endregion
//#region src/core/engine/settle/utils/input/utils/watchWriteEpoch.ts
const watchWriteEpoch = (context) => {
	const dirty = context.dirtyPaths;
	if (!(dirty instanceof DirtyPathSet)) return;
	const shadow = context.writeEpochShadow = new DirtyPathSet(/* @__PURE__ */ new Map());
	shadow.beginPostOrder();
	const inputs = context.writtenInputs;
	const set = inputs.set;
	const restore = dirty.restoreRegistrationObserver;
	inputs.set = function(node, value) {
		shadow.add(node.path);
		return set.call(this, node, value);
	};
	dirty.restoreRegistrationObserver = () => {
		inputs.set = set;
		restore?.();
	};
};

//#endregion
//#region src/core/engine/settle/utils/input/utils/prepareWriteEpoch.ts
const prepareWriteEpoch = (context) => {
	const node = context.target;
	const runtime = node.runtime;
	if (node.behavior.strategy !== "branch" || node.detached || node.disposed || context.replaceScope !== node || context.kind !== "callerReplace" && context.kind !== "input" || context.replacePaths !== void 0 || runtime.batchDepth || runtime.visitDepth || context.root.inactiveSlots?.size || context.root.inactiveSlotOverlays?.size || context.root.inactiveSlotChildren?.size || runtime.misfitPaths.size || !StaticFirstLoadCapability.has(runtime.blueprint)) return;
	const epoch = (runtime.writeEpoch ?? 0) + 1;
	if (!Number.isSafeInteger(epoch)) return;
	runtime.writeEpoch = epoch;
	context.writeEpoch = epoch;
	if (engineModes.gateSelection === "verify") watchWriteEpoch(context);
};

//#endregion
//#region src/core/engine/settle/utils/scratch/getSettlementScratch.ts
const getSettlementScratch = (runtime) => {
	const cached = runtime.settlementScratch;
	const dirtyChildrenByParent = cached && !cached.inUse ? cached.dirtyChildrenByParent : /* @__PURE__ */ new Map();
	const scratch = cached && !cached.inUse ? cached : {
		inUse: false,
		entered: /* @__PURE__ */ new Set(),
		revived: /* @__PURE__ */ new Set(),
		exited: /* @__PURE__ */ new Set(),
		pendingExits: /* @__PURE__ */ new Map(),
		perished: /* @__PURE__ */ new Set(),
		selectedDeclarationIds: /* @__PURE__ */ new Map(),
		writtenInputs: /* @__PURE__ */ new Map(),
		distributedInputs: /* @__PURE__ */ new Map(),
		wrongKindHosts: /* @__PURE__ */ new Set(),
		automaticLog: [],
		arrayStructureLog: [],
		arrayCounts: /* @__PURE__ */ new Map(),
		pathChanges: [],
		filledNodes: /* @__PURE__ */ new Set(),
		dirtyPaths: new DirtyPathSet(dirtyChildrenByParent),
		dirtyChildrenByParent,
		dependencyOwnerPaths: /* @__PURE__ */ new Set(),
		shapeDirtyPaths: /* @__PURE__ */ new Set(),
		changedRaw: /* @__PURE__ */ new Set(),
		explicitRaw: /* @__PURE__ */ new Set(),
		changedNodes: /* @__PURE__ */ new Set(),
		stateDirtyNodes: /* @__PURE__ */ new Set(),
		originalSchemas: /* @__PURE__ */ new Map()
	};
	if (!cached) runtime.settlementScratch = scratch;
	scratch.inUse = true;
	return scratch;
};

//#endregion
//#region src/core/engine/settle/utils/scratch/releaseSettlementScratch.ts
const releaseSettlementScratch = (scratch) => {
	if (scratch.dirtyPaths instanceof DirtyPathSet) scratch.dirtyPaths.restoreRegistrationObserver?.();
	if (scratch.entered.size) scratch.entered.clear();
	if (scratch.revived.size) scratch.revived.clear();
	if (scratch.exited.size) scratch.exited.clear();
	if (scratch.pendingExits.size) scratch.pendingExits.clear();
	if (scratch.pendingExitPaths?.size) scratch.pendingExitPaths.clear();
	if (scratch.perished.size) scratch.perished.clear();
	if (scratch.selectedDeclarationIds.size) scratch.selectedDeclarationIds.clear();
	if (scratch.writtenInputs.size) scratch.writtenInputs.clear();
	if (scratch.distributedInputs.size) scratch.distributedInputs.clear();
	if (scratch.wrongKindHosts.size) scratch.wrongKindHosts.clear();
	if (scratch.automaticLog.length) scratch.automaticLog.length = 0;
	if (scratch.arrayStructureLog.length) scratch.arrayStructureLog.length = 0;
	if (scratch.arrayCounts.size) scratch.arrayCounts.clear();
	if (scratch.pathChanges.length) scratch.pathChanges.length = 0;
	if (scratch.filledNodes.size) scratch.filledNodes.clear();
	scratch.dirtyPaths.clear();
	if (scratch.dependencyOwnerPaths.size) scratch.dependencyOwnerPaths.clear();
	if (scratch.shapeDirtyPaths.size) scratch.shapeDirtyPaths.clear();
	if (scratch.changedRaw.size) scratch.changedRaw.clear();
	if (scratch.explicitRaw.size) scratch.explicitRaw.clear();
	if (scratch.changedNodes.size) scratch.changedNodes.clear();
	if (scratch.stateDirtyNodes.size) scratch.stateDirtyNodes.clear();
	if (scratch.originalSchemas.size) scratch.originalSchemas.clear();
	scratch.inUse = false;
};

//#endregion
//#region src/core/engine/types/value.ts
let WriteOption = /* @__PURE__ */ function(WriteOption) {
	WriteOption[WriteOption["None"] = 0] = "None";
	WriteOption[WriteOption["Replace"] = 1] = "Replace";
	WriteOption[WriteOption["Overwrite"] = 1] = "Overwrite";
	WriteOption[WriteOption["Merge"] = 2] = "Merge";
	WriteOption[WriteOption["DisableAutomaticWrites"] = 4] = "DisableAutomaticWrites";
	WriteOption[WriteOption["EnableAutomaticWrites"] = 8] = "EnableAutomaticWrites";
	return WriteOption;
}({});

//#endregion
//#region src/core/engine/settle/utils/compute/childSelection/prepareGateSelection.ts
const prepareGateSelection = (blueprint, allowPreparation = true) => {
	const known = getBlueprintDerived(blueprint).splitOwnersPrepared;
	if (known !== void 0) return known;
	if (!allowPreparation) return false;
	const tables = /* @__PURE__ */ new Map();
	for (const host of blueprint.nodes) {
		const schema = host.declarations[0]?.schema;
		if (typeof schema !== "object" || schema === null || !(isArray(schema.oneOf) && schema.oneOf.length > 1 || isArray(schema.anyOf) && schema.anyOf.length > 1 || isArray(schema.allOf) && schema.allOf.length > 1 && host.childEntries.some((entry) => entry.declarations.some((declaration) => declaration.gates.some((gate) => gate.kind === "if"))))) continue;
		getDirectChildSelectionPlan(host, blueprint, true);
		const table = getGateSelectionTable(host, blueprint);
		if (table) tables.set(host, table);
	}
	if (tables.size) getDependencyIndex(blueprint, tables);
	const split = tables.size > 0 && getDependencyIndex(blueprint).hasSplitOwners;
	getBlueprintDerived(blueprint).splitOwnersPrepared = split;
	return split;
};

//#endregion
//#region src/core/engine/settle/utils/compute/getVirtualReferenceIndex.ts
const getVirtualReferenceIndex = (blueprint) => {
	let index = getBlueprintDerived(blueprint).virtualReferenceIndex;
	if (index !== void 0) return index;
	if (StaticFirstLoadCapability.has(blueprint)) {
		getBlueprintDerived(blueprint).virtualReferenceIndex = null;
		return null;
	}
	let hosts;
	for (const host of blueprint.nodes) {
		let fields;
		for (const entry of host.childEntries) {
			if (entry.node.kind !== "virtual") continue;
			fields ?? (fields = /* @__PURE__ */ new Map());
			for (const field of entry.node.fields ?? []) {
				const names = fields.get(field) ?? [];
				names.push(entry.name);
				fields.set(field, names);
			}
		}
		if (fields) {
			hosts ?? (hosts = /* @__PURE__ */ new Map());
			hosts.set(host, fields);
		}
	}
	index = hosts ?? null;
	getBlueprintDerived(blueprint).virtualReferenceIndex = index;
	return index;
};

//#endregion
//#region src/core/engine/settle/utils/gates/watchSplitRegistration.ts
const watchSplitRegistration = (context) => {
	if (engineModes.gateSelection !== "verify" || !context.hasGates) return;
	const dirty = context.dirtyPaths;
	const shape = context.shapeDirtyPaths;
	const owners = context.dependencyOwnerPaths;
	const add = dirty.add;
	const remove = dirty.delete;
	const clear = dirty.clear;
	const addShape = shape.add;
	const addOwner = owners.add;
	const shadow = context.registrationShadow = {
		dirty: new DirtyPathSet(/* @__PURE__ */ new Map()),
		shape: /* @__PURE__ */ new Set(),
		owners: /* @__PURE__ */ new Set(),
		registering: false,
		supplementInsertions: 0,
		restore: () => {
			dirty.add = add;
			dirty.delete = remove;
			dirty.clear = clear;
			shape.add = addShape;
			owners.add = addOwner;
			if (dirty instanceof DirtyPathSet) dirty.restoreRegistrationObserver = void 0;
			verifyGateSelection(shadow.supplementInsertions === 0, "S4 supplement insertions must be zero");
		}
	};
	for (const path of dirty) shadow.dirty.add(path);
	for (const path of shape) shadow.shape.add(path);
	for (const path of owners) shadow.owners.add(path);
	dirty.add = function(path) {
		if (!shadow.registering) shadow.dirty.add(path);
		return add.call(this, path);
	};
	dirty.delete = function(path) {
		if (!shadow.registering) shadow.dirty.delete(path);
		return remove.call(this, path);
	};
	dirty.clear = function() {
		verifyGateSelection(false, "S3 gated dirty set cleared during settlement");
		return clear.call(this);
	};
	shape.add = function(path) {
		if (!shadow.registering) shadow.shape.add(path);
		return addShape.call(this, path);
	};
	owners.add = function(path) {
		if (!shadow.registering) shadow.owners.add(path);
		return addOwner.call(this, path);
	};
	if (dirty instanceof DirtyPathSet) dirty.restoreRegistrationObserver = shadow.restore;
};

//#endregion
//#region src/core/engine/settle/utils/transition/getTransitionCap.ts
const getTransitionCap = (blueprint) => {
	return getTransitionBudgetCap(blueprint);
};

//#endregion
//#region src/core/engine/settle/utils/settlement/createSettlementContext.ts
const createSettlementContext = (node, kind, option, scratch, replaces = false) => {
	const root = node.rootNode;
	const runtime = root.runtime;
	const blueprint = runtime.blueprint;
	const disable = (option & WriteOption.DisableAutomaticWrites) !== 0;
	const enable = (option & WriteOption.EnableAutomaticWrites) !== 0;
	const hasSplitRegistration = !blueprint.capabilities.branchless && prepareGateSelection(blueprint, kind !== "load");
	const context = {
		root,
		previousEmit: root.emit,
		previousContext: runtime.context,
		target: node,
		kind,
		option,
		hasGates: !blueprint.capabilities.branchless && getTransitionCap(blueprint) > 1,
		virtualReferenceIndex: StaticFirstLoadCapability.has(blueprint) ? null : getVirtualReferenceIndex(blueprint),
		suppressAutomaticWrites: disable || !enable && runtime.disableAutomaticWrites === true,
		loadScope: kind === "load" ? node : void 0,
		replaceScope: replaces ? node : void 0,
		entered: scratch.entered,
		revived: scratch.revived,
		exited: scratch.exited,
		pendingExits: scratch.pendingExits,
		pendingExitPaths: scratch.pendingExitPaths,
		pendingExitScratch: scratch,
		perished: scratch.perished,
		selectedDeclarationIds: scratch.selectedDeclarationIds,
		writtenInputs: scratch.writtenInputs,
		distributedInputs: scratch.distributedInputs,
		wrongKindHosts: scratch.wrongKindHosts,
		automaticLog: scratch.automaticLog,
		arrayStructureLog: scratch.arrayStructureLog,
		arrayCounts: scratch.arrayCounts,
		pathChanges: scratch.pathChanges,
		filledNodes: scratch.filledNodes,
		inTransition: false,
		automatic: false,
		automaticChanged: false,
		dirtyPaths: scratch.dirtyPaths,
		dirtyChildrenByParent: scratch.dirtyChildrenByParent,
		dependencyOwnerPaths: scratch.dependencyOwnerPaths,
		registrationEpoch: 0,
		shapeDirtyPaths: scratch.shapeDirtyPaths,
		changedRaw: scratch.changedRaw,
		changedNodes: scratch.changedNodes,
		stateDirtyNodes: scratch.stateDirtyNodes,
		originalSchemas: scratch.originalSchemas
	};
	if (hasSplitRegistration) watchSplitRegistration(context);
	return context;
};

//#endregion
//#region src/core/engine/utils/pathIndex/utils/utils/NumericPathIndex.ts
var NumericPathIndex = class {
	constructor() {
		this.lengths = /* @__PURE__ */ new Map();
	}
	get empty() {
		return this.lengths.size === 0;
	}
	add(segment, path) {
		const root = this.lengths.get(segment.length) ?? { children: /* @__PURE__ */ new Map() };
		this.lengths.set(segment.length, root);
		let node = root;
		for (const digit of segment) {
			let child = node.children.get(digit);
			if (!child) {
				child = { children: /* @__PURE__ */ new Map() };
				node.children.set(digit, child);
			}
			node = child;
		}
		node.path = path;
	}
	delete(segment) {
		const root = this.lengths.get(segment.length);
		if (!root) return;
		const parents = [root];
		for (const digit of segment) {
			const child = parents[parents.length - 1].children.get(digit);
			if (!child) return;
			parents.push(child);
		}
		delete parents[parents.length - 1].path;
		for (let i = segment.length - 1; i >= 0; i--) {
			const child = parents[i + 1];
			if (child.path !== void 0 || child.children.size) break;
			parents[i].children.delete(segment[i]);
		}
		if (root.children.size === 0) this.lengths.delete(segment.length);
	}
	*tail(count) {
		const lower = String(count);
		for (const [length, root] of this.lengths) {
			if (length < lower.length) continue;
			const pending = [{
				node: root,
				prefix: ""
			}];
			while (pending.length) {
				const { node, prefix } = pending.pop();
				if (node.path !== void 0) yield node.path;
				for (const [digit, child] of node.children) {
					const next = prefix + digit;
					if (length === lower.length && next < lower.slice(0, next.length)) continue;
					pending.push({
						node: child,
						prefix: next
					});
				}
			}
		}
	}
};

//#endregion
//#region src/core/engine/utils/pathIndex/utils/utils/isCanonicalArraySlot.ts
const isCanonicalArraySlot = (segment) => {
	if (!segment.length || segment.length > 16 || segment.length > 1 && segment.charCodeAt(0) === 48) return false;
	for (let i = 0; i < segment.length; i++) {
		const digit = segment.charCodeAt(i);
		if (digit < 48 || digit > 57) return false;
	}
	return Number.isSafeInteger(Number(segment));
};

//#endregion
//#region src/core/engine/utils/pathIndex/utils/PathStoreIndex.ts
var PathStoreIndex = class {
	constructor() {
		this.pathsByKey = /* @__PURE__ */ new Map();
		this.prefixes = /* @__PURE__ */ new Map();
		this.slots = /* @__PURE__ */ new Map();
		this.pending = /* @__PURE__ */ new Set();
		this.batchDepth = 0;
	}
	add(key, paths) {
		if (this.pathsByKey.has(key)) return;
		const own = paths.map((path) => this.getPrefix(path));
		this.pathsByKey.set(key, own);
		for (const prefix of own) {
			prefix.exact.add(key);
			let ancestor = prefix;
			while (ancestor) {
				ancestor.keys.add(key);
				ancestor = ancestor.parent;
			}
		}
	}
	delete(key) {
		const paths = this.pathsByKey.get(key);
		if (!paths) return;
		this.pathsByKey.delete(key);
		for (const prefix of paths) {
			prefix.exact.delete(key);
			let ancestor = prefix;
			while (ancestor) {
				ancestor.keys.delete(key);
				if (!ancestor.keys.size) if (this.batchDepth) this.pending.add(ancestor);
				else this.dropPrefix(ancestor);
				ancestor = ancestor.parent;
			}
		}
	}
	beginBatch() {
		this.batchDepth++;
	}
	endBatch() {
		if (--this.batchDepth) return;
		for (const prefix of this.pending) if (!prefix.keys.size) this.dropPrefix(prefix);
		this.pending.clear();
	}
	clear() {
		this.pathsByKey.clear();
		this.prefixes.clear();
		this.slots.clear();
		this.pending.clear();
		this.batchDepth = 0;
	}
	under(path) {
		return this.prefixes.get(path)?.keys ?? EMPTY_KEYS;
	}
	tail(host, count) {
		return this.slots.get(host)?.tail(count) ?? EMPTY_KEYS;
	}
	intersecting(path) {
		const keys = new Set(this.under(path));
		let ancestor = path;
		while (ancestor) {
			ancestor = resolvePointer(ancestor, "..");
			for (const key of this.prefixes.get(ancestor)?.exact ?? []) keys.add(key);
		}
		return keys;
	}
	getPrefix(path) {
		const held = this.prefixes.get(path);
		if (held) return held;
		const missing = [];
		let cursor = path;
		let parent = this.prefixes.get(cursor);
		while (!parent) {
			missing.push(cursor);
			if (!cursor) break;
			cursor = resolvePointer(cursor, "..");
			parent = this.prefixes.get(cursor);
		}
		for (let i = missing.length - 1; i >= 0; i--) {
			const current = missing[i];
			const segment = readPointerSegment(current, -1) ?? "";
			if (typeof segment !== "string") throw new TypeError("Expected a named store path");
			const prefix = {
				path: current,
				parent,
				segment,
				numeric: current !== "" && isCanonicalArraySlot(segment),
				keys: /* @__PURE__ */ new Set(),
				exact: /* @__PURE__ */ new Set()
			};
			this.prefixes.set(current, prefix);
			if (prefix.numeric && parent) {
				let slots = this.slots.get(parent.path);
				if (!slots) this.slots.set(parent.path, slots = new NumericPathIndex());
				slots.add(segment, current);
			}
			parent = prefix;
		}
		return parent;
	}
	dropPrefix(prefix) {
		this.prefixes.delete(prefix.path);
		if (!prefix.numeric || !prefix.parent) return;
		const slots = this.slots.get(prefix.parent.path);
		slots?.delete(prefix.segment);
		if (slots?.empty) this.slots.delete(prefix.parent.path);
	}
};
const EMPTY_KEYS = /* @__PURE__ */ new Set();

//#endregion
//#region src/core/engine/utils/pathIndex/utils/getStoreKeyPaths.ts
const NO_PATHS$2 = Object.freeze([]);
const getStoreKeyPaths = (key, mode) => {
	if (mode === "path") return [key];
	const parts = JSON.parse(key);
	if (!isArray(parts) || typeof parts[0] !== "string") return NO_PATHS$2;
	return mode === "rule" && typeof parts[5] === "string" && parts[5] !== parts[0] ? [parts[0], parts[5]] : [parts[0]];
};

//#endregion
//#region src/core/engine/utils/pathIndex/PathKeyedMap.ts
var PathKeyedMap = class extends Map {
	constructor(mode, entries) {
		super();
		this.mode = mode;
		this.pathIndex = new PathStoreIndex();
		if (entries) for (const [key, value] of entries) this.set(key, value);
	}
	set(key, value) {
		if (!this.has(key)) this.pathIndex.add(key, getStoreKeyPaths(key, this.mode));
		return super.set(key, value);
	}
	delete(key) {
		this.pathIndex.delete(key);
		return super.delete(key);
	}
	clear() {
		this.pathIndex.clear();
		super.clear();
	}
	replaceEntries(moves) {
		this.pathIndex.beginBatch();
		try {
			for (const move of moves) {
				this.pathIndex.delete(move.previous);
				super.delete(move.previous);
			}
			for (const move of moves) if (move.key !== void 0) {
				this.pathIndex.add(move.key, move.paths);
				super.set(move.key, move.value);
			}
		} finally {
			this.pathIndex.endBatch();
		}
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/expireOccupiedSlotMemos.ts
const expireOccupiedSlotMemos = (source, overlay, live) => {
	if (!live) return;
	if (source) source.inactiveValueMemo = void 0;
	if (overlay) overlay.valueMemo = void 0;
	for (const entry of getSlotEntries(source, overlay)) {
		const child = getSlotSource(source, entry, overlay);
		expireOccupiedSlotMemos(child.source, child.overlay, live.structure?.[entry.name]);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/preserveSlotValueMemos.ts
const preserveSlotValueMemos = (previous, previousOverlay, current, overlay) => {
	if (!current && !overlay) return;
	const memo = previous?.inactiveValueMemo ?? previousOverlay?.valueMemo;
	if (current && !current.inactiveValueMemo) current.inactiveValueMemo = memo;
	else if (overlay && !overlay.valueMemo) overlay.valueMemo = memo;
	for (const entry of getSlotEntries(previous, previousOverlay)) {
		const old = getSlotSource(previous, entry, previousOverlay);
		const next = getSlotSource(current, entry, overlay);
		if (next.source || next.overlay) preserveSlotValueMemos(old.source, old.overlay, next.source, next.overlay);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/updateSlotChildIndex.ts
const updateSlotChildIndex = (host, name) => {
	const live = host.structure?.[name];
	if (live && !live.detached && (live.inactiveSlots?.size || live.inactiveSlotOverlays?.size || live.inactiveSlotChildren?.size)) (host.inactiveSlotChildren ?? (host.inactiveSlotChildren = /* @__PURE__ */ new Map())).set(name, live);
	else host.inactiveSlotChildren?.delete(name);
};

//#endregion
//#region src/core/engine/settle/utils/slots/commitSlotChanges.ts
const commitSlotChanges = (root) => {
	const hosts = root.runtime.slotDirtyHosts;
	if (!hosts?.size) return;
	const visited = /* @__PURE__ */ new Set();
	for (const host of hosts) {
		if (!host.detached) {
			for (const [entry, previous] of host.inactiveSlotBaselines ?? []) {
				preserveSlotValueMemos(previous.source, previous.overlay, host.inactiveSlots?.get(entry), host.inactiveSlotOverlays?.get(entry));
				updateSlotChildIndex(host, entry.name);
			}
			host.inactiveSlotBaselines?.clear();
			const bindings = new Set(host.inactiveSlots?.keys());
			for (const entry of host.inactiveSlotOverlays?.keys() ?? []) bindings.add(entry);
			for (const entry of bindings) expireOccupiedSlotMemos(host.inactiveSlots?.get(entry), host.inactiveSlotOverlays?.get(entry), host.structure?.[entry.name]);
		}
		for (let current = host; current; current = current.parent) {
			const parent = current.parent;
			if (parent && !parent.detached) updateSlotChildIndex(parent, current.name);
			if (current.detached || visited.has(current)) continue;
			visited.add(current);
			current.inactiveValuesDirty = true;
		}
	}
	hosts.clear();
};

//#endregion
//#region src/core/engine/settle/utils/commit/collectNonJsonPaths.ts
const collectNonJsonPaths = (value, path) => {
	const found = [];
	const active = /* @__PURE__ */ new WeakSet();
	const pending = [{
		value,
		path
	}];
	while (pending.length && found.length < 8) {
		const frame = pending.pop();
		if (!frame) continue;
		if ("leave" in frame) {
			active.delete(frame.leave);
			continue;
		}
		const current = frame.value;
		const currentPath = frame.path;
		if (current === void 0 || typeof current === "function" || typeof current === "symbol" || typeof current === "bigint" || typeof current === "number" && !Number.isFinite(current)) {
			found.push(currentPath);
			continue;
		}
		if (current === null || typeof current !== "object") continue;
		if (current instanceof Date || active.has(current)) {
			found.push(currentPath);
			continue;
		}
		active.add(current);
		pending.push({ leave: current });
		if (isArray(current)) for (let index = current.length - 1; index >= 0; index--) pending.push({
			value: current[index],
			path: appendSegment(currentPath, index)
		});
		else {
			const keys = Object.keys(current);
			for (let index = keys.length - 1; index >= 0; index--) {
				const key = keys[index];
				pending.push({
					value: Reflect.get(current, key),
					path: appendSegment(currentPath, key)
				});
			}
		}
	}
	return found;
};

//#endregion
//#region src/core/engine/navigation/utils/query/findNodes.ts
const findNodes = (origin, pointer) => {
	const input = pointer ?? "";
	const segments = parsePointerSegments(input);
	let cursors = [isAbsolutePointer(input) ? origin.rootNode : origin];
	for (const token of segments) {
		const next = [];
		if (token === PointerOperator.Context) return [];
		for (const cursor of cursors) if (token === PointerOperator.Current) {
			if (!next.includes(cursor)) next.push(cursor);
		} else if (token === PointerOperator.Parent) {
			const parent = cursor.parent;
			if (parent !== null && (!cursor.detached || parent.detached) && !next.includes(parent)) next.push(parent);
		} else if (cursor.structure !== null) if (token === PointerOperator.Wildcard) {
			for (const child of Object.values(cursor.structure)) if (!next.includes(child)) next.push(child);
		} else {
			if (typeof token !== "string") continue;
			const name = token;
			if (hasOwnProperty(cursor.structure, name)) {
				const child = cursor.structure[name];
				if (child !== void 0 && !next.includes(child)) next.push(child);
			}
		}
		if (next.length === 0) return [];
		cursors = next;
	}
	return cursors;
};

//#endregion
//#region src/core/engine/navigation/utils/query/find.ts
const find = (origin, pointer) => findNodes(origin, pointer)[0] ?? null;

//#endregion
//#region src/core/engine/navigation/utils/visit/visitFieldNodes.ts
const visitFieldNodes = (origin, visit, options) => {
	const owned = options?.owned === true;
	const seen = owned ? void 0 : /* @__PURE__ */ new Set();
	const pending = [origin];
	while (pending.length > 0) {
		const node = pending.pop();
		if (node === void 0) continue;
		if (seen !== void 0) {
			if (seen.has(node)) continue;
			seen.add(node);
		}
		if (visit(node) === false) continue;
		const children = node.children;
		if (children === null) continue;
		for (let index = children.length - 1; index >= 0; index--) {
			const child = children[index];
			if (!owned || child.parent === node) pending.push(child);
		}
	}
};

//#endregion
//#region src/core/engine/settle/utils/derivation/getDeriveState.ts
const getDeriveState = (context) => {
	if (context.deriveState) return context.deriveState;
	if (getDeriveRuleTable(context.root.runtime.blueprint).rules.length === 0) return void 0;
	const state = {
		root: context.root,
		selectedDeclarationIds: context.selectedDeclarationIds,
		committedRuleValues: context.root.runtime.committedRuleValues ?? /* @__PURE__ */ new Map(),
		consumedRuleValues: /* @__PURE__ */ new Map(),
		activeRuleKeys: /* @__PURE__ */ new Set(),
		activeRuleKeysBySource: /* @__PURE__ */ new Map(),
		activeUnsetTargets: /* @__PURE__ */ new Set(),
		appliedRanks: /* @__PURE__ */ new Map(),
		visitedSourcePaths: /* @__PURE__ */ new Set(),
		loadScope: context.loadScope,
		entered: context.entered,
		revived: context.revived,
		suppressAutomaticWrites: context.suppressAutomaticWrites,
		trace: __SCHEMA_FORM_DEV__
	};
	context.deriveState = state;
	return state;
};

//#endregion
//#region src/core/engine/settle/utils/commit/updateCommittedRuleValue.ts
const updateCommittedRuleValue = (runtime, key, operation, value) => {
	if (operation === "delete" && !runtime.committedRuleValues?.has(key)) return;
	const parts = JSON.parse(key);
	if (!isArray(parts) || typeof parts[0] !== "string") return;
	const source = parts[0];
	const target = typeof parts[5] === "string" ? parts[5] : void 0;
	if (operation === "delete") {
		runtime.committedRuleValues?.delete(key);
		const sourceKeys = runtime.committedRuleKeysBySource?.get(source);
		sourceKeys?.delete(key);
		if (sourceKeys?.size === 0) runtime.committedRuleKeysBySource?.delete(source);
		if (target !== void 0) {
			const targetKeys = runtime.committedRuleKeysByTarget?.get(target);
			targetKeys?.delete(key);
			if (targetKeys?.size === 0) runtime.committedRuleKeysByTarget?.delete(target);
		}
		return;
	}
	(runtime.committedRuleValues ?? (runtime.committedRuleValues = new PathKeyedMap("rule"))).set(key, value);
	let sourceKeys = runtime.committedRuleKeysBySource?.get(source);
	if (!sourceKeys) {
		sourceKeys = /* @__PURE__ */ new Set();
		(runtime.committedRuleKeysBySource ?? (runtime.committedRuleKeysBySource = /* @__PURE__ */ new Map())).set(source, sourceKeys);
	}
	sourceKeys.add(key);
	if (target === void 0) return;
	let targetKeys = runtime.committedRuleKeysByTarget?.get(target);
	if (!targetKeys) {
		targetKeys = /* @__PURE__ */ new Set();
		(runtime.committedRuleKeysByTarget ?? (runtime.committedRuleKeysByTarget = /* @__PURE__ */ new Map())).set(target, targetKeys);
	}
	targetKeys.add(key);
};

//#endregion
//#region src/core/engine/settle/utils/commit/pruneCommittedRuleKeys.ts
const pruneCommittedRuleKeys = (runtime, path, scope) => {
	for (const key of runtime.committedRuleKeysBySource?.get(path) ?? []) {
		if (scope === "exitPolicy") {
			const parts = JSON.parse(key);
			if (!isArray(parts) || typeof parts[3] !== "string" || readPointerSegment(parts[3], -1) !== "unsetOnInactive") continue;
		}
		updateCommittedRuleValue(runtime, key, "delete");
	}
	if (scope !== "occurrence") return;
	for (const key of runtime.committedRuleKeysByTarget?.get(path) ?? []) updateCommittedRuleValue(runtime, key, "delete");
};

//#endregion
//#region src/core/engine/settle/utils/commit/commitDeriveRules.ts
const CLEAN_STATE_PATCH = {
	[FieldNodeState.Dirty]: false,
	[FieldNodeState.Touched]: false
};
const commitDeriveRules = (context) => {
	const state = getDeriveState(context);
	if (!state) return;
	const decision = evaluateResetInteraction(context.root, state);
	if (state.trace && decision.trace.length) (context.traceRounds ?? (context.traceRounds = [])).push([...decision.trace]);
	for (const failure of decision.failures) recordSettlementFailure(context, new SchemaFormError(FormErrorCode.ExpressionThrew, `Reset interaction expression failed at ${failure.schemaPath}`, {
		path: failure.sourcePath,
		schemaPath: failure.schemaPath,
		cause: failure.cause
	}), "expression");
	for (const node of decision.nodes) {
		node.interactionReset += 1;
		const previous = node.interactionState;
		node.interactionState = captureFieldNodeChange(node, "interactionState", shallowPatch(node.interactionState, CLEAN_STATE_PATCH));
		if (node.interactionState !== previous) context.changedNodes.add(node);
	}
	const runtime = context.root.runtime;
	for (const path of state.visitedSourcePaths) pruneCommittedRuleKeys(runtime, path, "source");
	for (const exited of context.exited) visitFieldNodes(exited, (node) => {
		pruneCommittedRuleKeys(runtime, node.path, "occurrence");
	}, { owned: true });
	for (const key of state.activeRuleKeys) if (state.consumedRuleValues.has(key)) updateCommittedRuleValue(runtime, key, "set", state.consumedRuleValues.get(key));
};

//#endregion
//#region src/core/engine/settle/utils/controls/prepareControlLayers.ts
const EMPTY_GROUPS$1 = Object.freeze({
	all: [],
	exit: []
});
const prepareControlLayers = (node) => {
	const record = getHostDerived(node);
	if (record.controlLayerIndex) return record.controlLayerIndex;
	const ids = [];
	const groups = [];
	const fragments = /* @__PURE__ */ new Map();
	const fields = /* @__PURE__ */ new Map();
	let order = 0;
	let hasExitControls = false;
	for (const declaration of node.declarations) {
		ids.push(declaration.id);
		if (!declaration.schema || typeof declaration.schema !== "object") continue;
		const controls = Reflect.get(declaration.schema, SCHEMA_GROUP.controls);
		if (!controls || typeof controls !== "object" || isArray(controls)) continue;
		hasExitControls || (hasExitControls = hasOwnProperty(controls, CONTROL_KEY.unsetOnInactive));
		const group = {
			layer: declaration.scope === "node" ? "node" : "fragment",
			declarationId: declaration.id,
			schemaPath: appendSegment(declaration.schemaPath, "controls"),
			controls,
			order: order++
		};
		if (declaration.scope === "node") groups.push(group);
		else {
			let atPath = fragments.get(declaration.schemaPath);
			if (!atPath) fragments.set(declaration.schemaPath, atPath = []);
			atPath.push(group);
		}
		const items = Reflect.get(controls, CONTROL_KEY.fields);
		if (!isArray(items)) continue;
		for (let index = 0; index < items.length; index++) {
			const item = items[index];
			if (!item || typeof item !== "object") continue;
			const targets = Reflect.get(item, "targets");
			if (!isArray(targets)) continue;
			const itemControls = Reflect.get(item, SCHEMA_GROUP.controls);
			if (!itemControls || typeof itemControls !== "object" || isArray(itemControls)) continue;
			const field = {
				layer: "fields",
				declarationId: declaration.id,
				schemaPath: appendSegment(appendSegment(appendSegment(appendSegment(declaration.schemaPath, "controls"), "fields"), index), "controls"),
				controls: itemControls,
				order: order++
			};
			hasExitControls || (hasExitControls = hasOwnProperty(itemControls, CONTROL_KEY.unsetOnInactive));
			for (const target of targets) {
				if (typeof target !== "string") continue;
				let addressed = fields.get(target);
				if (!addressed) fields.set(target, addressed = []);
				if (addressed[addressed.length - 1] !== field) addressed.push(field);
			}
		}
	}
	return record.controlLayerIndex = {
		hasExitControls,
		ids: Object.freeze(ids),
		node: groups.length ? {
			all: groups,
			exit: groups.filter((group) => hasOwnProperty(group.controls, CONTROL_KEY.unsetOnInactive))
		} : EMPTY_GROUPS$1,
		fragments: fragments.size ? fragments : emptyReadonlyMap,
		fields: fields.size ? fields : emptyReadonlyMap
	};
};

//#endregion
//#region src/core/engine/settle/utils/controls/prepareFragmentOwners.ts
const prepareFragmentOwners = (node, runtime) => {
	const index = prepareControlLayers(node);
	if (index.owners) return index.owners;
	const owners = /* @__PURE__ */ new Map();
	for (const declaration of node.declarations) for (const path of getFragmentOwnerPaths(declaration.schemaPath, runtime?.blueprint ? getDependencyIndex(runtime.blueprint).pathSegments(declaration.schemaPath, runtime) : void 0)) {
		let ids = owners.get(path);
		if (!ids) owners.set(path, ids = []);
		ids.push(declaration.id);
	}
	return index.owners = owners;
};

//#endregion
//#region src/core/engine/settle/utils/controls/prepareParentControlLayers.ts
const EMPTY_GROUPS = Object.freeze({
	all: [],
	exit: []
});
const prepareParentControlLayers = (parent, node, name, runtime) => {
	const index = prepareControlLayers(parent);
	if (!index.fields.size && !index.fragments.size) return EMPTY_GROUPS;
	const targetName = index.fields.has(name) ? name : void 0;
	const bindings = index.targets ?? (index.targets = /* @__PURE__ */ new WeakMap());
	let targets = bindings.get(node);
	if (!targets) bindings.set(node, targets = /* @__PURE__ */ new Map());
	const previous = targets.get(targetName);
	if (previous) return previous;
	const groups = [...index.fields.get(name) ?? []];
	if (index.fragments.size) for (const [path, ownerIds] of prepareFragmentOwners(node, runtime)) for (const fragment of index.fragments.get(path) ?? []) groups.push({
		...fragment,
		ownerIds
	});
	groups.sort((left, right) => left.order - right.order);
	const prepared = {
		all: groups,
		exit: groups.filter((group) => hasOwnProperty(group.controls, CONTROL_KEY.unsetOnInactive))
	};
	targets.set(targetName, prepared);
	return prepared;
};

//#endregion
//#region src/core/engine/settle/utils/controls/getControlLayers.ts
const getControlLayers = (node, selectedDeclarationIds, exitOnly = false) => {
	const prepared = prepareControlLayers(node.blueprintNode);
	const own = exitOnly ? prepared.node.exit : prepared.node.all;
	const parent = node.parent;
	if (exitOnly && !prepared.hasExitControls && (!parent || !prepareControlLayers(parent.blueprintNode).hasExitControls)) return [];
	const addressed = parent ? prepareParentControlLayers(parent.blueprintNode, node.blueprintNode, node.name, node.runtime) : void 0;
	const inherited = exitOnly ? addressed?.exit : addressed?.all;
	if (!own.length && !inherited?.length) return [];
	const selected = (current) => selectedDeclarationIds.get(current) ?? current.runtime.committedDeclarationIds?.get(getCommittedDeclarationKey(current, current.runtime)) ?? prepareControlLayers(current.blueprintNode).ids;
	const nodeIds = selected(node);
	const groups = [];
	for (const group of own) if (nodeIds.includes(group.declarationId)) groups.push({
		layer: group.layer,
		declarationId: group.declarationId,
		schemaPath: group.schemaPath,
		controls: group.controls,
		host: node
	});
	if (!parent || !inherited?.length) return groups;
	const parentIds = selected(parent);
	for (const group of inherited) {
		if (!parentIds.includes(group.declarationId)) continue;
		if (group.ownerIds && !group.ownerIds.some((id) => nodeIds.includes(id))) continue;
		groups.push({
			layer: group.layer,
			declarationId: group.declarationId,
			schemaPath: group.schemaPath,
			controls: group.controls,
			host: parent
		});
	}
	return groups;
};

//#endregion
//#region src/core/engine/settle/utils/controls/getExitPolicyKey.ts
const getExitPolicyKey = (group) => JSON.stringify([
	group.host.path,
	getBlueprintNodeIdentity(group.host.blueprintNode),
	group.declarationId,
	appendSegment(group.schemaPath, "unsetOnInactive"),
	void 0
]);

//#endregion
//#region src/core/engine/settle/utils/controls/getStateDependencyPlan.ts
const getStateDependencyPlan = (runtime, hostPath, dependency, owner = runtime) => {
	const derived = getHostDerived(owner);
	let plans = derived.stateDependencyPlans;
	if (!plans || plans.hostPath !== hostPath) derived.stateDependencyPlans = plans = {
		hostPath,
		dependencies: /* @__PURE__ */ new Map()
	};
	let plan = plans.dependencies.get(dependency);
	if (!plan) {
		const path = resolveDependencyPath(hostPath, dependency);
		plan = {
			path,
			segments: getCachedPointerSegments(runtime, path)
		};
		plans.dependencies.set(dependency, plan);
	}
	return plan;
};

//#endregion
//#region src/core/engine/settle/utils/controls/readStateDependency.ts
const readStateDependency = (root, hostPath, dependency, snapshot, owner = root.runtime, absentContext) => {
	const { segments } = getStateDependencyPlan(root.runtime, hostPath, dependency, owner);
	if (segments[0] === PointerOperator.Context) return (snapshot ? snapshot.context : root.runtime.context) ?? absentContext ?? {};
	let value = snapshot ? snapshot.emit : root.emit;
	for (const name of segments) {
		if (value === null || typeof value !== "object") return void 0;
		if (typeof name !== "string") return void 0;
		if (!hasOwnProperty(value, name)) return void 0;
		value = Reflect.get(value, name);
	}
	return value;
};

//#endregion
//#region src/core/engine/settle/utils/dependencies/isDependencyOwner.ts
const isDependencyOwner = (context, path) => {
	const owner = context.splitHitEpochs ? getDependencyIndex(context.root.runtime.blueprint).splitOwners.get(path) : void 0;
	const result = context.dependencyOwnerPaths.has(path) || !!owner && !!context.splitHitEpochs?.has(owner.bucket);
	if (context.registrationShadow) verifyGateSelection(result === context.registrationShadow.owners.has(path), "S3 dependency owner differs: " + path);
	return result;
};

//#endregion
//#region src/core/engine/settle/utils/commit/commitExitPolicyValues.ts
const getExitExpressions = (blueprint) => {
	let indexed = getBlueprintDerived(blueprint).exitPolicyExpressions;
	if (indexed) return indexed;
	indexed = new Map(blueprint.expressions.filter((expression) => expression.key === "unsetOnInactive").map((expression) => [JSON.stringify([expression.declarationId, expression.schemaPath]), expression]));
	getBlueprintDerived(blueprint).exitPolicyExpressions = indexed;
	return indexed;
};
const commitExitPolicyValues = (context) => {
	const expressions = getExitExpressions(context.root.runtime.blueprint);
	if (expressions.size === 0) return;
	const runtime = context.root.runtime;
	for (const exited of context.exited) visitFieldNodes(exited, (node) => {
		pruneCommittedRuleKeys(runtime, node.path, "exitPolicy");
	}, { owned: true });
	if (context.kind === "load" && context.loadScope) visitFieldNodes(context.loadScope, (node) => {
		pruneCommittedRuleKeys(runtime, node.path, "exitPolicy");
	}, { owned: true });
	const candidates = new Set(context.stateDirtyNodes);
	for (const source of context.stateDirtyNodes) {
		if (source.detached || !source.structure) continue;
		if (context.kind !== "load" && !isDependencyOwner(context, source.path) && !context.shapeDirtyPaths.has(source.path)) continue;
		const sourceKey = JSON.stringify([source.path, getBlueprintNodeIdentity(source.blueprintNode)]);
		const selected = context.selectedDeclarationIds.get(source) ?? source.runtime.committedDeclarationIds?.get(sourceKey);
		for (const declaration of source.blueprintNode.declarations) {
			if (selected && !selected.includes(declaration.id)) continue;
			const schema = declaration.schema;
			if (!schema || typeof schema !== "object") continue;
			const controls = Reflect.get(schema, SCHEMA_GROUP.controls);
			if (!controls || typeof controls !== "object" || isArray(controls)) continue;
			if (declaration.scope === "fragment" && typeof Reflect.get(controls, CONTROL_KEY.unsetOnInactive) === "string") for (const child of source.children ?? []) {
				const childSelected = context.selectedDeclarationIds.get(child) ?? child.runtime.committedDeclarationIds?.get(getCommittedDeclarationKey(child, child.runtime));
				if (!child.blueprintNode.declarations.some((childDeclaration) => (!childSelected || childSelected.includes(childDeclaration.id)) && getFragmentOwnerPaths(childDeclaration.schemaPath).includes(declaration.schemaPath))) continue;
				candidates.add(child);
				break;
			}
			const fields = Reflect.get(controls, CONTROL_KEY.fields);
			if (!isArray(fields)) continue;
			for (const item of fields) {
				if (!item || typeof item !== "object") continue;
				const itemControls = Reflect.get(item, SCHEMA_GROUP.controls);
				if (!itemControls || typeof itemControls !== "object" || typeof Reflect.get(itemControls, CONTROL_KEY.unsetOnInactive) !== "string") continue;
				const targets = Reflect.get(item, "targets");
				if (!isArray(targets)) continue;
				for (const name of targets) {
					if (typeof name !== "string" || !hasOwnProperty(source.structure, name)) continue;
					candidates.add(source.structure[name]);
					break;
				}
			}
		}
	}
	const evaluated = /* @__PURE__ */ new Set();
	for (const node of candidates) {
		if (node.detached) continue;
		for (const group of getControlLayers(node, context.selectedDeclarationIds)) {
			if (!hasOwnProperty(group.controls, CONTROL_KEY.unsetOnInactive) || typeof Reflect.get(group.controls, CONTROL_KEY.unsetOnInactive) !== "string") continue;
			const schemaPath = appendSegment(group.schemaPath, "unsetOnInactive");
			const key = getExitPolicyKey(group);
			if (evaluated.has(key)) continue;
			evaluated.add(key);
			const expression = expressions.get(JSON.stringify([group.declarationId, schemaPath]));
			if (!expression) continue;
			try {
				updateCommittedRuleValue(runtime, key, "set", Boolean(expression.evaluate(expression.dependencies.map((dependency) => readStateDependency(context.root, group.host.path, dependency, void 0, group.host)))));
			} catch (cause) {
				updateCommittedRuleValue(runtime, key, "set", false);
				recordSettlementFailure(context, new SchemaFormError(FormErrorCode.ExpressionThrew, `Exit policy expression failed at ${schemaPath}`, {
					path: group.host.path,
					schemaPath,
					cause
				}), "expression");
			}
		}
	}
};

//#endregion
//#region src/core/engine/settle/utils/commit/conversionCandidates.ts
const conversionCandidates = (node, effective) => {
	const kinds = typeof effective === "string" ? [effective] : effective;
	const candidates = [];
	for (const kind of kinds) {
		if (kind === "null") continue;
		const converted = node.behavior.interpret(node.raw, {
			kinds: kind,
			mask: 0,
			nullable: node.nullable
		});
		if (!Object.is(converted, node.raw) && !isMisfit(converted, kind, node.nullable)) candidates.push(kind);
	}
	return candidates;
};

//#endregion
//#region src/core/engine/settle/utils/commit/effectiveType.ts
const effectiveType = (node) => {
	const schema = node.schema.schema;
	const candidate = typeof schema === "object" && schema !== null ? schema.type : void 0;
	if (typeof candidate === "string" && isTypeName(candidate)) return candidate;
	if (isArray(candidate) && candidate.every(isTypeName)) return candidate;
	return node.schemaType;
};
function isTypeName(value) {
	return value === "string" || value === "number" || value === "integer" || value === "boolean" || value === "null" || value === "object" || value === "array";
}

//#endregion
//#region src/core/engine/settle/utils/commit/finalizeDeriveTrace.ts
const finalizeDeriveTrace = (context) => {
	if (!context.traceRounds?.length) return;
	const live = /* @__PURE__ */ new Map();
	for (const round of context.traceRounds) for (let index = 0; index < round.length; index++) {
		const entry = round[index];
		if (entry.result !== "applied") continue;
		let exists = live.get(entry.targetPath);
		if (exists === void 0) {
			let node = context.root;
			for (const name of parsePointerSegments(entry.targetPath)) {
				if (typeof name !== "string") {
					node = void 0;
					break;
				}
				const children = node?.structure ?? null;
				node = children && hasOwnProperty(children, name) ? children[name] : void 0;
				if (!node) break;
			}
			exists = Boolean(node && !node.detached);
			live.set(entry.targetPath, exists);
		}
		if (!exists) round[index] = {
			...entry,
			result: "withdrawn"
		};
	}
};

//#endregion
//#region src/core/engine/settle/utils/controls/readFieldNodeWatchValues.ts
const EMPTY_WATCH_VALUES$1 = Object.freeze([]);
const readFieldNodeWatchValues = (node, snapshot) => {
	const runtime = node.runtime;
	const commit = runtime.commitNumber ?? 0;
	const memo = runtime.watchValuesMemo?.get(node);
	if (!snapshot && memo && node.detached) return memo.values;
	if (node.detached) return EMPTY_WATCH_VALUES$1;
	const schema = snapshot?.schema ?? node.schema.schema;
	const controls = typeof schema === "object" ? schema.controls : void 0;
	const watch = controls && typeof controls === "object" ? Reflect.get(controls, CONTROL_KEY.watch) : void 0;
	const paths = isArray(watch) ? watch : EMPTY_WATCH_VALUES$1;
	const reusable = !snapshot && memo?.commit === commit && memo.values.length === paths.length;
	const derived = getHostDerived(node);
	const witness = derived.watchValuesWitness;
	const selectedContext = snapshot ? snapshot.context : runtime.context;
	const reuseAbsentContext = reusable && witness !== void 0 && witness.schema === schema && witness.watch === watch && witness.path === node.path && !witness.snapshot && witness.contextAbsent && selectedContext == null;
	let next = reusable ? void 0 : [];
	for (let index = 0; index < paths.length; index++) {
		const path = paths[index];
		const previous = reuseAbsentContext ? memo.values[index] : void 0;
		const absentContext = previous !== null && typeof previous === "object" ? previous : void 0;
		const value = typeof path === "string" ? readStateDependency(node.rootNode, node.path, path, snapshot, node, absentContext) : void 0;
		if (!next && !Object.is(value, memo.values[index])) next = memo.values.slice(0, index);
		next?.push(value);
	}
	if (witness) {
		witness.schema = schema;
		witness.watch = watch;
		witness.path = node.path;
		witness.snapshot = snapshot !== void 0;
		witness.contextAbsent = selectedContext == null;
	} else derived.watchValuesWitness = {
		schema,
		watch,
		path: node.path,
		snapshot: snapshot !== void 0,
		contextAbsent: selectedContext == null
	};
	if (!next) return memo.values;
	const values = next.length ? Object.freeze(next) : EMPTY_WATCH_VALUES$1;
	const cache = runtime.watchValuesMemo ?? /* @__PURE__ */ new WeakMap();
	cache.set(node, {
		commit,
		values
	});
	runtime.watchValuesMemo = cache;
	return values;
};

//#endregion
//#region src/core/engine/settle/utils/commit/commitGlobalState.ts
const commitGlobalState = (context) => {
	const hadGlobalState = context.root.runtime.globalStateCounts.size > 0;
	const deltas = /* @__PURE__ */ new Map();
	const departing = /* @__PURE__ */ new Set();
	const pending = [...context.exited];
	for (const node of context.perished) if (node.detached) pending.push(node);
	while (pending.length) {
		const node = pending.pop();
		if (!node || departing.has(node)) continue;
		departing.add(node);
		for (const child of node.children ?? []) pending.push(child);
	}
	let loadNodes;
	if (context.kind === "load" && context.loadScope && !context.loadScope.detached) {
		const pending = [context.loadScope];
		loadNodes = /* @__PURE__ */ new Set();
		while (pending.length) {
			const node = pending.pop();
			if (!node || node.detached || loadNodes.has(node)) continue;
			loadNodes.add(node);
			for (const child of node.children ?? []) pending.push(child);
		}
	}
	return {
		departing,
		loadNodes,
		visit(node) {
			const previousState = node.deliveryChanges & 8 ? node.deliveryPreviousState ?? node.interactionState : node.interactionState;
			if (departing.size && departing.has(node)) {
				if (!context.entered.has(node) || node.deliveryInitialized) accumulateGlobalStateDeltas(deltas, previousState, {});
				if (node.detached) return;
			}
			if (node.detached) return;
			if (context.entered.size && context.entered.has(node)) {
				accumulateGlobalStateDeltas(deltas, node.deliveryInitialized ? previousState : {}, node.interactionState);
				return;
			}
			if (!hadGlobalState) {
				for (const key in node.interactionState) if (hasOwnProperty(node.interactionState, key) && node.interactionState[key]) deltas.set(key, (deltas.get(key) ?? 0) + 1);
				return;
			}
			const previous = previousState;
			if (previous !== node.interactionState) accumulateGlobalStateDeltas(deltas, previous, node.interactionState);
		},
		finish() {
			publishGlobalStateDeltas(context.root, deltas);
		}
	};
};

//#endregion
//#region src/core/engine/settle/utils/commit/utils/createWatchDeliveryIndex.ts
var WatchDeliveryIndex = class {
	constructor(runtime = {}) {
		this.runtime = runtime;
		this.allNodes = /* @__PURE__ */ new Set();
		this.contextNodes = /* @__PURE__ */ new Set();
		this.pathsByNode = /* @__PURE__ */ new Map();
		this.root = {
			watchers: /* @__PURE__ */ new Set(),
			children: /* @__PURE__ */ new Map()
		};
	}
	update(node, paths) {
		const previous = this.pathsByNode.get(node);
		if (previous?.length === paths.length && previous.every((entry, index) => entry.path === paths[index])) return;
		this.remove(node);
		const unique = [];
		for (const path of paths) if (!unique.some((entry) => entry.path === path)) unique.push({
			path,
			segments: getCachedPointerSegments(this.runtime, path)
		});
		if (unique.length === 0) return;
		this.pathsByNode.set(node, unique);
		this.allNodes.add(node);
		for (const { segments } of unique) {
			if (segments[0] === PointerOperator.Context) {
				this.contextNodes.add(node);
				continue;
			}
			let current = this.root;
			for (const segment of segments) {
				let child = current.children.get(segment);
				if (!child) {
					child = {
						watchers: /* @__PURE__ */ new Set(),
						children: /* @__PURE__ */ new Map()
					};
					current.children.set(segment, child);
				}
				current = child;
			}
			current.watchers.add(node);
		}
	}
	remove(node) {
		const paths = this.pathsByNode.get(node);
		if (!paths) return;
		this.pathsByNode.delete(node);
		this.allNodes.delete(node);
		this.contextNodes.delete(node);
		for (const { segments } of paths) {
			if (segments[0] === PointerOperator.Context) continue;
			const parents = [this.root];
			for (const segment of segments) {
				const child = parents[parents.length - 1].children.get(segment);
				if (!child) break;
				parents.push(child);
			}
			if (parents.length !== segments.length + 1) continue;
			parents[parents.length - 1].watchers.delete(node);
			for (let index = segments.length - 1; index >= 0; index--) {
				const child = parents[index + 1];
				if (child.watchers.size || child.children.size) break;
				parents[index].children.delete(segments[index]);
			}
		}
	}
	affected(path, candidates) {
		let current = this.root;
		for (const watcher of current.watchers) candidates.add(watcher);
		for (const segment of getCachedPointerSegments(this.runtime, path)) {
			current = current.children.get(segment);
			if (!current) return;
			for (const watcher of current.watchers) candidates.add(watcher);
		}
		const pending = [...current.children.values()];
		while (pending.length) {
			const child = pending.pop();
			if (!child) continue;
			for (const watcher of child.watchers) candidates.add(watcher);
			for (const next of child.children.values()) pending.push(next);
		}
	}
};
const createWatchDeliveryIndex = (runtime) => new WatchDeliveryIndex(runtime);

//#endregion
//#region src/core/engine/settle/utils/commit/utils/getWatchDeliveryPaths.ts
const NO_PATHS$1 = Object.freeze([]);
const getWatchDeliveryPaths = (node) => {
	const schema = node.schema.schema;
	const controls = typeof schema === "object" ? schema.controls : void 0;
	const watch = controls && typeof controls === "object" ? Reflect.get(controls, CONTROL_KEY.watch) : void 0;
	if (!isArray(watch)) return NO_PATHS$1;
	const paths = [];
	for (const path of watch) if (typeof path === "string") paths.push(getStateDependencyPlan(node.runtime, node.path, path, node).path);
	return paths;
};

//#endregion
//#region src/core/engine/settle/utils/commit/utils/readSettlementSource.ts
const readSettlementSource = (context, path, exact = false) => {
	const origins = context.writeOrigins;
	for (let index = (origins?.length ?? 0) - 1; index >= 0; index--) {
		const origin = origins[index];
		if (origin.keys && path !== origin.path) {
			const child = getChildPointer(path, origin.path);
			const name = child === void 0 ? void 0 : readPointerSegment(child, -1);
			if (typeof name !== "string" || !origin.keys.includes(name)) continue;
		}
		if (path === origin.path || isDescendantPath(path, origin.path)) return !exact || path === origin.path ? origin.source : void 0;
	}
	return !exact || path === context.target.path ? context.source ?? context.kind : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/commit/markCommitDeliveries.ts
const EMPTY_WATCH_VALUES = Object.freeze([]);
const markCommitDeliveries = (context, visit) => {
	const runtime = context.root.runtime;
	runtime.deliveries ?? (runtime.deliveries = /* @__PURE__ */ new Set());
	const previousTransitions = runtime.revisionTransitions;
	try {
		const refreshTargets = runtime.refreshTargets;
		const loadScope = context.kind === "load" ? context.loadScope : void 0;
		const automaticNodes = /* @__PURE__ */ new Set();
		for (let index = 0; index < context.automaticLog.length; index++) automaticNodes.add(context.automaticLog[index].node);
		const watchIndex = runtime.deliveryWatchIndex;
		const watchNodes = getFeatureNodeIndex(runtime.blueprint).watchNodes;
		let affectedPaths;
		if (watchIndex?.allNodes.size) {
			affectedPaths = runtime.deliveryAffectedPaths ?? /* @__PURE__ */ new Set();
			for (const node of context.entered) affectedPaths.add(node.path);
			for (const node of context.exited) affectedPaths.add(node.deliveryPreviousPath ?? node.path);
			for (const node of context.perished) affectedPaths.add(node.deliveryPreviousPath ?? node.path);
			for (const change of context.pathChanges) {
				affectedPaths.add(change.previous);
				affectedPaths.add(change.current);
			}
			for (const path of affectedPaths) {
				let ancestor = path;
				while (ancestor) {
					ancestor = resolvePointer(ancestor, "..");
					if (!context.changedRaw.has(ancestor)) affectedPaths.delete(ancestor);
				}
			}
		}
		const candidates = /* @__PURE__ */ new Set();
		for (const host of context.changedNodes) {
			if (host.detached || host.blueprintNode.kind !== "object" || !host.children) continue;
			if (host.deliveryInitialized && host.deliveryPreviousSchema === void 0 && !(host.deliveryChanges & 128)) continue;
			const schema = host.schema.schema;
			const required = typeof schema === "object" ? schema.required : void 0;
			for (let index = 0; index < host.children.length; index++) {
				const child = host.children[index];
				if (child.parent !== host || child.blueprintNode.kind === "virtual") continue;
				const next = isArray(required) && required.includes(child.name);
				if (child.required === next) continue;
				child.required = next;
				candidates.add(child);
				if (child.deliveryInitialized) markFieldNodeEvent(child, 256);
			}
		}
		candidates.add(context.root);
		for (const change of context.pathChanges) candidates.add(change.node);
		if (watchIndex) {
			if (runtime.deliveredContext !== runtime.context) for (const watcher of watchIndex.contextNodes) candidates.add(watcher);
			if (affectedPaths) for (const path of affectedPaths) watchIndex.affected(path, candidates);
		}
		const isTreeNode = (value) => value !== null && typeof value === "object" && Reflect.get(value, "runtime") === runtime;
		let silentMask = 0;
		const markSilent = (_node, bit) => {
			silentMask |= bit;
		};
		let mark = markFieldNodeEvent;
		for (const node of runtime.revisionNodes ?? []) candidates.add(node);
		if (runtime.deliveredDiagnostics && runtime.deliveredDiagnostics !== runtime.diagnostics) mark(context.root, 65536);
		runtime.deliveredDiagnostics = runtime.diagnostics;
		const globalState = commitGlobalState(context);
		const { departing: globalDeparting, loadNodes } = globalState;
		const { entered, changedNodes, stateDirtyNodes } = context;
		const sources = [
			globalDeparting,
			entered,
			changedNodes,
			stateDirtyNodes,
			loadNodes,
			candidates
		];
		let sourceIndex = 0;
		let iterator = globalDeparting.values();
		while (true) {
			const next = iterator.next();
			if (next.done) {
				do
					sourceIndex++;
				while (sourceIndex < sources.length && !sources[sourceIndex]?.size);
				if (sourceIndex === sources.length) break;
				iterator = sources[sourceIndex].values();
				continue;
			}
			const candidate = next.value;
			if (!isTreeNode(candidate)) continue;
			const node = candidate;
			if (sourceIndex > 0 && globalDeparting.size && globalDeparting.has(node) || sourceIndex > 1 && entered.size && entered.has(node) || sourceIndex > 2 && changedNodes.size && changedNodes.has(node) || sourceIndex > 3 && stateDirtyNodes.size && stateDirtyNodes.has(node) || sourceIndex > 4 && loadNodes?.size && loadNodes.has(node)) continue;
			visit?.(node);
			if (sourceIndex < 5) globalState.visit(node);
			if (!(sourceIndex >= 1 && sourceIndex <= 3) && sourceIndex !== 5 && !candidates.has(node) && !(entered.size && entered.has(node)) && !(changedNodes.size && changedNodes.has(node)) && !(stateDirtyNodes.size && stateDirtyNodes.has(node))) {
				clearFieldNodeChanges(node);
				continue;
			}
			if (node.detached) {
				clearFieldNodeChanges(node);
				node.deliveryWatchValues = void 0;
				watchIndex?.remove(node);
				continue;
			}
			const initialized = node.deliveryInitialized;
			const changes = node.deliveryChanges;
			const previousWatchValues = node.deliveryWatchValues ?? EMPTY_WATCH_VALUES;
			const pending = node.pendingDelivery?.payload;
			const hasWatch = watchNodes.has(node.blueprintNode.id);
			const watched = hasWatch ? readFieldNodeWatchValues(node) : EMPTY_WATCH_VALUES;
			if (hasWatch) if (watched.length) (runtime.deliveryWatchIndex ?? (runtime.deliveryWatchIndex = createWatchDeliveryIndex(runtime))).update(node, getWatchDeliveryPaths(node));
			else runtime.deliveryWatchIndex?.remove(node);
			let watchChanged = initialized && watched.length !== previousWatchValues.length;
			for (let index = 0; initialized && !watchChanged && index < watched.length; index++) if (!isSameDeliveryValue(watched[index], previousWatchValues[index])) watchChanged = true;
			const silent = canOmitFieldNodePayload(node);
			mark = silent ? markSilent : markFieldNodeEvent;
			silentMask = 0;
			if (initialized) {
				if (changes & 4 && (!isSameDeliveryValue(node.deliveryPreviousLocal, node.local) || !isSameDeliveryValue(node.deliveryPreviousEmit, node.emit))) if (silent) mark(node, 4);
				else {
					const pendingValue = pending?.[4];
					const payload = {
						previous: pendingValue !== null && typeof pendingValue === "object" ? Reflect.get(pendingValue, "previous") : node.behavior.strategy === "branch" ? {
							local: node.deliveryPreviousLocal,
							emit: node.deliveryPreviousEmit
						} : node.deliveryPreviousLocal,
						current: node.behavior.strategy === "branch" ? {
							local: node.local,
							emit: node.emit
						} : node.local
					};
					const source = automaticNodes.has(node) || context.filledNodes.has(node) ? "automatic" : readSettlementSource(context, node.path);
					mark(node, 4, __SCHEMA_FORM_DEV__ ? Object.freeze(payload) : payload, { source });
				}
				if (changes & 2 && node.deliveryPreviousPath !== node.path) if (silent) mark(node, 2);
				else {
					const pendingPath = pending?.[2];
					const payload = {
						previous: pendingPath !== null && typeof pendingPath === "object" ? Reflect.get(pendingPath, "previous") : node.deliveryPreviousPath,
						current: node.path
					};
					mark(node, 2, __SCHEMA_FORM_DEV__ ? Object.freeze(payload) : payload);
				}
				if (changes & 128 && node.deliveryPreviousChildren !== node.children) mark(node, 128);
				if (changes & 8 && node.deliveryPreviousState !== node.interactionState) {
					runtime.stateChanged = true;
					if (!((node.pendingNonSettleDelivery?.type ?? 0) & 8)) mark(node, 8);
				}
				if (changes & 256 && node.deliveryPreviousComputed !== (+node.active | +node.visible << 1 | +node.readOnly << 2 | +node.disabled << 3) || watchChanged) mark(node, 256);
				if (changes & 32768 && node.deliveryPreviousSchema !== node.schema) if (silent) mark(node, 32768);
				else {
					const pendingSchema = pending?.[32768];
					const payload = {
						previous: pendingSchema !== null && typeof pendingSchema === "object" ? Reflect.get(pendingSchema, "previous") : node.deliveryPreviousSchema?.schema,
						current: node.schema.schema
					};
					mark(node, 32768, __SCHEMA_FORM_DEV__ ? Object.freeze(payload) : payload);
				}
			} else if (context.changedNodes.has(node)) if (silent) mark(node, 4);
			else {
				const payload = {
					previous: void 0,
					current: node.behavior.strategy === "branch" ? {
						local: node.local,
						emit: node.emit
					} : node.local
				};
				const source = automaticNodes.has(node) || context.filledNodes.has(node) ? "automatic" : readSettlementSource(context, node.path);
				mark(node, 4, __SCHEMA_FORM_DEV__ ? Object.freeze(payload) : payload, { source });
			}
			if (loadScope && (node === loadScope || isDescendantPath(node.path, loadScope.path))) mark(node, 8192);
			else if (refreshTargets?.has(node.path)) mark(node, 8192);
			node.deliveryInitialized = true;
			if (hasWatch) node.deliveryWatchValues = watched;
			clearFieldNodeChanges(node);
			if (silentMask) node.pendingRevision |= silentMask;
			if (node.pendingRevision) {
				if (silent) advanceFieldNodeRevision(node, node.pendingRevision, silent);
				else node.revisionLedger = new FieldNodeRevisionLedger(node.revisionLedger, node.pendingRevision);
				node.pendingRevision = 0;
			}
		}
		globalState.finish();
		runtime.revisionNodes?.clear();
		const departing = [];
		for (const node of context.exited) departing.push(node);
		for (const node of context.perished) departing.push(node);
		const seenDeparting = /* @__PURE__ */ new Set();
		while (departing.length) {
			const node = departing.pop();
			if (!node || !node.detached || seenDeparting.has(node)) continue;
			seenDeparting.add(node);
			clearFieldNodeChanges(node);
			node.deliveryWatchValues = void 0;
			node.pendingDelivery = void 0;
			node.pendingRevision = 0;
			node.pendingNonSettleDelivery = void 0;
			runtime.deliveryWatchIndex?.remove(node);
			runtime.deliveries?.delete(node);
			runtime.revisionNodes?.delete(node);
			runtime.queuedNonSettleEvents?.delete(node);
			runtime.validationErrors?.delete(node);
			runtime.nodeErrors?.delete(node);
			if (runtime.externalContributions?.has(node)) (runtime.pendingExternalErrorNodes ?? (runtime.pendingExternalErrorNodes = /* @__PURE__ */ new Set())).add(node);
			runtime.combinedErrors?.delete(node);
			runtime.validationChangedNodes?.delete(node);
			runtime.validationTargets?.delete(node);
			runtime.validationPendingTargets?.delete(node);
			const children = node.children;
			for (let index = 0; children && index < children.length; index++) departing.push(children[index]);
		}
		runtime.deliveredContext = runtime.context;
		runtime.deliveryAffectedPaths = void 0;
	} finally {
		if (runtime.revisionTransitions !== previousTransitions) runtime.revisionTransitions = previousTransitions;
	}
};

//#endregion
//#region src/core/engine/settle/utils/commit/receivedType.ts
const receivedType = (value) => {
	if (value === null) return "null";
	if (typeof value === "number") return !Number.isFinite(value) ? "nonFinite" : Number.isInteger(value) ? "integer" : "number";
	if (typeof value === "string") return "string";
	if (typeof value === "boolean") return "boolean";
	if (isArray(value)) return "array";
	if (typeof value === "object") return "object";
	return "other";
};

//#endregion
//#region src/core/engine/settle/utils/commit/commitSettlement.ts
const EMPTY_PATHS$2 = Object.freeze([]);
const EMPTY_WARNINGS$1 = Object.freeze([]);
const commitSettlement = (context) => {
	const runtime = context.root.runtime;
	const development = __SCHEMA_FORM_DEV__;
	if (runtime.blueprint.capabilities.hasDerive) commitDeriveRules(context);
	if (runtime.blueprint.capabilities.hasExpressions) commitExitPolicyValues(context);
	if (development) {
		if (context.traceRounds?.length) finalizeDeriveTrace(context);
		runtime.settlementTrace = {
			entry: {
				api: context.entryApi ?? context.kind,
				option: context.option
			},
			rounds: context.traceRounds ?? [],
			...context.deriveBudgetRules ? { budget: context.deriveBudgetRules } : {}
		};
	} else delete runtime.settlementTrace;
	const commit = (runtime.commitNumber ?? 0) + 1;
	runtime.commitNumber = commit;
	if (context.hasGates) {
		const declarations = runtime.committedDeclarationIds ?? (runtime.committedDeclarationIds = new PathKeyedMap("pair"));
		for (const [node, ids] of context.selectedDeclarationIds) if (!node.detached) declarations.set(getCommittedDeclarationKey(node, node.runtime), ids);
	}
	if (context.failures?.length && runtime.diagnostics.status !== "degraded") runtime.diagnostics = {
		status: "degraded",
		cause: context.cause,
		...context.exceededBudget ? {
			exceededBudget: context.exceededBudget,
			iterations: context.iterations
		} : {},
		commit
	};
	const refreshTargets = runtime.refreshTargets ?? /* @__PURE__ */ new Set();
	refreshTargets.clear();
	const loadScope = context.kind === "load" ? context.loadScope : void 0;
	for (const path of context.changedRaw) {
		if (loadScope && (path === loadScope.path || isDescendantPath(path, loadScope.path))) continue;
		if (readSettlementSource(context, path, true) !== "input") refreshTargets.add(path);
	}
	runtime.refreshTargets = refreshTargets;
	let warnings;
	let warningTasks;
	markCommitDeliveries(context, (node) => {
		if (!context.changedNodes.has(node) || node.detached) return;
		const schemaType = node.schemaType;
		const effective = effectiveType(node);
		if (schemaType === void 0 || effective === void 0) return;
		const misfit = isMisfit(node.raw, effective, node.nullable);
		const wasOn = runtime.misfitPaths.has(node.path);
		if (misfit) runtime.misfitPaths.add(node.path);
		else runtime.misfitPaths.delete(node.path);
		if (!(misfit && !wasOn) && !(development && node.behavior.strategy === "terminal" && node.raw !== null && typeof node.raw === "object" && context.changedRaw.has(node.path))) return;
		(warningTasks ?? (warningTasks = /* @__PURE__ */ new Map())).set(node, () => {
			if (misfit && !wasOn) {
				const candidates = conversionCandidates(node, effective);
				const ambiguous = candidates.length > 1;
				const warning = {
					level: "warning",
					code: FormWarningCode.Misfit,
					path: node.path,
					expected: {
						schemaType,
						nullable: node.nullable,
						effective
					},
					received: receivedType(node.raw),
					reason: ambiguous ? "ambiguous" : "unconvertible",
					...ambiguous ? { candidates } : {},
					source: context.filledNodes.has(node) ? "fill" : context.kind === "load" && context.entered.has(node) ? "load" : context.changedRaw.has(node.path) ? context.kind : "gate"
				};
				if (!warnings) warnings = [];
				warnings.push(warning);
				if (runtime.errorReporter?.hasConsumer()) {
					const code = FormWarningCode.Misfit;
					const record = {
						level: "warning",
						code,
						path: node.path,
						message: "Value does not fit the schema type at " + node.path + " (commit " + commit + ")",
						details: {
							path: node.path,
							expected: warning.expected,
							received: warning.received,
							reason: warning.reason,
							...warning.candidates ? { candidates: warning.candidates } : {},
							source: warning.source
						}
					};
					indexFieldNodeWarning(runtime, JSON.stringify([
						code,
						node.path,
						commit
					]), node.path, record);
					runtime.chainOccurrences?.push({
						kind: "record",
						record
					});
				}
			}
			if (development && node.behavior.strategy === "terminal" && node.raw !== null && typeof node.raw === "object" && context.changedRaw.has(node.path)) {
				const innerPaths = collectNonJsonPaths(node.raw, node.path);
				if (innerPaths.length) {
					const code = FormWarningCode.NonJsonWholeValue;
					const key = JSON.stringify([code, node.path]);
					if (!runtime.warningKeys?.has(key)) {
						(runtime.warningKeys ?? (runtime.warningKeys = /* @__PURE__ */ new Set())).add(key);
						const record = {
							level: "warning",
							code,
							path: node.path,
							message: `Whole value at ${node.path} contains non-JSON data`,
							details: {
								path: node.path,
								innerPaths
							}
						};
						indexFieldNodeWarning(runtime, key, node.path, record);
						runtime.chainOccurrences?.push({
							kind: "record",
							record
						});
					}
				}
			}
		});
	});
	if (warningTasks) for (const node of context.changedNodes) warningTasks.get(node)?.();
	runtime.misfitRecords = warnings ? Object.freeze(warnings) : EMPTY_WARNINGS$1;
	const misfitsMemo = runtime.misfitsMemo ?? new PathKeyedMap("path");
	const built = runtime.misfitsMemoBuild;
	if (built?.memo !== misfitsMemo || built.mutations !== runtime.misfitPaths.mutations || built.size !== misfitsMemo.size) {
		if (runtime.misfitPaths.size === 0) {
			const empty = misfitsMemo.get("");
			if (misfitsMemo.size === 1 && empty?.paths.length === 0) empty.commit = commit;
			else {
				misfitsMemo.clear();
				misfitsMemo.set("", {
					commit,
					paths: EMPTY_PATHS$2
				});
			}
		} else {
			misfitsMemo.clear();
			const allPaths = [...runtime.misfitPaths].sort();
			misfitsMemo.set("", {
				commit,
				paths: Object.freeze(allPaths)
			});
			const byAncestor = /* @__PURE__ */ new Map();
			for (let index = 0; index < allPaths.length; index++) {
				const path = allPaths[index];
				let ancestor = path;
				while (ancestor) {
					let paths = byAncestor.get(ancestor);
					if (!paths) {
						paths = [];
						byAncestor.set(ancestor, paths);
					}
					paths.push(path);
					ancestor = resolvePointer(ancestor, "..");
				}
			}
			for (const [ancestor, paths] of byAncestor) misfitsMemo.set(ancestor, {
				commit,
				paths: Object.freeze(paths)
			});
		}
		runtime.misfitsMemoBuild = {
			memo: misfitsMemo,
			size: misfitsMemo.size,
			mutations: runtime.misfitPaths.mutations
		};
	}
	runtime.misfitsMemo = misfitsMemo;
	for (const node of context.entered) if (!node.detached) {
		if (node.inactiveValueMemo !== void 0) node.inactiveValueMemo = void 0;
		const parent = node.parent;
		if (parent && (parent.inactiveSlots?.size || parent.inactiveSlotOverlays?.size)) (runtime.slotDirtyHosts ?? (runtime.slotDirtyHosts = /* @__PURE__ */ new Set())).add(parent);
	}
	if (runtime.slotDirtyHosts?.size) commitSlotChanges(context.root);
};

//#endregion
//#region src/core/engine/settle/utils/controls/calculateStateKeys.ts
const NO_FAILURES = Object.freeze([]);
const STATE_KEYS = {
	visible: {
		initial: true,
		combine: (left, right) => left && right
	},
	readOnly: {
		initial: false,
		combine: (left, right) => left || right
	},
	disabled: {
		initial: false,
		combine: (left, right) => left || right
	}
};
const KEY_NAMES = [
	CONTROL_KEY.visible,
	CONTROL_KEY.readOnly,
	CONTROL_KEY.disabled
];
const calculateStateKeys = (root, stateDirtyNodes, selectedDeclarationIds, expandFrom) => {
	const blueprint = root.runtime.blueprint;
	const index = getFeatureNodeIndex(blueprint);
	const isTarget = (node) => index.stateKeyNodes.has(node.blueprintNode.id) || !!node.parent && !!(index.stateKeyChildren.get(node.parent.blueprintNode.id)?.has(node.name) || node.parent.blueprintNode.kind === "array" && index.stateKeyChildren.get(node.parent.blueprintNode.id)?.has(JSONPointer.Wildcard));
	const candidates = /* @__PURE__ */ new Set();
	for (const node of stateDirtyNodes) if (isTarget(node)) candidates.add(node);
	for (const source of stateDirtyNodes) {
		const targets = index.stateKeyChildren.get(source.blueprintNode.id);
		if (!targets) continue;
		if (source.detached || !source.children?.length) continue;
		if (!expandFrom(source)) continue;
		for (const child of source.children) if (targets.has(child.name) || source.blueprintNode.kind === "array" && targets.has(JSONPointer.Wildcard)) candidates.add(child);
	}
	const evaluated = /* @__PURE__ */ new Map();
	const entries = [];
	let failures;
	for (const node of candidates) {
		if (node.detached || node.parent && node.parent.structure?.[node.name] !== node) continue;
		const schema = node.schema.schema;
		const next = {
			visible: STATE_KEYS.visible.initial,
			readOnly: typeof schema === "object" && schema.readOnly === true,
			disabled: STATE_KEYS.disabled.initial
		};
		for (const group of getControlLayers(node, selectedDeclarationIds)) for (const key of KEY_NAMES) {
			const literal = Reflect.get(group.controls, key);
			if (literal === void 0) continue;
			let value;
			if (typeof literal === "boolean") value = literal;
			else if (typeof literal === "string") {
				const schemaPath = appendSegment(group.schemaPath, key);
				const cacheKey = JSON.stringify([group.host.path, schemaPath]);
				if (evaluated.has(cacheKey)) value = evaluated.get(cacheKey);
				else {
					const expression = getControlExpression(blueprint, group.declarationId, schemaPath, key);
					if (expression) try {
						value = Boolean(expression.evaluate(expression.dependencies.map((dependency) => readStateDependency(root, group.host.path, dependency, void 0, group.host))));
					} catch (cause) {
						(failures ?? (failures = [])).push({
							path: group.host.path,
							schemaPath,
							cause
						});
					}
					evaluated.set(cacheKey, value);
				}
			}
			if (value !== void 0) next[key] = STATE_KEYS[key].combine(next[key], value);
		}
		entries.push({
			node,
			...next
		});
	}
	return {
		entries,
		failures: failures ?? NO_FAILURES
	};
};

//#endregion
//#region src/core/engine/settle/utils/compute/publishStateKeys.ts
const publishStateKeys = (context) => {
	const index = getFeatureNodeIndex(context.root.runtime.blueprint);
	if (!index.stateKeyNodes.size && !index.stateKeyChildren.size) return;
	const result = calculateStateKeys(context.root, context.stateDirtyNodes, context.selectedDeclarationIds, (source) => context.kind === "load" || isDependencyOwner(context, source.path) || context.shapeDirtyPaths.has(source.path));
	for (const { node, visible, readOnly, disabled } of result.entries) {
		if (node.visible !== visible || node.readOnly !== readOnly || node.disabled !== disabled) context.changedNodes.add(node);
		node.visible = captureFieldNodeChange(node, "visible", visible);
		node.readOnly = captureFieldNodeChange(node, "readOnly", readOnly);
		node.disabled = captureFieldNodeChange(node, "disabled", disabled);
	}
	for (const failure of result.failures) {
		const { path, schemaPath, cause } = failure;
		recordSettlementFailure(context, new SchemaFormError(FormErrorCode.ExpressionThrew, `State key expression failed at ${schemaPath}`, {
			path,
			schemaPath,
			cause
		}), "expression");
	}
};

//#endregion
//#region src/core/engine/settle/utils/derivation/captureDeriveBaseline.ts
const captureDeriveBaseline = (context) => {
	const state = getDeriveState(context);
	if (!state) return;
	state.consumedRuleValues.clear();
	evaluateDeriveRound(context.root, {
		...state,
		loadScope: void 0,
		suppressAutomaticWrites: true,
		trace: false
	});
};

//#endregion
//#region src/core/engine/settle/utils/derivation/collectDeriveSourcePaths.ts
const collectDeriveSourcePaths = (context) => {
	const paths = /* @__PURE__ */ new Set();
	for (const owner of context.contextOwners ?? []) paths.add(owner);
	const dependencies = getDependencyIndex(context.root.runtime.blueprint);
	for (const changed of context.changedRaw) {
		for (const owner of dependencies.affected(changed, context.root)) paths.add(owner);
		let path = changed;
		while (true) {
			paths.add(path);
			if (!path) break;
			path = resolvePointer(path, "..");
		}
	}
	for (const node of context.entered) {
		paths.add(node.path);
		if (node.parent) paths.add(node.parent.path);
	}
	for (const [node, ids] of context.selectedDeclarationIds) {
		const previous = node.runtime.committedDeclarationIds?.get(JSON.stringify([node.path, getBlueprintNodeIdentity(node.blueprintNode)]));
		if (!previous || previous.length !== ids.length || previous.some((id, index) => id !== ids[index])) paths.add(node.path);
	}
	return paths;
};

//#endregion
//#region src/core/engine/settle/utils/derivation/utils/applyDeriveWrite.ts
const applyDeriveWrite = (write, context) => {
	if (!write.target) {
		if (write.template && write.siblings && write.targetOrder) writeInactiveSource(context, write.targetPath, write.template, write.value, write.targetOrder, true, write.siblings, true);
		return;
	}
	if (write.target.blueprintNode.kind !== "virtual") {
		markWrite(write.target, write.value, context);
		return;
	}
	const values = isArray(write.value) ? write.value : [];
	const fields = write.target.blueprintNode.fields ?? [];
	for (let index = 0; index < fields.length; index++) {
		const sibling = write.target.parent?.structure?.[fields[index]];
		if (sibling) markWrite(sibling, values[index], context);
	}
};

//#endregion
//#region src/core/engine/settle/utils/derivation/runDeriveRounds.ts
const ERROR_CODES = {
	expression: FormErrorCode.ExpressionThrew,
	injectTarget: FormErrorCode.InjectTargetMissing,
	writeShape: FormErrorCode.InvalidVirtualNodeValues
};
const ERROR_LABELS = {
	expression: "Derive expression failed",
	injectTarget: "Injection target missing",
	writeShape: "Invalid virtual node values"
};
const runDeriveRounds = (context) => {
	const state = getDeriveState(context);
	if (!state || context.exceededBudget) return;
	const previousTransition = context.inTransition;
	try {
		while (true) {
			state.sourcePaths = context.loadScope ? void 0 : collectDeriveSourcePaths(context);
			const decision = evaluateDeriveRound(context.root, state);
			if (state.trace) (context.traceRounds ?? (context.traceRounds = [])).push([...decision.trace]);
			for (const failure of decision.failures) recordSettlementFailure(context, new SchemaFormError(ERROR_CODES[failure.kind], `${ERROR_LABELS[failure.kind]} at ${failure.schemaPath}`, {
				path: failure.targetPath ?? failure.sourcePath,
				schemaPath: failure.schemaPath,
				cause: failure.cause,
				...failure.kind === "injectTarget" || failure.kind === "writeShape" ? { sourcePath: failure.sourcePath } : {},
				...failure.expectedLength === void 0 ? {} : {
					expectedLength: failure.expectedLength,
					received: failure.cause
				}
			}), failure.kind, [
				failure.kind,
				failure.sourcePath,
				failure.targetPath ?? "",
				failure.schemaPath
			].join("\0"));
			const changed = [];
			for (let index = 0; index < decision.writes.length; index++) {
				const write = decision.writes[index];
				if (!write.target || write.target.blueprintNode.kind === "virtual" || !sameValue(write.target.emit, write.value)) changed.push(write);
			}
			if (changed.length === 0) return;
			if ((context.deriveRounds ?? 0) >= 25) {
				recordSettlementFailure(context, new SchemaFormError(FormErrorCode.BudgetExceeded, `Derive budget exceeded at ${context.target.path}`, { path: context.target.path }), "budget");
				context.exceededBudget = "derive";
				context.iterations = 25;
				context.deriveBudgetRules = decision.trace;
				return;
			}
			context.deriveRounds = (context.deriveRounds ?? 0) + 1;
			context.automaticChanged = false;
			context.automatic = true;
			context.inTransition = true;
			const terminalTargets = DeriveConvergenceTargets.getOrCollect(context.root.runtime.blueprint);
			let skipConfirmation = terminalTargets !== void 0 && decision.failures.length === 0;
			for (let index = 0; index < changed.length; index++) {
				const write = changed[index];
				if (skipConfirmation && !terminalTargets.has(write.targetPath)) skipConfirmation = false;
				applyDeriveWrite(write, context);
				state.appliedRanks.set(write.targetPath, Math.max(state.appliedRanks.get(write.targetPath) ?? 0, write.rank));
			}
			context.automatic = false;
			registerRecalculation(context);
			context.hostWheelExceeded = void 0;
			computeNode(context.root, context);
			if (context.hostWheelExceeded !== void 0 && !context.exceededBudget) {
				recordSettlementFailure(context, new SchemaFormError(FormErrorCode.BudgetExceeded, `Host wheel budget exceeded at ${context.target.path}`, { path: context.target.path }), "budget");
				context.exceededBudget = "hostWheel";
				context.iterations = context.hostWheelExceeded;
				return;
			}
			if (context.exceededBudget) return;
			if (skipConfirmation) {
				if (engineModes.deriveShadow) {
					state.sourcePaths = context.loadScope ? void 0 : collectDeriveSourcePaths(context);
					const confirmation = evaluateDeriveRound(context.root, state);
					if (confirmation.writes.length !== 0 || confirmation.failures.length !== 0) throw new Error("Derive convergence proof failed: confirmation was not empty");
				}
				if (state.trace) (context.traceRounds ?? (context.traceRounds = [])).push([]);
				return;
			}
		}
	} finally {
		context.automatic = false;
		context.inTransition = previousTransition;
	}
};

//#endregion
//#region src/core/engine/settle/utils/loadValues/setLoadValue.ts
const setLoadValue = (snapshot, path, value) => {
	if (sameValue(getLoadValue(snapshot, path), value)) return snapshot;
	if (!path) return value;
	const segments = parsePointerSegments(path);
	if (!segments.every((segment) => typeof segment === "string")) return snapshot;
	const ancestors = [snapshot];
	let source = snapshot;
	for (const segment of segments) {
		source = source !== null && typeof source === "object" ? Reflect.get(source, segment) : void 0;
		ancestors.push(source);
	}
	let next = value;
	for (let index = segments.length - 1; index >= 0; index--) {
		const parent = ancestors[index];
		const copy = isArray(parent) ? [...parent] : parent !== null && typeof parent === "object" ? { ...parent } : {};
		Reflect.set(copy, segments[index], next);
		next = copy;
	}
	return next;
};

//#endregion
//#region src/core/engine/settle/utils/loadValues/alignArraySnapshotSlots.ts
const alignArraySnapshotSlots = (hosts) => {
	if (!hosts.length) return;
	const runtime = hosts[0].runtime;
	let draft = runtime.loadSnapshot;
	const copies = /* @__PURE__ */ new Map();
	const draftContainers = /* @__PURE__ */ new Set();
	const holey = /* @__PURE__ */ new Set();
	const draftCopy = (source, path) => {
		if (source !== null && typeof source === "object") {
			if (draftContainers.has(source)) {
				if (isArray(source) && holey.has(source)) {
					for (let index = 0; index < source.length; index++) if (!(index in source)) source[index] = void 0;
					holey.delete(source);
				}
				return source;
			}
			let byPath = copies.get(source);
			const existing = byPath?.get(path);
			if (existing) return existing;
			const clone = isArray(source) ? [...source] : { ...source };
			if (!byPath) {
				byPath = /* @__PURE__ */ new Map();
				copies.set(source, byPath);
			}
			byPath.set(path, clone);
			draftContainers.add(clone);
			return clone;
		}
		const clone = {};
		draftContainers.add(clone);
		return clone;
	};
	for (const host of hosts) {
		const previous = getLoadValue(draft, host.path);
		if (!isArray(previous) && host.itemCount === 0) continue;
		const slots = isArray(previous) ? previous.slice(0, host.itemCount) : [];
		while (slots.length < host.itemCount) slots.push(void 0);
		if (sameValue(previous, slots)) continue;
		draftContainers.add(slots);
		holey.add(slots);
		if (!host.path) {
			draft = slots;
			continue;
		}
		const segments = parsePointerSegments(host.path);
		if (!segments.every((segment) => typeof segment === "string")) continue;
		let probe = draft;
		let byName = false;
		for (const segment of segments) {
			if (isArray(probe) && !isCanonicalArrayIndex(segment)) {
				byName = true;
				break;
			}
			probe = probe !== null && typeof probe === "object" ? Reflect.get(probe, segment) : void 0;
		}
		if (byName) {
			draft = setLoadValue(draft, host.path, slots);
			continue;
		}
		let parent = draftCopy(draft, "");
		draft = parent;
		let parentPath = "";
		for (let index = 0; index < segments.length - 1; index++) {
			const segment = segments[index];
			parentPath = appendSegment(parentPath, segments[index]);
			const child = draftCopy(Reflect.get(parent, segment), parentPath);
			if (isArray(parent) && Number(segment) > parent.length) holey.add(parent);
			Reflect.set(parent, segment, child);
			parent = child;
		}
		const segment = segments[segments.length - 1];
		if (isArray(parent) && Number(segment) > parent.length) holey.add(parent);
		Reflect.set(parent, segment, slots);
	}
	runtime.loadSnapshot = draft;
};

//#endregion
//#region src/core/engine/settle/utils/loadValues/readFieldNodeDefaultValue.ts
const readFieldNodeDefaultValue = (node) => node.detached ? node.runtime.detachedReads?.get(node)?.defaultValue : getLoadValue(node.runtime.loadSnapshot, node.path, node.runtime.blueprint.capabilities.branchless ? getCachedPointerSegments(node.runtime, node.path) : getDependencyIndex(node.runtime.blueprint).pathSegments(node.path, node.runtime));

//#endregion
//#region src/core/engine/settle/utils/detached/emptyDetachedReads.ts
const EMPTY_PATHS$1 = Object.freeze([]);
const EMPTY_VALUES = Object.freeze([]);

//#endregion
//#region src/core/engine/settle/utils/detached/captureDetachedFieldNodeReads.ts
const captureDetachedFieldNodeReads = (node, watchSnapshot, load) => {
	const runtime = node.runtime;
	runtime.watchValuesMemo?.delete(node);
	readFieldNodeWatchValues(node, watchSnapshot);
	const reads = Object.freeze({
		errors: readFieldNodeErrors(node),
		misfit: runtime.misfitPaths.has(node.path),
		misfits: runtime.misfitsMemo?.get(node.path)?.paths ?? EMPTY_PATHS$1,
		defaultValue: load ? load.value : readFieldNodeDefaultValue(node),
		visible: node.visible,
		readOnly: node.readOnly,
		disabled: node.disabled
	});
	const detachedReads = runtime.detachedReads ?? /* @__PURE__ */ new WeakMap();
	runtime.detachedReads = detachedReads;
	detachedReads.set(node, reads);
};

//#endregion
//#region src/core/engine/settle/utils/inactive/getInactiveValuePath.ts
const getInactiveValuePath = (node, context) => {
	if (!context.compactedSlotSources?.size) return node.path;
	const lineage = [];
	for (let current = node; current?.parent; current = current.parent) lineage.push(current);
	let path = "";
	for (let index = lineage.length - 1; index >= 0; index--) {
		const child = lineage[index];
		const compaction = child.parent && context.compactedSlotSources.get(child.parent);
		let name = child.name;
		if (compaction) {
			const binding = [...compaction.sources].find(([, source]) => source === child)?.[0];
			if (!binding) return void 0;
			name = binding.name;
		}
		path = appendSegment(path, name);
	}
	return path;
};

//#endregion
//#region src/core/engine/settle/utils/inactive/applyInactiveValues.ts
const applyInactiveValues = (context) => {
	if (!context.inactiveValueOverrides) return;
	const overrides = [...context.inactiveValueOverrides].sort(([left], [right]) => left.depth - right.depth);
	for (const [node, value] of overrides) {
		const path = getInactiveValuePath(node, context);
		if (path === void 0) continue;
		writeSlotPath(context.root, path, node.blueprintNode, value, true, context);
	}
};

//#endregion
//#region src/core/engine/settle/utils/controls/readExitLayerPolicy.ts
const EXIT_LAYERS = [
	"node",
	"fields",
	"fragment"
];
const readExitLayerPolicy = (groups, committedRuleValues, inherited) => {
	for (const layer of EXIT_LAYERS) {
		let declared = false;
		let keep = false;
		for (const group of groups) {
			if (group.layer !== layer || !hasOwnProperty(group.controls, CONTROL_KEY.unsetOnInactive)) continue;
			declared = true;
			const literal = Reflect.get(group.controls, CONTROL_KEY.unsetOnInactive);
			const key = getExitPolicyKey(group);
			if ((typeof literal === "string" ? committedRuleValues?.get(key) : literal) !== true) keep = true;
		}
		if (declared) return !keep;
	}
	return inherited;
};

//#endregion
//#region src/core/engine/settle/utils/slots/readSlotExitPolicy.ts
const readSlotExitPolicy = (node, inherited) => {
	if (!hasOwnProperty(node, "retainedExitPolicy")) {
		const layers = getControlLayers(node, emptyReadonlyMap, true);
		const keep = readExitLayerPolicy(layers, node.runtime.committedRuleValues, false);
		node.retainedExitPolicy = keep === readExitLayerPolicy(layers, node.runtime.committedRuleValues, true) ? keep : void 0;
	}
	return node.retainedExitPolicy ?? inherited;
};

//#endregion
//#region src/core/engine/settle/utils/transition/isReplacedLivePath.ts
const isReplacedLivePath = (context, path) => {
	const scope = context.replaceScope;
	const withinScope = scope !== void 0 && (!scope.path || path === scope.path || isDescendantPath(path, scope.path));
	const withinVirtual = context.virtualReplacePaths?.some((replaced) => path === replaced || isDescendantPath(path, replaced)) ?? false;
	const withinBatch = context.replacePaths?.some((replaced) => path === replaced || isDescendantPath(path, replaced)) ?? false;
	if (!withinScope && !withinVirtual && !withinBatch) return false;
	const live = find(context.root, path);
	return live !== null && !live.detached;
};

//#endregion
//#region src/core/engine/settle/utils/transition/readDepartingAncestorPolicy.ts
const readDepartingAncestorPolicy = (context, node) => {
	for (let ancestor = node.parent; ancestor; ancestor = ancestor.parent) {
		if (ancestor.detached) continue;
		const departed = getControlLayers(ancestor, emptyReadonlyMap, true).filter((group) => {
			const key = JSON.stringify([group.host.path, getBlueprintNodeIdentity(group.host.blueprintNode)]);
			return !(context.selectedDeclarationIds.get(group.host) ?? context.root.runtime.committedDeclarationIds?.get(key))?.includes(group.declarationId);
		});
		if (departed.length) return readExitLayerPolicy(departed, context.root.runtime.committedRuleValues, context.root.runtime.unsetOnInactive === true);
	}
	return context.root.runtime.unsetOnInactive === true;
};

//#endregion
//#region src/core/engine/settle/utils/inactive/callInactiveValueResolver.ts
const callInactiveValueResolver = (node, resolver, value, inputs, context, ordinal) => {
	if (typeof resolver !== "function") return {
		value: resolver,
		failed: false
	};
	const runtime = node.runtime;
	const previous = runtime.resolvingInactiveValue;
	runtime.resolvingInactiveValue = true;
	try {
		return {
			value: resolver(value, inputs),
			failed: false
		};
	} catch (cause) {
		recordSettlementFailure(context, new SchemaFormError(FormErrorCode.ExpressionThrew, `Inactive value resolver failed at ${node.path}`, {
			path: node.path,
			schemaPath: node.blueprintNode.schemaPath,
			cause
		}), "expression", [
			node.path,
			"inactiveValue",
			ordinal
		].join("\0"));
		return {
			value: void 0,
			failed: true
		};
	} finally {
		runtime.resolvingInactiveValue = previous;
	}
};

//#endregion
//#region src/core/engine/settle/utils/inactive/getInactiveValueContext.ts
const getInactiveValueContext = (node, context) => {
	const parent = node.parent;
	const root = context.root;
	const origins = context.pathChanges.length ? readPathOrigins(context) : void 0;
	const path = origins?.get(node) ?? node.path;
	const parentPath = parent ? origins?.get(parent) ?? parent.path : "";
	return {
		dataPath: path,
		schemaPath: node.blueprintNode.schemaPath,
		jsonSchema: context.originalSchemas.get(node.path)?.schema ?? node.schema.schema,
		parentValue: parent ? getLoadValue(context.previousEmit, parentPath, getSlotPathNames(node.runtime, parentPath)) : null,
		parentJSONSchema: parent ? context.originalSchemas.get(parent.path)?.schema ?? parent.schema.schema : null,
		rootValue: context.previousEmit,
		rootJSONSchema: context.originalSchemas.get(root.path)?.schema ?? root.schema.schema,
		context: context.previousContext ?? {}
	};
};
const readPathOrigins = (context) => {
	if (context.inactivePathOrigins) return context.inactivePathOrigins;
	const origins = /* @__PURE__ */ new Map();
	for (const change of context.pathChanges) if (!origins.has(change.node)) origins.set(change.node, change.previous);
	return context.inactivePathOrigins = origins;
};

//#endregion
//#region src/core/engine/settle/utils/inactive/readExplicitWriteKind.ts
const readExplicitWriteKind = (context, inputPath) => {
	const origins = context.writeOrigins;
	if (!origins) return context.kind;
	if (context.replacePaths?.some((path) => inputPath === path || isDescendantPath(inputPath, path))) return "callerReplace";
	for (let index = origins.length - 1; index >= 0; index--) {
		const origin = origins[index];
		const path = origin.fields?.find((field) => inputPath === field || isDescendantPath(inputPath, field)) ?? origin.path;
		if (inputPath !== path && !isDescendantPath(inputPath, path)) continue;
		if (origin.keys && inputPath !== path) {
			const child = getChildPointer(inputPath, path);
			const name = child === void 0 ? void 0 : readPointerSegment(child, -1);
			if (typeof name !== "string" || !origin.keys.includes(name)) continue;
		}
		if (origin.source === "automatic") return "automatic";
		if (!origin.keys) return "callerReplace";
		return origins.length === 1 || inputPath === path ? "callerPartial" : "callerReplace";
	}
};

//#endregion
//#region src/core/engine/settle/utils/inactive/hasExplicitInactiveValue.ts
const hasExplicitInactiveValue = (node, exit, context) => {
	if (context.kind === "automatic" || !context.writtenInputs.has(context.target)) return false;
	const lineage = [];
	let ancestor = node;
	for (; ancestor && ancestor !== context.target; ancestor = ancestor.parent) lineage.push(ancestor);
	if (!ancestor) return false;
	let input = context.writtenInputs.get(context.target);
	for (let index = lineage.length; index >= 0; index--) {
		const current = index === lineage.length ? context.target : lineage[index];
		if (current.depth >= exit.depth) {
			const source = readExplicitWriteKind(context, current.path);
			if (source !== void 0 && source !== "automatic" && (current === node || source !== "callerPartial" || input === null || typeof input !== "object" || isArray(input))) return true;
		}
		if (index === 0) break;
		const child = lineage[index - 1];
		if (!hasDistributedChildInput(input, child.name, isArray(input))) return false;
		input = Reflect.get(input, child.name);
	}
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/inactive/readInactiveValueDeclaration.ts
const LAYERS = [
	"node",
	"fields",
	"fragment"
];
const readInactiveValueDeclaration = (node) => {
	const groups = getControlLayers(node, emptyReadonlyMap);
	for (const layer of LAYERS) for (let index = groups.length - 1; index >= 0; index--) {
		const group = groups[index];
		if (group.layer === layer && hasOwnProperty(group.controls, CONTROL_KEY.inactiveValue)) return Reflect.get(group.controls, CONTROL_KEY.inactiveValue);
	}
};

//#endregion
//#region src/core/engine/settle/utils/inactive/resolveInactiveValue.ts
const resolveInactiveValue = (node, exit, context) => {
	if (context.entered.has(node) || isReplacedLivePath(context, exit.path)) return;
	let outer = exit;
	for (let ancestor = exit.parent; ancestor?.parent && ancestor.parent.structure?.[ancestor.name] !== ancestor; ancestor = ancestor.parent) outer = ancestor;
	if (hasExplicitInactiveValue(node, outer, context)) return;
	if (outer !== exit && (context.entered.has(outer) || context.throwingGateExits?.has(outer))) return;
	const lineage = [];
	for (let ancestor = node; ancestor && ancestor !== outer.parent; ancestor = ancestor.parent) lineage.push(ancestor);
	let clear = readDepartingAncestorPolicy(context, outer);
	for (let index = lineage.length - 1; index >= 0; index--) clear = readSlotExitPolicy(lineage[index], clear);
	if (clear) return;
	const inputs = getInactiveValueContext(node, context);
	const value = getLoadValue(context.previousEmit, inputs.dataPath, getSlotPathNames(node.runtime, inputs.dataPath));
	const listeners = node.runtime.inactiveListeners?.get(node);
	let result;
	let failed = false;
	let ordinal = 0;
	if (listeners?.size) for (const listener of [...listeners]) {
		if (!listeners.has(listener)) continue;
		const resolved = callInactiveValueResolver(node, listener, value, inputs, context, ordinal++);
		failed || (failed = resolved.failed);
		if (resolved.value !== void 0) result = resolved.value;
	}
	if (failed) return;
	if (result === void 0) {
		const resolved = callInactiveValueResolver(node, readInactiveValueDeclaration(node), value, inputs, context, ordinal);
		if (resolved.failed) return;
		result = resolved.value;
	}
	if (result !== void 0) (context.inactiveValueOverrides ?? (context.inactiveValueOverrides = /* @__PURE__ */ new Map())).set(node, result);
};

//#endregion
//#region src/core/engine/settle/utils/slots/finalizeRestoredSlotRaw.ts
const finalizeRestoredSlotRaw = (context) => {
	for (const [node, preceding] of context.slotRestoredRaw ?? []) {
		if (!node.detached || preceding) continue;
		const live = find(context.root, node.path);
		if (live && live !== node && live.raw === void 0 && live.undeclaredValues === void 0 && !(live.behavior.type === "array" && live.itemCount > 0)) context.changedRaw.delete(node.path);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/captureAbsentSlotInputs.ts
const captureAbsentSlotInputs = (node, context) => {
	const distribution = context.distributedInputs.get(node);
	if (!distribution || distribution.automatic || distribution.preserveLatent) return void 0;
	let children;
	const array = node.behavior.type === "array";
	const packed = (overlay) => ({
		...overlay,
		packedArrayInput: true,
		...overlay.children ? { children: new Map([...overlay.children].map(([entry, child]) => [entry, packed(child)])) } : void 0
	});
	for (const name of Object.keys(distribution.input ?? {})) {
		if (node.structure?.[name]) continue;
		const current = getChildDistribution(node, name, context);
		if (!current || !hasDistributedChildInput(current.input, name, array)) continue;
		const entry = array ? getItemEntries(node.blueprintNode, Number(name))[0] : node.blueprintNode.childEntries.find((entry) => entry.name === name);
		if (!entry || array && !isArray(current.input)) continue;
		const prior = getSlotSource(node, entry);
		const result = createSlotValueOverlay(entry.node, Reflect.get(current.input, name), prior.source, prior.overlay, current.whole);
		(children ?? (children = /* @__PURE__ */ new Map())).set(entry, array && !node.blueprintNode.hasCandidateDescendants ? packed(result.overlay) : result.overlay);
	}
	return children ? { children } : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/slots/materializeKeptSlotOverlay.ts
const materializeKeptSlotOverlay = (template, source, overlay) => {
	const inherited = overlay?.replace ? void 0 : source;
	const raw = overlay && hasOwnProperty(overlay, "raw") ? overlay.raw : inherited?.raw;
	const undeclaredValues = overlay && hasOwnProperty(overlay, "undeclaredValues") ? overlay.undeclaredValues : inherited?.undeclaredValues;
	const children = /* @__PURE__ */ new Map();
	if (template.strategy === "branch") for (const entry of getSlotEntries(source, overlay, template)) {
		const child = getSlotSource(source, entry, overlay);
		children.set(entry, materializeKeptSlotOverlay(entry.node, child.source, child.overlay));
	}
	return {
		...overlay,
		replace: true,
		raw,
		undeclaredValues,
		...template.kind === "array" ? { itemCount: overlay?.itemCount ?? inherited?.itemCount ?? 0 } : void 0,
		...children.size ? { children } : void 0
	};
};

//#endregion
//#region src/core/engine/settle/utils/slots/createClearedArrayOverlay.ts
const createClearedArrayOverlay = (node, previous, context, resolve, sourceContext = context) => {
	const raw = [];
	const children = /* @__PURE__ */ new Map();
	const sources = /* @__PURE__ */ new Map();
	const entries = getSlotEntries(node, previous);
	let position = 0;
	while (position < entries.length) {
		const name = entries[position].name;
		let value;
		let retained = false;
		do {
			const entry = entries[position++];
			const child = getSlotSource(node, entry, previous);
			if (!child.source) continue;
			const result = resolve(child.source, true, true, child.overlay, node.structure?.[entry.name] === child.source ? context : void 0, sourceContext);
			if (!result.hasSource) continue;
			const target = getItemEntries(node.blueprintNode, raw.length).find((candidate) => candidate.node === entry.node) ?? {
				...entry,
				name: String(raw.length)
			};
			sources.set(target, child.source);
			children.set(target, materializeKeptSlotOverlay(entry.node, child.source, result.overlay));
			if (!retained || node.structure?.[name] === child.source) value = readSlotRawTree(entry.node, child.source, result.overlay);
			retained = true;
		} while (position < entries.length && entries[position].name === name);
		if (retained) raw.push(value);
	}
	if (sourceContext && raw.length) (sourceContext.compactedSlotSources ?? (sourceContext.compactedSlotSources = /* @__PURE__ */ new Map())).set(node, {
		itemCount: raw.length,
		sources,
		overlays: children
	});
	return {
		replace: true,
		raw: raw.length ? Object.freeze(raw) : void 0,
		undeclaredValues: void 0,
		itemCount: raw.length,
		packedArrayInput: true,
		children
	};
};

//#endregion
//#region src/core/engine/settle/utils/slots/expirePackedSlotMemos.ts
const expirePackedSlotMemos = (source, overlay) => {
	const clear = (node, patch) => {
		if (node) node.inactiveValueMemo = void 0;
		if (patch) patch.valueMemo = void 0;
		for (const entry of getSlotEntries(node, patch)) {
			const child = getSlotSource(node, entry, patch);
			clear(child.source, child.overlay);
		}
	};
	for (const entry of getSlotEntries(source, overlay)) {
		if (entry.node.hasCandidateDescendants || getItemEntries(source.blueprintNode, Number(entry.name)).length > 1 || overlay?.children?.has(entry) && overlay.children.get(entry) !== source.retainedSourceOverlay?.children?.get(entry)) continue;
		const child = getSlotSource(source, entry, overlay);
		clear(child.source, child.overlay);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/hasSlotOverlaySource.ts
const hasSlotOverlaySource = (overlay) => {
	if (overlay.raw !== void 0 || overlay.undeclaredValues !== void 0) return true;
	for (const child of overlay.children?.values() ?? []) if (hasSlotOverlaySource(child)) return true;
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/slots/createExitSlotOverlay.ts
const createExitSlotOverlay = (node, inherited, applyPolicy, previous, context, sourceContext = context) => {
	const supplied = context ? captureAbsentSlotInputs(node, context) : void 0;
	if (supplied?.children) previous = {
		...previous,
		children: new Map([...previous?.children ?? [], ...supplied.children])
	};
	const policy = readSlotExitPolicy(node, inherited);
	const clear = applyPolicy && policy;
	if (clear && node.behavior.type === "array" && !node.blueprintNode.hasKeepDescendants) {
		const overlay = {
			replace: true,
			raw: void 0,
			undeclaredValues: void 0,
			itemCount: 0
		};
		if (context) node.retainedSourceOverlay = overlay;
		return {
			overlay,
			hasSource: false,
			retain: false
		};
	}
	if (clear && node.behavior.type === "array") {
		const overlay = createClearedArrayOverlay(node, previous, context, createExitSlotOverlay, sourceContext);
		if (context) node.retainedSourceOverlay = overlay;
		const hasSource = overlay.itemCount !== 0;
		return {
			overlay,
			hasSource,
			retain: hasSource,
			compacted: hasSource
		};
	}
	const raw = previous && hasOwnProperty(previous, "raw") ? previous?.raw : previous?.replace ? void 0 : node.raw;
	const extras = previous && hasOwnProperty(previous, "undeclaredValues") ? previous?.undeclaredValues : previous?.replace ? void 0 : node.undeclaredValues;
	let hasSource = !clear && (context?.inactiveValueOverrides?.has(node) || raw !== void 0 || extras !== void 0 || node.behavior.type === "array");
	let children;
	let compacted = false;
	const visited = [];
	for (const child of node.children ?? []) {
		if (child.parent !== node) continue;
		const entry = getRetainedChildEntry(node, child.name, child.blueprintNode);
		if (!entry) continue;
		visited.push(entry);
		const prior = previous?.children?.get(entry);
		const result = createExitSlotOverlay(child, clear, applyPolicy, prior, context, sourceContext);
		if (result.hasSource) hasSource = true;
		if (result.compacted) compacted = true;
		if (result.overlay !== prior) {
			children ?? (children = new Map(previous?.children));
			if (result.overlay) children.set(entry, result.overlay);
			else children.delete(entry);
		}
	}
	for (const [entry, child] of node.inactiveSlots ?? []) {
		if (visited.includes(entry)) continue;
		visited.push(entry);
		const prior = previous?.children?.get(entry) ?? node.inactiveSlotOverlays?.get(entry);
		const result = createExitSlotOverlay(child, clear, applyPolicy, prior, void 0, sourceContext);
		if (result.hasSource) hasSource = true;
		if (result.compacted) compacted = true;
		if (result.overlay !== previous?.children?.get(entry)) {
			children ?? (children = new Map(previous?.children));
			if (result.overlay) children.set(entry, result.overlay);
		}
	}
	for (const [entry, prior] of node.inactiveSlotOverlays ?? []) {
		if (visited.includes(entry)) continue;
		if (!clear && hasSlotOverlaySource(prior)) hasSource = true;
		const overlay = clear ? {
			replace: true,
			raw: void 0,
			undeclaredValues: void 0
		} : prior;
		if (overlay !== previous?.children?.get(entry)) {
			children ?? (children = new Map(previous?.children));
			children.set(entry, overlay);
		}
	}
	const overlay = clear ? {
		...previous,
		raw: void 0,
		undeclaredValues: void 0,
		...node.behavior.type === "array" ? { itemCount: 0 } : void 0,
		...children ? { children } : void 0
	} : children ? {
		...previous,
		children
	} : previous;
	if (context) node.retainedSourceOverlay = overlay;
	if (!clear && node.behavior.type === "array" && node.raw === void 0) expirePackedSlotMemos(node, overlay);
	return {
		overlay,
		hasSource,
		retain: !clear || hasSource,
		compacted
	};
};

//#endregion
//#region src/core/engine/settle/utils/slots/retainExitedSlot.ts
const retainExitedSlot = (node, context, applyPolicy) => {
	const host = node.parent;
	if (!host) return;
	const entry = getRetainedChildEntry(host, node.name, node.blueprintNode);
	if (!entry) return;
	if (isReplacedLivePath(context, node.path)) {
		markSlotChange(host, entry, void 0, context);
		host.inactiveSlots?.delete(entry);
		host.inactiveSlotOverlays?.delete(entry);
		return;
	}
	const result = createExitSlotOverlay(node, readDepartingAncestorPolicy(context, node), applyPolicy, void 0, context);
	node.retainedSourceOverlay = result.overlay;
	markSlotChange(host, entry, context.entered.has(node) ? void 0 : node);
	if (!result.retain) {
		host.inactiveSlots?.delete(entry);
		host.inactiveSlotOverlays?.delete(entry);
		return;
	}
	const source = result.compacted ? cloneSlotSubtree(host, entry, node, context, false, context.compactedSlotSources) : node;
	(host.inactiveSlots ?? (host.inactiveSlots = /* @__PURE__ */ new Map())).set(entry, source);
	if (result.overlay) (host.inactiveSlotOverlays ?? (host.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, result.overlay);
	else host.inactiveSlotOverlays?.delete(entry);
};

//#endregion
//#region src/core/engine/settle/utils/slots/pruneArraySlotTail.ts
const pruneArraySlotTail = (host, context) => {
	for (const [name, child] of host.inactiveSlotChildren ?? []) {
		if (Number(name) < host.itemCount && host.structure?.[name] === child) continue;
		const entry = getRetainedChildEntry(host, name, child.blueprintNode);
		if (entry) markSlotChange(host, entry, child, context);
	}
	const entries = new Set(host.inactiveSlots?.keys());
	for (const entry of host.inactiveSlotOverlays?.keys() ?? []) entries.add(entry);
	for (const entry of entries) {
		if (Number(entry.name) < host.itemCount) continue;
		markSlotChange(host, entry, void 0, context);
		host.inactiveSlots?.delete(entry);
		host.inactiveSlotOverlays?.delete(entry);
	}
};

//#endregion
//#region src/core/engine/settle/utils/pathStores/getRuntimePathStores.ts
const getRuntimePathStores = (runtime) => ({
	declarations: runtime.committedDeclarationIds ?? (runtime.committedDeclarationIds = new PathKeyedMap("pair")),
	rules: runtime.committedRuleValues ?? (runtime.committedRuleValues = new PathKeyedMap("rule")),
	misfits: runtime.misfitPaths,
	misfitsMemo: runtime.misfitsMemo ?? (runtime.misfitsMemo = new PathKeyedMap("path"))
});

//#endregion
//#region src/core/engine/settle/utils/transition/prunePerishedPaths.ts
const prunePerishedPaths = (runtime, paths) => {
	if (paths.size === 0) return;
	const stores = getRuntimePathStores(runtime);
	const warningKeys = /* @__PURE__ */ new Set();
	if (runtime.warningKeysByPath?.size) for (const path of paths) for (const key of runtime.warningKeysByPath.get(path) ?? []) warningKeys.add(key);
	for (const key of warningKeys) {
		const parts = JSON.parse(key);
		if (isArray(parts) && typeof parts[1] === "string") indexFieldNodeWarning(runtime, key, parts[1], void 0, true);
	}
	for (const store of [stores.misfits, stores.declarations]) {
		if (!store) continue;
		if (store.size) for (const path of paths) for (const key of store.pathIndex.under(path)) store.delete(key);
	}
	if (stores.rules.size) for (const path of paths) for (const key of stores.rules.pathIndex.under(path)) updateCommittedRuleValue(runtime, key, "delete");
};

//#endregion
//#region src/core/engine/settle/utils/transition/pruneArrayTailPaths.ts
const pruneArrayTailPaths = (runtime, hosts) => {
	if (hosts.size === 0) return;
	const stores = getRuntimePathStores(runtime);
	const removed = /* @__PURE__ */ new Set();
	for (const [host, count] of hosts) {
		for (const store of [
			stores.declarations,
			stores.misfits,
			stores.rules
		]) {
			if (!store) continue;
			for (const path of store.pathIndex.tail(host, count)) removed.add(path);
		}
		for (const key of runtime.warningKeysByPath?.get(host) ?? []) {
			const parts = JSON.parse(key);
			if (!isArray(parts) || typeof parts[1] !== "string") continue;
			const child = getChildPointer(parts[1], host);
			const segment = child === void 0 ? void 0 : readPointerSegment(child, -1);
			if (typeof segment !== "string") continue;
			const index = Number(segment);
			if (isDescendantPath(parts[1], host) && Number.isInteger(index) && index >= count && index >= 0 && String(index) === segment) removed.add(appendSegment(host, segment));
		}
	}
	prunePerishedPaths(runtime, removed);
};

//#endregion
//#region src/core/engine/settle/utils/transition/utils/detachPerishedNode.ts
const detachPerishedNode = (departing, context, rekeyed) => {
	if (!departing.runtime.detachedReads?.has(departing)) captureDetachedFieldNodeReads(departing, {
		emit: context.previousEmit,
		context: context.previousContext,
		schema: context.originalSchemas.get(departing.path)?.schema ?? departing.schema.schema
	});
	if (rekeyed?.current !== void 0) departing.runtime.misfitPaths.delete(rekeyed.current + departing.path.slice(rekeyed.previous.length));
	departing.detached = true;
	departing.active = captureFieldNodeChange(departing, "active", false);
};

//#endregion
//#region src/core/engine/settle/utils/transition/finalizePerished.ts
const OWNED = { owned: true };
const finalizePerished = (context) => {
	let perishedPaths;
	const registry = getGateRegistry(context.root.runtime);
	const pendingExits = context.pendingExits;
	const perishing = pendingExits.size ? /* @__PURE__ */ new Set() : void 0;
	let rekeyed;
	const detach = (departing) => detachPerishedNode(departing, context, rekeyed);
	for (const node of context.perished) {
		if (node.parent?.structure?.[node.name] === node) continue;
		rekeyed = node.parent ? context.rekeyedArrayMoves?.get(node.parent)?.[Number(node.name)] : void 0;
		visitFieldNodes(node, detach, OWNED);
		registry.remove(node);
		perishing?.add(node);
		const parent = node.parent;
		const destinationCount = parent && context.rekeyedArrayMoves?.has(parent) ? parent.itemCount : void 0;
		if (!parent?.structure?.[node.name] && (destinationCount === void 0 || Number(node.name) >= destinationCount)) (perishedPaths ?? (perishedPaths = /* @__PURE__ */ new Set())).add(node.path);
	}
	if (perishing?.size) for (const [key, pending] of pendingExits) {
		const ancestor = findPerishedAncestor(pending, perishing);
		if (ancestor) {
			rekeyed = ancestor.parent ? context.rekeyedArrayMoves?.get(ancestor.parent)?.[Number(ancestor.name)] : void 0;
			pendingExits.delete(key);
			const path = JSON.parse(key)[0];
			updatePendingExitIndex(context, path, -1);
			visitFieldNodes(pending, detach, OWNED);
			registry.remove(pending);
		}
	}
	if (perishedPaths) prunePerishedPaths(context.root.runtime, perishedPaths);
	const resizedHosts = /* @__PURE__ */ new Map();
	for (const [host, previousCount] of context.arrayCounts) if (!host.detached && host.itemCount !== previousCount) {
		pruneArraySlotTail(host, context);
		resizedHosts.set(host.path, host.itemCount);
	}
	if (resizedHosts.size) pruneArrayTailPaths(context.root.runtime, resizedHosts);
};
const findPerishedAncestor = (node, perishing) => {
	for (let current = node; current; current = current.parent) if (perishing.has(current)) return current;
};

//#endregion
//#region src/core/engine/settle/utils/transition/utils/isRekeyedDestination.ts
const isRekeyedDestination = (node, moves) => {
	for (let current = node; current?.parent; current = current.parent) if (moves.has(current.parent) && Number(current.name) < current.parent.itemCount) return true;
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/slots/restoreSlotSources.ts
const restoreSlotSources = (context, scope) => {
	for (const [host, bindings] of context.slotAutomaticLog ?? []) for (const [entry, previous] of bindings) {
		const path = appendSegment(host.path, entry.name);
		if (scope !== void 0 && path !== scope && !isDescendantPath(path, scope)) continue;
		markSlotChange(host, entry);
		if (previous.source) (host.inactiveSlots ?? (host.inactiveSlots = /* @__PURE__ */ new Map())).set(entry, previous.source);
		else host.inactiveSlots?.delete(entry);
		if (previous.overlay) (host.inactiveSlotOverlays ?? (host.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, previous.overlay);
		else host.inactiveSlotOverlays?.delete(entry);
	}
};

//#endregion
//#region src/core/engine/settle/utils/transition/restoreArrayStructure.ts
const restoreArrayStructure = (context, within) => {
	for (let index = context.arrayStructureLog.length - 1; index >= 0; index--) {
		const entry = context.arrayStructureLog[index];
		if (entry.restored) continue;
		const { host, previousItems, previousItemCount, previousExtras } = entry;
		if (within) {
			let ancestor = host;
			while (ancestor && ancestor !== within) ancestor = ancestor.parent;
			if (!ancestor) continue;
		}
		const prior = new Set(previousItems);
		for (const item of host.children ?? []) if (!prior.has(item)) {
			getGateRegistry(item.runtime).remove(item);
			visitFieldNodes(item, (current) => {
				current.detached = true;
				current.active = captureFieldNodeChange(current, "active", false);
				context.entered.delete(current);
				context.perished.delete(current);
			}, { owned: true });
		}
		const structure = Object.create(null);
		for (const item of previousItems) {
			structure[item.name] = item;
			item.detached = false;
			item.active = captureFieldNodeChange(item, "active", true);
			context.perished.delete(item);
		}
		host.structure = structure;
		host.children = captureFieldNodeChange(host, "children", previousItems);
		host.itemCount = previousItemCount;
		host.undeclaredValues = previousExtras;
		context.dirtyPaths.add(host.path);
		context.shapeDirtyPaths.add(host.path);
		entry.restored = true;
	}
};

//#endregion
//#region src/core/engine/settle/utils/transition/withdrawDetachedFills.ts
const withdrawDetachedFills = (context) => {
	for (const node of context.filledNodes) {
		if (!node.detached) continue;
		restoreArrayStructure(context, node);
		restoreSlotSources(context, node.path);
		for (let index = context.automaticLog.length - 1; index >= 0; index--) {
			const entry = context.automaticLog[index];
			let ancestor = entry.node;
			while (ancestor && ancestor !== node) ancestor = ancestor.parent;
			if (!ancestor) continue;
			entry.node.raw = entry.previousRaw;
			entry.node.undeclaredValues = entry.previousExtras;
			if (entry.previousDistributed) context.distributedInputs.set(entry.node, entry.previousDistributed);
			else context.distributedInputs.delete(entry.node);
			context.changedRaw.delete(entry.node.path);
		}
		context.writtenInputs.delete(node);
	}
};

//#endregion
//#region src/core/engine/settle/utils/transition/finalizeExits.ts
const finalizeExits = (context) => {
	const scope = context.kind === "load" ? context.loadScope : void 0;
	const inLoadScope = (node) => scope !== void 0 && (!scope.path || node.path === scope.path || isDescendantPath(node.path, scope.path));
	const applyPolicy = !context.suppressAutomaticWrites && !context.exceededBudget;
	finalizePerished(context);
	let misfitIndex;
	for (const node of context.pendingExits.values()) {
		if (node.detached) continue;
		if (node.parent?.structure?.[node.name] === node) continue;
		context.exited.add(node);
		const rekeyed = context.rekeyedArrayMoves && isRekeyedDestination(node, context.rekeyedArrayMoves);
		visitFieldNodes(node, (departing) => {
			if ((departing.blueprintNode.hasInactiveValue || departing.runtime.inactiveListeners?.has(departing)) && applyPolicy && !rekeyed && !inLoadScope(node) && !context.entered.has(node) && !context.throwingGateExits?.has(node)) resolveInactiveValue(departing, node, context);
			if (!departing.runtime.detachedReads?.has(departing)) captureDetachedFieldNodeReads(departing, {
				emit: context.previousEmit,
				context: context.previousContext,
				schema: context.originalSchemas.get(departing.path)?.schema ?? departing.schema.schema
			});
			if (rekeyed) departing.runtime.misfitPaths.delete(departing.path);
			departing.detached = true;
			departing.active = captureFieldNodeChange(departing, "active", false);
		}, { owned: true });
		getGateRegistry(node.runtime).remove(node);
		if (rekeyed) continue;
		if (!misfitIndex) {
			misfitIndex = /* @__PURE__ */ new Map();
			for (const path of context.root.runtime.misfitPaths) {
				let ancestor = path;
				while (true) {
					let paths = misfitIndex.get(ancestor);
					if (!paths) {
						paths = /* @__PURE__ */ new Set();
						misfitIndex.set(ancestor, paths);
					}
					paths.add(path);
					if (!ancestor) break;
					ancestor = resolvePointer(ancestor, "..");
				}
			}
		}
		for (const path of [...misfitIndex.get(node.path) ?? []]) {
			context.root.runtime.misfitPaths.delete(path);
			let ancestor = path;
			while (true) {
				misfitIndex.get(ancestor)?.delete(path);
				if (!ancestor) break;
				ancestor = resolvePointer(ancestor, "..");
			}
		}
	}
	withdrawDetachedFills(context);
	for (const node of context.exited) if (!inLoadScope(node) && node.detached) retainExitedSlot(node, context, applyPolicy && !context.entered.has(node) && !context.throwingGateExits?.has(node));
	if (context.inactiveValueOverrides) applyInactiveValues(context);
	const affectedAncestors = /* @__PURE__ */ new Set();
	finalizeRestoredSlotRaw(context);
	for (const node of context.exited) for (let ancestor = node.parent; ancestor; ancestor = ancestor.parent) if (!ancestor.detached) affectedAncestors.add(ancestor);
	for (const ancestor of [...affectedAncestors].sort((left, right) => right.path.length - left.path.length)) updateOutput(ancestor, context);
};

//#endregion
//#region src/core/engine/settle/utils/transition/restoreSourceB.ts
const restoreSourceB = (context, explicitRaw) => {
	for (let index = context.automaticLog.length - 1; index >= 0; index--) {
		const entry = context.automaticLog[index];
		entry.node.raw = entry.previousRaw;
		entry.node.undeclaredValues = entry.previousExtras;
		if (entry.previousDistributed) context.distributedInputs.set(entry.node, entry.previousDistributed);
		else context.distributedInputs.delete(entry.node);
		context.dirtyPaths.add(entry.node.path);
		if (entry.node.behavior.strategy === "branch") context.shapeDirtyPaths.add(entry.node.path);
	}
	restoreArrayStructure(context);
	restoreSlotSources(context);
	withdrawDetachedFills(context);
	for (const node of context.filledNodes) context.writtenInputs.delete(node);
	context.selectedDeclarationIds.clear();
	context.changedRaw.clear();
	for (const path of explicitRaw) context.changedRaw.add(path);
	context.dirtyPaths.add("");
	context.shapeDirtyPaths.add("");
	registerRecalculation(context);
	computeNode(context.root, context);
};

//#endregion
//#region src/core/engine/settle/utils/transition/collectFillDescendants.ts
const collectFillDescendants = (context, appearances, count, ancestors, newArrayHosts) => {
	let byDepth;
	const firstEvaluations = context.hasGates ? /* @__PURE__ */ new Set() : void 0;
	for (let index = 0; index < count; index++) {
		var _byDepth, _node$depth;
		const node = appearances.next().value;
		if (node.detached || !node.parent) continue;
		const parentOrigin = ancestors.get(node.parent);
		if (parentOrigin === void 0 && !context.distributedInputs.get(node.parent)?.automatic) continue;
		const newItem = node.parent.behavior.type === "array" && newArrayHosts?.has(node.parent) && parentOrigin !== void 0 && parentOrigin >= 0 && Number(node.name) >= parentOrigin;
		const firstEvaluation = parentOrigin === -1 && firstEvaluations?.has(node.parent);
		if (context.hasGates && !firstEvaluation && !newItem) {
			const declarations = node.blueprintNode.declarations;
			let ungated = false;
			for (let declarationIndex = 0; declarationIndex < declarations.length; declarationIndex++) if (declarations[declarationIndex].role === "declaration" && declarations[declarationIndex].gates.length === 0) {
				ungated = true;
				break;
			}
			if (!ungated) continue;
		}
		if (node.behavior.strategy === "branch") {
			ancestors.set(node, -1);
			firstEvaluations?.add(node);
		}
		byDepth ?? (byDepth = []);
		((_byDepth = byDepth)[_node$depth = node.depth] ?? (_byDepth[_node$depth] = [])).push(node);
	}
	return byDepth;
};

//#endregion
//#region src/core/engine/settle/utils/transition/hasRecursiveFill.ts
const hasRecursiveFill = (node, hosts, context) => node.parent !== null && hasRecursiveExpansion(node.parent, node.blueprintNode, void 0, context, node.schema, hosts);

//#endregion
//#region src/core/engine/settle/utils/transition/hasWrongKindBranchAncestor.ts
const hasWrongKindBranchAncestor = (node) => {
	let parent = node.parent;
	while (parent) {
		if (parent.behavior.type === "object" && parent.behavior.strategy === "branch" && parent.raw !== void 0 && (parent.raw === null || typeof parent.raw !== "object" || isArray(parent.raw))) return true;
		if (parent.behavior.type === "array" && parent.behavior.strategy === "branch" && parent.raw !== void 0 && !isArray(parent.raw)) return true;
		parent = parent.parent;
	}
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/transition/isMissingRaw.ts
const isMissingRaw = (node, context) => {
	if (node.raw !== void 0) return false;
	if (node.behavior.strategy !== "branch") return true;
	if (node.undeclaredValues !== void 0 || node.inactiveSlots?.size) return false;
	for (const overlay of node.inactiveSlotOverlays?.values() ?? []) if (hasSlotOverlaySource(overlay)) return false;
	for (const pending of context.pendingExits.values()) if (isDescendantPath(pending.path, node.path) && pending.raw !== void 0 && !context.filledNodes.has(pending)) return false;
	return (node.children ?? []).every((child) => isMissingRaw(child, context));
};

//#endregion
//#region src/core/engine/settle/utils/transition/readDefault.ts
const DEFAULT_LAYERS = [
	"node",
	"fields",
	"fragment"
];
const readDefault = (node, selectedDeclarationIds) => {
	const groups = getControlLayers(node, selectedDeclarationIds);
	for (const layer of DEFAULT_LAYERS) for (let index = groups.length - 1; index >= 0; index--) {
		const group = groups[index];
		if (group.layer === layer && hasOwnProperty(group.controls, CONTROL_KEY.default)) return Reflect.get(group.controls, CONTROL_KEY.default);
	}
	const schema = node.schema.schema;
	if (schema === null || typeof schema !== "object") return void 0;
	return hasOwnProperty(schema, "default") ? schema.default : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/transition/transitionSettlement.ts
const transitionSettlement = (context) => {
	if (context.suppressAutomaticWrites || context.exceededBudget) return;
	if (!context.hasGates && context.entered.size === 0 && context.exited.size === 0) {
		let narrowed = false;
		for (const node of context.writtenInputs.keys()) if (!node.detached && effectiveType(node) !== node.schemaType) {
			narrowed = true;
			break;
		}
		if (!narrowed) return;
	}
	context.inTransition = true;
	const cap = getTransitionCap(context.root.runtime.blueprint);
	const filled = context.hasGates ? /* @__PURE__ */ new Set() : void 0;
	const filledNodes = context.hasGates ? void 0 : /* @__PURE__ */ new Set();
	let fillHosts;
	let fillAncestors;
	let newArrayHosts;
	let descendantsByDepth;
	let appearances;
	let appearanceCount = 0;
	let rounds = 0;
	while (true) {
		context.automaticChanged = false;
		newArrayHosts?.clear();
		const continuingFill = descendantsByDepth !== void 0;
		const enteredByDepth = descendantsByDepth ?? [];
		descendantsByDepth = void 0;
		if (!continuingFill) {
			appearances = context.entered.values();
			appearanceCount = context.entered.size;
			for (let index = 0; index < appearanceCount; index++) {
				var _node$depth;
				const node = appearances.next().value;
				(enteredByDepth[_node$depth = node.depth] ?? (enteredByDepth[_node$depth] = [])).push(node);
			}
		}
		for (let depth = 0; depth < enteredByDepth.length; depth++) {
			const entered = enteredByDepth[depth];
			if (!entered) continue;
			for (let index = 0; index < entered.length; index++) {
				const node = entered[index];
				if (node.detached || context.pendingExits.size !== 0 && context.pendingExits.has(JSON.stringify([node.path, getBlueprintNodeIdentity(node.blueprintNode)]))) continue;
				if (filledNodes) {
					if (filledNodes.has(node)) continue;
					filledNodes.add(node);
				} else if (filled) {
					const key = JSON.stringify([node.path, getBlueprintNodeIdentity(node.blueprintNode)]);
					if (filled.has(key)) continue;
					filled.add(key);
				}
				if (context.deriveState?.activeUnsetTargets.has(node)) continue;
				if (node.raw !== void 0) continue;
				if (hasWrongKindBranchAncestor(node)) continue;
				if (node.behavior.type === "array" && context.distributedInputs.get(node)?.input !== void 0) continue;
				const value = readDefault(node, context.selectedDeclarationIds);
				if (value === void 0 || !isMissingRaw(node, context)) continue;
				if (node.behavior.strategy === "branch") {
					if (fillHosts && hasRecursiveFill(node, fillHosts, context)) {
						recordSettlementFailure(context, new SchemaFormError(FormErrorCode.RecursiveShapeDiverged, `Recursive shape diverged at ${node.path}`, { path: node.path }), "budget");
						context.exceededBudget = "recursion";
						context.inTransition = false;
						return;
					}
					(fillHosts ?? (fillHosts = /* @__PURE__ */ new Set())).add(node);
					fillAncestors ?? (fillAncestors = /* @__PURE__ */ new Map());
					if (!fillAncestors.has(node) || fillAncestors.get(node) === -1) fillAncestors.set(node, node.itemCount);
				}
				context.filledNodes.add(node);
				context.automatic = true;
				context.writtenInputs.set(node, value);
				const logsStructure = node.behavior.strategy === "branch" || node.behavior.type === "array";
				const arrayLogStart = logsStructure ? context.arrayStructureLog.length : 0;
				markWrite(node, value, context);
				context.automatic = false;
				if (logsStructure) for (let logIndex = arrayLogStart; logIndex < context.arrayStructureLog.length; logIndex++) {
					const entry = context.arrayStructureLog[logIndex];
					if (fillAncestors && (!fillAncestors.has(entry.host) || fillAncestors.get(entry.host) === -1)) fillAncestors.set(entry.host, entry.previousItemCount);
					if (context.hasGates && entry.host.itemCount > entry.previousItemCount) (newArrayHosts ?? (newArrayHosts = /* @__PURE__ */ new Set())).add(entry.host);
				}
			}
		}
		for (const [node, original] of context.writtenInputs) {
			if (node.detached || context.pendingExits.size !== 0 && context.pendingExits.has(JSON.stringify([node.path, getBlueprintNodeIdentity(node.blueprintNode)]))) continue;
			const effective = effectiveType(node);
			if (effective === node.schemaType) continue;
			context.automatic = true;
			markWrite(node, original, context, staticSpec(effective, node.nullable));
			context.automatic = false;
		}
		if (context.initialOutputs) {
			const outputs = context.initialOutputs;
			context.initialOutputs = void 0;
			for (let index = 0; index < outputs.length; index++) updateOutput(outputs[index], context);
			context.dirtyPaths.clear();
			context.inTransition = false;
			return;
		}
		if (!context.automaticChanged) {
			if (continuingFill && context.hasGates) continue;
			withdrawDetachedFills(context);
			context.inTransition = false;
			return;
		}
		if (!continuingFill) rounds++;
		if (rounds > cap) {
			recordSettlementFailure(context, new SchemaFormError(FormErrorCode.BudgetExceeded, `Transition budget exceeded at ${context.target.path}`, { path: context.target.path }), "budget");
			context.exceededBudget = "transition";
			context.iterations = cap;
			context.inTransition = false;
			return;
		}
		registerRecalculation(context);
		context.hostWheelExceeded = void 0;
		computeNode(context.root, context);
		if (context.hostWheelExceeded !== void 0 && !context.exceededBudget) {
			recordSettlementFailure(context, new SchemaFormError(FormErrorCode.BudgetExceeded, `Host wheel budget exceeded at ${context.target.path}`, { path: context.target.path }), "budget");
			context.exceededBudget = "hostWheel";
			context.iterations = context.hostWheelExceeded;
		}
		if (context.exceededBudget) {
			context.inTransition = false;
			return;
		}
		if (context.root.runtime.blueprint.capabilities.hasDerive) runDeriveRounds(context);
		if (context.exceededBudget) {
			context.inTransition = false;
			return;
		}
		if (fillAncestors && context.entered.size > appearanceCount) {
			const count = context.entered.size;
			descendantsByDepth = collectFillDescendants(context, appearances, count - appearanceCount, fillAncestors, newArrayHosts);
			appearanceCount = count;
		}
	}
};

//#endregion
//#region src/core/engine/settle/utils/settlement/finishSettlement.ts
const finishSettlement = (context, scratch, scalarWrite = false) => {
	for (const path of context.changedRaw) scratch.explicitRaw.add(path);
	if (context.hostWheelExceeded && !context.exceededBudget) {
		recordSettlementFailure(context, new SchemaFormError(FormErrorCode.BudgetExceeded, `Host wheel budget exceeded at ${context.target.path}`, { path: context.target.path }), "budget");
		context.exceededBudget = "hostWheel";
		context.iterations = context.hostWheelExceeded;
	}
	if (!scalarWrite && !context.exceededBudget && context.root.runtime.blueprint.capabilities.hasDerive) runDeriveRounds(context);
	if (!context.exceededBudget && (context.hasGates || context.entered.size > 0 || context.exited.size > 0 || context.writtenInputs.size > 1 || context.writtenInputs.size === 1 && (!context.writtenInputs.has(context.target) || !scalarWrite && effectiveType(context.target) !== context.target.schemaType))) transitionSettlement(context);
	if (context.exceededBudget) {
		restoreSourceB(context, scratch.explicitRaw);
		captureDeriveBaseline(context);
	}
	publishStateKeys(context);
	if (context.pendingExits.size > 0 || context.perished.size > 0 || context.entered.size > 0 || context.revived.size > 0 || context.exited.size > 0 || context.filledNodes.size > 0 || context.arrayCounts.size > 0) finalizeExits(context);
	if (context.kind !== "load" && context.arrayCounts.size > 0) {
		const append = context.arrayAppend;
		const pop = context.arrayPop;
		const aligned = append && append.host.runtime.loadSnapshot === append.snapshot && append.host.itemCount === append.count + 1 ? append.host : pop && pop.host.runtime.loadSnapshot === pop.snapshot && pop.host.itemCount === pop.count - 1 ? pop.host : void 0;
		alignArraySnapshotSlots([...context.arrayCounts].filter(([host, previousCount]) => host !== aligned && !host.detached && host.itemCount !== previousCount).map(([host]) => host));
	}
	if (context.kind === "load") {
		for (const path of context.target.runtime.misfitPaths) if (!context.target.path || path === context.target.path || isDescendantPath(path, context.target.path)) context.target.runtime.misfitPaths.delete(path);
	}
	commitSettlement(context);
	const failures = context.failures;
	if (failures?.length || context.pathChanges.length > 0) discardStaticHostPreparation(context);
	if (!failures?.length) return;
	const runtime = context.root.runtime;
	if (runtime.entryDepth && runtime.chainErrors) return;
	throw failures.length === 1 ? failures[0] : new SchemaFormError(FormErrorCode.MultipleErrors, "Multiple settlement errors", { errors: failures });
};

//#endregion
//#region src/core/engine/settle/utils/slots/prepareSourcePruner.ts
const skipSourcePruning = () => {};
const prepareSourcePruner = (node) => {
	const derived = getHostDerived(node);
	if (derived.sourcePruner) return derived.sourcePruner;
	let unique = !hasRetainableDescendants(node.blueprintNode, /* @__PURE__ */ new WeakSet());
	for (let current = node; unique && current?.parent; current = current.parent) {
		const parent = current.parent;
		if (parent.behavior.type === "array" && !parent.blueprintNode.hasCandidateDescendants) continue;
		if (parent.behavior.type !== "object") {
			unique = false;
			break;
		}
		if (!parent.blueprintNode.hasCandidateDescendants) continue;
		const derived = getHostDerived(parent.blueprintNode);
		getSlotChildIndex(parent.blueprintNode, current.name, current.blueprintNode);
		const identity = getBlueprintNodeIdentity(current.blueprintNode);
		for (const template of derived.childOrderIndex?.get(current.name)?.keys() ?? []) if (getBlueprintNodeIdentity(template) !== identity) unique = false;
	}
	return derived.sourcePruner = unique ? skipSourcePruning : pruneInactiveSources;
};
const hasRetainableDescendants = (template, visited) => {
	if (visited.has(template)) return false;
	visited.add(template);
	if (template.kind === "virtual" || template.kind === "array" || template.hasCandidateDescendants) return true;
	for (const entry of template.childEntries) if (!entry.declarations.some((declaration) => declaration.gates.length === 0) || hasRetainableDescendants(entry.node, visited)) return true;
	for (const child of [...template.prefixItems ?? [], ...template.item ? [template.item] : []]) if (!child.declarations.some((declaration) => declaration.gates.length === 0) || hasRetainableDescendants(child, visited)) return true;
	return false;
};

//#endregion
//#region src/core/engine/settle/utils/write/collectReplacePaths.ts
const collectReplacePaths = (writeOrigins) => {
	const paths = [];
	for (let index = 0; index < writeOrigins.length; index++) {
		const origin = writeOrigins[index];
		if (origin.source === "automatic") continue;
		if (origin.keys) for (let key = 0; key < origin.keys.length; key++) paths.push(appendSegment(origin.path, origin.keys[key]));
		else paths.push(origin.path);
		if (origin.fields) paths.push(...origin.fields);
	}
	return paths;
};

//#endregion
//#region src/core/engine/settle/utils/write/markWrongKindAncestors.ts
const markWrongKindAncestors = (node, context) => {
	let parent = node.parent;
	while (parent) {
		if (parent.behavior.type === "object" && parent.behavior.strategy === "branch" && parent.raw !== void 0 && !isPlain(parent.raw)) context.wrongKindHosts.add(parent);
		parent = parent.parent;
	}
};

//#endregion
//#region src/core/engine/settle/utils/write/releaseWrongKindHosts.ts
const releaseWrongKindHosts = (context) => {
	let cleared;
	do {
		cleared = false;
		const hosts = [...context.wrongKindHosts].sort((left, right) => right.depth - left.depth);
		for (const host of hosts) {
			if (host.detached || host.raw === void 0 || isPlain(host.raw)) continue;
			if (!(host.children ?? []).some((child) => child.emit !== void 0)) continue;
			host.raw = void 0;
			context.changedRaw.add(host.path);
			context.changedNodes.add(host);
			context.dirtyPaths.add(host.path);
			context.shapeDirtyPaths.add(host.path);
			cleared = true;
		}
		if (cleared) {
			registerRecalculation(context);
			computeNode(context.root, context);
		}
	} while (cleared);
};

//#endregion
//#region src/core/engine/settle/utils/write/writeFieldNode.ts
const writeFieldNode = (node, input, kind, option, source = kind, writeOrigins) => {
	if (node.detached) return;
	const root = node.rootNode;
	if (source === "input" && (node.disposed || root.disposed)) return;
	const schema = node.schema.schema;
	const inputType = typeof input;
	const scalarWrite = node.parent !== null && !node.disposed && !root.disposed && root.runtime.blueprint.capabilities.branchless && !root.runtime.blueprint.capabilities.hasDerive && (kind === "input" || kind === "callerReplace" || kind === "callerPartial") && (inputType === "string" || inputType === "boolean" || inputType === "number") && node.schemaType === inputType && typeof node.raw === inputType && (inputType !== "number" || Number.isFinite(input) && Number.isFinite(node.raw)) && typeof schema === "object" && schema !== null && schema.type === node.schemaType;
	if (!scalarWrite) {
		assertFieldNodeWritable(node);
		if (node.behavior.type === "virtual" && kind !== "load" && kind !== "automatic") assertVirtualWriteShape(node, input);
	}
	const scratch = getSettlementScratch(root.runtime);
	const replaces = scalarWrite ? kind !== "input" : kind === "callerReplace" || kind === "input" && node.behavior.strategy === "branch" || kind === "callerPartial" && (input === null || typeof input !== "object" || isArray(input) || node.behavior.strategy !== "branch");
	const batch = writeOrigins !== void 0 && writeOrigins.length > 1;
	const context = createSettlementContext(node, kind, option, scratch, replaces && !batch);
	context.source = source;
	context.writeOrigins = writeOrigins;
	if (batch) context.replacePaths = collectReplacePaths(writeOrigins);
	if (!scalarWrite && replaces) prepareWriteEpoch(context);
	try {
		if (context.hasGates) getGateRegistry(context.root.runtime).register(context.root);
		if (!scalarWrite && (replaces || kind === "load")) {
			const pruneSources = prepareSourcePruner(node);
			if (batch) for (let index = 0; index < writeOrigins.length; index++) {
				const origin = writeOrigins[index];
				if (origin.source === "automatic") continue;
				pruneSources(node.runtime, origin.path, origin.keys, context);
				if (origin.fields) for (const field of origin.fields) pruneSources(node.runtime, field, void 0, context);
			}
			else pruneSources(node.runtime, node.path, void 0, context);
		}
		if (!context.hasGates && context.dirtyPaths instanceof DirtyPathSet && !context.dirtyPaths.isPostOrder) context.dirtyPaths.beginPostOrder();
		markWrite(node, input, context);
		if (kind !== "load" && kind !== "automatic") markWrongKindAncestors(node, context);
		registerRecalculation(context);
		computeNode(context.root, context);
		if (!scalarWrite || context.wrongKindHosts.size > 0) releaseWrongKindHosts(context);
		finishSettlement(context, scratch, scalarWrite);
	} finally {
		releaseSettlementScratch(scratch);
	}
};

//#endregion
//#region src/core/engine/utils/cache/clearTreeMemoStores.ts
const clearTreeMemoStores = (runtime) => {
	runtime.committedDeclarationKeys = void 0;
	runtime.deriveTargetIds = void 0;
	runtime.arrayShapes = void 0;
	runtime.objectShapes = void 0;
	runtime.hostBudgetCaps = void 0;
	runtime.arrayChildEntries = void 0;
};

//#endregion
//#region src/core/engine/settle/utils/dispose/disposeFieldNodeTree.ts
const disposeFieldNodeTree = (root) => {
	const runtime = root.runtime;
	visitFieldNodes(root, (node) => {
		if (node.disposed) return;
		node.disposed = true;
		node.interactionReset += 1;
		node.revisionLedger = new FieldNodeRevisionLedger(node.revisionLedger, 8192);
		node.pendingDelivery = void 0;
		node.pendingRevision = 0;
		node.pendingNonSettleDelivery = void 0;
	}, { owned: true });
	for (const subscriptions of runtime.listeners?.values() ?? []) subscriptions.clear();
	runtime.listeners?.clear();
	for (const subscriptions of runtime.inactiveListeners?.values() ?? []) subscriptions.clear();
	runtime.inactiveListeners?.clear();
	clearTreeMemoStores(runtime);
	runtime.validationStamp = (runtime.validationStamp ?? 0) + 1;
	runtime.validationPendingTargets = void 0;
};

//#endregion
//#region src/core/engine/settle/utils/input/interpretFieldNodeInput.ts
const interpretFieldNodeInput = (template, input, live, seen = /* @__PURE__ */ new WeakSet()) => {
	template = live?.blueprintNode ?? template;
	const row = BEHAVIORS[template.kind]?.[template.strategy];
	const value = row ? row.interpret(input, staticSpec(template.schemaType, template.nullable)) : input;
	if (template.strategy !== "branch" || value === null || typeof value !== "object" || seen.has(value)) return value;
	seen.add(value);
	try {
		if (template.kind === "array" && isArray(value)) {
			let copy;
			for (let index = 0; index < value.length; index++) {
				const item = live?.structure?.[String(index)];
				const candidates = getItemEntries(template, index);
				const child = item?.blueprintNode ?? (candidates.length === 1 ? candidates[0].node : void 0);
				if (!child) continue;
				const next = interpretFieldNodeInput(child, value[index], item, seen);
				if (next !== value[index]) (copy ?? (copy = value.slice()))[index] = next;
			}
			return copy ?? value;
		}
		if (template.kind === "object" && isPlain(value)) {
			let children = getHostDerived(template).objectChildren;
			if (!children) {
				const bindings = /* @__PURE__ */ new Map();
				for (const entry of template.childEntries) if (!bindings.has(entry.name)) bindings.set(entry.name, entry.node);
				getHostDerived(template).objectChildren = children = bindings;
			}
			let copy;
			for (const name of Object.keys(value)) {
				const item = live?.structure?.[name];
				const child = item?.blueprintNode ?? children.get(name);
				if (!child) continue;
				const next = interpretFieldNodeInput(child, value[name], item, seen);
				if (next !== value[name]) (copy ?? (copy = { ...value }))[name] = next;
			}
			return copy ?? value;
		}
		return value;
	} finally {
		seen.delete(value);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/readInactiveSlotSource.ts
const readInactiveSlotSource = (context, path, template) => {
	const resolved = resolveSlotSource(context.root, path, template);
	return resolved.source || resolved.overlay ? readSlotRawTree(template, resolved.source, resolved.overlay) : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/slots/readAbsentSlotSource.ts
const readAbsentSlotSource = (host, index, candidates, context) => {
	const name = String(index);
	const path = appendSegment(host.path, name);
	const distribution = getChildDistribution(host, name, context, path);
	if (distribution && !distribution.automatic && hasDistributedChildInput(distribution.input, name, true)) {
		const input = isArray(distribution.input) ? distribution.input[index] : void 0;
		return candidates.length === 1 ? interpretFieldNodeInput(candidates[0].node, input) : input;
	}
	for (const candidate of candidates) {
		const source = readInactiveSlotSource(context, path, candidate.node);
		if (source !== void 0) return source;
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/readSourceTree.ts
const readSourceTree = (node, context) => {
	if (node.detached) return readSlotRawTree(node.blueprintNode, node, void 0);
	if (node.raw !== void 0 || node.behavior.strategy === "terminal") return node.raw;
	if (node.behavior.type === "array") {
		const slots = [];
		let tailStart = 0;
		for (let index = 0; index < node.itemCount; index++) {
			const candidates = getItemEntries(node.blueprintNode, index);
			let value;
			if (candidates.length === 0) value = isArray(node.undeclaredValues) ? node.undeclaredValues[index - tailStart] : void 0;
			else {
				tailStart++;
				const item = node.structure?.[String(index)];
				value = item ? readSourceTree(item, context) : readAbsentSlotSource(node, index, candidates, context);
			}
			slots.push(value);
		}
		return slots;
	}
	const value = isPlain(node.undeclaredValues) ? { ...node.undeclaredValues } : {};
	let found = Object.keys(value).length > 0;
	for (const entry of node.blueprintNode.childEntries) {
		if (hasOwnProperty(value, entry.name)) continue;
		const child = node.structure?.[entry.name];
		const source = child ? readSourceTree(child, context) : readInactiveSlotSource(context, appendSegment(node.path, entry.name), entry.node);
		if (source === void 0) continue;
		Object.defineProperty(value, entry.name, {
			value: source,
			enumerable: true,
			configurable: true,
			writable: true
		});
		found = true;
	}
	return found ? value : void 0;
};

//#endregion
//#region src/core/engine/settle/utils/structure/readArrayLength.ts
const readArrayLength = (node) => node.behavior.strategy === "branch" ? node.itemCount : isArray(node.raw) ? node.raw.length : 0;

//#endregion
//#region src/core/engine/settle/utils/slots/rekeyArraySlotBindings.ts
const rekeyArraySlotBindings = (host, moves, context) => {
	var _host$runtime;
	const entries = new Set(host.inactiveSlots?.keys());
	for (const entry of host.inactiveSlotOverlays?.keys() ?? []) entries.add(entry);
	if (!entries.size) return;
	const destinations = new Map(moves.map((move) => [move.previous, move.current]));
	const pending = [];
	for (const entry of entries) {
		const previous = appendSegment(host.path, entry.name);
		if (!destinations.has(previous)) continue;
		const current = destinations.get(previous);
		if (current === previous) continue;
		const name = current === void 0 ? void 0 : readPointerSegment(current, -1);
		const target = typeof name !== "string" ? void 0 : getItemEntries(host.blueprintNode, Number(name)).find((candidate) => candidate.node === entry.node) ?? {
			...entry,
			name
		};
		const source = host.inactiveSlots?.get(entry);
		const overlay = host.inactiveSlotOverlays?.get(entry);
		markSlotChange(host, entry, void 0, context);
		host.inactiveSlots?.delete(entry);
		host.inactiveSlotOverlays?.delete(entry);
		if (target) pending.push({
			entry: target,
			source,
			overlay
		});
	}
	for (const { entry, source, overlay } of pending) {
		markSlotChange(host, entry, void 0, context);
		if (source) (host.inactiveSlots ?? (host.inactiveSlots = /* @__PURE__ */ new Map())).set(entry, source);
		if (overlay) (host.inactiveSlotOverlays ?? (host.inactiveSlotOverlays = /* @__PURE__ */ new Map())).set(entry, overlay);
	}
	if (host.inactiveSlots?.size || host.inactiveSlotOverlays?.size || host.inactiveSlotChildren?.size) ((_host$runtime = host.runtime).slotDirtyHosts ?? (_host$runtime.slotDirtyHosts = /* @__PURE__ */ new Set())).add(host);
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/rekey/rekeyCommittedRules.ts
const rekeyCommittedRules = (runtime, moves, mapPath) => {
	const { rules } = getRuntimePathStores(runtime);
	const keys = /* @__PURE__ */ new Set();
	for (const move of moves) for (const key of rules.pathIndex.under(move.previous)) keys.add(key);
	if (!keys.size) return;
	rules.pathIndex.beginBatch();
	try {
		const inserts = [];
		for (const key of keys) {
			const parts = JSON.parse(key);
			if (!isArray(parts) || typeof parts[0] !== "string") continue;
			const value = rules.get(key);
			updateCommittedRuleValue(runtime, key, "delete");
			const source = mapPath(parts[0]);
			const target = typeof parts[5] === "string" ? mapPath(parts[5]) : void 0;
			if (source === void 0 || typeof parts[5] === "string" && target === void 0) continue;
			parts[0] = source;
			if (target !== void 0) parts[5] = target;
			inserts.push([JSON.stringify(parts), value]);
		}
		for (const [key, value] of inserts) updateCommittedRuleValue(runtime, key, "set", value);
	} finally {
		rules.pathIndex.endBatch();
	}
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/rekey/rekeyPairedPathStore.ts
const rekeyPairedPathStore = (store, moves, mapPath, transform) => {
	const keys = /* @__PURE__ */ new Set();
	for (const move of moves) for (const key of store.pathIndex.under(move.previous)) keys.add(key);
	const replacements = [];
	for (const key of keys) {
		const parts = JSON.parse(key);
		if (!isArray(parts) || typeof parts[0] !== "string") continue;
		const value = store.get(key);
		const previous = parts[0];
		const path = mapPath(previous);
		if (path === void 0) {
			replacements.push({
				previous: key,
				value,
				paths: []
			});
			continue;
		}
		parts[0] = path;
		replacements.push({
			previous: key,
			key: JSON.stringify(parts),
			value: transform ? transform(value, path, previous) : value,
			paths: [path]
		});
	}
	store.replaceEntries(replacements);
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/rekey/rekeyArrayRuntimePaths.ts
const rekeyArrayRuntimePaths = (runtime, hostPath, moves, preservedPrefixCount = 0) => {
	const stores = getRuntimePathStores(runtime);
	const unaddressed = /* @__PURE__ */ new Set();
	for (const store of [
		stores.declarations,
		stores.rules,
		stores.misfits
	]) {
		if (!store) continue;
		for (const path of store.pathIndex.tail(hostPath, preservedPrefixCount + moves.length)) unaddressed.add(path);
	}
	prunePerishedPaths(runtime, unaddressed);
	const changed = moves.filter((move) => move.previous !== move.current);
	const moveByPath = new Map(moves.map((move) => [move.previous, move.current]));
	const mapPath = (path) => {
		const itemPath = getChildPointer(path, hostPath);
		if (itemPath === void 0) return path;
		const position = Number(readPointerSegment(itemPath, -1));
		if (position >= 0 && position < preservedPrefixCount) return path;
		const destination = moveByPath.get(itemPath);
		return destination === void 0 ? void 0 : rebasePointer(path, itemPath, destination);
	};
	const warningKeys = /* @__PURE__ */ new Set();
	for (const move of changed) for (const key of runtime.warningKeysByPath?.get(move.previous) ?? []) warningKeys.add(key);
	const warningMoves = [];
	for (const key of warningKeys) {
		const parts = JSON.parse(key);
		if (!isArray(parts) || typeof parts[1] !== "string") continue;
		const path = mapPath(parts[1]);
		const record = runtime.pendingWarningRecords?.get(key);
		const remembered = runtime.warningKeys?.has(key) === true;
		indexFieldNodeWarning(runtime, key, parts[1], void 0, true);
		if (path === void 0) continue;
		parts[1] = path;
		warningMoves.push({
			key: JSON.stringify(parts),
			path,
			record,
			remembered
		});
	}
	for (const move of warningMoves) {
		if (move.remembered) (runtime.warningKeys ?? (runtime.warningKeys = /* @__PURE__ */ new Set())).add(move.key);
		indexFieldNodeWarning(runtime, move.key, move.path, move.record);
	}
	rekeyPairedPathStore(stores.declarations, changed, mapPath);
	rekeyCommittedRules(runtime, changed, mapPath);
	const misfitKeys = /* @__PURE__ */ new Set();
	for (const move of changed) for (const path of stores.misfits.pathIndex.under(move.previous)) misfitKeys.add(path);
	const misfits = [];
	for (const path of misfitKeys) {
		const current = mapPath(path);
		misfits.push({
			previous: path,
			current
		});
	}
	stores.misfits.replacePaths(misfits);
	for (const store of [stores.misfitsMemo]) {
		if (!store) continue;
		const keys = /* @__PURE__ */ new Set();
		for (const move of changed) for (const key of store.pathIndex.intersecting(move.previous)) keys.add(key);
		for (const key of keys) store.delete(key);
	}
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/rekey/clearArrayRuntimePaths.ts
const keysBeneath = (index, hostPath, keep) => {
	const keys = /* @__PURE__ */ new Set();
	for (const slot of [...index.tail(hostPath, 0)]) if (keep(slot)) for (const key of index.under(slot)) keys.add(key);
	return keys;
};
const clearArrayRuntimePaths = (runtime, hostPath, oldCount, _perished) => {
	const stores = getRuntimePathStores(runtime);
	const inRange = (slot) => Number(readPointerSegment(slot, -1)) < oldCount;
	const owned = [
		stores.declarations,
		stores.rules,
		stores.misfits
	];
	const slots = /* @__PURE__ */ new Set();
	for (const store of owned) {
		if (!store) continue;
		for (const slot of store.pathIndex.tail(hostPath, 0)) slots.add(slot);
	}
	if (runtime.warningKeysByPath?.get(hostPath)?.size) {
		const warningKeys = /* @__PURE__ */ new Set();
		for (let index = 0; index < oldCount; index++) for (const key of runtime.warningKeysByPath.get(appendSegment(hostPath, index)) ?? []) warningKeys.add(key);
		for (const slot of slots) if (!inRange(slot)) for (const key of runtime.warningKeysByPath.get(slot) ?? []) warningKeys.add(key);
		for (const key of warningKeys) {
			const parts = JSON.parse(key);
			if (isArray(parts) && typeof parts[1] === "string") indexFieldNodeWarning(runtime, key, parts[1], void 0, true);
		}
	}
	for (const slot of slots) {
		for (const store of [stores.misfits, stores.declarations]) {
			if (!store) continue;
			for (const key of store.pathIndex.under(slot)) store.delete(key);
		}
		for (const key of stores.rules.pathIndex.under(slot)) updateCommittedRuleValue(runtime, key, "delete");
	}
	if (oldCount === 0) return;
	for (const store of [stores.misfitsMemo]) {
		if (!store) continue;
		const keys = keysBeneath(store.pathIndex, hostPath, inRange);
		for (const key of store.pathIndex.intersecting(appendSegment(hostPath, 0))) keys.add(key);
		for (const key of keys) store.delete(key);
	}
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/applyArrayTail.ts
const readPositionLoadValue = (hostValue, key) => hostValue !== null && typeof hostValue === "object" ? Reflect.get(hostValue, key) : void 0;
const applyArrayTail = (host, plan, context, offset = 0) => {
	const oldCount = host.itemCount;
	const length = offset + plan.slots.length;
	const prefixCount = Math.min(oldCount, length);
	const items = host.structure ?? Object.create(null);
	const snapshot = getLoadValue(host.runtime.loadSnapshot, host.path);
	const oldSnapshot = isArray(snapshot) ? snapshot : [];
	const oldExtras = isArray(host.undeclaredValues) ? host.undeclaredValues : [];
	const templateCount = host.blueprintNode.prefixItems?.length ?? 0;
	const removedIndex = plan.result.source === "removed" ? plan.result.index : -1;
	const removedItem = items[String(removedIndex)];
	const removedEntry = removedIndex < 0 ? void 0 : getItemEntry(host.blueprintNode, removedIndex);
	const removed = removedIndex < 0 ? void 0 : removedItem ? removedItem.local : removedEntry ? readInactiveSlotSource(context, appendSegment(host.path, removedIndex), removedEntry.node) : oldExtras[removedIndex - templateCount];
	const registry = getGateRegistry(host.runtime);
	if (context.hasGates) for (const item of host.children ?? []) registry.remove(item);
	const children = (host.children ?? []).slice(0, prefixCount);
	const nextSnapshot = new Array(prefixCount);
	for (let index = 0; index < prefixCount; index++) nextSnapshot[index] = oldSnapshot[index];
	const extras = [];
	if (!host.blueprintNode.item) for (let index = templateCount; index < prefixCount; index++) extras.push(oldExtras[index - templateCount]);
	const created = [];
	for (let index = prefixCount; index < length; index++) {
		const slot = plan.slots[index - offset];
		if (!("value" in slot)) continue;
		nextSnapshot.push(slot.value);
		const entry = getItemEntry(host.blueprintNode, index);
		if (!entry) {
			extras.push(slot.value);
			continue;
		}
		const node = createChildNode(host, entry);
		items[String(index)] = node;
		children.push(node);
		created.push({
			node,
			value: slot.value
		});
	}
	const moves = [];
	let perishedPaths;
	for (let index = prefixCount; index < oldCount; index++) {
		const key = String(index);
		const item = items[key];
		if (length) moves.push({ previous: appendSegment(host.path, index) });
		if (!item) continue;
		context.perished.add(item);
		const load = !item.detached && item.path === appendSegment(host.path, key) ? { value: readPositionLoadValue(snapshot, key) } : void 0;
		visitFieldNodes(item, (departing) => {
			if (!departing.runtime.detachedReads?.has(departing)) captureDetachedFieldNodeReads(departing, {
				emit: context.previousEmit,
				context: context.previousContext,
				schema: departing.schema.schema
			}, departing === item ? load : void 0);
		}, { owned: true });
		(perishedPaths ?? (perishedPaths = /* @__PURE__ */ new Set())).add(item.path);
		delete items[String(index)];
	}
	if (!length) clearArrayRuntimePaths(host.runtime, host.path, oldCount, perishedPaths ?? /* @__PURE__ */ new Set());
	else {
		if (perishedPaths) prunePerishedPaths(host.runtime, perishedPaths);
		rekeyArrayRuntimePaths(host.runtime, host.path, moves, prefixCount);
	}
	host.itemCount = length;
	host.raw = void 0;
	host.undeclaredValues = extras.length ? extras : void 0;
	host.structure = items;
	host.children = captureFieldNodeChange(host, "children", children);
	context.arrayCounts.set(host, oldCount);
	context.changedRaw.add(host.path);
	context.changedNodes.add(host);
	context.dirtyPaths.add(host.path);
	context.shapeDirtyPaths.add(host.path);
	for (const { node, value } of created) {
		context.entered.add(node);
		markWrite(node, value, context);
	}
	if (context.hasGates) for (const item of host.children) visitFieldNodes(item, (node) => {
		registry.register(node);
	}, { owned: true });
	host.runtime.loadSnapshot = setLoadValue(host.runtime.loadSnapshot, host.path, nextSnapshot);
	return removed;
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/canApplyArrayTail.ts
const canApplyArrayTail = (host, plan) => {
	const template = host.blueprintNode;
	if ((template.itemCandidates?.length ?? 0) > 1 || template.prefixItemCandidates?.some((candidates) => candidates.length > 1)) return false;
	if (host.raw !== void 0 || host.itemCount === plan.slots.length) return false;
	const prefixCount = Math.min(host.itemCount, plan.slots.length);
	for (let index = 0; index < prefixCount; index++) {
		const slot = plan.slots[index];
		if (!("from" in slot) || slot.from !== index) return false;
		const entry = getItemEntry(host.blueprintNode, index);
		const item = host.structure?.[String(index)];
		if (entry ? !item || item.blueprintNode !== entry.node || item.name !== String(index) : item !== void 0) return false;
	}
	for (let index = prefixCount; index < plan.slots.length; index++) if (!("value" in plan.slots[index])) return false;
	return true;
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/applyArraySlots.ts
const applyArraySlots = (host, plan, context) => {
	if (canApplyArrayTail(host, plan)) return applyArrayTail(host, plan, context);
	const oldCount = host.itemCount;
	const oldItems = host.structure ?? {};
	let rawSlots = host.raw === void 0 && host.blueprintNode.item && !host.blueprintNode.prefixItems?.length && host.undeclaredValues === void 0 ? void 0 : readRawSlots(host, context);
	const snapshot = getLoadValue(host.runtime.loadSnapshot, host.path);
	const oldSnapshot = isArray(snapshot) ? snapshot : [];
	const removedIndex = plan.result.source === "removed" ? plan.result.index : -1;
	const removedItem = oldItems[String(removedIndex)];
	const removed = removedIndex < 0 ? void 0 : removedItem ? removedItem.local : (rawSlots ?? (rawSlots = readRawSlots(host, context)))[removedIndex];
	const registry = getGateRegistry(host.runtime);
	if (context.hasGates) for (const item of host.children ?? []) registry.remove(item);
	const nextItems = Object.create(null);
	const nextRaw = [];
	const nextSnapshot = [];
	const reused = /* @__PURE__ */ new Set();
	const created = [];
	let deferred = false;
	const destinations = /* @__PURE__ */ new Map();
	const candidateMoves = host.blueprintNode.hasCandidateDescendants === true;
	for (let index = 0; index < plan.slots.length; index++) {
		const slot = plan.slots[index];
		const from = "from" in slot ? slot.from : void 0;
		const value = "value" in slot ? slot.value : rawSlots?.[slot.from];
		nextRaw.push(value);
		nextSnapshot.push("value" in slot ? slot.value : oldSnapshot[slot.from]);
		const candidates = getItemEntries(host.blueprintNode, index);
		const sourceCandidates = from !== void 0 && candidateMoves ? getItemEntries(host.blueprintNode, from) : void 0;
		const moved = from !== void 0 && candidateMoves && (candidates.length > 1 || candidates.some((candidate) => candidate.node.hasCandidateDescendants) || sourceCandidates !== void 0 && (sourceCandidates.length > 1 || sourceCandidates.some((candidate) => candidate.node.hasCandidateDescendants)));
		if (from !== void 0 && moved) destinations.set(from, index);
		const entry = candidates[0];
		if (!entry && !moved) continue;
		const old = from === void 0 ? void 0 : oldItems[String(from)];
		if (old && candidates.some((candidate) => old.blueprintNode === candidate.node)) {
			nextItems[String(index)] = old;
			reused.add(old);
			if (from !== void 0 && !moved) destinations.set(from, index);
			continue;
		}
		const source = from === void 0 || rawSlots ? value : (rawSlots = readRawSlots(host, context))[from];
		if (from !== void 0 && !old && !moved) destinations.set(from, index);
		if (old && moved) {
			const binding = getRetainedChildEntry(host, old.name, old.blueprintNode);
			if (binding) {
				markSlotChange(host, binding, old, context);
				(host.inactiveSlots ?? (host.inactiveSlots = /* @__PURE__ */ new Map())).set(binding, old);
			}
		}
		if (!entry) continue;
		if (candidates.length > 1) {
			nextRaw[index] = source;
			deferred = true;
			continue;
		}
		const node = createChildNode(host, entry);
		nextItems[String(index)] = node;
		created.push({
			node,
			value: source,
			moved
		});
	}
	const moves = [];
	for (let index = 0; index < oldCount; index++) {
		const item = oldItems[String(index)];
		const current = destinations.get(index);
		moves.push({
			previous: appendSegment(host.path, index),
			current: current === void 0 ? void 0 : appendSegment(host.path, current)
		});
		if (!item || reused.has(item)) continue;
		context.perished.add(item);
		visitFieldNodes(item, (departing) => {
			if (!departing.runtime.detachedReads?.has(departing)) captureDetachedFieldNodeReads(departing, {
				emit: context.previousEmit,
				context: context.previousContext,
				schema: departing.schema.schema
			});
		}, { owned: true });
	}
	rekeyArraySlotBindings(host, moves, context);
	rekeyArrayRuntimePaths(host.runtime, host.path, moves);
	if (candidateMoves) (context.rekeyedArrayMoves ?? (context.rekeyedArrayMoves = /* @__PURE__ */ new Map())).set(host, moves);
	for (const [name, item] of Object.entries(nextItems)) {
		if (!reused.has(item) || item.name === name) continue;
		visitFieldNodes(item, (descendant) => {
			var _descendant$runtime;
			const previous = descendant.path;
			updateFieldNodeNameAndPath(descendant, descendant === item ? name : descendant.name, descendant === item ? host : descendant.parent);
			context.pathChanges.push({
				node: descendant,
				previous,
				current: descendant.path
			});
			if (descendant.inactiveSlots?.size || descendant.inactiveSlotOverlays?.size || descendant.inactiveSlotChildren?.size) ((_descendant$runtime = descendant.runtime).slotDirtyHosts ?? (_descendant$runtime.slotDirtyHosts = /* @__PURE__ */ new Set())).add(descendant);
			context.dirtyPaths.add(descendant.path);
			if (descendant.behavior.strategy === "branch") context.shapeDirtyPaths.add(descendant.path);
			context.changedNodes.add(descendant);
		}, { owned: true });
	}
	host.itemCount = plan.slots.length;
	host.raw = void 0;
	host.undeclaredValues = arrayExtras(host, nextRaw);
	host.structure = nextItems;
	host.children = captureFieldNodeChange(host, "children", Object.values(nextItems));
	context.arrayCounts.set(host, oldCount);
	context.changedRaw.add(host.path);
	context.changedNodes.add(host);
	context.dirtyPaths.add(host.path);
	context.shapeDirtyPaths.add(host.path);
	if (deferred) {
		const distribution = {
			input: nextRaw,
			whole: false,
			automatic: false
		};
		context.distributedInputs.set(host, {
			...distribution,
			preserveLatent: true
		});
	}
	for (const { node, value, moved } of created) {
		context.entered.add(node);
		if (moved) replayMovedSource(node, value, context);
		else markWrite(node, value, context);
	}
	if (context.hasGates) for (const item of host.children) visitFieldNodes(item, (node) => {
		registry.register(node);
	}, { owned: true });
	host.runtime.loadSnapshot = setLoadValue(host.runtime.loadSnapshot, host.path, nextSnapshot);
	return removed;
};
const readRawSlots = (host, context) => {
	const raw = readSourceTree(host, context);
	return isArray(raw) ? raw : [];
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/applyArraySplice.ts
const applyArraySplice = (host, proof, context) => {
	const { count, index, entry } = proof;
	const length = entry ? count + 1 : count - 1;
	const items = host.structure ?? Object.create(null);
	const previous = host.children ?? [];
	const removedItem = entry ? void 0 : items[String(index)];
	const removed = removedItem?.local;
	const slot = proof.plan.slots[0];
	const value = slot && "value" in slot ? slot.value : void 0;
	const inserted = entry ? createChildNode(host, entry) : void 0;
	const snapshot = getLoadValue(host.runtime.loadSnapshot, host.path);
	const oldSnapshot = isArray(snapshot) ? snapshot : [];
	const nextSnapshot = new Array(length);
	for (let position = 0; position < index; position++) nextSnapshot[position] = oldSnapshot[position];
	const children = previous.slice(0, index);
	const moves = [];
	if (inserted) {
		nextSnapshot[index] = value;
		children.push(inserted);
		for (let position = index; position < count; position++) {
			nextSnapshot[position + 1] = oldSnapshot[position];
			children.push(previous[position]);
			moves.push({
				previous: appendSegment(host.path, position),
				current: appendSegment(host.path, position + 1)
			});
		}
		for (let position = count; position > index; position--) items[String(position)] = items[String(position - 1)];
		items[String(index)] = inserted;
	} else {
		moves.push({ previous: appendSegment(host.path, index) });
		for (let position = index + 1; position < count; position++) {
			nextSnapshot[position - 1] = oldSnapshot[position];
			children.push(previous[position]);
			moves.push({
				previous: appendSegment(host.path, position),
				current: appendSegment(host.path, position - 1)
			});
			items[String(position - 1)] = items[String(position)];
		}
		delete items[String(count - 1)];
	}
	if (removedItem) {
		context.perished.add(removedItem);
		visitFieldNodes(removedItem, (departing) => {
			if (!departing.runtime.detachedReads?.has(departing)) captureDetachedFieldNodeReads(departing, {
				emit: context.previousEmit,
				context: context.previousContext,
				schema: departing.schema.schema
			});
		}, { owned: true });
		prunePerishedPaths(host.runtime, /* @__PURE__ */ new Set([removedItem.path]));
	}
	rekeyArrayRuntimePaths(host.runtime, host.path, moves, index);
	for (let position = inserted ? index + 1 : index; position < length; position++) {
		const item = items[String(position)];
		const name = String(position);
		visitFieldNodes(item, (descendant) => {
			const former = descendant.path;
			updateFieldNodeNameAndPath(descendant, descendant === item ? name : descendant.name, descendant === item ? host : descendant.parent);
			context.pathChanges.push({
				node: descendant,
				previous: former,
				current: descendant.path
			});
			context.changedNodes.add(descendant);
		}, { owned: true });
	}
	host.itemCount = length;
	host.raw = void 0;
	host.undeclaredValues = void 0;
	host.structure = items;
	host.children = captureFieldNodeChange(host, "children", children);
	context.arrayCounts.set(host, count);
	context.changedRaw.add(host.path);
	context.changedNodes.add(host);
	context.dirtyPaths.add(host.path);
	context.shapeDirtyPaths.add(host.path);
	if (inserted) {
		context.entered.add(inserted);
		markWrite(inserted, value, context);
	}
	host.runtime.loadSnapshot = setLoadValue(host.runtime.loadSnapshot, host.path, nextSnapshot);
	return removed;
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/admitsStaticArrayTail.ts
const admitsStaticArrayTail = (node, allowUndeclared = false) => {
	const runtime = node.runtime;
	const count = node.itemCount;
	const local = node.local;
	const extrasOnly = allowUndeclared && !node.blueprintNode.item && !node.blueprintNode.prefixItems?.length;
	return !(node.behavior.arrange !== BEHAVIORS.array?.branch?.arrange || node.behavior.type !== "array" || node.behavior.strategy !== "branch" || node.detached || !node.active || !node.deliveryInitialized || runtime.batchDepth || runtime.visitDepth || !StaticFirstLoadCapability.has(runtime.blueprint) || node.inactiveSlots?.size || node.inactiveSlotOverlays?.size || node.inactiveSlotChildren?.size || runtime.misfitPaths.size > 0 || node.raw !== void 0 || (extrasOnly ? (node.children?.length ?? 0) !== 0 || (isArray(node.undeclaredValues) ? node.undeclaredValues.length : 0) !== count : node.undeclaredValues !== void 0 || !node.blueprintNode.item || (node.children?.length ?? 0) !== count) || !isArray(local) || local.length !== count || count > 0 && !node.structure || getStaticChoices(node.schema).omitTrailing || !isArray(getLoadValue(node.rootNode.emit, node.path)));
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/prepareArrayAppend.ts
const NO_ACTIVE_IDS$1 = Object.freeze([]);
const LENGTH_RESULT$1 = { source: "length" };
const prepareArrayAppend = (node, operation) => {
	const count = node.itemCount;
	if (operation.kind !== "push" && (operation.kind !== "insert" || operation.index !== count)) return void 0;
	const template = node.blueprintNode;
	if (!admitsStaticArrayTail(node, true) || count < (template.prefixItems?.length ?? 0)) return void 0;
	const entry = getItemEntry(template, count);
	if (entry && (entry.node.kind === "virtual" || !entry.declarations.length)) return void 0;
	const schema = entry ? mergeEffectiveSchema(entry.node, NO_ACTIVE_IDS$1, {
		mode: "runtime",
		isAtomic: node.runtime.blueprint.isAtomic
	}) : void 0;
	if (schema?.typeConflict) return void 0;
	return {
		host: node,
		count,
		entry,
		schema,
		plan: {
			kind: "slots",
			slots: [{ value: operation.value }],
			result: LENGTH_RESULT$1
		},
		local: node.local,
		valid: true
	};
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/prepareArrayPop.ts
const NO_SLOTS$1 = Object.freeze([]);
const prepareArrayPop = (node, operation) => {
	const count = node.itemCount;
	const index = count - 1;
	if (operation.kind !== "pop" && (operation.kind !== "remove" || operation.index !== index) || index < (node.blueprintNode.prefixItems?.length ?? 0) || !admitsStaticArrayTail(node)) return void 0;
	const last = node.structure?.[String(index)];
	if (!last || node.children?.[index] !== last) return void 0;
	return {
		host: node,
		count,
		plan: {
			kind: "slots",
			slots: NO_SLOTS$1,
			result: {
				source: "removed",
				index
			}
		},
		local: node.local,
		valid: true
	};
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/utils/arraySlots/prepareArraySplice.ts
const NO_ACTIVE_IDS = Object.freeze([]);
const LENGTH_RESULT = { source: "length" };
const NO_SLOTS = Object.freeze([]);
const prepareArraySplice = (node, operation) => {
	if (operation.kind !== "remove" && operation.kind !== "insert") return void 0;
	const count = node.itemCount;
	const index = operation.index;
	const template = node.blueprintNode;
	if (!Number.isInteger(index) || index < (template.prefixItems?.length ?? 0) || index >= (operation.kind === "remove" ? count - 1 : count) || !admitsStaticArrayTail(node)) return void 0;
	const items = node.structure;
	const children = node.children;
	for (let position = index; position < count; position++) {
		const item = items?.[String(position)];
		if (!item || children?.[position] !== item || item.name !== String(position) || item.blueprintNode !== template.item) return void 0;
	}
	if (operation.kind === "remove") return {
		host: node,
		count,
		index,
		plan: {
			kind: "slots",
			slots: NO_SLOTS,
			result: {
				source: "removed",
				index
			}
		},
		valid: true
	};
	const entry = getItemEntry(template, index);
	if (!entry || entry.node.kind === "virtual" || !entry.declarations.length) return void 0;
	const schema = mergeEffectiveSchema(entry.node, NO_ACTIVE_IDS, {
		mode: "runtime",
		isAtomic: node.runtime.blueprint.isAtomic
	});
	if (schema.typeConflict) return void 0;
	return {
		host: node,
		count,
		index,
		entry,
		schema,
		plan: {
			kind: "slots",
			slots: [{ value: operation.value }],
			result: LENGTH_RESULT
		},
		valid: true
	};
};

//#endregion
//#region src/core/engine/settle/arrangeFieldNodeItems/arrangeFieldNodeItems.ts
const resultOf = (node, plan, removed) => {
	if (plan.kind === "update") return void 0;
	if (plan.result.source === "removed") return removed;
	if (plan.result.source === "length") return plan.kind === "slots" ? node.itemCount : isArray(node.raw) ? node.raw.length : 0;
	if (plan.result.source === "updated") return isArray(node.local) ? node.local[plan.result.index] : void 0;
};
const arrangeFieldNodeItems = (node, operation) => {
	if (node.detached) return operation.kind === "push" || operation.kind === "insert" ? readArrayLength(node) : void 0;
	const append = prepareArrayAppend(node, operation);
	const pop = append ? void 0 : prepareArrayPop(node, operation);
	const splice = append || pop ? void 0 : prepareArraySplice(node, operation);
	const plan = append ? append.plan : pop ? pop.plan : splice ? splice.plan : node.behavior.arrange(node, operation);
	if (plan.kind === "noop") return operation.kind === "push" || operation.kind === "insert" ? readArrayLength(node) : void 0;
	if (plan.kind === "raw") {
		const previous = isArray(node.raw) && plan.result.source === "removed" ? node.raw[plan.result.index] : void 0;
		writeFieldNode(node, plan.raw, "callerReplace", WriteOption.Overwrite);
		return resultOf(node, plan, previous);
	}
	if (plan.kind === "update" && !node.structure?.[String(plan.index)]) {
		const scratch = getSettlementScratch(node.rootNode.runtime);
		const context = createSettlementContext(node, "callerReplace", WriteOption.Overwrite, scratch);
		let oldRaw;
		try {
			oldRaw = readSourceTree(node, context);
		} finally {
			releaseSettlementScratch(scratch);
		}
		const copy = isArray(oldRaw) ? oldRaw.slice() : [];
		copy[plan.index] = plan.value;
		writeFieldNode(node, copy, "callerReplace", WriteOption.Overwrite);
		const item = node.structure?.[String(plan.index)];
		if (item) return item.local;
		const readScratch = getSettlementScratch(node.rootNode.runtime);
		try {
			const current = readSourceTree(node, createSettlementContext(node, "callerReplace", WriteOption.Overwrite, readScratch));
			return isArray(current) ? current[plan.index] : void 0;
		} finally {
			releaseSettlementScratch(readScratch);
		}
	}
	if (plan.kind === "update") {
		const item = node.structure?.[String(plan.index)];
		if (!item) return void 0;
		writeFieldNode(item, plan.value, "callerReplace", WriteOption.Overwrite);
		return item.local;
	}
	const scratch = getSettlementScratch(node.rootNode.runtime);
	const context = createSettlementContext(node, "callerReplace", WriteOption.Overwrite, scratch);
	try {
		if (context.hasGates) getGateRegistry(context.root.runtime).register(context.root);
		let removed;
		if (append) {
			context.arrayAppend = append;
			removed = applyArrayTail(node, append.plan, context, append.count);
			append.children = node.children;
			append.snapshot = node.runtime.loadSnapshot;
		} else if (pop) {
			context.arrayPop = pop;
			removed = applyArrayTail(node, pop.plan, context, pop.count - 1);
			pop.children = node.children;
			pop.snapshot = node.runtime.loadSnapshot;
		} else if (splice) {
			context.arraySplice = splice;
			removed = applyArraySplice(node, splice, context);
			splice.children = node.children;
			splice.pathChanges = context.pathChanges.length;
		} else removed = applyArraySlots(node, plan, context);
		registerRecalculation(context);
		computeNode(context.root, context);
		finishSettlement(context, scratch);
		return resultOf(node, plan, removed);
	} finally {
		releaseSettlementScratch(scratch);
	}
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/canLoadStaticFirstTree.ts
const canLoadStaticFirstTree = (root, value) => value === void 0 && root.parent === null && !root.disposed && !root.detached && !root.deliveryInitialized && !root.runtime.commitNumber && !root.children?.length && !root.pendingDelivery && !root.pendingRevision && root.raw === void 0 && root.undeclaredValues === void 0 && !root.runtime.deliveries?.size && root.runtime.globalStateCounts.size === 0 && StaticFirstLoadCapability.has(root.runtime.blueprint);

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/assembleStaticFirstNode.ts
const NO_CHILDREN = Object.freeze([]);
const assembleStaticFirstNode = (node) => {
	const children = node.children ?? NO_CHILDREN;
	let local;
	let emit;
	switch (node.behavior.type) {
		case "object":
			local = node.behavior.assemble(node, children);
			emit = node.behavior.project(node, local);
			break;
		case "array":
			local = node.behavior.assemble(node, children);
			emit = node.behavior.project(node, local);
			break;
		case "string":
			local = node.behavior.assemble(node, children);
			emit = node.behavior.project(node, local);
			break;
		case "number":
			local = node.behavior.assemble(node, children);
			emit = node.behavior.project(node, local);
			break;
		case "boolean":
			local = node.behavior.assemble(node, children);
			emit = node.behavior.project(node, local);
			break;
		case "null":
			local = node.behavior.assemble(node, children);
			emit = node.behavior.project(node, local);
	}
	node.local = local;
	node.emit = node.parent === null && emit === void 0 && (node.behavior.type === "object" || node.behavior.type === "array") ? local : emit;
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/commitStaticFirstNode.ts
const STATIC_FIRST_DELIVERY_TYPE = 4 | 8192;
const commitStaticFirstNode = (node, automatic) => {
	const type = STATIC_FIRST_DELIVERY_TYPE;
	const silent = canOmitFieldNodePayload(node);
	if (silent) node.pendingDelivery = void 0;
	else {
		const payload = {
			previous: void 0,
			current: node.behavior.strategy === "branch" ? {
				local: node.local,
				emit: node.emit
			} : node.local
		};
		node.pendingDelivery = {
			type,
			payload: { [4]: __SCHEMA_FORM_DEV__ ? Object.freeze(payload) : payload },
			options: { [4]: { source: automatic ? "automatic" : "load" } }
		};
	}
	node.deliveryInitialized = true;
	if (silent) advanceFieldNodeRevision(node, type, silent);
	else node.revisionLedger = new FieldNodeRevisionLedger(node.revisionLedger, type);
	node.pendingRevision = 0;
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/finishStaticFirstLoad.ts
const EMPTY_WARNINGS = Object.freeze([]);
const EMPTY_PATHS = Object.freeze([]);
const finishStaticFirstLoad = (root, option, warnings) => {
	const runtime = root.runtime;
	const commit = runtime.commitNumber;
	if (__SCHEMA_FORM_DEV__) runtime.settlementTrace = {
		entry: {
			api: "load",
			option
		},
		rounds: []
	};
	else delete runtime.settlementTrace;
	runtime.refreshTargets ?? (runtime.refreshTargets = /* @__PURE__ */ new Set());
	runtime.refreshTargets.clear();
	const records = warnings ? [] : void 0;
	if (warnings) {
		warnings.sort((left, right) => left.order - right.order);
		for (let index = 0; index < warnings.length; index++) {
			const warning = warnings[index].warning;
			records.push(warning);
			runtime.misfitPaths.add(warning.path);
			if (!runtime.errorReporter?.hasConsumer()) continue;
			const code = FormWarningCode.Misfit;
			const record = {
				level: "warning",
				code,
				path: warning.path,
				message: "Value does not fit the schema type at " + warning.path + " (commit " + commit + ")",
				details: {
					path: warning.path,
					expected: warning.expected,
					received: warning.received,
					reason: warning.reason,
					...warning.candidates ? { candidates: warning.candidates } : {},
					source: warning.source
				}
			};
			indexFieldNodeWarning(runtime, JSON.stringify([
				code,
				warning.path,
				commit
			]), warning.path, record);
			runtime.chainOccurrences?.push({
				kind: "record",
				record
			});
		}
	}
	runtime.misfitRecords = records ? Object.freeze(records) : EMPTY_WARNINGS;
	const memo = runtime.misfitsMemo ?? (runtime.misfitsMemo = new PathKeyedMap("path"));
	memo.clear();
	if (!runtime.misfitPaths.size) memo.set("", {
		commit,
		paths: EMPTY_PATHS
	});
	else {
		const paths = [...runtime.misfitPaths].sort();
		memo.set("", {
			commit,
			paths: Object.freeze(paths)
		});
		const byAncestor = /* @__PURE__ */ new Map();
		for (let index = 0; index < paths.length; index++) {
			const path = paths[index];
			let ancestor = path;
			while (ancestor) {
				let children = byAncestor.get(ancestor);
				if (!children) {
					children = [];
					byAncestor.set(ancestor, children);
				}
				children.push(path);
				ancestor = resolvePointer(ancestor, "..");
			}
		}
		for (const [ancestor, children] of byAncestor) memo.set(ancestor, {
			commit,
			paths: Object.freeze(children)
		});
	}
	runtime.misfitsMemoBuild = {
		memo,
		size: memo.size,
		mutations: runtime.misfitPaths.mutations
	};
	runtime.deliveredDiagnostics = runtime.diagnostics;
	runtime.deliveredContext = runtime.context;
	runtime.deliveryAffectedPaths = void 0;
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/getStaticObjectEntries.ts
const getStaticObjectEntries = (template) => {
	const cached = getHostDerived(template).staticObjectEntries;
	if (cached) return cached;
	const byName = Object.create(null);
	const entries = template.childEntries;
	for (let index = 0; index < entries.length; index++) byName[entries[index].name] = entries[index];
	const result = Object.freeze(Object.values(byName));
	getHostDerived(template).staticObjectEntries = result;
	return result;
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/isMissingStaticInput.ts
const isMissingStaticInput = (template, value) => {
	if (value === void 0) return true;
	if (template.strategy !== "branch") return false;
	if (template.kind === "array") {
		if (!isArray(value)) return false;
		for (let index = 0; index < value.length; index++) {
			const entry = getItemEntry(template, index);
			if (!entry || !isMissingStaticInput(entry.node, value[index])) return false;
		}
		return true;
	}
	if (!isPlain(value)) return false;
	const names = Object.keys(value);
	const declared = getDeclaredChildNames(template);
	for (let index = 0; index < names.length; index++) if (!declared.has(names[index])) return false;
	const entries = template.childEntries;
	for (let index = 0; index < entries.length; index++) {
		const entry = entries[index];
		if (hasOwnProperty(value, entry.name) && !isMissingStaticInput(entry.node, Reflect.get(value, entry.name))) return false;
	}
	return true;
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/readStaticFirstWarning.ts
const readStaticFirstWarning = (node, automatic) => {
	const schemaType = node.schemaType;
	const effective = effectiveType(node);
	if (schemaType === void 0 || effective === void 0) return void 0;
	if (!isMisfit(node.raw, effective, node.nullable)) return void 0;
	const candidates = conversionCandidates(node, effective);
	const ambiguous = candidates.length > 1;
	return {
		level: "warning",
		code: FormWarningCode.Misfit,
		path: node.path,
		expected: {
			schemaType,
			nullable: node.nullable,
			effective
		},
		received: receivedType(node.raw),
		reason: ambiguous ? "ambiguous" : "unconvertible",
		...ambiguous ? { candidates } : {},
		source: automatic ? "fill" : "load"
	};
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/utils/staticFirst/loadStaticFirstTree.ts
const EMPTY = Object.freeze([]);
const loadStaticFirstTree = (root, option) => {
	const runtime = root.runtime;
	const commit = (runtime.commitNumber ?? 0) + 1;
	const disable = (option & WriteOption.DisableAutomaticWrites) !== 0;
	const enable = (option & WriteOption.EnableAutomaticWrites) !== 0;
	const suppress = disable || !enable && runtime.disableAutomaticWrites === true;
	const deliveries = runtime.deliveries ?? (runtime.deliveries = /* @__PURE__ */ new Set());
	const stack = [{
		node: root,
		input: void 0,
		automatic: false,
		blocked: false,
		entered: false,
		index: 0,
		entries: EMPTY,
		required: EMPTY,
		order: 0,
		children: void 0
	}];
	let deltas;
	let warnings;
	let order = 0;
	while (stack.length) {
		const frame = stack[stack.length - 1];
		const node = frame.node;
		if (!frame.entered) {
			frame.entered = true;
			frame.order = order++;
			deliveries.add(node);
			const schema = node.schema.schema;
			const authored = typeof schema === "object" && schema !== null ? schema : void 0;
			const fallback = authored && hasOwnProperty(authored, "default") ? authored.default : void 0;
			let input = frame.input;
			if (!frame.blocked && !suppress && fallback !== void 0 && !(node.behavior.type === "array" && node.behavior.strategy === "branch" && input !== void 0) && isMissingStaticInput(node.blueprintNode, input)) {
				input = fallback;
				frame.automatic = true;
			}
			const value = node.behavior.interpret(input, staticSpec(node.schemaType, node.nullable));
			frame.input = value;
			if (node.behavior.strategy === "branch") {
				node.structure = Object.create(null);
				node.children = frame.children = [];
				if (node.behavior.type === "array") {
					const array = isArray(value);
					node.itemCount = array ? value.length : 0;
					node.raw = array ? void 0 : value;
					node.undeclaredValues = array ? arrayExtras(node, value) : void 0;
					frame.entries = node.behavior.declareChildren(node);
				} else {
					const object = isPlain(value);
					node.raw = object ? void 0 : value;
					node.undeclaredValues = object ? nextExtras(void 0, value, getDeclaredChildNames(node.blueprintNode), false) : void 0;
					frame.entries = getStaticObjectEntries(node.blueprintNode);
					frame.required = isArray(authored?.required) ? authored.required : EMPTY;
				}
			} else node.raw = value;
			const state = node.interactionState;
			for (const key in state) if (hasOwnProperty(state, key) && state[key]) {
				deltas ?? (deltas = /* @__PURE__ */ new Map());
				deltas.set(key, (deltas.get(key) ?? 0) + 1);
			}
		}
		if (frame.index < frame.entries.length) {
			const entry = frame.entries[frame.index++];
			const child = createChildNode(node, entry);
			node.structure[entry.name] = child;
			frame.children.push(child);
			child.required = frame.required.includes(entry.name);
			const input = frame.input !== null && typeof frame.input === "object" && hasOwnProperty(frame.input, entry.name) ? Reflect.get(frame.input, entry.name) : void 0;
			stack.push({
				node: child,
				input,
				automatic: frame.automatic,
				blocked: frame.blocked || node.behavior.strategy === "branch" && node.raw !== void 0,
				entered: false,
				index: 0,
				entries: EMPTY,
				required: EMPTY,
				order: 0,
				children: void 0
			});
			continue;
		}
		assembleStaticFirstNode(node);
		commitStaticFirstNode(node, frame.automatic);
		const warning = readStaticFirstWarning(node, frame.automatic);
		if (warning) (warnings ?? (warnings = [])).push({
			order: frame.order,
			warning
		});
		stack.pop();
	}
	runtime.commitNumber = commit;
	if (deltas) publishGlobalStateDeltas(root, deltas);
	finishStaticFirstLoad(root, option, warnings);
};

//#endregion
//#region src/core/engine/settle/loadFieldNodeAtMount/loadFieldNodeAtMount.ts
const loadFieldNodeAtMount = (root, value, option) => {
	const nextSnapshot = setLoadValue(root.runtime.loadSnapshot, "", value);
	root.runtime.diagnostics = { status: "stable" };
	const previousTransitions = root.runtime.revisionTransitions;
	try {
		const blueprint = root.runtime.blueprint;
		if (!blueprint.capabilities.branchless && blueprint.capabilities.hasExpressions) prepareGateSelection(blueprint);
		if (canLoadStaticFirstTree(root, value)) loadStaticFirstTree(root, option);
		else writeFieldNode(root, value, "load", option);
	} finally {
		if (root.runtime.revisionTransitions !== previousTransitions) root.runtime.revisionTransitions = previousTransitions;
		root.runtime.loadSnapshot = nextSnapshot;
	}
};

//#endregion
//#region src/core/engine/settle/utils/reset/clearSubtreeState.ts
const clearSubtreeState = (node) => {
	const pending = [node];
	const visited = /* @__PURE__ */ new Set();
	while (pending.length) {
		const current = pending.pop();
		if (!current || visited.has(current)) continue;
		visited.add(current);
		current.interactionReset += 1;
		current.interactionState = captureFieldNodeChange(current, "interactionState", {});
		for (const child of current.children ?? []) pending.push(child);
	}
};

//#endregion
//#region src/core/engine/settle/utils/reset/resetFieldNodeForm.ts
const resetFieldNodeForm = (root, value, option) => {
	clearTreeMemoStores(root.runtime);
	const nextSnapshot = setLoadValue(root.runtime.loadSnapshot, "", value);
	root.runtime.diagnostics = { status: "stable" };
	clearSubtreeState(root);
	try {
		writeFieldNode(root, value, "load", option);
	} finally {
		root.runtime.loadSnapshot = nextSnapshot;
	}
};

//#endregion
//#region src/core/engine/settle/utils/reset/resetFieldNodeSubtree.ts
const resetFieldNodeSubtree = (node, option) => {
	if (node.detached) return;
	const value = getLoadValue(node.runtime.loadSnapshot, node.path);
	node.runtime.loadSnapshot = setLoadValue(node.runtime.loadSnapshot, node.path, value);
	clearSubtreeState(node);
	writeFieldNode(node, value, "load", option);
};

//#endregion
//#region src/core/engine/settle/utils/slots/getSlotEntryPosition.ts
const getSlotEntryPosition = (template, entry) => {
	const index = getSlotChildIndex(template, entry.name, entry.node);
	return index >= 0 ? index : template.kind === "array" ? Number(entry.name) : 0;
};

//#endregion
//#region src/core/engine/settle/utils/slots/readSlotValueEntry.ts
const readSlotValueEntry = (source, overlay, path, value, composed = false) => {
	const prior = source?.inactiveValueMemo ?? overlay?.valueMemo;
	if (prior && composed && sameValue(prior.value, value)) value = prior.value;
	if (prior?.path === path && Object.is(prior.value, value)) return prior.entry;
	const memo = {
		path,
		value,
		entry: Object.freeze({
			path,
			value
		})
	};
	if (source) source.inactiveValueMemo = memo;
	else if (overlay) overlay.valueMemo = memo;
	return memo.entry;
};

//#endregion
//#region src/core/engine/settle/utils/slots/collectSlotSourceValues.ts
const collectSlotSourceValues = (template, source, overlay, path, order, live, values, patchOnly = false) => {
	if (!source && !overlay || template.kind === "virtual") return;
	const ownsRaw = overlay !== void 0 && hasOwnProperty(overlay, "raw");
	const raw = ownsRaw ? overlay?.raw : overlay?.replace ? void 0 : source?.raw;
	const array = template.kind === "array" && template.strategy === "branch";
	const composed = array && source !== void 0 && !ownsRaw && !overlay?.replace;
	let value;
	if (!patchOnly || ownsRaw) {
		if (template.strategy === "terminal") value = raw;
		else if (raw !== void 0 && (array && isArray(raw) || isMisfit(raw, template.schemaType, template.nullable))) value = raw;
		else if (composed) {
			const materialized = readSlotRawTree(template, source, source.retainedSourceOverlay);
			value = isArray(materialized) ? Object.freeze(materialized) : materialized;
		}
	}
	if (value !== void 0 && !live && !overlay?.packedArrayInput) values.push({
		order,
		entry: readSlotValueEntry(source, overlay, path, value, composed)
	});
	if (template.strategy === "terminal") return;
	const packed = array && composed && !patchOnly;
	for (const entry of getSlotEntries(source, overlay, template)) {
		const explicit = overlay?.children?.has(entry) === true && overlay.children.get(entry) !== source?.retainedSourceOverlay?.children?.get(entry);
		const candidate = array && (entry.node.hasCandidateDescendants || getItemEntries(template, Number(entry.name)).length > 1);
		if (patchOnly && !explicit) continue;
		if (packed && !candidate && !explicit) continue;
		const child = getSlotSource(source, entry, overlay);
		collectSlotSourceValues(entry.node, child.source, child.overlay, appendSegment(path, entry.name), [...order, getSlotEntryPosition(template, entry)], live?.structure?.[entry.name], values, patchOnly || packed && !candidate);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/collectHostSlotValues.ts
const collectHostSlotValues = (host, order, values) => {
	const entries = new Set(host.inactiveSlots?.keys());
	for (const entry of host.inactiveSlotOverlays?.keys() ?? []) entries.add(entry);
	for (const entry of host.inactiveSlotBaselines?.keys() ?? []) entries.add(entry);
	const active = /* @__PURE__ */ new Set();
	for (const entry of entries) {
		const baseline = host.inactiveSlotBaselines?.get(entry);
		const source = baseline ? baseline.source : host.inactiveSlots?.get(entry);
		const overlay = baseline ? baseline.overlay : host.inactiveSlotOverlays?.get(entry);
		const counterpart = baseline ? baseline.active : host.structure?.[entry.name];
		const childOrder = [...order, getSlotEntryPosition(host.blueprintNode, entry)];
		if (baseline?.active && !active.has(baseline.active)) {
			active.add(baseline.active);
			collectHostSlotValues(baseline.active, childOrder, values);
		}
		collectSlotSourceValues(entry.node, source, overlay, appendSegment(host.path, entry.name), childOrder, counterpart, values);
	}
	for (const child of host.inactiveSlotChildren?.values() ?? []) {
		if (active.has(child) || host.structure?.[child.name] !== child || !child.deliveryInitialized) continue;
		const entry = getRetainedChildEntry(host, child.name, child.blueprintNode);
		if (!entry) continue;
		collectHostSlotValues(child, [...order, getSlotEntryPosition(host.blueprintNode, entry)], values);
	}
};

//#endregion
//#region src/core/engine/settle/utils/slots/compareSlotOrder.ts
const compareSlotOrder = (left, right) => {
	for (let index = 0; index < Math.min(left.length, right.length); index++) {
		const difference = left[index] - right[index];
		if (difference) return difference;
	}
	return left.length - right.length;
};

//#endregion
//#region src/core/engine/settle/utils/slots/materializeInactiveSlotValues.ts
const materializeInactiveSlotValues = (host) => {
	if (host.inactiveValuesCache && !host.inactiveValuesDirty) return host.inactiveValuesCache;
	const values = [];
	collectHostSlotValues(host, getSlotOrder(host.parent, host.name, host.blueprintNode), values);
	values.sort((left, right) => compareSlotOrder(left.order, right.order) || (left.entry.path < right.entry.path ? -1 : left.entry.path > right.entry.path ? 1 : 0));
	const chosen = /* @__PURE__ */ new Map();
	for (const candidate of values) if (!chosen.has(candidate.entry.path)) chosen.set(candidate.entry.path, candidate.entry);
	const next = [...chosen.values()];
	const previous = host.inactiveValuesCache;
	host.inactiveValuesDirty = false;
	if (previous?.length === next.length && previous.every((entry, index) => entry === next[index])) return previous;
	return host.inactiveValuesCache = next.length ? Object.freeze(next) : EMPTY_VALUES;
};

//#endregion
//#region src/core/engine/settle/utils/detached/readFieldNodeInactiveValues.ts
const readFieldNodeInactiveValues = (node) => materializeInactiveSlotValues(node);

//#endregion
//#region src/core/engine/settle/utils/detached/readFieldNodeMisfit.ts
const readFieldNodeMisfit = (node) => node.detached ? node.runtime.detachedReads?.get(node)?.misfit ?? false : node.runtime.misfitPaths.has(node.path);

//#endregion
//#region src/core/engine/settle/utils/detached/readFieldNodeMisfits.ts
const readFieldNodeMisfits = (node) => node.detached ? node.runtime.detachedReads?.get(node)?.misfits ?? EMPTY_PATHS$1 : node.runtime.misfitsMemo?.get(node.path)?.paths ?? EMPTY_PATHS$1;

//#endregion
//#region src/core/engine/settle/utils/context/changeFieldNodeContext.ts
const changeFieldNodeContext = (root, contextValue) => {
	if (sameValue(root.runtime.context, contextValue)) return;
	const scratch = getSettlementScratch(root.runtime);
	const context = createSettlementContext(root, "automatic", WriteOption.Overwrite, scratch);
	context.entryApi = "setContext";
	const owners = getContextOwners(root.runtime.blueprint);
	context.contextOwners = owners.some((owner) => hasPointerOperator(owner, PointerOperator.Wildcard)) ? owners.flatMap((owner) => expandTemplatePaths(root, owner)) : owners;
	root.runtime.context = contextValue;
	context.changedNodes.add(root);
	try {
		if (context.hasGates) getGateRegistry(root.runtime).register(root);
		for (const owner of context.contextOwners) {
			context.dirtyPaths.add(owner);
			context.dependencyOwnerPaths.add(owner);
			context.shapeDirtyPaths.add(resolvePointer(owner, ".."));
			let ancestor = owner;
			while (ancestor) {
				ancestor = resolvePointer(ancestor, "..");
				context.dirtyPaths.add(ancestor);
			}
		}
		computeNode(root, context);
		finishSettlement(context, scratch);
	} finally {
		releaseSettlementScratch(scratch);
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/captureChainError.ts
const captureChainError = (runtime, error) => {
	runtime.chainErrors?.push(error);
	if (runtime.errorReporter?.hasConsumer()) runtime.chainOccurrences?.push({
		kind: "error",
		error
	});
};

//#endregion
//#region src/core/engine/write/utils/report/assertNotInDelivery.ts
const assertNotInDelivery = (runtime) => {
	if (runtime.reportingErrors) throw new SchemaFormError(FormErrorCode.WriteInObserver, "A form cannot be written while its error observer is running");
};

//#endregion
//#region src/core/engine/write/utils/report/reportOwnerlessError.ts
const reportOwnerlessError = (error) => {
	if (typeof window !== "undefined") {
		if ("reportError" in window && typeof window.reportError === "function") {
			window.reportError(error);
			return;
		}
		if (typeof ErrorEvent !== "undefined") {
			if (!window.dispatchEvent(new ErrorEvent("error", {
				error,
				message: String(error)
			}))) return;
		}
	}
	console.error(error);
};

//#endregion
//#region src/core/engine/write/utils/report/deliverChainRecords.ts
const deliverChainRecords = (runtime, records, original, caller) => {
	const failures = [];
	const reporter = runtime.errorReporter;
	for (const record of records) {
		if (!reporter?.hasConsumer()) {
			if (__SCHEMA_FORM_DEV__ && (record.code === FormWarningCode.NonJsonWholeValue || record.code === FormWarningCode.DetachedNodeWrite || record.code === FormWarningCode.WriteInInactiveResolver)) console.warn(record.code, record.message, record.details);
			continue;
		}
		const previous = runtime.reportingErrors;
		runtime.reportingErrors = true;
		try {
			reporter.report(record);
		} catch (error) {
			if (caller) failures.push(error);
			else reportOwnerlessError(error);
		} finally {
			runtime.reportingErrors = previous;
		}
	}
	if (!caller && original !== void 0) reportOwnerlessError(original);
	return failures;
};

//#endregion
//#region src/core/engine/write/utils/report/refuseInactiveResolverWrite.ts
const refuseInactiveResolverWrite = (node) => {
	if (!node.runtime.resolvingInactiveValue) return false;
	if (node.runtime.reportingErrors) return true;
	if (__SCHEMA_FORM_DEV__) deliverChainRecords(node.runtime, [{
		level: "warning",
		code: FormWarningCode.WriteInInactiveResolver,
		message: "A write inside an inactive value resolver has no effect",
		path: node.path,
		details: { path: node.path }
	}], void 0, false);
	return true;
};

//#endregion
//#region src/core/engine/write/utils/chain/openVisitBatch.ts
const openVisitBatch = (node) => {
	const runtime = node.rootNode.runtime;
	runtime.entryDepth = (runtime.entryDepth ?? 0) + 1;
	runtime.batchDepth = 1;
	runtime.visitBatchEntry = node;
};

//#endregion
//#region src/core/engine/write/utils/chain/refuseListenerFeedback.ts
const refuseListenerFeedback = (runtime) => {
	if (!runtime.entryDepth || !runtime.currentListener || (runtime.feedbackBudget ?? 0) < 25) return false;
	(runtime.feedbackBlockedListeners ?? (runtime.feedbackBlockedListeners = /* @__PURE__ */ new Set())).add(runtime.currentListener);
	if (!runtime.feedbackLimitReported) {
		captureChainError(runtime, new SchemaFormError(FormErrorCode.FeedbackLimitExceeded, "Listener feedback exceeded 25 waves"));
		runtime.feedbackLimitReported = true;
	}
	return true;
};

//#endregion
//#region src/core/engine/write/utils/chain/startFieldNodeChain.ts
const startFieldNodeChain = (root) => {
	const runtime = root.runtime;
	runtime.enclosingChain = runtime.chainErrors && runtime.chainOccurrences ? {
		errors: runtime.chainErrors,
		occurrences: runtime.chainOccurrences,
		outer: runtime.enclosingChain
	} : void 0;
	runtime.chainRoot = root;
	runtime.chainInitialEmit = root.emit;
	runtime.chainErrors = [];
	runtime.chainOccurrences = [];
	runtime.feedbackBudget = 0;
	runtime.feedbackBlockedListeners = void 0;
	runtime.feedbackLimitReported = false;
};

//#endregion
//#region src/core/engine/write/utils/chain/enterFieldNodeChain.ts
const enterFieldNodeChain = (node) => {
	if (refuseInactiveResolverWrite(node)) return false;
	assertFieldNodeWritable(node);
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (!runtime.entryDepth) startFieldNodeChain(node.rootNode);
	if (refuseListenerFeedback(runtime)) return false;
	if (runtime.visitDepth && !runtime.batchDepth) openVisitBatch(node);
	runtime.entryDepth = (runtime.entryDepth ?? 0) + 1;
	return true;
};

//#endregion
//#region src/core/engine/write/utils/chain/queueNonSettleEvent.ts
const queueNonSettleEvent = (node, bit, payload) => {
	const runtime = node.rootNode.runtime;
	const queued = runtime.queuedNonSettleEvents ?? /* @__PURE__ */ new Set();
	const previous = node.pendingNonSettleDelivery;
	node.pendingNonSettleDelivery = {
		type: (previous?.type ?? 0) | bit,
		payload: payload === void 0 ? previous?.payload : {
			...previous?.payload,
			[bit]: payload
		}
	};
	queued.add(node);
	runtime.queuedNonSettleEvents = queued;
};

//#endregion
//#region src/core/engine/write/utils/entry/utils/publishRootExternalErrors.ts
const publishRootExternalErrors = (root) => {
	const previous = root.runtime.globalErrors ?? EMPTY_GLOBAL_ERRORS;
	updateFieldNodeGlobalErrors(root);
	if (root.runtime.globalErrors !== previous) queueNonSettleEvent(root, 64, root.runtime.globalErrors);
};

//#endregion
//#region src/core/engine/write/utils/entry/utils/propagateExternalErrorsToRoot.ts
const NO_ISSUES$1 = [];
const isCanonical = isCanonicalPath;
const isPendingNode = (candidate, runtime) => candidate !== null && typeof candidate === "object" && Reflect.get(candidate, "runtime") === runtime;
const rebuildRootExternalErrors = (root) => {
	const runtime = root.runtime;
	const pending = runtime.pendingExternalErrorNodes;
	if (!pending?.size) return;
	runtime.pendingExternalErrorNodes = void 0;
	const nodes = [];
	for (const candidate of pending) if (isPendingNode(candidate, runtime)) nodes.push(candidate);
	if (!nodes.length) return;
	const contributions = runtime.externalContributions ?? (runtime.externalContributions = /* @__PURE__ */ new Map());
	const placed = /* @__PURE__ */ new Set();
	const retired = /* @__PURE__ */ new Set();
	const paths = /* @__PURE__ */ new Set();
	for (let index = 0; index < nodes.length; index++) {
		const node = nodes[index];
		const previous = contributions.get(node);
		if (previous) for (let at = 0; at < previous.length; at++) retired.add(previous[at]);
		if (node.detached) {
			contributions.delete(node);
			continue;
		}
		paths.add(node.path);
		const list = runtime.nodeErrors?.get(node);
		if (list) for (let at = 0; at < list.length; at++) placed.add(list[at]);
	}
	const resolved = /* @__PURE__ */ new Map();
	const canonical = (dataPath) => {
		if (dataPath === "" || isCanonical(dataPath)) return dataPath;
		let path = resolved.get(dataPath);
		if (path === void 0) {
			path = find(root, dataPath)?.path ?? dataPath;
			resolved.set(dataPath, path);
		}
		return path;
	};
	const current = runtime.nodeErrors?.get(root) ?? NO_ISSUES$1;
	const present = /* @__PURE__ */ new Set();
	const next = [];
	let changed = false;
	for (let index = 0; index < current.length; index++) {
		const issue = current[index];
		if (placed.has(issue)) {
			present.add(issue);
			next.push(issue);
		} else if (retired.has(issue) || paths.has(canonical(issue.dataPath))) changed = true;
		else next.push(issue);
	}
	for (let index = 0; index < nodes.length; index++) {
		const node = nodes[index];
		if (node.detached) continue;
		const list = runtime.nodeErrors?.get(node);
		if (list) {
			for (let at = 0; at < list.length; at++) if (!present.has(list[at])) {
				next.push(list[at]);
				changed = true;
			}
			contributions.set(node, list);
		} else contributions.delete(node);
	}
	if (!changed) return;
	if (next.length) (runtime.nodeErrors ?? (runtime.nodeErrors = /* @__PURE__ */ new Map())).set(root, next);
	else runtime.nodeErrors?.delete(root);
	publishRootExternalErrors(root);
	queueNonSettleEvent(root, 32, next);
};
const propagateExternalErrorsToRoot = (node) => {
	const root = node.rootNode;
	const runtime = root.runtime;
	(runtime.pendingExternalErrorNodes ?? (runtime.pendingExternalErrorNodes = /* @__PURE__ */ new Set())).add(node);
	if (!runtime.entryDepth) rebuildRootExternalErrors(root);
};

//#endregion
//#region src/core/engine/write/utils/report/bundleChainErrors.ts
const bundleChainErrors = (errors) => errors.length < 2 ? errors[0] : new SchemaFormError(FormErrorCode.MultipleErrors, "Multiple dispatch errors", { errors });

//#endregion
//#region src/core/engine/write/utils/report/createFormErrorRecord.ts
function createFormErrorRecord(consumed, code, levelOrError, format, fields) {
	if (!consumed) return void 0;
	if (typeof code === "string") {
		if (levelOrError !== "error" && levelOrError !== "warning" || !format) return void 0;
		return {
			level: levelOrError,
			code,
			message: format(),
			...fields
		};
	}
	if (!(code.level === "error" ? isFormErrorCode(code.code) : isFormWarningCode(code.code))) return void 0;
	const error = levelOrError;
	const message = error instanceof Error ? error.message : code.code.slice(code.code.indexOf(".") + 1) + " at " + code.schemaPath;
	const details = error instanceof JSONSchemaError ? error.details : { ...code.details };
	if (code.level === "error") return {
		level: "error",
		code: code.code,
		message,
		schemaPath: code.schemaPath,
		details,
		error,
		surface: "sink"
	};
	return {
		level: "warning",
		code: code.code,
		message,
		schemaPath: code.schemaPath,
		details
	};
}

//#endregion
//#region src/core/engine/write/utils/report/readFormErrorCode.ts
const readFormErrorCode = (error) => (error instanceof SchemaFormError || error instanceof JSONSchemaError) && isFormErrorCode(error.code) ? error.code : FormErrorCode.ListenerThrew;

//#endregion
//#region src/core/engine/write/utils/report/collectChainRecords.ts
const collectChainRecords = (pending, occurrences, aggregate, surface, reported) => {
	const created = /* @__PURE__ */ new Set();
	for (const occurrence of occurrences) {
		if (occurrence.kind === "record") {
			pending.push(occurrence.record);
			continue;
		}
		const error = occurrence.error;
		const existing = pending.find((record) => !created.has(record) && record.level === "error" && record.code === readFormErrorCode(error) && error instanceof SchemaFormError && record.schemaPath === error.details.schemaPath);
		if (existing && error instanceof SchemaFormError) {
			if (!aggregate || existing.aggregate !== aggregate) {
				existing.error = error;
				existing.details = error.details;
			}
			existing.surface = surface;
			if (aggregate) existing.aggregate = aggregate;
			continue;
		}
		if (error instanceof SchemaFormError && readFormErrorCode(error) === FormErrorCode.GuardFailed && typeof error.details.schemaPath === "string" && reported?.has(error.details.schemaPath)) continue;
		const record = createFormErrorRecord(true, readFormErrorCode(error), "error", () => error instanceof Error ? error.message : String(error), {
			error,
			...error instanceof SchemaFormError || error instanceof JSONSchemaError ? { details: error.details } : {},
			...error instanceof SchemaFormError && typeof error.details.path === "string" ? { path: error.details.path } : {},
			...error instanceof SchemaFormError && typeof error.details.schemaPath === "string" ? { schemaPath: error.details.schemaPath } : {},
			...aggregate ? { aggregate } : {},
			surface
		});
		if (record) {
			pending.push(record);
			created.add(record);
		}
	}
};

//#endregion
//#region src/core/engine/write/utils/report/reportValidationFailure.ts
const reportValidationFailure = (runtime, failure) => {
	if (runtime.errorReporter?.hasConsumer()) {
		const wasReporting = runtime.reportingErrors;
		runtime.reportingErrors = true;
		try {
			runtime.errorReporter.report({
				level: "error",
				code: readFormErrorCode(failure),
				message: failure instanceof Error ? failure.message : String(failure),
				...failure instanceof SchemaFormError ? { details: failure.details } : {},
				error: failure,
				surface: "sink"
			});
		} catch (reporterFailure) {
			reportOwnerlessError(reporterFailure);
		} finally {
			runtime.reportingErrors = wasReporting;
		}
	}
	reportOwnerlessError(failure);
};

//#endregion
//#region src/core/engine/write/utils/report/finishQueuedErrors.ts
const finishQueuedErrors = (runtime, errors, occurrences, caller) => {
	const original = bundleChainErrors(errors);
	const aggregate = errors.length > 1 && original instanceof SchemaFormError ? original : void 0;
	const pending = [];
	collectChainRecords(pending, occurrences, aggregate, caller ? "thrown" : "sink", runtime.reportedGuardFailures);
	const handlerErrors = deliverChainRecords(runtime, pending, original, caller);
	if (caller && (errors.length || handlerErrors.length)) throw errors.length && handlerErrors.length ? bundleChainErrors([original, ...handlerErrors]) : errors.length ? original : bundleChainErrors(handlerErrors);
};

//#endregion
//#region src/core/engine/write/utils/chain/resolveFieldNodeChainRoot.ts
const isFieldNodeChainRoot = (value) => value !== null && typeof value === "object" && "runtime" in value && "rootNode" in value;
const resolveFieldNodeChainRoot = (root, passed) => {
	let active = root;
	passed?.add(active.runtime);
	while (isFieldNodeChainRoot(active.runtime.adoptedRoot)) {
		active = active.runtime.adoptedRoot;
		passed?.add(active.runtime);
	}
	return active;
};

//#endregion
//#region src/core/engine/write/utils/chain/utils/compareDocumentOrder.ts
const compareDocumentOrder = (left, right, siblingIndexes) => {
	if (left === right) return 0;
	const leftLine = [];
	const rightLine = [];
	for (let node = left; node; node = node.parent) leftLine.push(node);
	for (let node = right; node; node = node.parent) rightLine.push(node);
	leftLine.reverse();
	rightLine.reverse();
	let index = 0;
	while (index < leftLine.length && index < rightLine.length && leftLine[index] === rightLine[index]) index += 1;
	if (index === leftLine.length) return -1;
	if (index === rightLine.length) return 1;
	const parent = leftLine[index - 1];
	let positions = siblingIndexes.get(parent);
	if (!positions) {
		positions = /* @__PURE__ */ new Map();
		for (const [position, child] of (parent.children ?? []).entries()) positions.set(child, position);
		siblingIndexes.set(parent, positions);
	}
	return (positions.get(leftLine[index]) ?? -1) - (positions.get(rightLine[index]) ?? -1);
};

//#endregion
//#region src/core/engine/write/utils/chain/deliverWave.ts
const isWaveNode = (value, runtime) => value !== null && typeof value === "object" && Reflect.get(value, "runtime") === runtime;
const deliverWave = (root, pending) => {
	const runtime = root.runtime;
	const fixed = [];
	for (const [candidate, event] of pending) {
		if (!isWaveNode(candidate, runtime)) continue;
		const listeners = runtime.listeners?.get(candidate);
		if (listeners?.size) fixed.push({
			node: candidate,
			event,
			listeners: [...listeners]
		});
	}
	const siblingIndexes = /* @__PURE__ */ new Map();
	fixed.sort((left, right) => compareDocumentOrder(left.node, right.node, siblingIndexes));
	for (const { node, event, listeners } of fixed) {
		if (node.detached) continue;
		for (const listener of listeners) {
			if (!runtime.listeners?.get(node)?.has(listener) || runtime.feedbackBlockedListeners?.has(listener)) continue;
			runtime.currentListener = listener;
			try {
				listener(event);
			} catch (error) {
				captureChainError(resolveFieldNodeChainRoot(root).runtime, error);
			} finally {
				const passed = /* @__PURE__ */ new Set([runtime]);
				resolveFieldNodeChainRoot(root, passed);
				for (const owner of passed) owner.currentListener = void 0;
			}
		}
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/runDeliveryWaves.ts
const runDeliveryWaves = (root) => {
	let active = resolveFieldNodeChainRoot(root);
	let waves = 0;
	while (active.runtime.deliveries?.size) {
		const runtime = active.runtime;
		const pending = [];
		for (const node of runtime.deliveries ?? []) {
			if (node.pendingDelivery) pending.push([node, node.pendingDelivery]);
			node.pendingDelivery = void 0;
		}
		runtime.deliveries = /* @__PURE__ */ new Set();
		waves += 1;
		runtime.feedbackBudget = waves - 1;
		deliverWave(active, pending);
		active = resolveFieldNodeChainRoot(active);
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/flushQueuedEvents.ts
const isQueuedNode = (candidate, runtime) => candidate !== null && typeof candidate === "object" && Reflect.get(candidate, "runtime") === runtime && Reflect.get(candidate, "detached") === false;
const flushQueuedEvents = (root, caller = true) => {
	const entryRuntime = root.runtime;
	if (entryRuntime.flushingQueuedEvents) return;
	entryRuntime.flushingQueuedEvents = true;
	const standalone = !entryRuntime.entryDepth && !entryRuntime.chainErrors;
	const previousErrors = entryRuntime.chainErrors;
	const previousOccurrences = entryRuntime.chainOccurrences;
	let waves = 0;
	let budgetReported = false;
	if (standalone) {
		entryRuntime.chainErrors = [];
		entryRuntime.chainOccurrences = [];
	}
	const owners = /* @__PURE__ */ new Set([entryRuntime]);
	let active = root;
	let runtime = entryRuntime;
	try {
		for (;;) {
			active = resolveFieldNodeChainRoot(active, owners);
			runtime = active.runtime;
			runtime.flushingQueuedEvents = true;
			if (!runtime.pendingExternalErrorNodes?.size && !runtime.queuedNonSettleEvents?.size && !runtime.deliveries?.size && !(!runtime.entryDepth && runtime.stateChanged)) break;
			if (runtime.pendingExternalErrorNodes?.size) {
				rebuildRootExternalErrors(active);
				continue;
			}
			if (runtime.deliveries?.size) {
				runDeliveryWaves(active);
				continue;
			}
			if (runtime.queuedNonSettleEvents?.size) {
				waves += 1;
				if (waves > 25) {
					for (const node of runtime.queuedNonSettleEvents) node.pendingNonSettleDelivery = void 0;
					runtime.queuedNonSettleEvents = void 0;
					if (!budgetReported) captureChainError(runtime, new SchemaFormError(FormErrorCode.FeedbackLimitExceeded, "Non-settlement feedback exceeded 25 waves"));
					budgetReported = true;
					continue;
				}
				const pending = [];
				for (const candidate of runtime.queuedNonSettleEvents) {
					const delivery = candidate.pendingNonSettleDelivery;
					candidate.pendingNonSettleDelivery = void 0;
					if (!delivery) continue;
					if (!isQueuedNode(candidate, runtime)) continue;
					const node = candidate;
					pending.push([node, delivery]);
					node.revisionLedger = new FieldNodeRevisionLedger(node.revisionLedger, delivery.type);
				}
				runtime.queuedNonSettleEvents = void 0;
				deliverWave(active, pending);
				continue;
			}
			runtime.stateChanged = false;
			try {
				runtime.onStateChange?.();
			} catch (error) {
				captureChainError(resolveFieldNodeChainRoot(active, owners).runtime, error);
			}
		}
		if (standalone) finishQueuedErrors(runtime, runtime.chainErrors ?? [], runtime.chainOccurrences ?? [], caller);
	} finally {
		for (const owner of owners) {
			owner.flushingQueuedEvents = false;
			if (!standalone) continue;
			owner.chainErrors = previousErrors;
			owner.chainOccurrences = previousOccurrences;
			if (owner !== entryRuntime) owner.chainRoot = void 0;
		}
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/deliverValidationWave.ts
const deliverValidationWave = (node, issues, commit) => {
	const runtime = node.rootNode.runtime;
	if ((runtime.commitNumber ?? 0) !== commit) return;
	for (const changed of runtime.validationChangedNodes ?? []) queueNonSettleEvent(changed, 32, runtime.validationErrors?.get(changed) ?? []);
	runtime.validationChangedNodes = void 0;
	if (runtime.validationListChanged) queueNonSettleEvent(node.rootNode, 64, issues);
	runtime.validationListChanged = void 0;
	flushQueuedEvents(node.rootNode, false);
};

//#endregion
//#region src/core/engine/write/utils/chain/exitFieldNodeChain.ts
const exitFieldNodeChain = (node, failure) => {
	const passed = /* @__PURE__ */ new Set();
	const activeRoot = resolveFieldNodeChainRoot(node.rootNode, passed);
	let runtime = activeRoot.runtime;
	if (failure !== void 0) captureChainError(runtime, failure);
	if ((runtime.entryDepth ?? 0) > 1) {
		runtime.entryDepth = (runtime.entryDepth ?? 0) - 1;
		return;
	}
	let root = runtime.chainRoot ?? activeRoot;
	rebuildRootExternalErrors(root);
	runDeliveryWaves(root);
	flushQueuedEvents(resolveFieldNodeChainRoot(root, passed));
	root = resolveFieldNodeChainRoot(root, passed);
	runtime = root.runtime;
	const occurrences = runtime.chainOccurrences ?? [];
	const pending = [];
	const warnings = runtime.pendingWarningRecords;
	if (warnings?.size) {
		for (const [key, record] of warnings) {
			if (!occurrences.some((item) => item.kind === "record" && item.record === record)) pending.push(record);
			if (!runtime.warningKeys?.has(key)) {
				const parts = JSON.parse(key.startsWith("[") ? key : "null");
				const path = isArray(parts) ? parts[1] : void 0;
				indexFieldNodeWarning(runtime, key, typeof path === "string" ? path : void 0, void 0, true);
			}
		}
		warnings.clear();
	}
	const guardRecords = runtime.guardFailureRecords;
	if (guardRecords?.size) {
		for (const [key, record] of guardRecords) {
			var _runtime;
			if (!occurrences.some((item) => item.kind === "record" && item.record === record)) pending.push(record);
			((_runtime = runtime).reportedGuardFailures ?? (_runtime.reportedGuardFailures = /* @__PURE__ */ new Set())).add(key);
		}
		guardRecords.clear();
	}
	const changed = runtime.chainInitialEmit !== root.emit;
	const requests = runtime.validationTargets;
	if (!runtime.deferMountValidation && runtime.validationMode && runtime.validationMode & ValidationMode.OnChange) {
		var _runtime2;
		(_runtime2 = runtime).reportValidationFailure ?? (_runtime2.reportValidationFailure = (error) => reportValidationFailure(runtime, error));
		if (changed && !requests?.has(root)) requestFieldNodeValidation(root, (issues, commit) => deliverValidationWave(root, issues, commit));
		for (const target of requests ?? []) requestFieldNodeValidation(target, (issues, commit) => deliverValidationWave(target, issues, commit));
	}
	runtime.validationTargets = void 0;
	runtime.deferMountValidation = void 0;
	runtime.entryDepth = 0;
	const errors = runtime.chainErrors ?? [];
	if (runtime.stateChanged) {
		runtime.stateChanged = false;
		try {
			runtime.onStateChange?.();
		} catch (error) {
			errors.push(error);
			if (runtime.errorReporter?.hasConsumer()) occurrences.push({
				kind: "error",
				error
			});
		}
		root = resolveFieldNodeChainRoot(root, passed);
		runtime = root.runtime;
		runtime.chainErrors = errors;
		runtime.chainOccurrences = occurrences;
	}
	if (changed && runtime.onChange) if ((runtime.onChangeBudget ?? 0) >= 25) {
		const error = new SchemaFormError(FormErrorCode.FeedbackLimitExceeded, "onChange nesting exceeded 25 callbacks");
		errors.push(error);
		if (runtime.errorReporter?.hasConsumer()) occurrences.push({
			kind: "error",
			error
		});
	} else {
		runtime.onChangeBudget = (runtime.onChangeBudget ?? 0) + 1;
		try {
			runtime.onChange(root.emit);
		} catch (error) {
			errors.push(error);
			if (runtime.errorReporter?.hasConsumer()) occurrences.push({
				kind: "error",
				error
			});
		} finally {
			const raised = /* @__PURE__ */ new Set();
			root = resolveFieldNodeChainRoot(root, raised);
			runtime = root.runtime;
			for (const owner of raised) {
				owner.onChangeBudget = (owner.onChangeBudget ?? 1) - 1;
				passed.add(owner);
			}
		}
	}
	const enclosing = runtime.enclosingChain;
	runtime.enclosingChain = enclosing?.outer;
	runtime.chainErrors = enclosing?.errors;
	runtime.chainRoot = void 0;
	runtime.feedbackBudget = 0;
	runtime.feedbackBlockedListeners = void 0;
	runtime.feedbackLimitReported = false;
	runtime.chainOccurrences = enclosing?.occurrences;
	for (const stale of passed) {
		if (stale === runtime) continue;
		stale.chainErrors = runtime.chainErrors;
		stale.chainRoot = void 0;
	}
	if (enclosing) {
		enclosing.errors.push(...errors);
		for (const record of pending) enclosing.occurrences.push({
			kind: "record",
			record
		});
		enclosing.occurrences.push(...occurrences);
		return;
	}
	const original = bundleChainErrors(errors);
	collectChainRecords(pending, occurrences, errors.length > 1 && original instanceof SchemaFormError ? original : void 0, "thrown", runtime.reportedGuardFailures);
	const handlerErrors = deliverChainRecords(runtime, pending, original, true);
	const exposed = !errors.length ? bundleChainErrors(handlerErrors) : handlerErrors.length ? bundleChainErrors([original, ...handlerErrors]) : original;
	if (!errors.length && !handlerErrors.length) return;
	throw exposed;
};

//#endregion
//#region src/core/engine/write/utils/chain/isBatchMarking.ts
const isBatchMarking = (node) => !!node.rootNode.runtime.batchDepth && !node.detached;

//#endregion
//#region src/core/engine/write/utils/chain/utils/replaceAtPath.ts
const markedValue = (previous, incoming, option) => (option & WriteOption.Merge) === WriteOption.Merge && !(option & WriteOption.Replace) && previous !== null && incoming !== null && typeof previous === "object" && typeof incoming === "object" && !isArray(previous) && !isArray(incoming) ? {
	...previous,
	...incoming
} : incoming;
const replaceAtPath = (current, names, incoming, option) => {
	if (!names.length) return markedValue(current, incoming, option);
	const [name, ...rest] = names;
	if (isArray(current)) {
		const next = [...current];
		next[Number(name)] = replaceAtPath(next[Number(name)], rest, incoming, option);
		return next;
	}
	const next = current !== null && typeof current === "object" ? { ...current } : {};
	return {
		...next,
		[name]: replaceAtPath(Reflect.get(next, name), rest, incoming, option)
	};
};

//#endregion
//#region src/core/engine/write/utils/chain/composeBatchValue.ts
const composeBatchValue = (root, writes) => {
	let value = root.local;
	for (const write of writes) {
		const names = parsePointerSegments(write.node.path);
		if (!names.every((segment) => typeof segment === "string")) throw new TypeError("Expected a named node path");
		const fields = write.node.behavior.type === "virtual" ? write.node.blueprintNode.fields ?? [] : void 0;
		if (fields === void 0) {
			value = replaceAtPath(value, names, write.value, write.option);
			continue;
		}
		const values = isArray(write.value) ? write.value : void 0;
		const parentNames = names.slice(0, -1);
		for (let index = 0; index < fields.length; index++) {
			if (!write.node.parent?.structure?.[fields[index]]) continue;
			value = replaceAtPath(value, [...parentNames, fields[index]], values?.[index], write.option);
		}
	}
	return value;
};

//#endregion
//#region src/core/engine/write/utils/chain/readBatchValue.ts
const readBatchValue = (node) => {
	const root = node.rootNode;
	const virtual = node.behavior.type === "virtual" ? node : void 0;
	const names = [];
	for (let cursor = virtual ? node.parent : node; cursor && cursor !== root; cursor = cursor.parent) names.unshift(cursor.name);
	let value = composeBatchValue(root, root.runtime.batchWrites ?? []);
	for (const name of names) value = value !== null && typeof value === "object" ? Reflect.get(value, name) : void 0;
	if (!virtual) return value;
	return (virtual.blueprintNode.fields ?? []).map((field) => value !== null && typeof value === "object" ? Reflect.get(value, field) : void 0);
};

//#endregion
//#region src/core/engine/write/utils/report/refuseDetachedWrite.ts
const refuseDetachedWrite = (node) => {
	if (!node.detached) return false;
	if (refuseInactiveResolverWrite(node)) return true;
	if (__SCHEMA_FORM_DEV__) deliverChainRecords(node.runtime, [{
		level: "warning",
		code: FormWarningCode.DetachedNodeWrite,
		message: "A write through a detached node reference has no effect",
		path: node.path,
		details: { path: node.path }
	}], void 0, false);
	return true;
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchSetValue.ts
const dispatchSetValue = (node, value, option = WriteOption.Overwrite, source) => {
	if (refuseDetachedWrite(node)) return;
	if (source === "input" && (node.disposed || node.rootNode.disposed)) return;
	if (!enterFieldNodeChain(node)) return;
	try {
		if (option & WriteOption.Overwrite && option & WriteOption.Merge) throw new SchemaFormError(FormErrorCode.InvalidWriteOption, "Overwrite and Merge cannot be combined", {
			path: node.path,
			option
		});
		const marking = isBatchMarking(node);
		const input = typeof value === "function" ? value(marking ? readBatchValue(node) : node.local) : value;
		if (marking) {
			var _node$rootNode$runtim;
			if (node.behavior.type === "virtual") assertVirtualWriteShape(node, input);
			((_node$rootNode$runtim = node.rootNode.runtime).batchWrites ?? (_node$rootNode$runtim.batchWrites = [])).push({
				node,
				value: input,
				option,
				source
			});
		} else writeFieldNode(node, input, (option & WriteOption.Merge) === WriteOption.Merge && !(option & WriteOption.Replace) ? "callerPartial" : "callerReplace", option, source);
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/flushBatchWrites.ts
const flushBatchWrites = (root) => {
	const runtime = root.runtime;
	const writes = runtime.batchWrites ?? [];
	runtime.batchWrites = void 0;
	if (!writes.length) return;
	const option = writes.reduce((flags, write) => flags | write.option, WriteOption.None);
	const target = writes.length === 1 ? find(root, writes[0].node.path) : root;
	if (!target) return;
	const input = writes.length === 1 ? writes[0].value : composeBatchValue(root, writes);
	const merge = writes.length === 1 && (option & WriteOption.Merge) === WriteOption.Merge && !(option & WriteOption.Replace);
	const source = writes.every((write) => write.source === "input") ? "input" : writes.every((write) => write.source === "automatic") ? "automatic" : void 0;
	const origins = writes.map((write) => {
		const partial = (write.option & WriteOption.Merge) === WriteOption.Merge && !(write.option & WriteOption.Replace);
		return {
			path: write.node.path,
			source: write.source ?? (partial ? "callerPartial" : "callerReplace"),
			keys: partial && write.value !== null && typeof write.value === "object" && !isArray(write.value) ? Object.keys(write.value) : void 0,
			fields: !partial && write.node.behavior.type === "virtual" ? (write.node.blueprintNode.fields ?? []).flatMap((field) => {
				const sibling = write.node.parent?.structure?.[field];
				return sibling ? [sibling.path] : [];
			}) : void 0
		};
	});
	try {
		writeFieldNode(target, input, source === "automatic" ? "automatic" : merge ? "callerPartial" : "callerReplace", option, source, origins);
	} catch (error) {
		captureChainError(runtime, error);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchBatch.ts
const dispatchBatch = (node, fn) => {
	if (!enterFieldNodeChain(node)) return;
	const runtime = node.rootNode.runtime;
	runtime.batchDepth = (runtime.batchDepth ?? 0) + 1;
	try {
		fn();
	} catch (error) {
		const active = resolveFieldNodeChainRoot(node.rootNode).runtime;
		if ((active.batchDepth ?? 0) > 1) throw error;
		captureChainError(active, error);
	} finally {
		const activeRoot = resolveFieldNodeChainRoot(node.rootNode);
		const active = activeRoot.runtime;
		active.batchDepth = (active.batchDepth ?? 1) - 1;
		if (!active.batchDepth) flushBatchWrites(activeRoot);
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/closeNonSettleEntry.ts
const closeNonSettleEntry = (node) => {
	const runtime = node.rootNode.runtime;
	if (runtime.entryDepth) return;
	if (!runtime.visitDepth) return flushQueuedEvents(node.rootNode);
	startFieldNodeChain(node.rootNode);
	openVisitBatch(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchClearExternalErrors.ts
const NO_ISSUES = [];
const dispatchClearExternalErrors = (node) => {
	assertFieldNodeWritable(node);
	if (node.detached) return;
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (refuseListenerFeedback(runtime)) return;
	if (!runtime.nodeErrors?.delete(node)) return;
	if (node === node.rootNode) publishRootExternalErrors(node);
	else propagateExternalErrorsToRoot(node);
	queueNonSettleEvent(node, 32, NO_ISSUES);
	closeNonSettleEntry(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchSetState.ts
const dispatchSetState = (node, state) => {
	assertFieldNodeWritable(node);
	if (node.detached) return;
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (refuseListenerFeedback(runtime)) return;
	const previous = node.interactionState;
	patchFieldNodeInteractionState(node, state);
	if (previous === node.interactionState) return;
	const deltas = /* @__PURE__ */ new Map();
	accumulateGlobalStateDeltas(deltas, previous, node.interactionState, state);
	publishGlobalStateDeltas(node.rootNode, deltas);
	if (node.deliveryChanges & 8) node.deliveryPreviousState = node.interactionState;
	runtime.stateChanged = true;
	queueNonSettleEvent(node, 8, node.interactionState);
	closeNonSettleEntry(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchWriteInput.ts
const DIRTY_STATE_PATCH$1 = { [FieldNodeState.Dirty]: true };
const dispatchWriteInput = (node, value, option) => {
	if (node.disposed || node.rootNode.disposed) return;
	dispatchBatch(node, () => {
		dispatchSetValue(node, value, option, "input");
		if (node.disposed || node.rootNode.disposed) return;
		dispatchClearExternalErrors(node);
		dispatchSetState(node, DIRTY_STATE_PATCH$1);
	});
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchFinishInput.ts
const dispatchFinishInput = (node, option = WriteOption.Overwrite) => {
	if (node.disposed || node.rootNode.disposed) return;
	if (!enterFieldNodeChain(node)) return;
	try {
		const runtime = node.rootNode.runtime;
		if (option & WriteOption.DisableAutomaticWrites || !(option & WriteOption.EnableAutomaticWrites) && runtime.disableAutomaticWrites) return;
		const marking = isBatchMarking(node);
		const input = marking ? Object.create(node, { raw: { value: readBatchValue(node) } }) : node;
		const value = node.behavior.finishInput(input);
		if (value === void 0 || value === input.raw) return;
		if (marking) (runtime.batchWrites ?? (runtime.batchWrites = [])).push({
			node,
			value,
			option,
			source: "automatic"
		});
		else writeFieldNode(node, value, "automatic", option);
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/read/readFieldNodeInteractionReset.ts
const readFieldNodeInteractionReset$1 = (node) => node.interactionReset;

//#endregion
//#region src/core/engine/write/utils/chain/markBatchArrayOperation.ts
const markBatchArrayOperation = (node, operation) => {
	var _node$rootNode$runtim;
	const value = readBatchValue(node);
	const source = isArray(value) ? value : [];
	const view = Object.create(node, {
		raw: { value },
		itemCount: { value: source.length }
	});
	const plan = node.behavior.arrange(view, operation);
	if (plan.kind === "noop") return operation.kind === "push" || operation.kind === "insert" ? readArrayLength(view) : void 0;
	let raw;
	if (plan.kind === "update") {
		const copy = source.slice();
		copy[plan.index] = plan.value;
		raw = copy;
	} else raw = plan.kind === "raw" ? plan.raw : plan.slots.map((slot) => "from" in slot ? source[slot.from] : slot.value);
	((_node$rootNode$runtim = node.rootNode.runtime).batchWrites ?? (_node$rootNode$runtim.batchWrites = [])).push({
		node,
		value: raw,
		option: WriteOption.Replace
	});
	if (plan.kind === "update" || plan.result.source === "updated") {
		const index = plan.kind === "update" ? plan.index : plan.result.source === "updated" ? plan.result.index : -1;
		const live = node.structure?.[String(index)];
		const candidates = getItemEntries(node.blueprintNode, index);
		const template = live?.blueprintNode ?? (candidates.length === 1 ? candidates[0].node : void 0);
		return template ? interpretFieldNodeInput(template, raw[index], live) : raw[index];
	}
	if (plan.result.source === "removed") {
		const index = plan.result.index;
		const live = node.structure?.[String(index)];
		const candidates = getItemEntries(node.blueprintNode, index);
		const template = live?.blueprintNode ?? (candidates.length === 1 ? candidates[0].node : void 0);
		return template ? interpretFieldNodeInput(template, source[index], live) : source[index];
	}
	return plan.result.source === "length" ? raw.length : void 0;
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchPush.ts
const dispatchPush = (node, value) => {
	if (refuseDetachedWrite(node)) return readArrayLength(node);
	if (!enterFieldNodeChain(node)) return readArrayLength(node);
	try {
		const length = isBatchMarking(node) ? markBatchArrayOperation(node, {
			kind: "push",
			value
		}) : arrangeFieldNodeItems(node, {
			kind: "push",
			value
		});
		if (typeof length === "number") return length;
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
	return readArrayLength(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchPop.ts
const POP_OPERATION = { kind: "pop" };
const dispatchPop = (node) => {
	if (refuseDetachedWrite(node)) return;
	if (!enterFieldNodeChain(node)) return;
	try {
		return isBatchMarking(node) ? markBatchArrayOperation(node, POP_OPERATION) : arrangeFieldNodeItems(node, POP_OPERATION);
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchUpdate.ts
const dispatchUpdate = (node, index, value) => {
	if (refuseDetachedWrite(node)) return;
	if (!enterFieldNodeChain(node)) return;
	try {
		return isBatchMarking(node) ? markBatchArrayOperation(node, {
			kind: "update",
			index,
			value
		}) : arrangeFieldNodeItems(node, {
			kind: "update",
			index,
			value
		});
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchRemove.ts
const dispatchRemove = (node, index) => {
	if (refuseDetachedWrite(node)) return;
	if (!enterFieldNodeChain(node)) return;
	try {
		return isBatchMarking(node) ? markBatchArrayOperation(node, {
			kind: "remove",
			index
		}) : arrangeFieldNodeItems(node, {
			kind: "remove",
			index
		});
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchInsert.ts
const dispatchInsert = (node, index, value) => {
	if (refuseDetachedWrite(node)) return readArrayLength(node);
	if (!enterFieldNodeChain(node)) return readArrayLength(node);
	try {
		const length = isBatchMarking(node) ? markBatchArrayOperation(node, {
			kind: "insert",
			index,
			value
		}) : arrangeFieldNodeItems(node, {
			kind: "insert",
			index,
			value
		});
		if (typeof length === "number") return length;
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
	return readArrayLength(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchClear.ts
const CLEAR_OPERATION = { kind: "clear" };
const dispatchClear = (node) => {
	if (refuseDetachedWrite(node)) return;
	if (!enterFieldNodeChain(node)) return;
	try {
		return isBatchMarking(node) ? markBatchArrayOperation(node, CLEAR_OPERATION) : arrangeFieldNodeItems(node, CLEAR_OPERATION);
	} catch (error) {
		if (node.rootNode.runtime.batchDepth) throw error;
		captureChainError(node.rootNode.runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchResetSubtree.ts
const dispatchResetSubtree = (node, option = WriteOption.Overwrite) => {
	if (node.detached) {
		refuseInactiveResolverWrite(node);
		return;
	}
	if (!enterFieldNodeChain(node)) return;
	const runtime = node.rootNode.runtime;
	if (runtime.batchWrites) runtime.batchWrites = runtime.batchWrites.filter((write) => write.node !== node && !isDescendantPath(write.node.path, node.path));
	(runtime.validationTargets ?? (runtime.validationTargets = /* @__PURE__ */ new Set())).add(node);
	try {
		resetFieldNodeSubtree(node, option);
	} catch (error) {
		captureChainError(runtime, error);
	} finally {
		exitFieldNodeChain(node);
	}
};

//#endregion
//#region src/core/engine/write/utils/report/clearWarningKeys.ts
const clearWarningKeys = (runtime) => {
	runtime.warningKeys?.clear();
	runtime.warningKeysByPath?.clear();
	for (const [key, record] of runtime.pendingWarningRecords ?? []) {
		if (record.path === void 0) continue;
		const parts = JSON.parse(key);
		if (isArray(parts) && typeof parts[1] === "string") indexFieldNodeWarning(runtime, key, parts[1]);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/utils/clearFieldNodeFormErrors.ts
const clearFieldNodeFormErrors = (root) => {
	const runtime = root.runtime;
	const rootExternalChanged = runtime.nodeErrors?.delete(root);
	const changed = routeValidationIssues(root, []);
	if (rootExternalChanged) changed.add(root);
	const pending = [root];
	while (pending.length) {
		const node = pending.pop();
		if (!node) continue;
		if (runtime.nodeErrors?.has(node)) changed.add(node);
		for (const child of node.children ?? []) if (child.parent === node) pending.push(child);
	}
	runtime.nodeErrors?.clear();
	runtime.adoptedExternalErrors = void 0;
	runtime.validationResult = void 0;
	runtime.validationListChanged = void 0;
	if (!((runtime.validationMode ?? 0) & ValidationMode.OnChange)) runtime.validationStamp = (runtime.validationStamp ?? 0) + 1;
	runtime.validationPendingTargets = void 0;
	runtime.validationChangedNodes = void 0;
	for (const node of changed) queueNonSettleEvent(node, 32, []);
	queueNonSettleEvent(root, 64, []);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchResetForm.ts
const dispatchResetForm = (root, value, option = WriteOption.Overwrite) => {
	var _root$runtime;
	if (!enterFieldNodeChain(root)) return;
	clearWarningKeys(root.runtime);
	root.runtime.validationUnavailable = false;
	root.runtime.validationCompileReported = false;
	root.runtime.batchWrites = void 0;
	((_root$runtime = root.runtime).validationTargets ?? (_root$runtime.validationTargets = /* @__PURE__ */ new Set())).add(root);
	try {
		clearFieldNodeFormErrors(root);
		resetFieldNodeForm(root, value, option);
	} catch (error) {
		captureChainError(root.runtime, error);
	} finally {
		exitFieldNodeChain(root);
	}
};

//#endregion
//#region src/core/engine/write/utils/chain/restoreAdoptedExternalErrors.ts
const restoreAdoptedExternalErrors = (root) => {
	const runtime = root.runtime;
	for (const [path, errors] of runtime.adoptedExternalErrors ?? []) {
		const node = find(root, path);
		if (!node) continue;
		(runtime.nodeErrors ?? (runtime.nodeErrors = /* @__PURE__ */ new Map())).set(node, errors);
		if (node === root) updateFieldNodeGlobalErrors(root);
		else (runtime.externalContributions ?? (runtime.externalContributions = /* @__PURE__ */ new Map())).set(node, errors);
		runtime.adoptedExternalErrors?.delete(path);
		queueNonSettleEvent(node, 32, errors);
	}
	if (!runtime.adoptedExternalErrors?.size) runtime.adoptedExternalErrors = void 0;
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchMount.ts
const NO_MOUNT_SETTINGS = {};
const dispatchMount = (root, value = root.runtime.loadSnapshot, option = WriteOption.Overwrite, settings = NO_MOUNT_SETTINGS) => {
	var _root$runtime;
	if (!enterFieldNodeChain(root)) return;
	clearWarningKeys(root.runtime);
	root.runtime.validationUnavailable = false;
	root.runtime.validationCompileReported = false;
	root.runtime.deferMountValidation = settings.deferValidation === true;
	if (!settings.deferValidation) ((_root$runtime = root.runtime).validationTargets ?? (_root$runtime.validationTargets = /* @__PURE__ */ new Set())).add(root);
	root.runtime.mountingGuardPass = __SCHEMA_FORM_DEV__;
	try {
		loadFieldNodeAtMount(root, value, option);
	} catch (error) {
		captureChainError(root.runtime, error);
	} finally {
		restoreAdoptedExternalErrors(root);
		root.runtime.adoptedExternalErrors = void 0;
		const runtime = root.runtime;
		if (runtime.errorReporter?.hasConsumer() && !runtime.validator && runtime.validationMode !== ValidationMode.None && !runtime.warningKeys?.has(FormWarningCode.ValidatorMissing)) {
			(runtime.warningKeys ?? (runtime.warningKeys = /* @__PURE__ */ new Set())).add(FormWarningCode.ValidatorMissing);
			const record = {
				level: "warning",
				code: FormWarningCode.ValidatorMissing,
				message: "Validation is disabled because no validator was selected"
			};
			(runtime.pendingWarningRecords ?? (runtime.pendingWarningRecords = /* @__PURE__ */ new Map())).set(FormWarningCode.ValidatorMissing, record);
			runtime.chainOccurrences?.push({
				kind: "record",
				record
			});
		}
		root.runtime.mountingGuardPass = false;
		exitFieldNodeChain(root);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchContextChange.ts
const dispatchContextChange = (root, context) => {
	if (!enterFieldNodeChain(root)) return;
	try {
		changeFieldNodeContext(root, context);
	} catch (error) {
		captureChainError(root.runtime, error);
	} finally {
		exitFieldNodeChain(root);
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchSetSubtreeState.ts
const dispatchSetSubtreeState = (node, state) => {
	assertFieldNodeWritable(node);
	if (node.detached) return;
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (refuseListenerFeedback(runtime)) return;
	const deltas = /* @__PURE__ */ new Map();
	visitFieldNodes(node, (current) => {
		if (current.detached) return false;
		const previous = current.interactionState;
		patchFieldNodeInteractionState(current, state);
		if (previous !== current.interactionState) {
			accumulateGlobalStateDeltas(deltas, previous, current.interactionState, state);
			if (current.deliveryChanges & 8) current.deliveryPreviousState = current.interactionState;
			runtime.stateChanged = true;
			queueNonSettleEvent(current, 8, current.interactionState);
		}
		return true;
	});
	publishGlobalStateDeltas(node.rootNode, deltas);
	closeNonSettleEntry(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchVisitSubtree.ts
const dispatchVisitSubtree = (node, visitor) => {
	const runtime = resolveFieldNodeChainRoot(node.rootNode).runtime;
	runtime.visitDepth = (runtime.visitDepth ?? 0) + 1;
	try {
		visitFieldNodes(node, visitor);
	} catch (error) {
		const active = resolveFieldNodeChainRoot(node.rootNode).runtime;
		if (active.visitDepth !== 1 || active.visitBatchEntry === void 0) throw error;
		captureChainError(active, error);
	} finally {
		const activeRoot = resolveFieldNodeChainRoot(node.rootNode);
		const active = activeRoot.runtime;
		active.visitDepth = (active.visitDepth ?? 1) - 1;
		const entry = active.visitDepth ? void 0 : active.visitBatchEntry;
		if (entry !== void 0) {
			active.visitBatchEntry = void 0;
			active.batchDepth = (active.batchDepth ?? 1) - 1;
			if (!active.batchDepth) flushBatchWrites(activeRoot);
			exitFieldNodeChain(entry);
		}
	}
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchClearSubtreeState.ts
const dispatchClearSubtreeState = (node) => {
	assertFieldNodeWritable(node);
	if (node.detached) return;
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (refuseListenerFeedback(runtime)) return;
	const deltas = /* @__PURE__ */ new Map();
	visitFieldNodes(node, (current) => {
		if (current.detached) return false;
		current.interactionReset += 1;
		if (Object.keys(current.interactionState).length) {
			const previous = current.interactionState;
			current.interactionState = {};
			accumulateGlobalStateDeltas(deltas, previous, current.interactionState, previous);
			if (current.deliveryChanges & 8) current.deliveryPreviousState = current.interactionState;
			runtime.stateChanged = true;
			queueNonSettleEvent(current, 8, current.interactionState);
		}
		return true;
	});
	publishGlobalStateDeltas(node.rootNode, deltas);
	closeNonSettleEntry(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchSetExternalErrors.ts
const dispatchSetExternalErrors = (node, errors) => {
	assertFieldNodeWritable(node);
	if (node.detached) return;
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (refuseListenerFeedback(runtime)) return;
	if (runtime.nodeErrors?.get(node) === errors) return;
	(runtime.nodeErrors ?? (runtime.nodeErrors = /* @__PURE__ */ new Map())).set(node, errors);
	if (node === node.rootNode) publishRootExternalErrors(node);
	else propagateExternalErrorsToRoot(node);
	queueNonSettleEvent(node, 32, errors);
	closeNonSettleEntry(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchRequest.ts
const dispatchRequest = (node, kind) => {
	assertFieldNodeWritable(node);
	if (node.detached) return;
	const runtime = node.rootNode.runtime;
	assertNotInDelivery(runtime);
	if (kind !== FieldNodeRequestType.Focus && kind !== FieldNodeRequestType.Select && kind !== FieldNodeRequestType.Refresh && kind !== FieldNodeRequestType.Remount) return;
	if (refuseListenerFeedback(runtime)) return;
	queueNonSettleEvent(node, kind);
	closeNonSettleEntry(node);
};

//#endregion
//#region src/core/engine/write/utils/entry/dispatchValidate.ts
const dispatchValidate = async (node) => {
	const runtime = node.rootNode.runtime;
	if (runtime.validationMode === ValidationMode.None) return [];
	if (node.disposed || node.rootNode.disposed) return await runFieldNodeValidation(node) ?? [];
	runtime.validationStamp = (runtime.validationStamp ?? 0) + 1;
	runtime.validationPendingTargets = void 0;
	const stamp = runtime.validationStamp;
	const commit = runtime.commitNumber ?? 0;
	let result;
	try {
		result = await runFieldNodeValidation(node);
	} catch (failure) {
		if (node.disposed || node.rootNode.disposed) throw failure;
		const compileFailure = failure instanceof SchemaFormError && failure.code === FormErrorCode.ValidatorCompileFailed;
		if (compileFailure) runtime.validationUnavailable = true;
		const firstReport = !compileFailure || !runtime.validationCompileReported;
		if (compileFailure) runtime.validationCompileReported = true;
		if (firstReport && runtime.errorReporter?.hasConsumer()) {
			const details = failure instanceof SchemaFormError || failure instanceof JSONSchemaError ? failure.details : void 0;
			const record = createFormErrorRecord(true, readFormErrorCode(failure), "error", () => failure instanceof Error ? failure.message : String(failure), {
				error: failure,
				...details ? { details } : {},
				surface: "rejected"
			});
			const handlerErrors = deliverChainRecords(runtime, record ? [record] : [], failure, true);
			if (handlerErrors.length) throw bundleChainErrors([failure, ...handlerErrors]);
		}
		throw failure;
	}
	if (result === null) return [];
	if (runtime.validationStamp !== stamp || (runtime.commitNumber ?? 0) !== commit) return result;
	const issues = retainEqualValidationIssues(node, result);
	routeValidationIssues(node, issues);
	runtime.validationResult = {
		commit,
		issues
	};
	deliverValidationWave(node, issues, commit);
	return issues;
};

//#endregion
//#region src/core/engine/write/utils/report/dedupeWarningRecord.ts
const dedupeWarningRecord = (keys, code, location, discriminator, format, fields) => {
	const key = JSON.stringify([
		code,
		location,
		discriminator
	]);
	if (keys.has(key)) return void 0;
	keys.add(key);
	return createFormErrorRecord(true, code, "warning", format, fields);
};

//#endregion
//#region src/core/engine/write/utils/report/readReferenceOnlySchemaPaths.ts
const NO_PATHS = Object.freeze([]);
const readReferenceOnlySchemaPaths = (previous, next) => {
	const pending = [{
		previous,
		next,
		path: JSONPointer.Fragment
	}];
	const paths = [];
	const seen = /* @__PURE__ */ new Map();
	while (pending.length) {
		const item = pending.pop();
		if (!item || Object.is(item.previous, item.next)) continue;
		const left = item.previous;
		const right = item.next;
		if (typeof left !== typeof right || left === null || right === null) return NO_PATHS;
		if (typeof left === "function" || typeof left === "symbol" || typeof left === "bigint") {
			paths.push(item.path);
			continue;
		}
		if (typeof left !== "object" || typeof right !== "object") return NO_PATHS;
		const leftArray = isArray(left);
		if (leftArray !== isArray(right)) return NO_PATHS;
		if (!leftArray) {
			const leftPrototype = Object.getPrototypeOf(left);
			if (leftPrototype !== Object.getPrototypeOf(right)) return NO_PATHS;
			if (leftPrototype !== Object.prototype && leftPrototype !== null) {
				paths.push(item.path);
				continue;
			}
		}
		if (seen.get(left)?.has(right)) continue;
		const seenRight = seen.get(left) ?? /* @__PURE__ */ new Set();
		seenRight.add(right);
		seen.set(left, seenRight);
		const leftKeys = Object.keys(left);
		const rightKeys = Object.keys(right);
		if (leftKeys.length !== rightKeys.length || leftKeys.some((key) => !hasOwnProperty(right, key))) return NO_PATHS;
		for (let index = leftKeys.length - 1; index >= 0; index -= 1) {
			const key = leftKeys[index];
			pending.push({
				previous: Reflect.get(left, key),
				next: Reflect.get(right, key),
				path: appendSegment(item.path, key)
			});
		}
	}
	return paths;
};

//#endregion
//#region src/core/engine/write/utils/chain/adoptFieldNodeChain.ts
const adoptFieldNodeChain = (previousRoot, nextRoot) => {
	assertFieldNodeWritable(previousRoot);
	assertFieldNodeWritable(nextRoot);
	assertValidationRootReady(nextRoot);
	rebuildRootExternalErrors(previousRoot);
	const previous = previousRoot.runtime;
	const next = nextRoot.runtime;
	next.entryDepth = previous.entryDepth;
	next.chainRoot = nextRoot;
	next.chainInitialEmit = previous.chainInitialEmit;
	next.chainErrors = previous.chainErrors;
	next.chainOccurrences = previous.chainOccurrences;
	next.enclosingChain = previous.enclosingChain;
	next.errorReporter ?? (next.errorReporter = previous.errorReporter);
	next.feedbackBudget = previous.feedbackBudget;
	next.feedbackBlockedListeners = previous.feedbackBlockedListeners;
	next.feedbackLimitReported = previous.feedbackLimitReported;
	next.currentListener = previous.currentListener;
	next.onChangeBudget = previous.onChangeBudget;
	next.batchDepth = previous.batchDepth;
	next.batchWrites = previous.batchWrites;
	next.visitDepth = previous.visitDepth;
	next.visitBatchEntry = previous.visitBatchEntry;
	next.validationTargets = previous.validationTargets?.size ? /* @__PURE__ */ new Set([nextRoot]) : void 0;
	next.deliveries = previous.deliveries;
	next.queuedNonSettleEvents = previous.queuedNonSettleEvents;
	next.stateChanged = previous.stateChanged;
	next.adoptedExternalErrors = new Map(previous.adoptedExternalErrors);
	for (const [node, errors] of previous.nodeErrors ?? []) if (node !== null && typeof node === "object" && "path" in node && typeof node.path === "string") next.adoptedExternalErrors.set(node.path, errors);
	restoreAdoptedExternalErrors(nextRoot);
	if (previous.pendingWarningRecords) for (const [key, record] of previous.pendingWarningRecords) {
		const parts = record.path === void 0 ? void 0 : JSON.parse(key);
		indexFieldNodeWarning(next, key, isArray(parts) && typeof parts[1] === "string" ? parts[1] : void 0, record);
	}
	if (next.errorReporter?.hasConsumer()) {
		const paths = next.rebuiltReferenceSchemaPaths ?? readReferenceOnlySchemaPaths(previous.blueprint?.schema, next.blueprint?.schema);
		if (paths.length) {
			const code = FormWarningCode.ResetRebuiltByReference;
			const record = dedupeWarningRecord(next.warningKeys ?? (next.warningKeys = /* @__PURE__ */ new Set()), code, "", "", () => "Form reset rebuilt the schema by reference", { details: { schemaPaths: paths } });
			if (record) {
				(next.pendingWarningRecords ?? (next.pendingWarningRecords = /* @__PURE__ */ new Map())).set(JSON.stringify([code, ""]), record);
				next.chainOccurrences?.push({
					kind: "record",
					record
				});
			}
		}
	}
	next.rebuiltReferenceSchemaPaths = void 0;
	previous.adoptedRoot = nextRoot;
	previous.entryDepth = 0;
	previous.batchDepth = 0;
	previous.batchWrites = void 0;
	previous.visitDepth = 0;
	previous.visitBatchEntry = void 0;
	previous.deliveries = void 0;
	previous.queuedNonSettleEvents = void 0;
	previous.stateChanged = void 0;
	previous.chainOccurrences = void 0;
	previous.enclosingChain = void 0;
	previous.pendingWarningRecords = void 0;
	previous.warningKeysByPath = void 0;
	disposeFieldNodeTree(previousRoot);
};

//#endregion
//#region src/core/engine/write/utils/read/readFieldNodeRevision.ts
const readFieldNodeRevision = (node, mask = Number.MAX_SAFE_INTEGER) => {
	node.runtime.revisionObserved = true;
	const ledger = node.revisionLedger;
	if (ledger === EMPTY_REVISION_LEDGER) return 0;
	if (ledger instanceof FieldNodeRevisionLedger) return ledger.read(mask);
	let revision = 0;
	for (let bit = 1; bit <= 65536; bit *= 2) if (mask & bit) revision += ledger[bit] ?? 0;
	return revision;
};

//#endregion
//#region src/core/engine/write/utils/read/onInactiveFieldNode.ts
const onInactiveFieldNode = (node, listener) => {
	if (node.disposed || node.rootNode.disposed) return NOOP_FUNCTION;
	const runtime = node.runtime;
	const listeners = runtime.inactiveListeners ?? (runtime.inactiveListeners = /* @__PURE__ */ new Map());
	const subscriptions = listeners.get(node) ?? /* @__PURE__ */ new Set();
	subscriptions.add(listener);
	listeners.set(node, subscriptions);
	return () => {
		subscriptions.delete(listener);
		if (!subscriptions.size && listeners.get(node) === subscriptions) listeners.delete(node);
	};
};

//#endregion
//#region src/core/engine/write/utils/read/subscribeFieldNode.ts
const subscribeFieldNode = (node, listener) => {
	if (node.disposed || node.rootNode.disposed) return NOOP_FUNCTION;
	const runtime = node.rootNode.runtime;
	const listeners = runtime.listeners ?? /* @__PURE__ */ new Map();
	const subscriptions = listeners.get(node) ?? /* @__PURE__ */ new Set();
	subscriptions.add(listener);
	listeners.set(node, subscriptions);
	runtime.listeners = listeners;
	return () => {
		subscriptions.delete(listener);
		if (!subscriptions.size) listeners.delete(node);
	};
};

//#endregion
//#region src/core/engine/utils/pathIndex/PathKeyedSet.ts
var PathKeyedSet = class extends Set {
	get mutations() {
		return this.mutationCount;
	}
	constructor(paths) {
		super();
		this.pathIndex = new PathStoreIndex();
		this.mutationCount = 0;
		if (paths) for (const path of paths) this.add(path);
	}
	add(path) {
		if (!this.has(path)) {
			this.pathIndex.add(path, [path]);
			this.mutationCount++;
		}
		return super.add(path);
	}
	delete(path) {
		this.pathIndex.delete(path);
		const removed = super.delete(path);
		if (removed) this.mutationCount++;
		return removed;
	}
	clear() {
		this.pathIndex.clear();
		super.clear();
		this.mutationCount++;
	}
	replacePaths(moves) {
		this.mutationCount++;
		this.pathIndex.beginBatch();
		try {
			for (const move of moves) {
				this.pathIndex.delete(move.previous);
				super.delete(move.previous);
			}
			for (const move of moves) if (move.current !== void 0) {
				this.pathIndex.add(move.current, [move.current]);
				super.add(move.current);
			}
		} finally {
			this.pathIndex.endBatch();
		}
	}
};

//#endregion
//#region src/core/surface/type.ts
const SetValueOption = Object.freeze({
	Overwrite: WriteOption.Overwrite,
	Merge: WriteOption.Merge,
	DisableAutomaticWrites: WriteOption.DisableAutomaticWrites,
	EnableAutomaticWrites: WriteOption.EnableAutomaticWrites
});

//#endregion
//#region src/core/surface/runtime/FieldNode.ts
var FieldNode = class {
	constructor(behavior, runtime, blueprintNode, parent, name, escapedName, path, depth, structure, children, schema, state) {
		this.behavior = behavior;
		this.runtime = runtime;
		this.blueprintNode = blueprintNode;
		this.parent = parent;
		this.root = parent?.rootNode ?? this;
		this.storedName = name;
		this.storedEscapedName = escapedName;
		this.storedPath = path;
		this.storedDepth = depth;
		this.storedRequired = false;
		this.storedNullable = blueprintNode.nullable;
		this.storedSchemaType = blueprintNode.schemaType;
		this.structure = structure;
		this.storedChildren = children;
		this.itemKey = null;
		this.itemCount = 0;
		this.nextItemKey = 0;
		this.storedRaw = void 0;
		this.storedUndeclaredValues = void 0;
		this.storedActive = true;
		this.storedVisible = true;
		this.storedReadOnly = false;
		this.storedDisabled = false;
		this.local = void 0;
		this.emit = void 0;
		this.schema = schema;
		this.interactionState = state;
		this.revisionLedger = EMPTY_REVISION_LEDGER;
		this.deliveryInitialized = false;
		this.deliveryChanges = 0;
		this.deliveryPreviousLocal = void 0;
		this.deliveryPreviousEmit = void 0;
		this.deliveryPreviousPath = void 0;
		this.deliveryPreviousChildren = void 0;
		this.deliveryPreviousComputed = void 0;
		this.deliveryPreviousSchema = void 0;
		this.deliveryPreviousState = void 0;
		this.deliveryWatchValues = void 0;
		this.pendingDelivery = void 0;
		this.pendingRevision = 0;
		this.pendingNonSettleDelivery = void 0;
		this.detached = false;
		this.disposed = false;
		this.interactionReset = 0;
	}
	get type() {
		return this.behavior.type;
	}
	get strategy() {
		return this.behavior.strategy;
	}
	get schemaType() {
		return this.storedSchemaType;
	}
	get jsonSchema() {
		return this.schema.schema;
	}
	get required() {
		return this.storedRequired;
	}
	set required(value) {
		this.storedRequired = value;
	}
	get nullable() {
		return this.storedNullable;
	}
	get depth() {
		return this.storedDepth;
	}
	set depth(value) {
		this.storedDepth = value;
	}
	get isRoot() {
		return this.parent === null;
	}
	get rootNode() {
		return this.root;
	}
	get parentNode() {
		return this.parent;
	}
	get name() {
		return this.storedName;
	}
	set name(value) {
		this.storedName = value;
	}
	get escapedName() {
		return this.storedEscapedName;
	}
	set escapedName(value) {
		this.storedEscapedName = value;
	}
	get path() {
		return this.storedPath;
	}
	set path(value) {
		this.storedPath = value;
	}
	get children() {
		return this.storedChildren;
	}
	set children(value) {
		this.storedChildren = value;
	}
	get raw() {
		return this.storedRaw;
	}
	set raw(value) {
		this.storedRaw = value;
	}
	get undeclaredValues() {
		return this.storedUndeclaredValues;
	}
	set undeclaredValues(value) {
		this.storedUndeclaredValues = value;
	}
	get value() {
		return this.local;
	}
	get outputValue() {
		return this.emit;
	}
	get inactiveValues() {
		return readFieldNodeInactiveValues(this);
	}
	get active() {
		return this.storedActive;
	}
	set active(value) {
		this.storedActive = value;
	}
	get visible() {
		return this.storedVisible;
	}
	set visible(value) {
		this.storedVisible = value;
	}
	get enabled() {
		return this.active && this.visible;
	}
	get readOnly() {
		return this.storedReadOnly;
	}
	set readOnly(value) {
		this.storedReadOnly = value;
	}
	get disabled() {
		return this.storedDisabled;
	}
	set disabled(value) {
		this.storedDisabled = value;
	}
	get watchValues() {
		return readFieldNodeWatchValues(this);
	}
	get context() {
		return this.runtime.context;
	}
	get misfit() {
		return readFieldNodeMisfit(this);
	}
	get misfits() {
		return readFieldNodeMisfits(this);
	}
	get diagnostics() {
		return this.runtime.diagnostics;
	}
	get defaultValue() {
		return readFieldNodeDefaultValue(this);
	}
	find(pointer) {
		return find(this, pointer);
	}
	findNodes(pointer) {
		return findNodes(this, pointer);
	}
	visitSubtree(visitor) {
		return dispatchVisitSubtree(this, visitor);
	}
	setValue(value, option = SetValueOption.Overwrite) {
		return dispatchSetValue(this, value, option);
	}
	push(value) {
		return dispatchPush(this, value);
	}
	pop() {
		return dispatchPop(this);
	}
	update(index, value) {
		return dispatchUpdate(this, index, value);
	}
	remove(index) {
		return dispatchRemove(this, index);
	}
	insert(index, value) {
		return dispatchInsert(this, index, value);
	}
	clear() {
		return dispatchClear(this);
	}
	resetSubtree(option = SetValueOption.Overwrite) {
		return dispatchResetSubtree(this, option);
	}
	get state() {
		return this.interactionState;
	}
	set state(value) {
		dispatchSetState(this, value);
	}
	setState(state) {
		return dispatchSetState(this, state);
	}
	get globalState() {
		return this.runtime.globalState;
	}
	setSubtreeState(state) {
		return dispatchSetSubtreeState(this, state);
	}
	clearSubtreeState() {
		return dispatchClearSubtreeState(this);
	}
	get errors() {
		return readFieldNodeErrors(this);
	}
	get globalErrors() {
		return this.runtime.globalErrors ?? EMPTY_GLOBAL_ERRORS;
	}
	setExternalErrors(errors) {
		return dispatchSetExternalErrors(this, errors);
	}
	clearExternalErrors() {
		return dispatchClearExternalErrors(this);
	}
	validate() {
		return dispatchValidate(this);
	}
	subscribe(listener) {
		return subscribeFieldNode(this, listener);
	}
	onInactive(listener) {
		return onInactiveFieldNode(this, listener);
	}
	revision(mask) {
		return readFieldNodeRevision(this, mask);
	}
	request(kind) {
		return dispatchRequest(this, kind);
	}
	batch(fn) {
		return dispatchBatch(this, fn);
	}
};

//#endregion
//#region src/core/surface/utils/fieldNodeFactory.ts
const NO_ACTIVE_DECLARATION_IDS = Object.freeze([]);
const createFieldNode = (entry, parent, runtime, source) => {
	const template = "node" in entry ? entry.node : entry;
	const name = "node" in entry ? entry.name : "";
	const escapedName = formatSegment(name);
	const path = parent ? appendFormattedSegment(parent.path, escapedName) : "";
	const depth = parent ? parent.depth + 1 : 0;
	const row = source?.behavior ?? BEHAVIORS[template.kind]?.[template.strategy];
	if (!row) throw new Error(`Missing behavior for ${template.kind}/${template.strategy}`);
	return new FieldNode(row, runtime, template, parent, name, escapedName, path, depth, template.strategy === "branch" ? {} : null, template.strategy === "branch" ? [] : null, source?.schema ?? mergeEffectiveSchema(template, NO_ACTIVE_DECLARATION_IDS, {
		mode: "runtime",
		isAtomic: runtime.blueprint?.isAtomic
	}), {});
};
function fieldNodeFactory(analysis, runtimeSeed, validator) {
	const runtime = {
		...runtimeSeed,
		misfitPaths: runtimeSeed.misfitPaths ?? new PathKeyedSet(),
		globalStateCounts: /* @__PURE__ */ new Map(),
		globalState: {},
		validator,
		context: runtimeSeed.context ?? {},
		blueprint: analysis,
		nodeFactory: createFieldNode,
		settlementScratch: void 0,
		entryDepth: 0,
		feedbackBudget: 0,
		onChangeBudget: 0,
		batchDepth: 0
	};
	if (runtime.errorReporter?.hasConsumer()) collectBlueprintWarnings(analysis, (diagnostic) => {
		const record = createFormErrorRecord(true, diagnostic);
		if (record) (runtime.pendingWarningRecords ?? (runtime.pendingWarningRecords = /* @__PURE__ */ new Map())).set(JSON.stringify([
			record.code,
			diagnostic.schemaPath,
			diagnostic.details.keyword ?? diagnostic.details.propertyName ?? ""
		]), record);
	});
	const authoredSchema = analysis.schema;
	if (__SCHEMA_FORM_DEV__ && validator?.dialect && authoredSchema !== null && typeof authoredSchema === "object" && typeof authoredSchema.$schema === "string" && validator.dialect !== authoredSchema.$schema) {
		const record = createFormErrorRecord(true, FormWarningCode.DialectMismatch, "warning", () => `Validator dialect ${validator.dialect} differs from schema ${authoredSchema.$schema}`, {
			schemaPath: "#/$schema",
			details: {
				dialect: validator.dialect,
				$schema: authoredSchema.$schema
			}
		});
		if (record) if (runtime.errorReporter?.hasConsumer()) runtime.errorReporter.report(record);
		else console.warn(record.code, record.message, record.details);
	}
	if (validator && __SCHEMA_FORM_DEV__ && analysis.schema !== null && typeof analysis.schema === "object") compileEntryGuards(readValidationEntry(validator, analysis.schema), validator, analysis);
	return createFieldNode(analysis.root, null, runtime);
}

//#endregion
//#region src/core/surface/utils/binding/buildFieldNodeTree.ts
function buildFieldNodeTree(props) {
	return fieldNodeFactory(blueprint(props.jsonSchema, props), {
		diagnostics: { status: "stable" },
		loadSnapshot: props.defaultValue,
		context: props.context,
		validationMode: props.validationMode,
		onChange: props.onChange,
		onStateChange: props.onStateChange,
		errorReporter: props.errorReporter,
		unsetOnInactive: props.unsetOnInactive,
		disableAutomaticWrites: props.disableAutomaticWrites
	}, props.validator);
}

//#endregion
//#region src/core/surface/runtime/requireRuntimeFieldNode.ts
const requireRuntimeFieldNode = (node, rootOnly = false) => {
	if (node instanceof FieldNode && (!rootOnly || node.isRoot && !node.detached)) return node;
	throw new TypeError("Binding requires a schema-form node with the requested root shape");
};

//#endregion
//#region src/core/surface/utils/binding/mountFieldNode.ts
const mountFieldNode = (root, value, option, settings) => dispatchMount(requireRuntimeFieldNode(root, true), value, option, settings);

//#endregion
//#region src/core/surface/utils/binding/reloadFieldNodeForm.ts
const reloadFieldNodeForm = (root, value, option) => dispatchResetForm(requireRuntimeFieldNode(root, true), value, option);

//#endregion
//#region src/core/surface/utils/binding/adoptFieldNodeTree.ts
const adoptFieldNodeTree = (previousRoot, nextRoot) => adoptFieldNodeChain(requireRuntimeFieldNode(previousRoot, true), requireRuntimeFieldNode(nextRoot, true));

//#endregion
//#region src/core/surface/utils/binding/writeFieldNodeInput.ts
const writeFieldNodeInput = (node, value, option) => dispatchWriteInput(requireRuntimeFieldNode(node), value, option);

//#endregion
//#region src/core/surface/utils/binding/finishFieldNodeInput.ts
const finishFieldNodeInput = (node) => dispatchFinishInput(requireRuntimeFieldNode(node));

//#endregion
//#region src/core/surface/utils/binding/readFieldNodeInteractionReset.ts
const readFieldNodeInteractionReset = (node) => readFieldNodeInteractionReset$1(requireRuntimeFieldNode(node));

//#endregion
//#region src/core/surface/utils/binding/observeFieldNodeReports.ts
const observeFieldNodeReports = (root, deliver) => {
	const runtime = requireRuntimeFieldNode(root, true).runtime;
	const previous = runtime.reportingErrors;
	runtime.reportingErrors = true;
	try {
		deliver();
	} finally {
		runtime.reportingErrors = previous;
	}
};

//#endregion
//#region src/core/surface/utils/binding/interpretFieldNodeDraft.ts
const interpretFieldNodeDraft = (node, draft) => {
	const authored = isArray(node.schemaType) ? node.schemaType : [node.schemaType];
	const schema = node.jsonSchema;
	const type = typeof schema === "object" && schema !== null ? schema.type : void 0;
	const effective = isArray(type) ? type : type === void 0 ? authored : [type];
	const kinds = authored.filter((kind) => kind !== void 0 && kind !== "null" && effective.includes(kind));
	const value = interpret(draft, {
		kinds,
		mask: 0,
		nullable: node.nullable
	});
	return {
		value,
		isMember: value === void 0 || (value === null ? node.nullable : kinds.some((kind) => isMember(value, kind)))
	};
};

//#endregion
//#region src/core/surface/runtime/setContext.ts
const setContext = (root, context) => dispatchContextChange(requireRuntimeFieldNode(root, true), context);

//#endregion
//#region src/core/surface/utils/guards.ts
const isFieldNode = (value) => value instanceof FieldNode;
const isStringNode = (node) => node.type === "string";
const isNumberNode = (node) => node.type === "number";
const isBooleanNode = (node) => node.type === "boolean";
const isObjectNode = (node) => node.type === "object";
const isArrayNode = (node) => node.type === "array";
const isVirtualNode = (node) => node.type === "virtual";
const isUnionNode = (node) => node.type === "union";
const isBranchNode = (node) => node.strategy === "branch";
const isTerminalNode = (node) => node.strategy === "terminal";

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputUnion/utils/readUnionDisplay.ts
const EMPTY_DISPLAY = {
	text: "",
	structured: false,
	invalid: false
};
const INVALID_DISPLAY = {
	text: "",
	structured: true,
	invalid: true
};
const readUnionDisplay = (value, nullable) => {
	if (value === void 0 || value === null && nullable) return EMPTY_DISPLAY;
	if (value === null || typeof value !== "object") return {
		text: String(value),
		structured: false,
		invalid: false
	};
	try {
		const text = JSON.stringify(value);
		return {
			text: text ?? "",
			structured: true,
			invalid: text === void 0
		};
	} catch {
		return INVALID_DISPLAY;
	}
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputUnion/FieldInputUnion.tsx
const FieldInputUnion = (props) => {
	const { node, value, nullable, schemaType, jsonSchema, misfit } = props;
	const display = useMemo(() => readUnionDisplay(value, nullable), [value, nullable]);
	const effectiveTypes = useMemo(() => {
		const authored = isArray(schemaType) ? schemaType : [schemaType];
		const type = jsonSchema.type;
		const effective = isArray(type) ? type : type === void 0 ? authored : [type];
		return authored.filter((kind) => effective.includes(kind));
	}, [schemaType, jsonSchema]);
	const effectiveKey = effectiveTypes.join(",");
	const editable = !display.structured && effectiveTypes.some((kind) => kind === "string" || kind === "number" || kind === "integer" || kind === "boolean");
	const [text, setText] = useState(display.text);
	const draft = useRef(void 0);
	const composing = useRef(false);
	const publish = useHandle((next) => {
		if (composing.current || !editable || props.readOnly || props.disabled) return false;
		const result = interpretFieldNodeDraft(node, next === "" ? void 0 : next);
		if (!result.isMember) return false;
		props.onChange(result.value);
		return true;
	});
	const handleChange = useHandle((event) => {
		draft.current = event.target.value;
		setText(draft.current);
		publish(draft.current);
	});
	useEffect(() => {
		if (draft.current === void 0) setText(display.text);
	}, [display.text]);
	useEffect(() => {
		if (draft.current !== void 0) publish(draft.current);
	}, [effectiveKey, publish]);
	const invalid = misfit || display.invalid;
	return /* @__PURE__ */ jsx(FieldInputString, {
		...props,
		defaultValue: display.text,
		readOnly: props.readOnly || !editable,
		inputProps: {
			value: text,
			defaultValue: void 0,
			"aria-invalid": invalid || void 0,
			onChange: handleChange,
			onCompositionStart: () => {
				composing.current = true;
			},
			onCompositionEnd: (event) => {
				composing.current = false;
				draft.current = event.currentTarget.value;
				setText(draft.current);
				publish(draft.current);
			},
			onBlur: () => {
				if (composing.current) return;
				if (draft.current !== void 0 && !publish(draft.current)) {
					draft.current = void 0;
					setText(readUnionDisplay(node.value, nullable).text);
				}
			}
		}
	});
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputUnion/index.ts
const FieldInputUnionDefinition = {
	Component: FieldInputUnion,
	test: { type: "union" }
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputVirtual/FieldInputVirtual.tsx
const FieldInputVirtual = ({ ChildFields }) => {
	return /* @__PURE__ */ jsx(Fragment$1, { children: ChildFields && map(ChildFields, (ChildField) => /* @__PURE__ */ jsx(ChildField, {}, ChildField.key)) });
};

//#endregion
//#region src/fieldInputs/fieldInputDefinitions/FieldInputVirtual/index.ts
const FieldInputVirtualDefinition = {
	Component: FieldInputVirtual,
	test: { type: "virtual" }
};

//#endregion
//#region src/fieldInputs/index.tsx
const builtinFieldInputDefinitions = [
	FieldInputDateFormatDefinition,
	FieldInputStringCheckboxDefinition,
	FieldInputStringRadioDefinition,
	FieldInputStringEnumDefinition,
	FieldInputVirtualDefinition,
	FieldInputArrayDefinition,
	FieldInputObjectDefinition,
	FieldInputBooleanDefinition,
	FieldInputUnionDefinition,
	FieldInputStringDefinition,
	FieldInputNumberDefinition
];

//#endregion
//#region src/helpers/fieldInputDefinition/utils/fieldInputTestFnFactory.ts
const fieldInputTestFnFactory$1 = (path) => {
	const segments = parsePointerSegments(path);
	return (hint) => {
		const hintSegments = parsePointerSegments(hint.path);
		if (segments.length !== hintSegments.length) return false;
		for (let i = 0, l = segments.length; i < l; i++) {
			const segment = segments[i];
			const hintSegment = hintSegments[i];
			if (segment === PointerOperator.Wildcard) continue;
			else if (segment !== hintSegment) return false;
		}
		return true;
	};
};

//#endregion
//#region src/helpers/fieldInputDefinition/utils/hasWildcardPath.ts
const hasWildcardPath = (path) => {
	const parsed = parsePointer(path);
	return parsed.absolute && parsed.segments[parsed.segments.length - 1] !== "" && parsed.segments.includes(PointerOperator.Wildcard);
};

//#endregion
//#region src/helpers/fieldInputDefinition/utils/formatFieldInputMapError.ts
const formatFieldInputMapError = (inputPath, error) => {
	const divider = createDivider();
	return `
Invalid key pattern in FieldInputMap.

  ╭${divider}
  │  Pattern:  '${inputPath}'
  ├${divider}
  │  Error:  ${getErrorMessage(error)}
  ╰${divider}

FieldInputMap keys must be valid JSONPointer paths or patterns.
The provided pattern could not be compiled into a valid path matcher.

Valid patterns:
  • Exact paths:    '/property/nested'
  • Root path:      ''
  • With wildcard:  '/items/*/name'  (matches any index)
  • Fragment:       '#/definitions/User'

How to fix:
  1. Use valid JSONPointer syntax:
     {
       '/users/0/name': UserNameInput,
       '/items/*/title': ItemTitleInput
     }

  2. Escape special characters properly:
     • '/' in property names → '~1'
     • '~' in property names → '~0'

  3. Check for typos or invalid regex patterns in the key
`.trim();
};

//#endregion
//#region src/helpers/fieldInputDefinition/utils/pathExactMatchFnFactory.ts
const pathExactMatchFnFactory = (inputPath) => {
	try {
		const path = stripFragment(inputPath);
		const segments = parsePointerSegments(inputPath);
		const exactEmptyName = isAbsolutePointer(inputPath) && segments.length === 1 && segments[0] === "";
		const regex = path && !exactEmptyName ? new RegExp(path) : null;
		return (hint) => {
			if (hint.path === path) return true;
			if (regex?.test(hint.path)) return true;
			return false;
		};
	} catch (error) {
		throw new SchemaFormError(FormErrorCode.FormTypeInputMap, formatFieldInputMapError(inputPath, error), {
			path: inputPath,
			error
		});
	}
};

//#endregion
//#region src/providers/FormErrorContext/utils/reportErrorToHost.ts
const reportErrorToHost = (error) => {
	if (typeof globalThis.reportError === "function") {
		globalThis.reportError(error);
		return;
	}
	if (typeof window !== "undefined" && typeof ErrorEvent === "function") {
		const event = new ErrorEvent("error", {
			error,
			message: error instanceof Error ? error.message : String(error),
			cancelable: true
		});
		if (!window.dispatchEvent(event)) return;
	}
	console.error(error);
};

//#endregion
//#region src/providers/FormErrorContext/utils/createFormErrorService.ts
const createFormErrorService = () => {
	const seen = /* @__PURE__ */ new WeakSet();
	const warnings = /* @__PURE__ */ new Set();
	let delivering = false;
	const service = {
		hasConsumer: () => !!service.onError || __SCHEMA_FORM_DEV__,
		load: 0,
		beginLoad: () => {
			service.load++;
			warnings.clear();
		},
		report(record) {
			if (delivering) return;
			if (record.error && typeof record.error === "object") seen.add(record.error);
			if (record.level === "warning") {
				const key = JSON.stringify([record.code, record.path]);
				if (warnings.has(key)) return;
				warnings.add(key);
			}
			delivering = true;
			try {
				if (service.onError) {
					const deliver = () => service.onError?.(record);
					if (service.root) observeFieldNodeReports(service.root, deliver);
					else deliver();
				} else if (__SCHEMA_FORM_DEV__) console.warn(record.message, record);
			} finally {
				delivering = false;
			}
		},
		capture(error, componentStack, surface = "sink", path) {
			if (error && typeof error === "object" && seen.has(error)) {
				if (componentStack !== void 0) seen.delete(error);
				return;
			}
			const domain = error;
			try {
				service.report({
					level: "error",
					code: componentStack !== void 0 ? FormErrorCode.RenderFailed : domain?.code ?? FormErrorCode.RenderFailed,
					message: domain?.message ?? String(error),
					error,
					...path !== void 0 ? { path } : {},
					details: domain?.details,
					surface,
					...componentStack !== void 0 ? { componentStack } : {}
				});
			} catch (handlerError) {
				reportErrorToHost(handlerError);
			}
		}
	};
	return service;
};

//#endregion
//#region src/providers/FormErrorContext/components/FormErrorContext.ts
const FormErrorContext = createContext(void 0);

//#endregion
//#region src/providers/FormErrorContext/components/FormErrorContextProvider.tsx
const FormErrorContextProvider = ({ onError, children }) => {
	const [reporter] = useState(() => {
		const service = createFormErrorService();
		service.onError = onError;
		return service;
	});
	useInsertionEffect(() => {
		reporter.onError = onError;
	}, [reporter, onError]);
	return /* @__PURE__ */ jsx(FormErrorContext.Provider, {
		value: reporter,
		children
	});
};

//#endregion
//#region src/providers/FormErrorContext/hooks/useFormErrorContext.ts
const useFormErrorContext = () => useContext(FormErrorContext);

//#endregion
//#region src/providers/FormErrorContext/hooks/useBoundaryReporter.ts
const useBoundaryReporter = (path) => {
	const reporter = useFormErrorContext();
	return useCallback((error, info) => {
		if (path === void 0) reporter?.pendingLoad?.();
		reporter?.capture(error, info.componentStack ?? "", "sink", path);
	}, [reporter, path]);
};

//#endregion
//#region src/providers/FormErrorContext/components/FormErrorPathContext.ts
const FormErrorPathContext = createContext(void 0);

//#endregion
//#region src/providers/FormErrorContext/hooks/usePlaceholderBoundaryReporter.ts
const usePlaceholderBoundaryReporter = () => useBoundaryReporter(useContext(FormErrorPathContext));

//#endregion
//#region src/helpers/fieldInputDefinition/utils/withFieldInputErrorBoundary.tsx
const withFieldInputErrorBoundary = (Component) => {
	return memo(function FieldInputBoundary({ inputGeneration, ...props }) {
		return /* @__PURE__ */ jsx(ErrorBoundary, {
			onError: useBoundaryReporter(props.path),
			children: /* @__PURE__ */ createElement(Component, {
				...props,
				key: inputGeneration
			})
		});
	});
};

//#endregion
//#region src/helpers/fieldInputDefinition/utils/normalizeFieldInputMap.ts
const normalizeFieldInputMap = (fieldInputMap) => {
	if (!fieldInputMap) return [];
	const result = [];
	const keys = Object.keys(fieldInputMap);
	for (let i = 0, k = keys[0], l = keys.length; i < l; i++, k = keys[i]) {
		const Component = fieldInputMap[k];
		if (!isReactComponent(Component)) continue;
		if (hasWildcardPath(k)) result.push({
			test: fieldInputTestFnFactory$1(k),
			Component: withFieldInputErrorBoundary(Component)
		});
		else result.push({
			test: pathExactMatchFnFactory(k),
			Component: withFieldInputErrorBoundary(Component)
		});
	}
	return result;
};

//#endregion
//#region src/helpers/fieldInputDefinition/utils/normalizeFieldInputDefinitions.ts
const cache = /* @__PURE__ */ new WeakMap();
const testKeys = [
	"type",
	"schemaType",
	"path",
	"required",
	"nullable",
	"format",
	"inputType"
];
const testKeySet = new Set(testKeys);
const normalizeFieldInputDefinitions = (definitions) => {
	const result = [];
	for (const definition of definitions ?? []) {
		if (cache.has(definition)) {
			result.push(cache.get(definition));
			continue;
		}
		const { Component, test } = definition;
		if (!isReactComponent(Component) || !isFunction(test) && !isPlainObject(test)) continue;
		if (!isFunction(test)) {
			const invalid = Object.keys(test).filter((key) => !testKeySet.has(key));
			if ((isArray(test.type) ? test.type : [test.type]).includes("integer")) invalid.push("type:integer");
			if (invalid.length && __SCHEMA_FORM_DEV__) console.warn(FormWarningCode.FormTypeTestInvalid, {
				definition,
				invalid
			});
		}
		const normalized = {
			test: isFunction(test) ? test : fieldInputTestFnFactory(test),
			Component: withFieldInputErrorBoundary(Component)
		};
		cache.set(definition, normalized);
		result.push(normalized);
	}
	return result;
};
const fieldInputTestFnFactory = (test) => {
	const keys = testKeys.filter((key) => hasOwnProperty(test, key));
	return (hint) => keys.every((key) => {
		const reference = test[key], subject = hint[key];
		return isArray(reference) ? reference.includes(subject) : reference === subject;
	});
};

//#endregion
//#region src/app/plugin/utils/PluginManager.ts
const defaultRenderKit = {
	FieldRenderer: FormFieldRenderer,
	FormLabelRenderer,
	FormInputRenderer,
	FormErrorRenderer
};
const defaultFieldInputDefinitions = normalizeFieldInputDefinitions(builtinFieldInputDefinitions);
var PluginManager = class PluginManager {
	static get FieldRenderer() {
		return PluginManager.__renderKit__.FieldRenderer;
	}
	static get FormLabelRenderer() {
		return PluginManager.__renderKit__.FormLabelRenderer;
	}
	static get FormInputRenderer() {
		return PluginManager.__renderKit__.FormInputRenderer;
	}
	static get FormErrorRenderer() {
		return PluginManager.__renderKit__.FormErrorRenderer;
	}
	static appendRenderKit(renderKit) {
		if (!renderKit) return;
		PluginManager.__renderKit__ = {
			...PluginManager.__renderKit__,
			...remainOnlyReactComponent(renderKit)
		};
	}
	static get fieldInputDefinitions() {
		return PluginManager.__fieldInputDefinitions__;
	}
	static appendFieldInputDefinitions(fieldInputDefinitions) {
		if (!fieldInputDefinitions) return;
		PluginManager.__fieldInputDefinitions__ = [...normalizeFieldInputDefinitions(fieldInputDefinitions), ...PluginManager.__fieldInputDefinitions__];
	}
	static get validator() {
		return PluginManager.__validator__;
	}
	static get formatError() {
		return PluginManager.__formatError__;
	}
	static appendValidator(validator) {
		if (!validator) return;
		PluginManager.__validator__ = validator;
	}
	static appendFormatError(formatError) {
		if (!formatError) return;
		PluginManager.__formatError__ = formatError;
	}
	static reset() {
		PluginManager.__renderKit__ = defaultRenderKit;
		PluginManager.__fieldInputDefinitions__ = defaultFieldInputDefinitions;
		PluginManager.__validator__ = void 0;
		PluginManager.__formatError__ = formatValidationError;
	}
};
PluginManager.__renderKit__ = defaultRenderKit;
PluginManager.__fieldInputDefinitions__ = defaultFieldInputDefinitions;
PluginManager.__formatError__ = formatValidationError;

//#endregion
//#region src/app/plugin/utils/formatRegisterPluginError.ts
const formatRegisterPluginError = (plugin, error) => {
	const divider = createDivider();
	const errorMessage = getErrorMessage(error);
	const pluginFeatures = [];
	if (plugin.FormErrorRenderer) pluginFeatures.push("FormError");
	if (plugin.FieldRenderer) pluginFeatures.push("FormField");
	if (plugin.FormInputRenderer) pluginFeatures.push("FormInput");
	if (plugin.FormLabelRenderer) pluginFeatures.push("FormLabel");
	if (plugin.fieldInputDefinitions?.length) pluginFeatures.push("fieldInputDefinitions");
	if (plugin.validator) pluginFeatures.push("validator");
	if (plugin.formatError) pluginFeatures.push("formatError");
	return `
Failed to register schema form plugin.

  ╭${divider}
  │  Plugin Features:
${pluginFeatures.length > 0 ? formatBulletList(pluginFeatures) : "  │    (none detected)"}
  ├${divider}
  │  Error:  ${errorMessage}
  ╰${divider}

The plugin could not be registered with the form system.
This may indicate a problem with the plugin's configuration
or a conflict with existing registered plugins.

How to fix:
  1. Check that the plugin exports are correctly structured:
     {
       renderKit?: { ... },
       fieldInputDefinitions?: [...],
       validator?: ValidatorFactory,
       formatError?: ErrorFormatter
     }

  2. Ensure the plugin is not already registered

  3. Verify there are no conflicts with existing plugins

  4. Check the error message above for specific details
`.trim();
};
const formatBulletList = (items, prefix = "  │    ", emptyMessage = "(none)") => {
	if (items.length === 0) return `${prefix}${emptyMessage}`;
	return items.map((item) => `${prefix}• ${item}`).join("\n");
};

//#endregion
//#region src/app/plugin/utils/registerPlugin.ts
const RegisteredPlugin = /* @__PURE__ */ new Set();
const getPluginKey = createFingerprintFactory();
const registerPlugin = (plugin) => {
	if (plugin === null) {
		PluginManager.reset();
		RegisteredPlugin.clear();
		return;
	}
	if (!isPlainObject(plugin)) return;
	const hash = getPluginKey(plugin);
	if (RegisteredPlugin.has(hash)) return;
	try {
		const { fieldInputDefinitions, validator, formatError, ...renderKit } = plugin;
		PluginManager.appendRenderKit(renderKit);
		PluginManager.appendFieldInputDefinitions(fieldInputDefinitions);
		PluginManager.appendValidator(validator);
		PluginManager.appendFormatError(formatError);
	} catch (error) {
		throw new UnhandledError(FormErrorCode.RegisterPlugin, formatRegisterPluginError(plugin, error), {
			plugin,
			error
		});
	}
	RegisteredPlugin.add(hash);
};

//#endregion
//#region src/providers/ExternalFormContext/components/ExternalFormContext.ts
const ExternalFormContext = createContext({});

//#endregion
//#region src/providers/ExternalFormContext/components/ExternalFormContextProvider.tsx
const ExternalFormContextProvider = ({ fieldInputDefinitions, FieldRenderer, FormLabelRenderer, FormInputRenderer, FormErrorRenderer, formatError, showError, validationMode, context: inputContext, validatorFactory, children }) => {
	const constant = useConstant({
		fieldInputDefinitions,
		FieldRenderer,
		FormLabelRenderer,
		FormInputRenderer,
		FormErrorRenderer,
		formatError
	});
	const context = useSnapshot(inputContext);
	const value = useMemo(() => ({
		fromExternalFieldInputDefinitions: constant.fieldInputDefinitions ? normalizeFieldInputDefinitions(constant.fieldInputDefinitions) : void 0,
		FieldRenderer: constant.FieldRenderer,
		FormLabelRenderer: constant.FormLabelRenderer,
		FormInputRenderer: constant.FormInputRenderer,
		FormErrorRenderer: constant.FormErrorRenderer,
		formatError: constant.formatError,
		showError,
		validationMode,
		validatorFactory,
		context
	}), [
		constant,
		showError,
		validationMode,
		validatorFactory,
		context
	]);
	return /* @__PURE__ */ jsx(ExternalFormContext.Provider, {
		value,
		children
	});
};

//#endregion
//#region src/providers/ExternalFormContext/hooks/useExternalFormContext.ts
const useExternalFormContext = () => useContext(ExternalFormContext);

//#endregion
//#region src/providers/FieldInputsContext/components/FieldInputsContext.ts
const FieldInputsContext = createContext({});

//#endregion
//#region src/providers/FieldInputsContext/components/FieldInputsContextProvider.tsx
const FieldInputsContextProvider = ({ fieldInputDefinitions, fieldInputMap, children }) => {
	const constant = useConstant({
		fieldInputDefinitions,
		fieldInputMap
	});
	const value = useMemo(() => ({
		fromFieldInputDefinitions: normalizeFieldInputDefinitions(constant.fieldInputDefinitions),
		fromFieldInputMap: normalizeFieldInputMap(constant.fieldInputMap)
	}), [constant]);
	return /* @__PURE__ */ jsx(FieldInputsContext.Provider, {
		value,
		children
	});
};

//#endregion
//#region src/providers/FieldInputsContext/hooks/useFieldInputsContext.ts
const useFieldInputsContext = () => useContext(FieldInputsContext);

//#endregion
//#region src/types/error/error.ts
let ShowError = /* @__PURE__ */ function(ShowError) {
	ShowError[ShowError["Always"] = 1] = "Always";
	ShowError[ShowError["Never"] = 2] = "Never";
	ShowError[ShowError["Dirty"] = 4] = "Dirty";
	ShowError[ShowError["Touched"] = 8] = "Touched";
	ShowError[ShowError["DirtyTouched"] = 16] = "DirtyTouched";
	return ShowError;
}({});

//#endregion
//#region src/providers/FieldRendererContext/components/FieldRendererContext.ts
const FieldRendererContext = createContext({});

//#endregion
//#region src/providers/FieldRendererContext/components/FieldRendererProvider.tsx
const DEFAULT_SHOW_ERROR = ShowError.DirtyTouched;
const FieldRendererContextProvider = ({ FieldRenderer, FormLabelRenderer, FormInputRenderer, FormErrorRenderer, formatError, showError: inputShowError, children }) => {
	const { FieldRenderer: ExternalFormFieldRenderer, formatError: externalFormatError, showError: externalShowError } = useExternalFormContext();
	const checkShowError = useMemo(() => {
		const showError = inputShowError ?? externalShowError ?? DEFAULT_SHOW_ERROR;
		const errorState = typeof showError === "boolean" ? showError ? ShowError.Always : ShowError.Never : showError;
		return (condition) => {
			const showError = condition?.[4], dirty = condition?.[1], touched = condition?.[2];
			if (showError !== void 0) return showError;
			if (errorState & ShowError.Always) return true;
			if (errorState & ShowError.Never) return false;
			if (errorState & ShowError.Dirty && dirty) return true;
			if (errorState & ShowError.Touched && touched) return true;
			if (errorState & ShowError.DirtyTouched && dirty && touched) return true;
			return false;
		};
	}, [inputShowError, externalShowError]);
	const constant = useConstant({
		FieldRenderer,
		FormLabelRenderer,
		FormInputRenderer,
		FormErrorRenderer,
		formatError
	});
	const value = useMemo(() => {
		const FieldRenderer = isReactComponent(constant.FieldRenderer) ? constant.FieldRenderer : ExternalFormFieldRenderer;
		const formatError = isFunction(constant.formatError) ? constant.formatError : externalFormatError;
		return {
			FieldRenderer,
			FormLabelRenderer: constant.FormLabelRenderer,
			FormInputRenderer: constant.FormInputRenderer,
			FormErrorRenderer: constant.FormErrorRenderer,
			formatError,
			checkShowError
		};
	}, [
		constant,
		checkShowError,
		ExternalFormFieldRenderer,
		externalFormatError
	]);
	return /* @__PURE__ */ jsx(FieldRendererContext.Provider, {
		value,
		children
	});
};

//#endregion
//#region src/providers/FieldRendererContext/hooks/useFieldRendererContext.ts
const useFieldRendererContext = () => {
	const context = useContext(FieldRendererContext);
	const external = useExternalFormContext();
	return {
		FormLabelRenderer: context.FormLabelRenderer || external.FormLabelRenderer || PluginManager.FormLabelRenderer,
		FormInputRenderer: context.FormInputRenderer || external.FormInputRenderer || PluginManager.FormInputRenderer,
		FormErrorRenderer: context.FormErrorRenderer || external.FormErrorRenderer || PluginManager.FormErrorRenderer,
		FieldRenderer: context.FieldRenderer || PluginManager.FieldRenderer,
		formatError: context.formatError || PluginManager.formatError,
		checkShowError: context.checkShowError
	};
};

//#endregion
//#region src/providers/InputControlContext/components/InputControlContext.ts
const InputControlContext = createContext({});

//#endregion
//#region src/providers/InputControlContext/components/InputControlContextProvider.tsx
const InputControlContextProvider = ({ readOnly, disabled, children }) => {
	const value = useMemo(() => ({
		readOnly,
		disabled
	}), [readOnly, disabled]);
	return /* @__PURE__ */ jsx(InputControlContext.Provider, {
		value,
		children
	});
};

//#endregion
//#region src/providers/InputControlContext/hooks/useInputControlContext.ts
const useInputControlContext = () => useContext(InputControlContext);

//#endregion
//#region src/app/cache/utils/CacheManager.ts
var CacheManager = class CacheManager {
	static register(domain) {
		CacheManager.domains.add(domain);
	}
	static reset() {
		for (const domain of CacheManager.domains) domain.clear();
	}
};
CacheManager.domains = /* @__PURE__ */ new Set();

//#endregion
//#region src/app/cache/utils/BlueprintCacheStore.ts
var BlueprintCacheStore = class extends WeakMap {
	constructor(domain) {
		super();
		this.domain = domain;
	}
	get(key) {
		return this.domain.peek(key)?.value;
	}
	set(key, value) {
		this.domain.invalidate(key);
		this.domain.resolve(key, () => value);
		return this;
	}
	delete(key) {
		return this.domain.invalidate(key);
	}
	has(key) {
		return this.domain.peek(key) !== void 0;
	}
};

//#endregion
//#region src/app/cache/utils/createCacheDomain.ts
function createCacheDomain(name) {
	let entries = /* @__PURE__ */ new WeakMap();
	let generation = 0;
	const domain = {
		name,
		resolve(key, build) {
			const existing = entries.get(key);
			if (existing) return existing;
			const value = build();
			const entry = {
				value,
				generation
			};
			if (__SCHEMA_FORM_DEV__) {
				Object.freeze(value);
				Object.freeze(entry);
			}
			entries.set(key, entry);
			return entry;
		},
		peek: (key) => entries.get(key),
		invalidate: (key) => entries.delete(key),
		clear() {
			entries = /* @__PURE__ */ new WeakMap();
			generation++;
		}
	};
	CacheManager.register(domain);
	return domain;
}

//#endregion
//#region src/app/cache/utils/blueprintCacheDomain.ts
const domain = createCacheDomain("blueprint");
const blueprintCacheDomain = {
	cache: new BlueprintCacheStore(domain),
	invalidate: (schema) => domain.invalidate(schema)
};

//#endregion
//#region src/helpers/schemaIdentity/utils/isSameSchema.ts
const isSameSchema = (left, right) => {
	if (Object.is(left, right)) return true;
	if (!left || !right || typeof left !== "object" || typeof right !== "object") return false;
	if (hasOwnProperty(left, "$$typeof") || hasOwnProperty(right, "$$typeof") || hasOwnProperty(left, "current") || hasOwnProperty(right, "current")) return false;
	if (isArray(left) !== isArray(right)) return false;
	if (!isArray(left) && (!isPlainObject(left) || !isPlainObject(right))) return false;
	const keys = Object.keys(left);
	const otherKeys = Object.keys(right);
	if (keys.length !== otherKeys.length) return false;
	return keys.every((key, index) => key === otherKeys[index] && isSameSchema(left[key], right[key]));
};

//#endregion
//#region src/helpers/schemaIdentity/utils/isRenderAtomic.ts
const isRenderAtomic = (value) => !!value && typeof value === "object" && (hasOwnProperty(value, "$$typeof") || hasOwnProperty(value, "current"));

//#endregion
//#region src/helpers/schemaIdentity/utils/isRenderTerminal.ts
const isRenderTerminal = (schema) => schema && typeof schema === "object" && isReactComponent(schema.presentation?.FieldInput) ? true : void 0;

//#endregion
//#region src/providers/WorkspaceContext/components/WorkspaceContext.ts
const WorkspaceContext = createContext({});

//#endregion
//#region src/providers/WorkspaceContext/components/WorkspaceContextProvider.tsx
const WorkspaceContextProvider = ({ attachedFilesMap, context: inputContext, children }) => {
	const external = useExternalFormContext();
	const context = useSnapshot(inputContext);
	const contextValue = useMemo(() => ({
		attachedFilesMap,
		context: {
			...external.context || {},
			...context || {}
		}
	}), [
		attachedFilesMap,
		external.context,
		context
	]);
	return /* @__PURE__ */ jsx(WorkspaceContext.Provider, {
		value: contextValue,
		children
	});
};

//#endregion
//#region src/providers/WorkspaceContext/hooks/useWorkspaceContext.ts
const useWorkspaceContext = () => useContext(WorkspaceContext);

//#endregion
//#region src/providers/RootNodeContext/utils/applyFormErrors.ts
const NO_ERRORS = [];
const applyFormErrors = (root, errors = NO_ERRORS, previous = NO_ERRORS) => {
	if (!isArray(errors)) errors = NO_ERRORS;
	if (!isArray(previous)) previous = NO_ERRORS;
	const resolved = /* @__PURE__ */ new Map();
	const resolve = (dataPath) => {
		let node = resolved.get(dataPath);
		if (node === void 0) {
			node = root.find(dataPath);
			resolved.set(dataPath, node);
		}
		return node;
	};
	const groups = /* @__PURE__ */ new Map();
	const nodes = [];
	for (let index = 0; index < errors.length; index++) {
		const issue = errors[index];
		const node = resolve(issue.dataPath);
		if (!node || node === root) continue;
		let group = groups.get(node);
		if (!group) {
			group = [];
			groups.set(node, group);
			nodes.push(node);
		}
		group.push(issue);
	}
	for (let index = 0; index < previous.length; index++) {
		const node = resolve(previous[index].dataPath);
		if (!node || node === root || groups.has(node)) continue;
		groups.set(node, []);
		nodes.push(node);
	}
	root.batch(() => {
		root.setExternalErrors(errors);
		for (let index = 0; index < nodes.length; index++) nodes[index].setExternalErrors(groups.get(nodes[index]));
	});
};

//#endregion
//#region src/providers/RootNodeContext/utils/createRootLoad.ts
const createRootLoad = (props, reporter, mount = true) => {
	const load = {
		props,
		records: [],
		ready: false,
		prepared: false,
		reporter
	};
	try {
		load.root = buildFieldNodeTree({
			...props,
			cache: blueprintCacheDomain.cache,
			defaultValue: clone(props.defaultValue),
			isTerminal: isRenderTerminal,
			isAtomic: isRenderAtomic,
			errorReporter: {
				hasConsumer: () => reporter?.hasConsumer() ?? __SCHEMA_FORM_DEV__,
				report: (record) => {
					if (load.ready) {
						if (reporter && load.root) reporter.root = load.root;
						reporter?.report(record);
					} else load.records.push(record);
				}
			},
			onChange: (value) => {
				if (load.ready) load.props.onChange?.(value);
			},
			onStateChange: () => {
				if (load.ready && load.root) load.props.onStateChange?.(load.root.globalState);
			}
		});
		if (mount) mountFieldNode(load.root, void 0, void 0, { deferValidation: true });
	} catch (error) {
		load.error = error;
		if (load.root?.diagnostics.cause === "sharedConflict") load.root = void 0;
	}
	return load;
};

//#endregion
//#region src/providers/RootNodeContext/utils/flushRootLoad.ts
const flushRootLoad = (load, errorsOnly = false) => {
	if (load.reporter && load.root) load.reporter.root = load.root;
	if (load.reported) return;
	load.reported = true;
	for (const record of load.records.splice(0)) if (!errorsOnly || record.level === "error") try {
		load.reporter?.report(record);
	} catch (error) {
		reportErrorToHost(error);
	}
	if (load.error) {
		load.reporter?.capture(load.error);
		reportErrorToHost(load.error);
	}
};

//#endregion
//#region src/providers/RootNodeContext/utils/reportRootLoadValidation.ts
const reportRootLoadValidation = (load, store) => {
	const onValidate = load.props.onValidate;
	if (!load.root || !onValidate) return;
	const errors = load.root.globalErrors;
	if (errors === store.lastReportedErrors || !errors.length && store.lastReportedErrors?.length === 0) return;
	store.lastReportedErrors = errors;
	onValidate(errors);
};

//#endregion
//#region src/providers/RootNodeContext/utils/resetRootLoad.ts
const AUTOMATIC_WRITES_MASK = SetValueOption.DisableAutomaticWrites | SetValueOption.EnableAutomaticWrites;
const resetRootLoad = (previous, props, option, rebuild = false) => {
	const loadOption = (option ?? 0) & AUTOMATIC_WRITES_MASK || (props.disableAutomaticWrites ? SetValueOption.DisableAutomaticWrites : SetValueOption.EnableAutomaticWrites);
	previous.reporter?.beginLoad();
	const root = previous.root;
	if (!rebuild && root && previous.props.validator === props.validator && isSameSchema(previous.props.jsonSchema, props.jsonSchema)) {
		previous.props = {
			...props,
			jsonSchema: previous.props.jsonSchema
		};
		previous.error = void 0;
		try {
			root.batch(() => {
				reloadFieldNodeForm(root, clone(props.defaultValue), loadOption);
				applyFormErrors(root, props.errors);
			});
		} catch (error) {
			previous.error = error;
		}
		return previous;
	}
	const next = createRootLoad(props, previous.reporter, false);
	if (!next.root) {
		previous.reporter?.capture(next.error);
		return previous;
	}
	next.ready = previous.ready;
	next.prepared = true;
	const replacement = next.root;
	if (next.reporter) next.reporter.root = replacement;
	const load = () => {
		if (root) adoptFieldNodeTree(root, replacement);
		mountFieldNode(replacement, clone(props.defaultValue), loadOption);
		applyFormErrors(replacement, props.errors);
	};
	try {
		if (root) root.batch(load);
		else load();
	} catch (error) {
		next.error = error;
	}
	for (const record of next.records.splice(0)) next.reporter?.report(record);
	return next;
};

//#endregion
//#region src/providers/RootNodeContext/utils/subscribeRootLoad.ts
const subscribeRootLoad = (load, store) => load.root?.subscribe(({ type }) => {
	if (!load.ready || !load.root) return;
	if (type & 64) reportRootLoadValidation(load, store);
	if (type & 65536) load.props.onDiagnosticsChange?.(load.root.diagnostics);
}) ?? NOOP_FUNCTION;

//#endregion
//#region src/providers/RootNodeContext/components/RootBindingContext.ts
const RootBindingContext = createContext(null);

//#endregion
//#region src/providers/RootNodeContext/components/RootNodeContext.ts
const RootNodeContext = createContext({});

//#endregion
//#region src/providers/RootNodeContext/components/RootNodeContextProvider.tsx
const DEFAULT_VALIDATION_MODE = ValidationMode.OnChange | ValidationMode.OnRequest;
const RootNodeContextProvider = ({ children, binding, onReset, ...props }) => {
	const external = useExternalFormContext();
	const { context, attachedFilesMap } = useWorkspaceContext();
	const reporter = useFormErrorContext();
	const current = {
		...props,
		context,
		validator: props.validatorFactory ?? external.validatorFactory ?? PluginManager.validator,
		validationMode: props.validationMode ?? external.validationMode ?? DEFAULT_VALIDATION_MODE
	};
	const committed = useRef(current);
	const initial = useMemo(() => createRootLoad(current, reporter), []);
	const store = useLazyConstant(() => ({
		load: initial,
		listeners: /* @__PURE__ */ new Set(),
		unsubscribe: NOOP_FUNCTION
	}));
	const subscribe = useMemo(() => (listener) => {
		store.listeners.add(listener);
		return () => {
			store.listeners.delete(listener);
		};
	}, [store]);
	const getSnapshot = useMemo(() => () => store.load, [store]);
	const load = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
	if (reporter) {
		reporter.root = load.root;
		reporter.pendingLoad = () => flushRootLoad(load, true);
	}
	const pending = useRef(void 0);
	const [, schedule] = useState(0);
	const reset = useHandle((option, rebuild = false) => {
		const used = committed.current;
		store.load = resetRootLoad(store.load, used, option, rebuild);
		store.unsubscribe();
		store.unsubscribe = subscribeRootLoad(store.load, store);
		binding.current.root = store.load.root;
		attachedFilesMap.clear();
		onReset();
		pending.current = {
			props: used,
			option
		};
		schedule((version) => version + 1);
		for (const listener of store.listeners) listener();
		try {
			if (store.load.root && !store.load.root.globalErrors.length && store.lastReportedErrors?.length) reportRootLoadValidation(store.load, store);
		} catch (error) {
			throw store.load.error || error;
		}
		if (store.load.error) throw store.load.error;
	});
	const rebuild = useHandle((option) => {
		const schema = committed.current.jsonSchema;
		if (schema !== null && typeof schema === "object") blueprintCacheDomain.invalidate(schema);
		reset(option, true);
	});
	useLayoutEffect(() => {
		const previous = committed.current;
		committed.current = current;
		binding.current = {
			root: store.load.root,
			reset,
			rebuild
		};
		store.load.props = {
			...store.load.props,
			onChange: current.onChange,
			onStateChange: current.onStateChange,
			onValidate: current.onValidate,
			onDiagnosticsChange: current.onDiagnosticsChange
		};
		if (store.load.root && previous.context !== current.context) setContext(store.load.root, context);
		const requested = pending.current;
		pending.current = void 0;
		if (previous.validator !== current.validator) reset(requested?.option);
		else if (requested) {
			const { props: used, option } = requested;
			if (!isSameSchema(used.jsonSchema, current.jsonSchema) || !isSameSchema(used.defaultValue, current.defaultValue) || !isSameSchema(used.errors, current.errors) || used.showError !== current.showError) reset(option);
		}
	});
	useLayoutEffect(() => {
		store.unsubscribe = subscribeRootLoad(load, store);
		load.ready = true;
		const root = load.root;
		const validator = load.props.validator;
		const authored = load.props.jsonSchema;
		if (root && validator) retainValidationRoot(validator, authored);
		if (!load.prepared) {
			load.prepared = true;
			flushRootLoad(load);
			if (root) {
				applyFormErrors(root, load.props.errors);
				if ((load.props.validationMode ?? 0) & ValidationMode.OnChange) root.validate().catch((error) => reporter?.capture(error, void 0, "rejected"));
			}
		}
		return () => {
			load.ready = false;
			store.unsubscribe();
			if (root && validator) releaseValidationRoot(validator, authored);
		};
	}, [
		load,
		reporter,
		store
	]);
	const lastErrors = useRef(props.errors);
	useLayoutEffect(() => {
		if (load.root && lastErrors.current !== props.errors) applyFormErrors(load.root, props.errors, lastErrors.current);
		lastErrors.current = props.errors;
	}, [load, props.errors]);
	if (!load.root) return /* @__PURE__ */ jsx("div", {
		role: "alert",
		children: "Unable to load form."
	});
	return /* @__PURE__ */ jsx(RootBindingContext.Provider, {
		value: binding,
		children: /* @__PURE__ */ jsx(RootNodeContext.Provider, {
			value: load.root,
			children
		})
	});
};

//#endregion
//#region src/providers/RootNodeContext/hooks/useRootNodeContext.ts
const useRootNodeContext = () => useContext(RootNodeContext);

//#endregion
//#region src/providers/RootNodeContext/hooks/useLiveNode.ts
const useLiveNode = (node) => {
	const binding = useContext(RootBindingContext);
	const rootFromContext = useRootNodeContext();
	return useCallback(() => !binding || (binding.current.root ?? rootFromContext).find(node.path) === node, [
		binding,
		rootFromContext,
		node
	]);
};

//#endregion
//#region src/helpers/warning/utils/warnDevelopmentIssue.ts
const emittedWarnings = /* @__PURE__ */ new Set();
const warnDevelopmentIssue = (issue) => {
	if (!__SCHEMA_FORM_DEV__) return;
	const signature = `${issue.code}\n${issue.message}`;
	if (emittedWarnings.has(signature)) return;
	emittedWarnings.add(signature);
	const details = issue.details ?? {};
	printWarning(`[@canard/schema-form] ${issue.code}`, issue.message.split("\n"), isEmptyObject(details) ? void 0 : { details });
};

//#endregion
//#region src/helpers/virtualization/resolveVirtualizationOptions/type.ts
let VirtualizationBackfill = /* @__PURE__ */ function(VirtualizationBackfill) {
	VirtualizationBackfill["None"] = "none";
	VirtualizationBackfill["Idle"] = "idle";
	return VirtualizationBackfill;
}({});

//#endregion
//#region src/helpers/virtualization/resolveVirtualizationOptions/resolveVirtualizationOptions.ts
const DEFAULT_OPTIONS = {
	threshold: 30,
	eagerCount: 20,
	rootMargin: "100%",
	backfill: "idle",
	estimateHeight: 40,
	Placeholder: null
};
const resolveVirtualizationOptions = (input) => {
	if (!input) return null;
	if (input === true) return DEFAULT_OPTIONS;
	return {
		threshold: input.threshold ?? DEFAULT_OPTIONS.threshold,
		eagerCount: input.eagerCount ?? DEFAULT_OPTIONS.eagerCount,
		rootMargin: input.rootMargin ?? DEFAULT_OPTIONS.rootMargin,
		backfill: input.backfill ?? DEFAULT_OPTIONS.backfill,
		estimateHeight: input.estimateHeight ?? DEFAULT_OPTIONS.estimateHeight,
		Placeholder: input.Placeholder ?? DEFAULT_OPTIONS.Placeholder
	};
};

//#endregion
//#region src/helpers/virtualization/VirtualizationManager/utils/formatVirtualizationDisabledWarning.ts
const formatVirtualizationDisabledWarning = () => {
	const divider = createDivider();
	return `
'virtualization' is enabled but IntersectionObserver is unavailable, so it is
disabled. Render-level virtualization is client-side-rendering only.

  ╭${divider}
  │  Requires:  IntersectionObserver (browser only)
  │  Status:    disabled (unavailable in this environment, e.g. SSR)
  ╰${divider}

Enabling it in an SSR/hydration app causes a hydration mismatch: the server
renders every field while the client gates them behind placeholders.

How to fix:
  1. Do not set 'virtualization' in SSR/hydration apps
  2. Or enable it only on the client, after mount (client-side rendering only)
`.trim();
};

//#endregion
//#region src/helpers/virtualization/VirtualizationManager/utils/scheduleIdle.ts
const FALLBACK_BUDGET_MS = 8;
const FALLBACK_DEADLINE = {
	didTimeout: true,
	timeRemaining: () => FALLBACK_BUDGET_MS
};
const scheduleIdle = (callback) => {
	if (typeof requestIdleCallback === "function") {
		const id = requestIdleCallback(callback);
		return () => cancelIdleCallback(id);
	}
	return scheduleCancelableMacrotaskSafe(() => callback(FALLBACK_DEADLINE));
};

//#endregion
//#region src/helpers/virtualization/VirtualizationManager/VirtualizationManager.ts
const MAX_REVEALS_PER_SLICE = 25;
const MIN_IDLE_BUDGET_MS = 4;
var VirtualizationManager = class VirtualizationManager {
	forBranch(childCount) {
		return childCount >= this.options.threshold ? this : null;
	}
	forChild(renderedIndex, node) {
		return renderedIndex >= this.options.eagerCount && !this.revealedNodes.has(node) ? this : null;
	}
	estimateHeight(node) {
		const estimate = this.options.estimateHeight;
		return typeof estimate === "function" ? estimate(node) : estimate;
	}
	register(element, reveal) {
		this.registry.set(element, reveal);
		this.ensureObserver()?.observe(element);
		if (this.options.backfill === "idle") this.ensureIdlePump();
	}
	unregister(element) {
		if (!this.registry.delete(element)) return;
		this.observer?.unobserve(element);
		if (this.registry.size === 0) this.stopIdlePump();
	}
	hasRevealed(node) {
		return this.revealedNodes.has(node);
	}
	markRevealed(node) {
		this.revealedNodes.add(node);
	}
	disconnect() {
		this.stopIdlePump();
		this.observer?.disconnect();
		this.registry.clear();
	}
	reveal(element) {
		const reveal = this.registry.get(element);
		if (reveal === void 0) return;
		this.registry.delete(element);
		this.observer?.unobserve(element);
		if (this.registry.size === 0) this.stopIdlePump();
		reveal();
	}
	ensureObserver() {
		if (this.observer !== null) return this.observer;
		if (typeof IntersectionObserver === "undefined") return null;
		this.observer = new IntersectionObserver(this.handleIntersections, { rootMargin: this.options.rootMargin });
		return this.observer;
	}
	ensureIdlePump() {
		if (this.cancelIdle !== null || this.registry.size === 0) return;
		this.cancelIdle = scheduleIdle(this.idleTick);
	}
	stopIdlePump() {
		if (this.cancelIdle === null) return;
		this.cancelIdle();
		this.cancelIdle = null;
	}
	static create(input) {
		if (typeof IntersectionObserver === "undefined") {
			if (input) warnDevelopmentIssue({
				code: FormWarningCode.VirtualizationDisabledForForm,
				message: formatVirtualizationDisabledWarning()
			});
			return null;
		}
		const options = resolveVirtualizationOptions(input);
		return options === null ? null : new VirtualizationManager(options);
	}
	constructor(options) {
		this.registry = /* @__PURE__ */ new Map();
		this.revealedNodes = /* @__PURE__ */ new WeakSet();
		this.observer = null;
		this.cancelIdle = null;
		this.handleIntersections = (entries) => {
			for (let index = 0, length = entries.length; index < length; index++) {
				const entry = entries[index];
				if (entry.isIntersecting) this.reveal(entry.target);
			}
		};
		this.idleTick = (deadline) => {
			this.cancelIdle = null;
			const iterator = this.registry.keys();
			let reveals = 0;
			while (reveals < MAX_REVEALS_PER_SLICE && this.registry.size > 0 && (deadline.didTimeout || deadline.timeRemaining() > MIN_IDLE_BUDGET_MS)) {
				const next = iterator.next();
				if (next.done) break;
				this.reveal(next.value);
				reveals++;
			}
			if (this.registry.size > 0) this.ensureIdlePump();
		};
		this.options = options;
		this.Placeholder = isReactComponent(options.Placeholder) ? withErrorBoundary(options.Placeholder, void 0, usePlaceholderBoundaryReporter) : null;
	}
};

//#endregion
//#region src/providers/VirtualizationContext/components/VirtualizationContext.ts
const VirtualizationContext = createContext({ manager: null });

//#endregion
//#region src/providers/VirtualizationContext/components/VirtualizationContextProvider.tsx
const VirtualizationContextProvider = ({ virtualization, children }) => {
	const contextValue = useLazyConstant(() => ({ manager: VirtualizationManager.create(virtualization) }));
	const manager = contextValue.manager;
	useEffect(() => {
		if (manager === null) return;
		return () => manager.disconnect();
	}, [manager]);
	return /* @__PURE__ */ jsx(VirtualizationContext.Provider, {
		value: contextValue,
		children
	});
};

//#endregion
//#region src/providers/VirtualizationContext/hooks/useVirtualizationContext.ts
const useVirtualizationContext = () => useContext(VirtualizationContext);

//#endregion
//#region src/hooks/fieldNode/useFieldNode.ts
const useFieldNode = (input) => {
	const rootNode = useRootNodeContext();
	return useMemo(() => {
		if (isFieldNode(input)) return input;
		else return rootNode.find(input);
	}, [input, rootNode]);
};

//#endregion
//#region src/hooks/fieldNode/useFieldNodeTracker.ts
const useFieldNodeTracker = (node, tracking = -1) => {
	const subscribe = useCallback((onStoreChange) => {
		if (node === null) return NOOP_FUNCTION;
		return node.subscribe(({ type }) => {
			if (type & tracking) onStoreChange();
		});
	}, [node, tracking]);
	const getRevision = useCallback(() => node === null ? 0 : node.revision(tracking), [node, tracking]);
	return useSyncExternalStore(subscribe, getRevision, getRevision);
};

//#endregion
//#region src/hooks/fieldNode/useFieldNodeSubscribe.ts
const useFieldNodeSubscribe = (node, listener, options) => {
	const handleListener = useHandle(listener);
	const handleSubscribe = useHandle(options?.onSubscribe);
	useLayoutEffect(() => {
		if (node === null) return;
		const unsubscribe = node.subscribe(handleListener);
		handleSubscribe(node);
		return unsubscribe;
	}, [
		node,
		handleListener,
		handleSubscribe
	]);
};

//#endregion
//#region src/hooks/fieldNode/useChildFieldMap.ts
const CHILD_FIELD_MAP_HANDLER = { get(target, key) {
	return target[key] ?? NOOP_FUNCTION;
} };
const useChildFieldMap = (ChildFields) => useMemo(() => new Proxy(ChildFields.reduce((accumulator, ChildField) => {
	const field = ChildField.field;
	if (field) accumulator[field] = ChildField;
	return accumulator;
}, {}), CHILD_FIELD_MAP_HANDLER), [ChildFields]);

//#endregion
//#region src/hooks/fieldNode/useChildFieldErrors.ts
const CHILD_FIELD_ERROR_EVENTS = 128 | 8 | 2 | 32;
const useChildFieldErrors = (node, disabled) => {
	const { formatError, checkShowError } = useFieldRendererContext();
	const { context } = useWorkspaceContext();
	const children = node.children;
	const subscribe = useCallback((update) => {
		if (disabled) return NOOP_FUNCTION;
		const unsubscribes = [node, ...children ?? []].map((child) => child.subscribe(({ type }) => {
			if (type & CHILD_FIELD_ERROR_EVENTS) update();
		}));
		return () => {
			for (const unsubscribe of unsubscribes) unsubscribe();
		};
	}, [
		node,
		children,
		disabled
	]);
	const snapshot = useCallback(() => [node, ...node.children ?? []].map((child) => child.revision(CHILD_FIELD_ERROR_EVENTS)).join(":"), [node]);
	return useMemo(() => {
		const current = node.children ?? [];
		const errorMatrix = current.map((child) => disabled ? [] : child.errors);
		const formattedErrors = errorMatrix.map((errors, index) => errors.length ? formatError(errors[0], current[index], context) : null);
		const showErrors = current.map((child) => !disabled && checkShowError(child.state));
		const formattedError = formattedErrors.find((message) => message != null) ?? null;
		const showError = !disabled && (checkShowError(node.state) || showErrors.some(Boolean));
		return {
			errorMessage: showError ? formattedError : null,
			showError,
			formattedError,
			showErrors,
			formattedErrors,
			errorMatrix
		};
	}, [
		node,
		disabled,
		useSyncExternalStore(subscribe, snapshot, snapshot),
		formatError,
		checkShowError,
		context
	]);
};

//#endregion
//#region src/hooks/form/useFormSubmit.ts
const useFormSubmit = (ref) => {
	const [subscribe, getSnapshot] = useMemo(() => [(onStoreChange) => ref.current?.submit?.subscribe?.(onStoreChange) || NOOP_FUNCTION, () => ref?.current?.submit?.pending], [ref]);
	const pending = useSyncExternalStore(subscribe, getSnapshot);
	const submit = useCallback(() => {
		const handler = ref.current?.submit;
		if (!handler) return Promise.resolve(void 0);
		return handler();
	}, [ref]);
	return useMemo(() => ({
		submit,
		pending
	}), [pending, submit]);
};

//#endregion
//#region src/components/Form/components/FormCore/components/FormChildrenRenderer.tsx
const RERENDERING_EVENT$1 = 4 | 64 | 8192 | 16384;
const FormChildrenRendererInner = ({ jsonSchema, render }) => {
	const rootNode = useRootNodeContext();
	useFieldNodeTracker(rootNode ?? null, RERENDERING_EVENT$1);
	return /* @__PURE__ */ jsx(Fragment, { children: render({
		jsonSchema,
		node: rootNode,
		defaultValue: rootNode?.defaultValue,
		value: rootNode?.value,
		errors: rootNode?.globalErrors || void 0
	}) });
};
const FormChildrenRenderer = memo(FormChildrenRendererInner);

//#endregion
//#region src/components/Form/components/FormCore/utils/createChildren.ts
const createChildren = (children, jsonSchema) => {
	if (children == null) return null;
	if (typeof children !== "function") return children;
	return createElement(FormChildrenRenderer, {
		jsonSchema,
		render: children
	});
};

//#endregion
//#region src/components/Form/components/FormCore/utils/submitForm.ts
const submitForm = async (root, onSubmit, onFailure) => {
	if (!root) return;
	let value;
	try {
		if (root.diagnostics.status === "degraded") throw new SchemaFormError(FormErrorCode.SubmitWhileDegraded, "Cannot submit a degraded form", { diagnostics: root.diagnostics });
		value = root.outputValue;
		const errors = await root.validate();
		if (errors.length) throw new ValidationError(FormErrorCode.SchemaValidationFailed, "Schema validation failed", {
			value,
			errors,
			jsonSchema: root.jsonSchema
		});
	} catch (error) {
		if (!(error instanceof ValidationError)) onFailure?.(error);
		throw error;
	}
	await onSubmit?.(value);
};

//#endregion
//#region src/constants/style.ts
const DISPLAY_CONTENT = { display: "contents" };
const NONE_ROLE = "none";

//#endregion
//#region src/components/FieldProxy/components/DeferredFieldProxy/DeferredFieldProxy.tsx
const FORCE_REVEAL_EVENT = 2048 | 4096;
const DEFERRED_TRACKING_EVENTS = 256 | 2;
const DeferredFieldProxy = ({ manager, NodeProxy, ...proxyProps }) => {
	const node = proxyProps.node;
	const [revealed, setRevealed] = useState(() => manager.hasRevealed(node));
	const pendingEventsRef = useRef(0);
	const placeholderRef = useRef(null);
	useFieldNodeTracker(node, DEFERRED_TRACKING_EVENTS);
	useFieldNodeSubscribe(revealed ? null : node, ({ type }) => {
		const forced = type & FORCE_REVEAL_EVENT;
		if (!forced) return;
		pendingEventsRef.current |= forced;
		setRevealed(true);
	});
	useLayoutEffect(() => {
		if (!revealed) return;
		manager.markRevealed(node);
		const pending = pendingEventsRef.current;
		if (pending === 0) return;
		pendingEventsRef.current = 0;
		if (pending & 2048) node.request(FieldNodeRequestType.Focus);
		if (pending & 4096) node.request(FieldNodeRequestType.Select);
	}, [
		revealed,
		manager,
		node
	]);
	const handlePlaceholder = useCallback((element) => {
		const previous = placeholderRef.current;
		if (previous !== null) manager.unregister(previous);
		placeholderRef.current = element;
		if (element !== null) manager.register(element, () => setRevealed(true));
	}, [manager]);
	useLayoutEffect(() => {
		const element = placeholderRef.current;
		if (element === null) return;
		manager.register(element, () => setRevealed(true));
		return () => manager.unregister(element);
	}, [
		manager,
		revealed,
		node.enabled
	]);
	if (!node.enabled) return null;
	if (revealed) return /* @__PURE__ */ jsx(NodeProxy, { ...proxyProps });
	const Placeholder = manager.Placeholder;
	const height = manager.estimateHeight(node);
	return /* @__PURE__ */ jsx("div", {
		ref: handlePlaceholder,
		"data-path": node.path,
		"data-deferred": true,
		"aria-hidden": true,
		style: { height },
		children: Placeholder !== null && /* @__PURE__ */ jsx(FormErrorPathContext.Provider, {
			value: node.path,
			children: /* @__PURE__ */ jsx(Placeholder, {
				node,
				height
			})
		})
	});
};

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/hooks/useChildFields.tsx
const useChildFields = (node, NodeProxy, mountedChildren, terminalChildren) => {
	const children = node.children;
	const { manager } = useVirtualizationContext();
	const cache = useLazyConstant(() => /* @__PURE__ */ new Map());
	useOnUnmount(() => cache.clear());
	return useMemo(() => {
		if (isTerminalNode(node) || children === null) return terminalChildren;
		const gateManager = manager?.forBranch(children.length) ?? null;
		const ChildFields = [];
		for (const node of children) {
			const key = String(cache.size);
			const CachedComponent = cache.get(node);
			if (CachedComponent) {
				CachedComponent.path = node.path;
				CachedComponent.field = node.name;
				ChildFields.push(CachedComponent);
			} else {
				const deferredManager = gateManager?.forChild(ChildFields.length, node) ?? null;
				const ChildComponent = memo(({ FieldRenderer: InputFieldRenderer, onChange, onFileAttach, ...restProps }) => {
					useLayoutEffect(() => {
						mountedChildren.current++;
						return () => {
							mountedChildren.current--;
						};
					}, []);
					const onChangeRef = useReference(onChange);
					const onFileAttachRef = useReference(onFileAttach);
					const overridePropsRef = useReference(restProps);
					const FieldRenderer = useConstant(InputFieldRenderer);
					return deferredManager !== null ? /* @__PURE__ */ jsx(DeferredFieldProxy, {
						node,
						manager: deferredManager,
						NodeProxy,
						onChangeRef,
						onFileAttachRef,
						overridePropsRef,
						FieldRenderer
					}) : /* @__PURE__ */ jsx(NodeProxy, {
						node,
						onChangeRef,
						onFileAttachRef,
						overridePropsRef,
						FieldRenderer
					});
				});
				ChildComponent.key = key;
				ChildComponent.path = node.path;
				ChildComponent.field = node.name;
				cache.set(node, ChildComponent);
				ChildFields.push(ChildComponent);
			}
		}
		return ChildFields;
	}, [
		node,
		children,
		NodeProxy,
		manager,
		cache,
		terminalChildren,
		mountedChildren
	]);
};

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/hooks/useFieldInput.ts
const useFieldInput = (node, disabled) => {
	const { fromFieldInputMap, fromFieldInputDefinitions } = useFieldInputsContext();
	const { fromExternalFieldInputDefinitions } = useExternalFormContext();
	const schema = node.jsonSchema;
	const path = node.path;
	const inline = schema.presentation?.FieldInput;
	const Inline = useMemo(() => isReactComponent(inline) ? withFieldInputErrorBoundary(inline) : null, [inline]);
	return useMemo(() => {
		if (disabled || inline === null) return null;
		if (Inline) return Inline;
		const hint = {
			type: node.type,
			schemaType: node.schemaType,
			misfit: node.misfit,
			path,
			required: node.required,
			nullable: node.nullable,
			jsonSchema: schema,
			format: typeof schema.format === "string" ? schema.format : void 0,
			inputType: typeof schema.presentation?.inputType === "string" ? schema.presentation.inputType : void 0
		};
		for (const definitions of [
			fromFieldInputMap,
			fromFieldInputDefinitions,
			fromExternalFieldInputDefinitions,
			PluginManager.fieldInputDefinitions
		]) for (const { test, Component } of definitions ?? []) if (test(hint)) return Component;
		return null;
	}, [
		node,
		schema,
		path,
		disabled,
		inline,
		Inline,
		fromFieldInputMap,
		fromFieldInputDefinitions,
		fromExternalFieldInputDefinitions
	]);
};

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/type.ts
const REACTIVE_RERENDERING_EVENTS = 4 | 8 | 32 | 256 | 32768 | 2;

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/hooks/useFieldInputControl.ts
const INPUT_TRACKING_EVENTS = REACTIVE_RERENDERING_EVENTS | 128 | 8192;
const INPUT_TRACKING_EVENTS_WITHOUT_REFRESH = INPUT_TRACKING_EVENTS & ~8192;
const COMPOSING = 1;
const CLEAR_COMPOSING_MASK = -2;
const MOUNTED_CHILDREN = 2;
const useFieldInputControl = (node, mountedChildren, commitTerminalChildren) => {
	const generation = useRef(node.revision(8192));
	const [, releaseComposition] = useReducer((value) => value + 1, 0);
	const ref = useRef(null);
	const refreshDeferral = useRef(0);
	refreshDeferral.current = refreshDeferral.current & COMPOSING | (mountedChildren.current > 0 ? MOUNTED_CHILDREN : 0);
	const subscribe = useCallback((onStoreChange) => {
		refreshDeferral.current = refreshDeferral.current & COMPOSING | (mountedChildren.current > 0 ? MOUNTED_CHILDREN : 0);
		return node.subscribe(({ type }) => {
			if (!(type & INPUT_TRACKING_EVENTS)) return;
			refreshDeferral.current = refreshDeferral.current & COMPOSING | (mountedChildren.current > 0 ? MOUNTED_CHILDREN : 0);
			onStoreChange();
		});
	}, [node, mountedChildren]);
	const getRevision = useCallback(() => {
		if (refreshDeferral.current === 0) return node.revision(INPUT_TRACKING_EVENTS);
		return node.revision(INPUT_TRACKING_EVENTS_WITHOUT_REFRESH) + generation.current;
	}, [node]);
	useSyncExternalStore(subscribe, getRevision, getRevision);
	if (refreshDeferral.current === 0) generation.current = node.revision(8192);
	const handleCompositionStart = useCallback(() => {
		refreshDeferral.current |= COMPOSING;
	}, []);
	const handleCompositionEnd = useCallback(() => {
		refreshDeferral.current &= CLEAR_COMPOSING_MASK;
		if (mountedChildren.current === 0 && generation.current !== node.revision(8192)) releaseComposition();
	}, [node, mountedChildren]);
	useLayoutEffect(() => {
		commitTerminalChildren();
		if (!node) return;
		return node.subscribe(({ type }) => {
			if (type & 2048) queryElement(ref.current)?.focus();
			if (type & 4096) {
				const element = queryElement(ref.current);
				if (element && typeof element.select === "function") element.select();
			}
		});
	}, [
		node,
		ref,
		commitTerminalChildren
	]);
	return [
		ref,
		generation.current,
		handleCompositionStart,
		handleCompositionEnd
	];
};
const FOCUS_SELECT_SELECTOR = "input, textarea, button";
const queryElement = (container) => {
	if (!container) return null;
	return container.querySelector(FOCUS_SELECT_SELECTOR) ?? null;
};

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/hooks/utils/isDetectableTerminal.ts
const isDetectableTerminal = (node) => node.strategy === "terminal" && (node.type === "object" || node.type === "array");

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/hooks/useTerminalChildren.ts
const NUMERIC_KEY = /^\d+$/;
const EMPTY_CHILDREN = Object.freeze([]);
const COMMITTED = 1;
const ACCESSED = 2;
const CLEAR_ACCESSED_MASK = -3;
const UNDETECTED = [EMPTY_CHILDREN, () => {}];
Object.freeze(UNDETECTED);
const useTerminalChildren = (node) => {
	const reporter = useFormErrorContext();
	const accessed = useRef(0);
	return useMemo(() => {
		accessed.current = 0;
		if (__SCHEMA_FORM_DEV__ && reporter && isDetectableTerminal(node)) {
			let readLoad = reporter.load;
			const get = (target = EMPTY_CHILDREN, key, receiver) => {
				if (readLoad !== reporter.load) {
					readLoad = reporter.load;
					accessed.current &= CLEAR_ACCESSED_MASK;
				}
				if (key === void 0) {
					reporter.report({
						level: "warning",
						code: FormWarningCode.ChildNodeComponentsOnTerminal,
						message: "Terminal inputs have no child components",
						path: node.path
					});
					return;
				}
				if (!(accessed.current & ACCESSED) && (key === "length" || key === Symbol.iterator || typeof key === "string" && NUMERIC_KEY.test(key))) {
					accessed.current |= ACCESSED;
					if (accessed.current & COMMITTED) queueMicrotask(get);
				}
				return Reflect.get(target, key, receiver);
			};
			const commit = () => {
				accessed.current |= COMMITTED;
				if (accessed.current & ACCESSED) reporter.report({
					level: "warning",
					code: FormWarningCode.ChildNodeComponentsOnTerminal,
					message: "Terminal inputs have no child components",
					path: node.path
				});
			};
			return [new Proxy(EMPTY_CHILDREN, { get }), commit];
		}
		return UNDETECTED;
	}, [node, reporter]);
};

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/FieldInputSlot.tsx
const DIRTY_STATE_PATCH = { 1: true };
const TOUCHED_STATE_PATCH = { 2: true };
const FieldInputSlot = memo(({ node, onChangeRef, onFileAttachRef, overrideProps, PreferredFieldInput, NodeProxy }) => {
	const selected = useFieldInput(node, PreferredFieldInput !== null);
	const FieldInput = PreferredFieldInput || selected;
	const mountedChildren = useRef(0);
	const [terminalChildren, commitTerminalChildren] = useTerminalChildren(node);
	const ChildFields = useChildFields(node, NodeProxy, mountedChildren, terminalChildren);
	const { checkShowError } = useFieldRendererContext();
	const { attachedFilesMap, context } = useWorkspaceContext();
	const { readOnly: rootReadOnly, disabled: rootDisabled } = useInputControlContext();
	const isLive = useLiveNode(node);
	const [ref, generation, handleCompositionStart, handleCompositionEnd] = useFieldInputControl(node, mountedChildren, commitTerminalChildren);
	const defaultValue = useMemorize(() => node.value, [node, generation]);
	const accepts = useCallback(() => isLive() && (mountedChildren.current > 0 || generation === node.revision(8192)), [
		node,
		generation,
		isLive
	]);
	const handleChange = useCallback((input, option = SetValueOption.Overwrite) => {
		if (!accepts() || rootReadOnly || rootDisabled || node.readOnly || node.disabled) return;
		if (!onChangeRef.current) writeFieldNodeInput(node, input, option);
		else node.batch(() => {
			onChangeRef.current(input, option);
			node.clearExternalErrors();
			node.setState(DIRTY_STATE_PATCH);
		});
	}, [
		accepts,
		rootReadOnly,
		rootDisabled,
		node,
		onChangeRef
	]);
	const handleFileAttach = useCallback((files) => {
		if (!accepts()) return;
		if (onFileAttachRef.current) return onFileAttachRef.current(files);
		if (files === void 0) attachedFilesMap.delete(node.path);
		else attachedFilesMap.set(node.path, isArray(files) ? files : [files]);
	}, [
		accepts,
		node,
		onFileAttachRef,
		attachedFilesMap
	]);
	const requestId = useRef(void 0);
	const handleFocus = useCallback(() => {
		if (requestId.current !== void 0) cancelAnimationFrame(requestId.current);
		requestId.current = void 0;
	}, []);
	const handleBlur = useCallback(() => {
		if (!accepts()) return;
		const reset = readFieldNodeInteractionReset(node);
		finishFieldNodeInput(node);
		if (node.state[2]) return;
		requestId.current = requestAnimationFrame(() => {
			if (isLive() && reset === readFieldNodeInteractionReset(node) && !node.state[2]) node.setState(TOUCHED_STATE_PATCH);
		});
	}, [
		accepts,
		isLive,
		node
	]);
	useOnUnmount(() => {
		attachedFilesMap.delete(node.path);
		if (requestId.current !== void 0) cancelAnimationFrame(requestId.current);
	});
	if (!FieldInput) return null;
	return /* @__PURE__ */ jsx("div", {
		ref,
		role: NONE_ROLE,
		style: DISPLAY_CONTENT,
		onFocus: handleFocus,
		onBlur: handleBlur,
		onCompositionStartCapture: handleCompositionStart,
		onCompositionEnd: handleCompositionEnd,
		children: /* @__PURE__ */ jsx(FieldInput, {
			required: node.required,
			placeholder: void 0,
			style: void 0,
			className: void 0,
			...node.jsonSchema.presentation?.FieldInputProps,
			defaultValue,
			value: node.value,
			onChange: handleChange,
			onFileAttach: handleFileAttach,
			...overrideProps,
			readOnly: rootReadOnly || node.readOnly || !!overrideProps.readOnly,
			disabled: rootDisabled || node.disabled || !!overrideProps.disabled,
			inputGeneration: generation,
			jsonSchema: node.jsonSchema,
			node,
			type: node.type,
			schemaType: node.schemaType,
			misfit: node.misfit,
			name: node.name,
			path: node.path,
			nullable: node.nullable,
			errors: node.errors,
			errorVisible: checkShowError(node.state),
			watchValues: node.watchValues,
			ChildFields,
			context
		})
	});
});

//#endregion
//#region src/components/FieldProxy/components/FieldInputSlot/components/FieldInputSlotWrapper.tsx
const FieldInputSlotWrapper = (node, overrideOnChangeRef, overrideOnFileAttachRef, overrideFieldInputPropsRef, OverridePreferredFieldInput, NodeProxy) => {
	if (!node) return NULL_FUNCTION;
	return ({ onChange: preferredOnChange, onFileAttach: preferredOnFileAttach, ...preferredOverrideProps }) => {
		return /* @__PURE__ */ jsx(FieldInputSlot, {
			node,
			onChangeRef: useReference(preferredOnChange || overrideOnChangeRef?.current),
			onFileAttachRef: useReference(preferredOnFileAttach || overrideOnFileAttachRef?.current),
			overrideProps: useSnapshot({
				...overrideFieldInputPropsRef?.current,
				...preferredOverrideProps
			}),
			PreferredFieldInput: useLazyConstant(() => OverridePreferredFieldInput && isReactComponent(OverridePreferredFieldInput) ? isMemoComponent(OverridePreferredFieldInput) ? withFieldInputErrorBoundary(OverridePreferredFieldInput) : memo(withFieldInputErrorBoundary(OverridePreferredFieldInput)) : null),
			NodeProxy
		});
	};
};

//#endregion
//#region src/components/FieldProxy/FieldProxy.tsx
const RERENDERING_EVENT = 4 | 8 | 32 | 256 | 32768 | 2;
const FieldProxy = ({ path, node: inputNode, onChangeRef, onFileAttachRef, overridePropsRef, FieldInput, FieldRenderer: InputFieldRenderer, Wrapper: InputWrapper }) => {
	const node = useFieldNode(inputNode || path);
	const refreshRef = useReference(useFieldNodeTracker(node, RERENDERING_EVENT));
	const onError = useBoundaryReporter(node?.path);
	const Input = useMemo(() => FieldInputSlotWrapper(node, onChangeRef, onFileAttachRef, overridePropsRef, FieldInput, FieldProxy), [
		node,
		onChangeRef,
		onFileAttachRef,
		overridePropsRef,
		FieldInput
	]);
	const { FieldRenderer: ContextFieldRenderer, formatError: contextFormatError, checkShowError } = useFieldRendererContext();
	const FieldRenderer = useLazyConstant(() => {
		const Component = InputFieldRenderer || ContextFieldRenderer;
		const Renderer = isMemoComponent(Component) ? Component : memo(Component);
		return function RendererWithErrorMessage(props) {
			const { node, context, formatError } = props;
			const errorMessage = useMemo(() => {
				const errors = node.errors;
				if (!errors) return null;
				for (let index = 0; index < errors.length; index++) {
					const message = formatError(errors[index], node, context);
					if (message !== null) return message;
				}
				return null;
			}, [
				node,
				refreshRef.current,
				context,
				formatError
			]);
			return /* @__PURE__ */ jsx(Renderer, {
				...props,
				errorMessage
			});
		};
	});
	const Wrapper = useConstant(InputWrapper || Fragment$1);
	const { context } = useWorkspaceContext();
	const errorVisible = checkShowError(node?.state);
	const formatError = errorVisible ? contextFormatError : NULL_FUNCTION;
	const version = useFieldNodeTracker(node, 16384);
	if (!node?.enabled) return null;
	return /* @__PURE__ */ jsx(Wrapper, { children: /* @__PURE__ */ jsx("div", {
		"data-path": node.path,
		role: NONE_ROLE,
		style: DISPLAY_CONTENT,
		children: /* @__PURE__ */ jsx(ErrorBoundary, {
			onError,
			children: /* @__PURE__ */ jsx(FieldRenderer, {
				...node.jsonSchema.presentation?.FieldRendererProps,
				...overridePropsRef?.current,
				node,
				type: node.type,
				jsonSchema: node.jsonSchema,
				isRoot: node.isRoot,
				depth: node.depth,
				path: node.path,
				name: node.name,
				value: node.value,
				errors: node.errors,
				required: node.required,
				Input,
				errorVisible,
				formatError,
				context
			})
		})
	}) }, version);
};

//#endregion
//#region src/components/Form/components/FormCore/components/FormRootProxy.tsx
const FormRootProxy = memo(({ onSubmit, children }) => /* @__PURE__ */ jsx("form", {
	onSubmit,
	children: children || /* @__PURE__ */ jsx(FieldProxy, {})
}));

//#endregion
//#region src/components/Form/components/FormCore/components/FormRoot.tsx
const FormRoot = (props, ref) => {
	const binding = useLazyConstant(() => ({ current: {
		reset: NOOP_FUNCTION,
		rebuild: NOOP_FUNCTION
	} }));
	const attachedFilesMap = useLazyConstant(() => /* @__PURE__ */ new Map());
	const reporter = useFormErrorContext();
	const [showError, setShowError] = useState(props.showError);
	const onReset = useHandle(() => setShowError(props.showError));
	const submit = useHandle((native = false) => submitForm(binding.current.root, props.onSubmit, native ? (error) => reporter?.capture(error) : void 0));
	const handleSubmit = useMemo(() => getTrackableHandler(submit), [submit]);
	const handleNativeSubmit = useCallback(async (event) => {
		event.preventDefault();
		try {
			await handleSubmit(true);
		} catch (error) {
			reportErrorToHost(error);
		}
	}, [handleSubmit]);
	useImperativeHandle(ref, () => ({
		get node() {
			return binding.current.root;
		},
		focus: (path) => binding.current.root?.find(path)?.request(FieldNodeRequestType.Focus),
		select: (path) => binding.current.root?.find(path)?.request(FieldNodeRequestType.Select),
		refresh: (path) => binding.current.root?.find(path)?.request(FieldNodeRequestType.Refresh),
		remount: (path) => binding.current.root?.find(path)?.request(FieldNodeRequestType.Remount),
		reset: (option) => binding.current.reset(option),
		rebuild: (option) => binding.current.rebuild(option),
		findNode: (path) => binding.current.root?.find(path) ?? null,
		findNodes: (path) => binding.current.root?.findNodes(path) ?? [],
		getState: () => binding.current.root?.globalState ?? {},
		setState: (state) => binding.current.root?.setSubtreeState(state),
		clearState: () => binding.current.root?.clearSubtreeState(),
		getValue: () => binding.current.root?.outputValue,
		setValue: (value, options) => binding.current.root?.setValue(value, options),
		getErrors: () => binding.current.root?.globalErrors ?? [],
		getAttachedFilesMap: () => attachedFilesMap,
		validate: async () => await binding.current.root?.validate() ?? [],
		showError: (visible = true) => setShowError(visible ? true : props.showError),
		submit: handleSubmit
	}), [
		attachedFilesMap,
		binding,
		handleSubmit,
		props.showError
	]);
	const children = useMemo(() => createChildren(props.children, props.jsonSchema), [props.children, props.jsonSchema]);
	return /* @__PURE__ */ jsx(WorkspaceContextProvider, {
		attachedFilesMap,
		context: props.context,
		children: /* @__PURE__ */ jsx(FieldInputsContextProvider, {
			fieldInputDefinitions: props.fieldInputDefinitions,
			fieldInputMap: props.fieldInputMap,
			children: /* @__PURE__ */ jsx(FieldRendererContextProvider, {
				FieldRenderer: props.FieldRenderer,
				FormLabelRenderer: props.FormLabelRenderer,
				FormInputRenderer: props.FormInputRenderer,
				FormErrorRenderer: props.FormErrorRenderer,
				formatError: props.formatError,
				showError,
				children: /* @__PURE__ */ jsx(InputControlContextProvider, {
					readOnly: props.readOnly,
					disabled: props.disabled,
					children: /* @__PURE__ */ jsx(VirtualizationContextProvider, {
						virtualization: props.virtualization,
						children: /* @__PURE__ */ jsx(RootNodeContextProvider, {
							...props,
							binding,
							onReset,
							children: /* @__PURE__ */ jsx(FormRootProxy, {
								onSubmit: handleNativeSubmit,
								children
							})
						})
					})
				})
			})
		})
	});
};

//#endregion
//#region src/components/Form/components/FormCore/FormCore.tsx
const ErrorBoundedFormRoot = withErrorBoundaryForwardRef(forwardRef(FormRoot), void 0, useBoundaryReporter);
const FormCore = memo(forwardRef((props, ref) => /* @__PURE__ */ jsx(FormErrorContextProvider, {
	onError: props.onError,
	children: /* @__PURE__ */ jsx(ErrorBoundedFormRoot, {
		...props,
		ref
	})
})));

//#endregion
//#region src/components/Form/components/FormError/FormError.tsx
const FormError = memo(({ path, style, className }) => {
	const { FormErrorRenderer } = useFieldRendererContext();
	return /* @__PURE__ */ jsx("span", {
		style,
		className,
		children: /* @__PURE__ */ jsx(FieldProxy, {
			path,
			FieldRenderer: FormErrorRenderer || PluginManager.FormErrorRenderer
		})
	});
});

//#endregion
//#region src/components/Form/components/FormField/FormField.tsx
const FormField = memo(({ path, FieldInput, FieldRenderer, Wrapper, ...restProps }) => {
	const overridePropsRef = useReference(restProps);
	const constant = useConstant({
		FieldInput,
		FieldRenderer,
		Wrapper
	});
	return /* @__PURE__ */ jsx(FieldProxy, {
		path,
		overridePropsRef,
		FieldInput: constant.FieldInput,
		FieldRenderer: constant.FieldRenderer,
		Wrapper: constant.Wrapper
	});
});

//#endregion
//#region src/components/Form/components/FormInput/FormInput.tsx
const FormInput = memo(({ path, FieldInput: InputFieldInput, ...restProps }) => {
	const { FormInputRenderer } = useFieldRendererContext();
	return /* @__PURE__ */ jsx(FieldProxy, {
		path,
		overridePropsRef: useReference(restProps),
		FieldInput: useConstant(InputFieldInput),
		FieldRenderer: FormInputRenderer || PluginManager.FormInputRenderer
	});
});

//#endregion
//#region src/components/Form/components/FormLabel/FormLabel.tsx
const FormLabel = memo(({ path, style, className }) => {
	const { FormLabelRenderer } = useFieldRendererContext();
	return /* @__PURE__ */ jsx("label", {
		style,
		className,
		htmlFor: path,
		id: path !== void 0 ? "label:" + path : void 0,
		children: /* @__PURE__ */ jsx(FieldProxy, {
			path,
			FieldRenderer: FormLabelRenderer || PluginManager.FormLabelRenderer
		})
	});
});

//#endregion
//#region src/components/Form/components/FormRender/FormRender.tsx
const FormRender = memo(({ path, FieldInput, Wrapper, children, ...restProps }) => {
	const overridePropsRef = useReference(restProps);
	const constant = useConstant({
		FieldInput,
		FieldRenderer: children,
		Wrapper
	});
	return /* @__PURE__ */ jsx(FieldProxy, {
		path,
		overridePropsRef,
		FieldInput: constant.FieldInput,
		FieldRenderer: constant.FieldRenderer,
		Wrapper: constant.Wrapper
	});
});

//#endregion
//#region src/components/Form/Form.tsx
const Form = Object.assign(FormCore, {
	Render: FormRender,
	Field: FormField,
	Label: FormLabel,
	Input: FormInput,
	Error: FormError
});

//#endregion
export { FieldNodeEventType, FieldNodeRequestType, FieldNodeState, Form, FormErrorCode, ExternalFormContextProvider as FormProvider, FormWarningCode, JSONPointer, SetValueOption, ShowError, ValidationMode, VirtualizationBackfill, isArrayNode, isBooleanNode, isBranchNode, isFieldNode, isJSONSchemaError, isNumberNode, isObjectNode, isSchemaFormError, isStringNode, isTerminalNode, isUnhandledError, isUnionNode, isValidationError, isVirtualNode, registerPlugin, useChildFieldErrors, useChildFieldMap, useFieldNodeSubscribe, useFieldNodeTracker, useFormSubmit };
export { blueprint, fieldNodeFactory, PathKeyedMap, PathKeyedSet, mountFieldNode, writeFieldNodeInput, getControlLayers, readExitLayerPolicy };
