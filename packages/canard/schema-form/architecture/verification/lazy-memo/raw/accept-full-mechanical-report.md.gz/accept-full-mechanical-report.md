# Lazy B acceptance measurement record

## Quiet check

File: `<scratch>/lazy-b-accept-measure/quiet-1.txt`

Second sample:

```
Processes: 1021 total, 3 running, 1018 sleeping, 4986 threads 
2026/11/02 19:32:54
Load Avg: 1.93, 2.68, 4.19 
CPU usage: 1.96% user, 3.75% sys, 94.28% idle 
SharedLibs: 1305M resident, 213M data, 382M linkedit.
MemRegions: 0 total, 0B resident, 859M private, 7374M shared.
PhysMem: 53G used (3978M wired, 5146M compressor), 10G unused.
VM: 485T vsize, 57G framework vsize, 0(0) swapins, 0(0) swapouts.
Networks: packets: 115001550/88G in, 92839749/56G out.
Disks: 112631077/1104G read, 111503541/1359G written.

PID    COMMAND          %CPU
50254  top              10.9
436    WindowServer     10.6
1056   Stats            4.6 
81982  2.1.312          3.1 
650    ControlCenter    2.7 
0      kernel_task      2.1 
80848  orca-terminal-ho 1.8 
60507  node             1.6 
```

## Attempts

- Command: `python3 <scratch>/lazy-b/impl/accept/run.py --full`
- Attempt: 1
- Exit code: 0
- Duration seconds: 97.282099
- Start epoch: 1793615597.277049
- End epoch: 1793615694.559148
- Output log: `<scratch>/lazy-b-accept-measure/attempt-1.log`

Last 20 lines:

```
{"path": "<scratch>/lazy-b/impl/accept/full/w4-merged-baseline-attempt1.json", "exitCode": 0, "seconds": 38.625648975372314, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w4-merged-candidate-attempt1.json", "exitCode": 0, "seconds": 4.320864200592041, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w4-merged-control-attempt1.json", "exitCode": 0, "seconds": 38.9247407913208, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w4-single-control-attempt1.json", "exitCode": 0, "seconds": 2.765601873397827, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w4-single-candidate-attempt1.json", "exitCode": 0, "seconds": 2.7708232402801514, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w4-single-baseline-attempt1.json", "exitCode": 0, "seconds": 2.774301052093506, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-all-baseline-attempt1.json", "exitCode": 0, "seconds": 1.5342979431152344, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-all-candidate-attempt1.json", "exitCode": 0, "seconds": 0.6125011444091797, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-all-control-attempt1.json", "exitCode": 0, "seconds": 1.5228521823883057, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-single-control-attempt1.json", "exitCode": 0, "seconds": 0.6122429370880127, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-single-candidate-attempt1.json", "exitCode": 0, "seconds": 0.30072593688964844, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-single-baseline-attempt1.json", "exitCode": 0, "seconds": 0.6101460456848145, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-cold-baseline-attempt1.json", "exitCode": 0, "seconds": 0.29898691177368164, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-cold-candidate-attempt1.json", "exitCode": 0, "seconds": 0.30637192726135254, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/impl/accept/full/w1-cold-control-attempt1.json", "exitCode": 0, "seconds": 0.3070662021636963, "competitorsBefore": [], "competitorsDuring": []}
{"mode": "full", "processes": 15, "seconds": 96.28717136383057}
```

## Result paths

- `<scratch>/lazy-b/impl/accept/full/run-status.json`
- `<scratch>/lazy-b/impl/accept/full/summary.json`

## summary.json

Source: `<scratch>/lazy-b/impl/accept/full/summary.json`

| field | value |
| --- | --- |
| mode | full |

| field | value |
| --- | --- |
| control | abs(control-baseline) <= max(0.3 ms, 3% baseline median); invalid rerun once, invalid again void |
| main | saving >= 1 ms and >= 10%, strictly > twice control gap |
| auxiliary | regression <= max(0.05 ms, 5% baseline median) |
| w1SingleUnit | one sample times 200 single-child waves, divide elapsed by 200 |

| field | value |
| --- | --- |
| W4 | ACCEPT |
| W1 | ACCEPT |

| cell | attempt | baseline.median | baseline.p95 | candidate.median | candidate.p95 | control.median | control.p95 | controlGap | controlBand | controlValid | void | savingMs | savingFraction | savingPass | regressionLimitMs | regressionPass | main |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| w4-merged | 1 | 478.0415209999992 | 497.3909580000036 | 1.6791665000000648 | 1.8189159999999447 | 482.84856249999984 | 497.20950000000084 | 4.807041500000651 | 14.341245629999975 | true | false | 476.3623544999991 | 0.99648740449054 | true | 23.902076049999962 | true | true |
| w4-single | 1 | 0.6905420000000504 | 0.7301669999999376 | 0.7223539999999957 | 0.771874999999909 | 0.6880419999999958 | 0.7350000000000136 | 0.0025000000000545697 | 0.3 | true | false | -0.03181199999994533 | -0.0460681609517495 | false | 0.05 | true | false |
| w1-all | 1 | 14.164479000000028 | 14.903125000000045 | 0.06118700000000388 | 0.13150000000000261 | 13.969645499999956 | 14.790290999999996 | 0.1948335000000725 | 0.42493437000000084 | true | false | 14.103292000000025 | 0.9956802505761063 | true | 0.7082239500000015 | true | true |
| w1-single | 1 | 0.014331457500000012 | 0.015880835000000103 | 5.3332499999996224e-05 | 6.687499999998181e-05 | 0.014224584999999977 | 0.01605812499999999 | 0.00010687250000003534 | 0.3 | true | false | 0.014278125000000016 | 0.9962786408849208 | false | 0.05 | true | false |
| w1-cold | 1 | 0.019187500000001023 | 0.021041999999994232 | 0.019708500000007234 | 0.02174999999999727 | 0.01991650000000078 | 0.022333000000003267 | 0.0007289999999997576 | 0.3 | true | false | -0.0005210000000062109 | -0.027153094462862966 | false | 0.05 | true | false |
