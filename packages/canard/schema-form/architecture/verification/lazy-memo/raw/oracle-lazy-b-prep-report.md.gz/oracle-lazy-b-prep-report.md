# Follow-up B preparation report

Prepared on 2026-11-02 at repository HEAD `55055f65b52f952cd934eeec641314171e1ff253`.
Amendment 1 controls this report. Preparation is complete: fixtures, the full W5 bypass, the W2 context-identity witness, direct probes, all pilot cells, call-count checks and the sequential full-run script are present. **No full matrix was run; no repository file, commit or ref was changed.** These pilot measurements establish harness operation only, not a candidate decision.

## Re-verified code facts

Paths below are relative to `packages/canard/schema-form/` at the assigned SHA; these were read in this worktree rather than accepted from the survey. For brevity, bare `settle/`, `validation/`, `write/`, `types/` and `utils/` engine paths below omit the `src/core/engine/` prefix.

- **W5 watch routing:** `src/core/engine/settle/utils/commit/utils/createWatchDeliveryIndex.ts:71` decodes newly bound watch paths through `getCachedPointerSegments`; `:124` does the same for affected changed paths. Membership retains decoded segments (`:12–16`) and unchanged paths return before decoding (`:51–58`). Delivery invokes affected for `affectedPaths` in `settle/utils/commit/markCommitDeliveries.ts:122–126`, and updates membership after reading live watch values at `:210–218`.
- **W5 dependency routing:** `settle/utils/dependencies/getDependencyIndex.ts:100–106` prefers blueprint-prepared segments, then uses the runtime cache when supplied. Changed-path calls occur in `affectedForRegistration` at `:427`, `affected` at `:472`, and `affectedByPresence` at `:529`. The full stub retains the prepared lookup and replaces only the dynamic fallback at all three sites. `utils/paths/getCachedPointerSegments.ts:8,24–34` implements a 256-entry insertion-order FIFO; hits do not refresh order.
- **Why the W5 fixture uses derived:** `settle/utils/dependencies/registerRecalculation.ts:58–68` selects `affectedForRegistration` only for gated split owners; otherwise `:85–90` calls `affected`. `registerPresenceChanges.ts:81–87` calls the presence method for shape changes. The required fixed-shape, nongated fixture exercises `affected`, and does not pretend to exercise the other two methods during its timed writes.
- **W2:** `settle/utils/controls/readFieldNodeWatchValues.ts:53–59` checks same-commit/length reuse and selects context, but still scans every path at `:70–88`; witness publication and stable array reuse occur at `:90–111`. Detached/snapshot handling is separate at `:43–44`. The measured second read follows the delivery read at `markCommitDeliveries.ts:210–213`.
- **Relative syntax:** `settle/__tests__/settle.derive.test.ts:14–23` uses `controls.derived: '../source'`; `settle/__tests__/settle.pointer-watch-work.test.ts:45–55` uses `watch: ['../source', '@']`. The fixture asserts the watched values equal the sibling values and the derived result equals their concatenation, before timing and after every sequence. `src/core/engine/types/controls.ts:58–59` declares `derived`; no `computed` key is used.
- **W1:** `src/hooks/fieldNode/useChildFieldErrors.ts:23–27` defines the mask; `:44–56` subscribes separately to parent and children; `:58–65` maps **parent plus direct children** to `revision(mask)` and joins on every snapshot call. There is no in-package product call to the hook; root export `src/index.ts:117`, stories (`stories/features/input-components/utils/CardInput.tsx:1,9`) and verification consumers were found. The C-call wave is a conditional upper-bound probe, not a claim that React always schedules exactly C snapshots.
- **W4:** `validation/utils/route/routeValidationIssues.ts:40–46` builds active IDs only when issues and committed declarations exist. `settle/utils/commit/commitSettlement.ts:57–64` stores declarations for gated settlement; a plain static fixture had no map and was rejected for this probe. `write/utils/entry/dispatchResetSubtree.ts:27–37` adds each public subtree reset to a Set of validation targets; `write/utils/chain/exitFieldNodeChain.ts:103–107` forwards those targets. `validation/utils/run/requestFieldNodeValidation.ts:29–41` merges targets without ancestor deduplication, calls the validator once (`:47`), then routes once per target (`:62–66`).

### W4 maximum target count

There is **no fixed global maximum T** in this code: the Set can accumulate distinct requested occurrences. For a fixed stable tree with V live nodes, requesting every node gives T = V; ancestor and descendant requests coexist. The probe realizes **T = 1,000** on a tree with exactly **1,000 selected declaration IDs and 1,000 live nodes**: an object root plus 999 distinct scalar properties, each scalar having `controls.active: 'true'`. A public `root.batch(() => { root.resetSubtree(); for (const child of root.children) child.resetSubtree(); })` requests every occurrence. The pilot asserts 1,000 pending targets, 1,000 unique active IDs, one validator invocation, and error publication to all 999 children. The potential reusable-Set saving is **(T − 1) × construction = 999 × construction**, not T times construction. This worst-case merged request pattern is deliberately explicit; T = 1 for an ordinary explicit root `validate()`, so its reuse bound is zero.

## Fixtures, stubs and timing scope

The A3 production Node runtime configuration and internal `nodeFromJSONSchema` entry are reused from `<scratch>/lazy-a/`, adapting its stronger **single-build VM** protocol (`a3-single-build.mjs`, `a3-run-single.py`) rather than its exploratory multi-build VM. All source modifications and outputs are beneath `<scratch>/lazy-b/`. Six bundles are saved: baseline, byte-identical control, W5, W2, and two diagnostic variants. Timed W5/W2 bundles contain no counters or equivalence rescans. No transpile-only loader, dependency installation or network fetch was used.

The earlier A3 dependency links pointed at a removed worktree. The new scratch dependency directory uses already installed local packages under `<workspace>/node_modules`, and the already built A3 workspace libraries. The pinned local Yarn 4.12.0 and Rolldown 1.2.0 runtime configuration built the probe entry with bare `yarn exec rolldown -c oracle.config.mjs` calls, sequentially. The scratch config emits only the A3 Node oracle output using the same Node build options/development-flag plugin; it does not claim declaration, hash or release checks.

### W5 and W2 fixture

`fixture.mjs` supplies an array of N = 300 / 1,000 objects, each containing four string fields:

```diff
+ a: { type: 'string' }
+ b: { type: 'string' }
+ c: { type: 'string', controls: { watch: ['../a', '../b'] } }
+ d: { type: 'string', controls: { derived: '../a + ":" + ../b' } }
```

Every item has one watching node with W = 2 and one derived node. There are no `active` or `computed` controls here. Bulk writes replace all four supplied values in all items; derive overwrites d normally. Typing performs 200 consecutive public writes to a on the middle item. W5 times the writes; W2 times each write plus one `watchValues` read on every watching node. Setup, initial reads, next-input allocation, pending-task drain, forced GC, and postcondition assertions are outside timers. All runs assert stable diagnostics and final sibling/derived values.

Each oracle process gets 3 warmup sequences and 5 recorded sequences in the pilot. A bulk sequence yields one sample; a typing sequence yields 200 separately timed **per-write** samples. Thus a pilot typing cell has 1,000 individual samples, retaining sequence grouping in JSON. Full mode uses 12 warmup and 60 recorded sequences (12,000 per-write typing samples per build/cell), with median and nearest-rank p95 computed over individual writes. It never reports the 200-write total as a typing latency.

### W5 full stub

The full stub includes both watch sites and all three dependency changed-path sites. Prepared blueprint syntax remains prepared. Existing watch membership still retains the newly parsed segments. Ordinary live getter path caching remains unchanged. Full exact scratch diffs are `w5-index.diff` and `w5-dependency.diff`:

```diff
--- src/core/engine/settle/utils/commit/utils/createWatchDeliveryIndex.ts
+++ src/core/engine/settle/utils/commit/utils/createWatchDeliveryIndex.ts
@@ -2,11 +2,11 @@
 
 import {
   PointerOperator,
+  parsePointerSegments,
   type PointerSegment,
 } from '@/schema-form/helpers/jsonPointer';
 
 import type { FieldNodeRuntime } from '../../../../record';
-import { getCachedPointerSegments } from '../../../../utils/paths/getCachedPointerSegments';
 
 /** Live membership carries the syntax needed to remove its edge without decoding. */
 interface WatchPathMembership {
@@ -68,7 +68,7 @@
       if (!present)
         unique.push({
           path,
-          segments: getCachedPointerSegments(this.runtime, path),
+          segments: parsePointerSegments(path),
         });
     }
     if (unique.length === 0) return;
@@ -121,7 +121,7 @@
   affected(path: string, candidates: Set<unknown>): void {
     let current: Optional<WatchPathNode> = this.root;
     for (const watcher of current.watchers) candidates.add(watcher);
-    for (const segment of getCachedPointerSegments(this.runtime, path)) {
+    for (const segment of parsePointerSegments(path)) {
       current = current.children.get(segment);
       if (!current) return;
       for (const watcher of current.watchers) candidates.add(watcher);
--- src/core/engine/settle/utils/dependencies/getDependencyIndex.ts
+++ src/core/engine/settle/utils/dependencies/getDependencyIndex.ts
@@ -424,7 +424,7 @@
     };
     let current = [this.root];
     collect(this.root);
-    for (const segment of this.pathSegments(changedPath, root.runtime)) {
+    for (const segment of (this.preparedSegments.get(changedPath) ?? parsePointerSegments(changedPath))) {
       if (typeof segment !== 'string') return;
 
       const next = this.presenceChildren(current, segment);
@@ -469,7 +469,7 @@
       }
     };
     collect(rootIndex);
-    for (const segment of this.pathSegments(changedPath, root.runtime)) {
+    for (const segment of (this.preparedSegments.get(changedPath) ?? parsePointerSegments(changedPath))) {
       if (typeof segment !== 'string') return [...owners];
 
       const next: DependencyNode[] = [];
@@ -526,7 +526,7 @@
     if (typeof childName !== 'string')
       return { owners, stateOnly, outerTemplates, directTemplates };
     const changedPath = appendSegment(hostPath, childName);
-    const changedSegments = this.pathSegments(changedPath, runtime);
+    const changedSegments = (this.preparedSegments.get(changedPath) ?? parsePointerSegments(changedPath));
     const ancestorOwners = new Set<string>();
     let memo = settlement?.dependencyPresenceMemo;
     if (!memo) {
```

### W2 witness stub

The witness adds the selected context identity. The early return requires the existing same-commit/no-snapshot/length reuse test plus unchanged schema, authored watch identity, node path, previous no-snapshot witness and `Object.is(previousContext, selectedContext)`. The normal scan updates the context witness. **For these public writes followed by post-commit reads, the fast return is the very same array that the full rescan returns.** The diagnostic bundle invokes an untouched original `readFieldNodeWatchValues` implementation at every fast hit and checks reference equality and element equality before returning; those checks are absent from timed builds. This is evidence for the selected operations, not a general proof for unsupported mutation patterns.

```diff
--- src/core/engine/settle/utils/controls/readFieldNodeWatchValues.ts
+++ src/core/engine/settle/utils/controls/readFieldNodeWatchValues.ts
@@ -25,6 +25,7 @@
   path: string;
   snapshot: boolean;
   contextAbsent: boolean;
+  context: unknown;
 }
 
 /**
@@ -57,6 +58,12 @@
   );
   const witness = derived.watchValuesWitness;
   const selectedContext = snapshot ? snapshot.context : runtime.context;
+  if (reusable && witness !== undefined && witness.schema === schema &&
+      witness.watch === watch && witness.path === node.path && !witness.snapshot &&
+      Object.is(witness.context, selectedContext)) {
+    
+    return memo!.values;
+  }
   const reuseAbsentContext =
     reusable &&
     witness !== undefined &&
@@ -93,6 +100,7 @@
     witness.path = node.path;
     witness.snapshot = snapshot !== undefined;
     witness.contextAbsent = selectedContext == null;
+    witness.context = selectedContext;
   } else
     derived.watchValuesWitness = {
       schema,
@@ -100,6 +108,7 @@
       path: node.path,
       snapshot: snapshot !== undefined,
       contextAbsent: selectedContext == null,
+      context: selectedContext,
     };
   if (!next) return memo!.values;
   const values = next.length ? Object.freeze(next) : EMPTY_WATCH_VALUES;
```

### Direct probes

- **W1 (`probe.mjs`)** creates two fresh equivalent C-child string-array forms per repetition. A custom synchronous validator returns one changed issue per child. One form times `await root.validate()` alone; the other times the same validation followed by C calls of the exact hook snapshot body, using the original `@winglet/common-utils/array` map implementation and original event mask. Setup and assertions stay outside timing; operation order alternates. The snapshot interval is timed directly within the combined interval. Every child must acquire an error and a newer masked revision. The denominator is the measured combined validation-plus-snapshots total; it includes validation, not the snapshot interval alone. No React rendering or subscription scheduling cost is claimed.
- **W4 (`probe.mjs`)** constructs exactly 1,000 real gated declaration IDs, generates 999 child issues, and accumulates T = 1,000 public reset requests as above. It times one exact Set-building loop from the route implementation, then times one unchanged merged-target validation run on the same form. Only the pending frame clock is cancelled, and the existing `runtime.validationRun()` domain callback is invoked directly to exclude frame waiting; no routing or validator code is replaced. A `setImmediate` drain includes all result/routing/delivery continuations; one validator call and all child errors are asserted. Bound = 999 × Set time; denominator = merged validation time. Reset/setup work is outside the timer.

## Pilot results — functional preparation evidence only

All entries are median / p95 in milliseconds. Bulk and typing are different units. `pilot/run-status.json` retains process exit, elapsed time and observed competing processes. Some final-build pilot cells overlapped unrelated Vitest work; pilot mode deliberately records that rather than claiming a quiet measurement. Even an apparently valid pilot control is not a final decision. The earlier helper-based W5 experiment and broadly loaded initial pilots are retained only under `pilot-exploratory/` and `counts-exploratory/`; they are excluded below.

| Candidate | N | Operation unit | Baseline med/p95 | Stub med/p95 | Identical control med/p95 | Control gap | Pilot noise check |
| --- | ---: | --- | ---: | ---: | ---: | ---: | --- |
| W5 | 300 | one bulk write | 14.793125 / 15.800917 | 13.197875 / 14.790666 | 14.833041 / 15.693334 | 0.039916 | within band |
| W5 | 300 | one write | 0.041042 / 0.050708 | 0.043625 / 0.056583 | 0.041584 / 0.050875 | 0.000542 | within band |
| W5 | 1000 | one bulk write | 62.549125 / 76.975167 | 56.507666 / 65.591709 | 59.774042 / 70.203000 | 2.775083 | outside band; no decision |
| W5 | 1000 | one write | 0.052604 / 0.074958 | 0.054167 / 0.079958 | 0.052896 / 0.077667 | 0.000292 | within band |
| W2 | 300 | one bulk write | 15.783250 / 16.470542 | 15.892209 / 15.919000 | 15.263667 / 16.118334 | 0.519583 | outside band; no decision |
| W2 | 300 | one write | 0.127958 / 0.179292 | 0.131667 / 0.185709 | 0.123083 / 0.144459 | 0.004875 | within band |
| W2 | 1000 | one bulk write | 62.209375 / 72.767833 | 103.787958 / 128.928458 | 99.815084 / 247.672125 | 37.605709 | outside band; no decision |
| W2 | 1000 | one write | 0.354583 / 0.415708 | 0.352084 / 0.404250 | 0.346334 / 0.397459 | 0.008249 | within band |

W2 rows include reading all watchers in the timed unit. There is no full-run retry in pilot mode: an out-of-band pilot records harness operation and remains non-decisional. All 27 final-build pilot processes exited 0; 60 bulk samples and 12,000 individual typing samples were recorded, besides the direct probes.

### Stub call counts (separate untimed diagnostic processes)

Each row below covers one fresh setup and one operation sequence; typing means all 200 writes. These are actual runtime-cache fallbacks at dependency sites, not merely calls that returned already prepared segments.

| Candidate | N | Operation | Setup watch-path decodes | Timed-scope watch affected decodes | Dependency affected fallbacks | W2 fast returns | Original-rescan identity matches |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| W5 | 300 | bulk | 600 | 1200 | 4800 | 0 | 0 |
| W5 | 300 | typing | 600 | 400 | 1200 | 0 | 0 |
| W5 | 1000 | bulk | 2000 | 4000 | 16000 | 0 | 0 |
| W5 | 1000 | typing | 2000 | 400 | 1200 | 0 | 0 |
| W2 | 300 | bulk | 0 | 0 | 0 | 300 | 300 |
| W2 | 300 | typing | 0 | 0 | 0 | 200 | 200 |
| W2 | 1000 | bulk | 0 | 0 | 0 | 1000 | 1000 |
| W2 | 1000 | typing | 0 | 0 | 0 | 200 | 200 |

The fixed-shape W5 operations do not change watch membership, so `watchUpdate` has zero decodes inside the timed operation; its 2N setup decodes prove the stub is wired. The registration-specific and presence-specific changed-path sites have zero fallbacks in all these nongated fixed-shape operations. **This absence is part of the fixture scope, not hidden coverage.** `site-smoke.mjs` separately calls the two unchanged index APIs on the same live fixture, yielding one dynamic fallback at `affectedForRegistration('/1/a', ...)` and one at `affectedByPresence('/1', 'a', ...)`; `site-smoke.json` records both. These direct internal smoke calls are not product workload measurements.

For W2 bulk, all N watchers have a current delivery memo and all N render reads fast-return. For typing, only the watcher whose siblings changed has a current memo before the render sweep, so there is **one** fast hit per write (200 per sequence), not N per write. Other watchers still need their first scan for the newer commit. All fast hits matched the exact original rescan by reference and by element.

### Direct-probe pilot numbers

| Probe | Size | Engine-only median/p95 | Upper-bound part median/p95 | Combined/denominator median/p95 | Bound share of denominator |
| --- | ---: | ---: | ---: | ---: | ---: |
| W1 exact C-snapshot wave | 300 children | 0.453584 / 0.468583 | 2.045042 / 5.199958 | 2.523958 / 5.723750 | 81.03% |
| W1 exact C-snapshot wave | 1000 children | 1.325500 / 1.440291 | 21.538458 / 24.187792 | 23.027291 / 25.699458 | 93.53% |
| W4 999 redundant Set builds | 1,000 IDs; T=1,000 | 490.983208 / 501.142542 | 121.003875 / 142.649208 | 490.983208 / 501.142542 | 24.65% |

One W4 Set construction itself was **0.121125 / 0.142792 ms**. The W4 bound is the prescribed multiplication, not an implemented saving. For W1 the engine-only comparison uses a separate fresh equivalent form; its median need not equal combined median minus snapshot median. The recorded combined interval itself is exactly its engine interval plus its snapshot interval.

## Closed without new measurements

- **W3 entirely:** ordinary array items render through `ChildFields` (`src/fieldInputs/fieldInputDefinitions/FieldInputArray/components/ArrayItems.tsx:83–89`). `node.find('./' + index)` is only in the empty-slot loop below the minItems/maxItems bound (`:102–115`). `src/hooks/fieldNode/useFieldNode.ts:21–25,33–35` resolves a node instance directly and invokes root find for string paths, so the hypothesized per-item product-render cost is absent. Explicit wildcard API queries do not establish that product-render workload. No W3 probe or candidate bundle was created.
- **C2:** previous isolated oracle savings were 0.903584 ms (rounded 0.904) and 0.861 ms, both below 1 ms; retained as a closed record. Source report `<scratch>/460-briefs/lazy-a-report.md:7,177,420`. No C2 remeasurement or stub was created here.

## Measurement-worker handoff

Run exactly this one command after other performance/build/test work has stopped:

```sh
python3 <scratch>/lazy-b/run.py --full
```

The runner verifies immutable bundle SHA-256 fingerprints and identical control bytes; holds a process lock; starts all cells sequentially; imports one build per fresh production Node VM; reverses baseline/stub/control order across successive groups; and executes 12 warmup / 60 recorded sequences per cell. No build is performed during measurement. Oracle cells produce one JSON per candidate/size/operation/build/attempt; direct probes produce one JSON per probe/size. Expected normal process count is **27**; maximum with all eight control-invalid groups repeated is **51**. Full oracle samples are bulk **720** and typing **144,000**, excluding warmups/retries. `full/run-status.json` is the mechanical receipt, `full/oracle-summary.json` contains per-attempt medians/p95/noise/regression facts, and all raw samples and stdout logs remain beside them.

The runner refuses full mode if it sees another Node/Python performance script, Vitest, or Rolldown process before a cell. It samples the process list every 250 ms while the cell runs and aborts if it observes overlap; this is an overlap guard, not an operating-system guarantee against all host activity or very short tasks. Do not run the full command while a previous failed child is still alive. For a quiet-control failure, **rerun the entire baseline/stub/control group once**; retain both attempts; mark a second invalid attempt void. A host-overlap abort is a separate environment failure, not a statistically valid retry. The runner does not classify candidates from pilots or automatically split W5.

The pre-registered arithmetic is encoded literally: control band `max(0.3 ms, 3% × baseline median)`; counted saving must exceed twice the absolute control gap, and at N=1,000 must reach both 1 ms and 10%. Bulk regression limit is 0.5 ms; typing limit is `max(0.05 ms, 5% × baseline median)` **per write**. A coordinator must also check that no relevant cell exceeds its regression limit and that required cells are valid before selecting a design. Direct probes require at least 1 ms and 10% of the denominator; W4 uses `(T−1) × Set construction`. These are candidate screening bounds, not production-implementation approval.

Final-build pilot elapsed process time was 27.01 seconds. Budget **3–7 minutes** for a quiet full first pass, approximately **5–12 minutes** if many oracle groups need their one retry; this is an estimate from the pilot, not a measured full-run duration.

## Verification and artifact index

`python3 <scratch>/lazy-b/verify.py` passed. It recomputes medians/p95 from raw samples, checks warmup/run/sample counts and diagnostic counters, validates W4 target/declaration arithmetic, hashes all six saved bundles, compares all 2,962 tracked schema-form source files with the unchanged worktree after scratch restoration, and verifies clean Git status at the assigned SHA. It asserts that no `full/` directory exists. No repository-wide product test/build gate is claimed or required for this scratch-only preparation.

- `source/packages/canard/schema-form/` — isolated source/build copy, restored to baseline for source comparisons; the extra original-rescan helper is scratch-only.
- `originals/`, `prepare.py`, `w5-*.diff`, `w2-*.diff` — exact inputs and reproducible stub generation.
- `builds/`, `build-manifest.json` — frozen measurement and diagnostic bundles.
- `fixture.mjs`, `cell.mjs`, `probe.mjs`, `run.py` — fixture, one-build oracle process, direct probes and sequential full matrix.
- `pilot/`, `counts/`, `site-smoke.mjs`, `site-smoke.json` — final-build pilot samples, separate call-count/identity checks and dormant-site wiring evidence.
- `verify.py`, `verification.json` — independent arithmetic/artifact/source checks.
- `pilot-exploratory/`, `counts-exploratory/` — superseded exploratory results, excluded from all tables and decisions.

All paths in this index are relative to `<scratch>/lazy-b/`. The remaining work belongs to the measurement worker (quiet full matrix) and coordinator (apply the rule and decide whether any design proceeds).
