# Lazy A/B measurement record

## Quiet checks

### Before A acceptance

File: `<scratch>/lazy-ab-measure/quiet-1.txt`

Second sample:

```
Processes: 1002 total, 2 running, 1000 sleeping, 4699 threads 
2026/11/02 17:47:40
Load Avg: 2.37, 2.15, 2.68 
CPU usage: 1.44% user, 3.73% sys, 94.82% idle 
SharedLibs: 1305M resident, 213M data, 388M linkedit.
MemRegions: 0 total, 0B resident, 818M private, 6401M shared.
PhysMem: 49G used (4104M wired, 5161M compressor), 14G unused.
VM: 468T vsize, 57G framework vsize, 0(0) swapins, 0(0) swapouts.
Networks: packets: 113645802/87G in, 92023306/56G out.
Disks: 112291960/1095G read, 110530273/1346G written.

PID    COMMAND          %CPU
65005  top              12.2
436    WindowServer     7.7 
1056   Stats            5.1 
650    ControlCenter    3.2 
0      kernel_task      2.9 
60507  node             2.8 
553    com.apple.Driver 1.4 
80344  Orca             1.0 
```

### Before B oracle matrix

File: `<scratch>/lazy-ab-measure/quiet-2.txt`

Second sample:

```
Processes: 1001 total, 2 running, 999 sleeping, 4706 threads 
2026/11/02 17:51:09
Load Avg: 3.03, 2.46, 2.67 
CPU usage: 1.63% user, 3.78% sys, 94.58% idle 
SharedLibs: 1305M resident, 213M data, 388M linkedit.
MemRegions: 0 total, 0B resident, 817M private, 6400M shared.
PhysMem: 49G used (4101M wired, 5161M compressor), 14G unused.
VM: 468T vsize, 57G framework vsize, 0(0) swapins, 0(0) swapouts.
Networks: packets: 113650247/87G in, 92026594/56G out.
Disks: 112294633/1095G read, 110549352/1347G written.

PID    COMMAND          %CPU
68108  top              10.9
436    WindowServer     7.7 
1056   Stats            6.6 
0      kernel_task      2.7 
60507  node             2.6 
650    ControlCenter    2.4 
20772  codex            1.1 
625    cfprefsd         1.1 
```

## Attempts

### A acceptance

- Command: `python3 <scratch>/lazy-a/accept/run.py --full`
- Attempt: 1
- Exit code: 0
- Duration seconds: 99
- Duration evidence: log birth_epoch 1793609340 to mtime_epoch 1793609439
- Output log: `<scratch>/lazy-ab-measure/a-attempt-1.log`

Last 20 lines:

```
{"path": "<scratch>/lazy-a/accept/full/watch-clear()-control-attempt1.json", "exitCode": 0, "seconds": 3.386183023452759, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/watch-remove(0)-control-attempt1.json", "exitCode": 0, "seconds": 4.611714839935303, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/watch-remove(0)-candidate-attempt1.json", "exitCode": 0, "seconds": 4.3002917766571045, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/watch-remove(0)-baseline-attempt1.json", "exitCode": 0, "seconds": 4.610430955886841, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-setValue([])-baseline-attempt1.json", "exitCode": 0, "seconds": 3.0467710494995117, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-setValue([])-candidate-attempt1.json", "exitCode": 0, "seconds": 2.765108346939087, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-setValue([])-control-attempt1.json", "exitCode": 0, "seconds": 3.0804479122161865, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-clear()-control-attempt1.json", "exitCode": 0, "seconds": 2.7528538703918457, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-clear()-candidate-attempt1.json", "exitCode": 0, "seconds": 2.7567989826202393, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-clear()-baseline-attempt1.json", "exitCode": 0, "seconds": 2.74650502204895, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-clear()-control-attempt2.json", "exitCode": 0, "seconds": 2.7595057487487793, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-clear()-candidate-attempt2.json", "exitCode": 0, "seconds": 2.7560057640075684, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-clear()-baseline-attempt2.json", "exitCode": 0, "seconds": 2.7657930850982666, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-remove(0)-baseline-attempt1.json", "exitCode": 0, "seconds": 2.762775182723999, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-remove(0)-candidate-attempt1.json", "exitCode": 0, "seconds": 2.758845806121826, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/errors-remove(0)-control-attempt1.json", "exitCode": 0, "seconds": 2.759139060974121, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/guard-six-switches-control-attempt1.json", "exitCode": 0, "seconds": 0.9195730686187744, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/guard-six-switches-candidate-attempt1.json", "exitCode": 0, "seconds": 0.9215431213378906, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-a/accept/full/guard-six-switches-baseline-attempt1.json", "exitCode": 0, "seconds": 0.914675235748291, "competitorsBefore": [], "competitorsDuring": []}
{"mode": "full", "processes": 36, "seconds": 96.56784152984619}
```

### B oracle matrix

- Command: `python3 <scratch>/lazy-b/run.py --full`
- Attempt: 1
- Exit code: 0
- Duration seconds: 169.317447
- Start epoch: 1793609503.064263
- End epoch: 1793609672.381710
- Output log: `<scratch>/lazy-ab-measure/b-attempt-1.log`

Last 20 lines:

```
{"path": "<scratch>/lazy-b/full/w5-1000-bulk-control-attempt1.json", "exitCode": 0, "seconds": 7.961410999298096, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w5-1000-typing-control-attempt1.json", "exitCode": 0, "seconds": 4.907055854797363, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w5-1000-typing-w5-attempt1.json", "exitCode": 0, "seconds": 4.6000378131866455, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w5-1000-typing-baseline-attempt1.json", "exitCode": 0, "seconds": 4.5981550216674805, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-300-bulk-baseline-attempt1.json", "exitCode": 0, "seconds": 2.750900983810425, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-300-bulk-w2-attempt1.json", "exitCode": 0, "seconds": 2.7689449787139893, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-300-bulk-control-attempt1.json", "exitCode": 0, "seconds": 2.7605528831481934, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-300-typing-control-attempt1.json", "exitCode": 0, "seconds": 3.6701157093048096, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-300-typing-w2-attempt1.json", "exitCode": 0, "seconds": 3.6829779148101807, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-300-typing-baseline-attempt1.json", "exitCode": 0, "seconds": 3.670121908187866, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-1000-bulk-baseline-attempt1.json", "exitCode": 0, "seconds": 7.971214056015015, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-1000-bulk-w2-attempt1.json", "exitCode": 0, "seconds": 7.963342189788818, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-1000-bulk-control-attempt1.json", "exitCode": 0, "seconds": 7.952880144119263, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-1000-typing-control-attempt1.json", "exitCode": 0, "seconds": 8.877662897109985, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-1000-typing-w2-attempt1.json", "exitCode": 0, "seconds": 9.19483208656311, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w2-1000-typing-baseline-attempt1.json", "exitCode": 0, "seconds": 9.183346033096313, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w1-300.json", "exitCode": 0, "seconds": 1.2043051719665527, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w1-1000.json", "exitCode": 0, "seconds": 3.0656867027282715, "competitorsBefore": [], "competitorsDuring": []}
{"path": "<scratch>/lazy-b/full/w4-1000.json", "exitCode": 0, "seconds": 39.327377796173096, "competitorsBefore": [], "competitorsDuring": []}
{"mode": "full", "processes": 27, "seconds": 167.34430408477783, "oracleAttempts": 8}
```

## Result paths

- `<scratch>/lazy-a/accept/full/run-status.json`
- `<scratch>/lazy-a/accept/full/summary.json`
- `<scratch>/lazy-b/full/run-status.json`
- `<scratch>/lazy-b/full/oracle-summary.json`

## summary.json

Source: `<scratch>/lazy-a/accept/full/summary.json`

| field | value |
| --- | --- |
| mode | full |
| bulkPassingCells | 2 |
| verdict | CLOSE_C1_AS_RECORD |

| field | value |
| --- | --- |
| controlBand | abs(control median - baseline median) <= max(0.3 ms, 3% baseline median) |
| retry | one complete group rerun after invalid control; invalid again = void |
| acceptance | at least 4 of 6 bulk cells save >= 10% and >= 1 ms, strictly exceeding twice the control gap; no cell including remove(0) and guard regresses > 0.5 ms median |

| variant | operation | attempt | unit | baseline.median | baseline.p95 | candidate.median | candidate.p95 | control.median | control.p95 | controlGap | controlBand | controlVerdict | savingMs | savingFraction | aboveTwiceControlGap | bulk | bulkSavingVerdict | regressionMs | regressionLimitMs | regressionVerdict |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| plain | setValue([]) | 1 | one public operation | 6.220396000000051 | 8.367457999999942 | 5.446729000000005 | 8.865750000000048 | 6.461082999999917 | 8.467333000000053 | 0.2406869999998662 | 0.3 | VALID | 0.7736670000000458 | 0.12437584359581601 | true | true | FAIL | -0.7736670000000458 | 0.5 | PASS |
| plain | clear() | 1 | one public operation | 5.599978999999962 | 7.910250000000019 | 4.688791999999978 | 6.757541000000003 | 5.462270999999987 | 7.822499999999991 | 0.13770799999997507 | 0.3 | VALID | 0.911186999999984 | 0.16271257445786674 | true | true | FAIL | -0.911186999999984 | 0.5 | PASS |
| plain | remove(0) | 2 | one public operation | 5.160208500000067 | 7.2549999999999955 | 5.096771000000047 | 6.9375 | 5.381437500000061 | 7.470957999999882 | 0.2212289999999939 | 0.3 | VALID | 0.06343750000002046 | 0.012293592400388402 | false | false | NOT_BULK | -0.06343750000002046 | 0.5 | PASS |
| watch | setValue([]) | 1 | one public operation | 10.941874499999983 | 14.383166999999958 | 9.998166500000082 | 13.340165999999954 | 10.84660400000007 | 14.650667000000112 | 0.09527049999991277 | 0.3282562349999995 | VALID | 0.9437079999999014 | 0.08624737927673205 | true | true | FAIL | -0.9437079999999014 | 0.5 | PASS |
| watch | clear() | 1 | one public operation | 10.674854500000038 | 13.289416999999958 | 9.919833500000095 | 12.571332999999868 | 10.691958499999942 | 13.238875000000007 | 0.017103999999903863 | 0.32024563500000114 | VALID | 0.7550209999999424 | 0.070728926562881 | true | true | FAIL | -0.7550209999999424 | 0.5 | PASS |
| watch | remove(0) | 1 | one public operation | 25.82566650000001 | 32.452125000000024 | 25.635041500000057 | 31.757457999999588 | 25.685666999999853 | 32.252792 | 0.13999950000015815 | 0.7747699950000003 | VALID | 0.19062499999995453 | 0.00738122286214586 | false | false | NOT_BULK | -0.19062499999995453 | 0.5 | PASS |
| errors | setValue([]) | 1 | one public operation | 8.844624999999837 | 9.879709000000048 | 7.462020999999936 | 8.275499999999965 | 8.68060399999996 | 9.85370899999998 | 0.1640209999998774 | 0.3 | VALID | 1.3826039999999011 | 0.15632138163007778 | true | true | PASS | -1.3826039999999011 | 0.5 | PASS |
| errors | clear() | 2 | one public operation | 8.322938000000022 | 9.032124999999724 | 6.840853999999922 | 7.723583999999846 | 8.043645499999968 | 9.008249999999862 | 0.2792925000000537 | 0.3 | VALID | 1.4820840000000999 | 0.17807221440314658 | true | true | PASS | -1.4820840000000999 | 0.5 | PASS |
| errors | remove(0) | 1 | one public operation | 5.908999499999936 | 8.226667000000134 | 5.679583500000035 | 7.703666999999996 | 5.863333499999953 | 8.310666999999967 | 0.04566599999998289 | 0.3 | VALID | 0.22941599999990103 | 0.038824846744343694 | true | false | NOT_BULK | -0.22941599999990103 | 0.5 | PASS |
| guard | six-switches | 1 | one branch switch | 0.1250414999999805 | 0.5400000000000205 | 0.12810400000000755 | 0.5454169999999294 | 0.12529200000000174 | 0.5339579999999842 | 0.0002505000000212476 | 0.3 | VALID | -0.0030625000000270575 | -0.024491868699811944 | false | false | NOT_BULK | 0.0030625000000270575 | 0.5 | PASS |

## oracle-summary.json

Source: `<scratch>/lazy-b/full/oracle-summary.json`

| candidate | n | operation | attempt | baseline.median | baseline.p95 | candidateBuild | candidateBuild.median | candidateBuild.p95 | control.median | control.p95 | controlGap | noiseBand | valid | savingMs | savingFraction | aboveTwiceControlGap | regressionLimit | excessiveRegression | absoluteAndRelativeGate | void |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| w5 | 300 | bulk | 1 | 17.579458499999987 | 19.513958000000002 | w5 | 16.666999999999916 | 18.583167000000003 | 17.50108400000005 | 20.006208000000015 | 0.07837449999993851 | 0.5273837549999996 | true | 0.9124585000000707 | 0.05190481265393194 | true | 0.5 | false | false | false |
| w5 | 300 | typing | 1 | 0.055041999999957625 | 0.07016700000008314 | w5 | 0.05608299999994415 | 0.0717499999999518 | 0.055083999999851585 | 0.06920800000000327 | 4.1999999893960194e-05 | 0.3 | true | -0.001040999999986525 | -0.018912830202160648 | false | 0.05 | false | false | false |
| w5 | 1000 | bulk | 1 | 57.78310449999992 | 67.47829199999978 | w5 | 54.03735450000022 | 64.40654199999972 | 57.336187499999596 | 67.7743330000003 | 0.44691700000032597 | 1.7334931349999976 | true | 3.7457499999997026 | 0.06482431209627561 | true | 0.5 | false | false | false |
| w5 | 1000 | typing | 1 | 0.05462499999975989 | 0.07316699999955745 | w5 | 0.055957999999918684 | 0.07370800000012423 | 0.05716700000016317 | 0.07674999999994725 | 0.0025420000004032772 | 0.3 | true | -0.0013330000001587905 | -0.024402745998437524 | false | 0.05 | false | false | false |
| w2 | 300 | bulk | 1 | 17.72483299999999 | 19.71520799999996 | w2 | 17.726729499999976 | 19.923999999999978 | 17.337895999999944 | 19.57224999999994 | 0.3869370000000458 | 0.5317449899999996 | true | -0.001896499999986645 | -0.00010699677678129019 | false | 0.5 | false | false | false |
| w2 | 300 | typing | 1 | 0.135707999999795 | 0.1736670000000231 | w2 | 0.13712499999996908 | 0.1864580000001297 | 0.13437499999992042 | 0.18975000000000364 | 0.0013329999998745734 | 0.3 | true | -0.0014170000001740846 | -0.010441536240871763 | false | 0.05 | false | false | false |
| w2 | 1000 | bulk | 1 | 57.25683349999963 | 67.07187500000055 | w2 | 58.272645999999895 | 66.8113330000001 | 57.9356244999999 | 68.88979199999994 | 0.6787910000002739 | 1.717705004999989 | true | -1.0158125000002656 | -0.017741332132875844 | false | 0.5 | true | false | false |
| w2 | 1000 | typing | 1 | 0.32583400000021356 | 0.4285829999998896 | w2 | 0.3422080000000278 | 0.442417000000205 | 0.323500000000422 | 0.4228339999999662 | 0.0023339999997915584 | 0.3 | true | -0.01637399999981426 | -0.05025258260280857 | false | 0.05 | false | false | false |
