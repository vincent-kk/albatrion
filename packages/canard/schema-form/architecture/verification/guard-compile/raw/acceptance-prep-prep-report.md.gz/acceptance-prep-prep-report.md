# guard-compile acceptance 준비

승인된 scratch 빌드와 네 셀 파일럿이 완료되었습니다. 측정 제품 source commit은 `f750262ea73c4d82d048a06d89d14aa7d5022936`이며 coordinator 지시에 따라 최종 head repin을 기다립니다. Full matrix는 실행하지 않았고 이 작업의 저장소 변경·커밋·설치도 없습니다. 정적·원시 결과 검증은 `seiri:verify` 절차로 확인했습니다.

최초 기준은 `1c44a823bdd9214ff79e2d60549c8a9c8339fb80`였고 coordinator의 후속 지시 `msg_187386bb47d4`로 측정 기준을 `1202dd53b677ccefdf84fbe360f377426bf6ea98`로 옮겼습니다. 두 커밋의 runtime/build/fixture 범위에서는 `union.write-paths.test.ts`만 바뀌었고 제품 소스는 동일합니다. 전체 diff에는 별도로 architecture 문서와 검증 증거도 포함됩니다. 따라서 명시적으로 허용된 기존 `1c44a823b` browser ESM 제품(SHA-256 `0f12294ac18277016d955fad271ebafe4b3b95a5ac3133c59acba2dfc4693ab1`)을 기준 제품으로 재사용하며, 준비 시 두 diff 범위 및 재사용 근거를 JSON으로 고정합니다. 최종 candidate는 coordinator가 지정합니다. 기존 carried-c/measure-prep의 oracle 소스/제품, 12페이지 gate-equivalence 및 full-01 증거를 재사용합니다. 이전 oracle 결과는 이번 candidate의 동등성 증거로 대체하지 않으며 candidate pilot에서 별도로 비교합니다.

네 셀은 `mount-if-flat-500-none`, `mount-if-flat-500-validate`, `mount-flat-500-none`, `mount-flat-500-validate`입니다. canonical fixture, input-only renderer, 900×700 viewport, 첫 input DOM 삽입 다음 rAF의 firstPaintedMs, mount부터 첫 rAF까지 겹치는 ≥50 ms longtask 중 최댓값, 1초 mount window를 유지합니다. first paint는 실제 화면 표시가 아닌 paint opportunity proxy입니다.

Time to first verdict는 `mountFixture`가 `root.render` 직전에 기록한 `mount.startedAt`부터 **Form의 첫 `onValidate` callback 진입 시각**까지의 차이입니다. 모든 callback의 절대 시각과 error count를 보존하고, 두 OnChange 셀에서 첫 callback의 유한한 경과 시간을 요구합니다. 기존 `observation.delivery`는 입력 이벤트가 없는 초기 callback을 기록하지 않으므로 callback 직전 별도 passive sink를 둡니다. fallback은 사용하지 않습니다. validate 호출 종료 시각은 verdict로 대체하지 않습니다. 이 정의는 full run 전에 동결합니다.

정식 실행은 빌드당 warmup 3회와 보존 20회이며, 각 셀마다 baseline/candidate/control 순서를 번갈아 실행합니다. control은 baseline 제품과 browser bundle의 바이트 단위 복사입니다. control validity는 기존 C 규칙 그대로 셀별 firstPaintedMs median gap ≤ max(0.3 ms, 기준 median의 3%)입니다. invalid group은 전체 group을 한 번 재시도하고 두 번째도 invalid이면 void입니다.

Acceptance는 네 조건을 모두 요구합니다: if/None first paint median이 ≥10% 및 ≥16.7 ms 절감되고 그 절감이 control gap의 두 배보다 큽니다; if/OnChange first paint median도 ≥10% 및 ≥16.7 ms 절감됩니다; if/OnChange 첫 verdict median 지연이 기준 대비 ≤16.7 ms입니다; 두 guard-free 셀의 first paint median 회귀가 각각 ≤max(0.5 ms, 기준 median의 3%)입니다. 그 밖에는 record로 닫습니다. longest task에 별도 회귀 gate를 추가하지 않습니다. Amendment 1의 guard-free limit만 수정하고 명시적으로 보존된 원래 control band는 변경하지 않았습니다.

승인 `msg_63855d101858` 이후 각 셀에 warmup 1회와 보존 3회/빌드의 pilot group을 한 번 실행했습니다. 파일럿은 수용 판정을 내리지 않습니다. 30초 quiet start, 두 기존 measurement lock, 250 ms competitor 검사를 pilot과 full 모두에 적용하여 Vitest/build/browser benchmark 겹침을 거부합니다. 승인 전에 빌드나 pilot을 시작하지 않았습니다.

full-run 명령(이번 작업에서는 실행하지 않습니다):

```sh
python3 <scratch>/guard-compile/acceptance-prep/run.py --full --out <scratch>/guard-compile/acceptance-prep/full-01
```

## 파일럿 결과

각 값은 median / nearest-rank p95(ms)이며 n=3에서 p95는 최대값입니다. 총 보존 36개, warmup 12개로 48개 fresh page를 실행했습니다. 네 셀 group은 각각 한 번만 실행했고 첫 시도 원시 자료를 보존했습니다. 30초 quiet start와 실행 전·중 competitor 관측은 모두 비어 있습니다. 브라우저 group 총 시간은 57.717초이며 full-run 결과가 아닙니다.

| 셀 | 빌드 | First paint | Longest mount task | 첫 Form.onValidate |
| --- | --- | ---: | ---: | ---: |
| mount-if-flat-500-none | baseline | 104.500 / 105.200 | 103 / 104 | — |
| mount-if-flat-500-none | candidate | 70.200 / 70.300 | 69 / 69 | — |
| mount-if-flat-500-none | control | 106.200 / 106.400 | 105 / 105 | — |
| mount-if-flat-500-validate | baseline | 107.500 / 109.000 | 107 / 108 | 123.500 / 126.700 |
| mount-if-flat-500-validate | candidate | 70.000 / 70.300 | 69 / 69 | 110.900 / 111.200 |
| mount-if-flat-500-validate | control | 106.200 / 109.000 | 105 / 108 | 122.200 / 125.300 |
| mount-flat-500-none | baseline | 38.000 / 38.900 | 0 / 0 | — |
| mount-flat-500-none | candidate | 38.300 / 40.100 | 0 / 0 | — |
| mount-flat-500-none | control | 38.400 / 39.400 | 0 / 0 | — |
| mount-flat-500-validate | baseline | 37.400 / 39.000 | 0 / 0 | 87.800 / 90.600 |
| mount-flat-500-validate | candidate | 38.300 / 38.400 | 0 / 0 | 90.000 / 90.900 |
| mount-flat-500-validate | control | 39.700 / 41.100 | 0 / 0 | 89.500 / 96.700 |

if/None first paint 절감은 34.300 ms(32.823%)이며 control gap은 1.700 ms입니다. if/OnChange 절감은 37.500 ms(34.884%)이고 첫 verdict median은 기준 대비 12.600 ms 빨랐습니다. guard-free None의 first paint 회귀는 0.300 ms입니다. guard-free OnChange는 회귀 0.900 ms였으나 control gap 2.300 ms가 band 1.122 ms를 초과하여 이 pilot group은 **invalid**입니다. 지시한 셀당 한 pilot만 실행했으므로 다시 돌리지 않았습니다. 정식 실행에서는 해당 group이 invalid이면 전체 group을 한 번 재시도하고 다시 invalid이면 void 처리합니다. 파일럿 수치로 수용/기각 판정을 내리지 않습니다.

Long task 0은 브라우저의 ≥50 ms 기준에 해당하는 태스크가 관측되지 않았다는 뜻입니다. 48개 페이지의 기대 입력 수, 완전 reveal, page error 없음, candidate None의 whole compile 0회, candidate OnChange의 paint 후 whole compile 1회, 첫 callback 경계 및 빌드 간 gate decision/effective schema/value/error/paint field/final field 동등성 검사가 모두 통과했습니다. 원래 C의 12페이지 kind a/b 전환 oracle 증거는 inherited에 그대로 보존했고 이번 pilot은 candidate의 fresh-mount 결과를 비교합니다. 이전 oracle로 일반화된 plugin/duplicate-id 동작을 주장하지 않습니다.

## 동결 및 재현

`frozen-manifest.json`은 22,809개 파일의 소스·제품·fixture·tool·증거 해시를 고정하며 SHA-256은 `3718a44f72d2891b7035b8bfb9f4e76812948a37a2465d67c1c737ec941d4965`입니다. `dependency-manifest.json`은 번들에 사용된 의존성 해시를 기록합니다. 기준/control의 product.mjs, bundle.js 및 index.html 바이트 동일성과 모든 frozen hash를 실행 전후 다시 확인했습니다.

| 빌드 | Product SHA-256 | Browser SHA-256 |
| --- | --- | --- |
| baseline/control | `0f12294ac18277016d955fad271ebafe4b3b95a5ac3133c59acba2dfc4693ab1` | `ab5ff205b409ba80982db81d7103eca2a0a4a84a27875cabe643c6d700987e28` |
| candidate | `26e4e430959497d02c5fef84f16420f306a868458b6c479142bbbf268b931f6a` | `43cfaf69b6f9924181cd302e69e0cb53e049cc12438bde9b2176478f7032c931` |

소스 archive는 baseline-source.tar와 candidate-source.tar이며 제품 소스에는 scratch 수정이 없습니다. harness.diff에는 canonical mount helper에 추가한 guard timing과 첫 Form.onValidate sink가 있습니다. acceptanceHarness.tsx는 canonical fixture와 첫-rAF mount 경계를 재사용합니다. preregistration.json은 후보 확정 전 규칙/도구 해시를 남깁니다. 이후 coordinator가 요구한 최종 head repin 검증과 full-run guard를 추가했으며 계측 경계와 acceptance 기준은 바꾸지 않았습니다.

실제로 실행한 준비/검증 명령은 다음과 같습니다. 현재 root는 동결되어 있으므로 준비 명령으로 덮어쓰기를 시도하면 거부합니다.

```sh
python3 <scratch>/guard-compile/acceptance-prep/prepare.py --candidate f750262ea73c4d82d048a06d89d14aa7d5022936
yarn --cwd <scratch>/guard-compile/acceptance-prep/sources/candidate workspace @canard/schema-form exec rolldown -c acceptance.config.mjs
node <scratch>/guard-compile/acceptance-prep/bundle.mjs
python3 <scratch>/guard-compile/acceptance-prep/freeze.py
python3 <scratch>/guard-compile/acceptance-prep/run.py --pilot --out <scratch>/guard-compile/acceptance-prep/pilot-01
python3 <scratch>/guard-compile/acceptance-prep/verify.py --pilot-out <scratch>/guard-compile/acceptance-prep/pilot-01
```

Yarn은 별도 bare shell 호출로 실행했습니다. 정식 repository build/types/lint/test를 이 scratch 작업의 gate로 주장하지 않습니다. 저장소의 문서 수정은 다른 작업자가 소유하며 본 작업은 git archive만 읽었습니다. 환경은 React/React DOM 19.2.6, Playwright 1.58.0, esbuild 0.25.9, Rolldown 1.2.0, AJV 8.17.1이며 설치는 하지 않았습니다.

Full-run 명령은 위의 --full 명령이며 최종 final-pin.json/final-manifest.json이 생기기 전에는 거부합니다. 최종 head에서 runtime/build 입력이 달라지면 재고정도 거부합니다. Full은 빌드당 20 retained + 3 warmup으로 네 group을 실행하며 추정 시간은 quiet start 포함 약 6–7분, 네 group 모두 validity 재시도가 필요하면 약 12분입니다. 추정치는 이번 파일럿 시간에서 계산한 값이고 실제 full 실행 결과가 아닙니다.

## 검증 증거

Python 구문, Node cell/bundle 구문, acceptance 경계값 15개 및 frozen hash 검사가 통과했습니다. verification.json은 pilot raw의 36개 retained/12개 warmup, 네 group, callback timestamp와 median/p95 재계산, quiet receipt, control byte equality를 확인합니다. 원시 결과와 run-inputs는 pilot-01에 있고 full-01은 생성하지 않았습니다.
